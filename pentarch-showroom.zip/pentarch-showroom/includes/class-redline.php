<?php
/**
 * REDLINE: Laqim's tested, costed, compared section.
 * Lab Tests from the game's own physics, Kenyan ownership tools, head-to-heads, lead capture and ad slots.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PSR_Redline {

	public static $view = null;
	private static $lab = null;
	private static $ads_done = false;

	/* Kenya figures, checked November 2026. Editable in the calculators; shown as estimates. */
	const PUMP_PETROL = 226.96;
	const PUMP_DIESEL = 227.76;
	const PUMP_DATE   = '15 Nov – 14 Dec 2026, Nairobi';

	public static function init() {
		add_action( 'init', array( __CLASS__, 'rewrites' ), 11 );
		add_filter( 'query_vars', array( __CLASS__, 'qv' ) );
		add_action( 'parse_request', array( __CLASS__, 'files' ), 0 );
		add_action( 'wp', array( __CLASS__, 'resolve' ), -10 );
		add_filter( 'template_include', array( __CLASS__, 'template' ), 100 );
		add_filter( 'pre_get_document_title', array( __CLASS__, 'title' ), PHP_INT_MAX - 1 );
		add_action( 'wp_head', array( __CLASS__, 'head' ), 1 );
		add_filter( 'body_class', array( __CLASS__, 'body_class' ) );
		add_shortcode( 'psr_redline_ad', array( __CLASS__, 'sc_ad' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'rest' ) );
	}

	/* ------------------------------------------------------------ routes */

	public static function rewrites() {
		add_rewrite_rule( '^redline/?$', 'index.php?psr_rl=hub', 'top' );
		add_rewrite_rule( '^redline/(import-duty-calculator|car-loan-calculator|fuel-cost-calculator|advertise|lab)/?$', 'index.php?psr_rl=$matches[1]', 'top' );
		add_rewrite_rule( '^redline/lab/([^/]+)/?$', 'index.php?psr_rl=car&psr_rl_a=$matches[1]', 'top' );
		add_rewrite_rule( '^redline/vs/([^/]+)/?$', 'index.php?psr_rl=vs&psr_rl_a=$matches[1]', 'top' );
		if ( get_option( 'psr_rl_rules' ) !== 'r3' ) {
			flush_rewrite_rules( false );
			update_option( 'psr_rl_rules', 'r3' );
		}
	}

	public static function qv( $v ) {
		$v[] = 'psr_rl';
		$v[] = 'psr_rl_a';
		return $v;
	}

	public static function url( $p = '' ) {
		return home_url( '/redline/' . ( $p ? trailingslashit( $p ) : '' ) );
	}

	public static function resolve() {
		$k = get_query_var( 'psr_rl' );
		if ( ! $k ) {
			return;
		}
		$view = array( 'k' => $k );
		if ( 'car' === $k ) {
			$v = PSR_DB::by_slug( sanitize_title( get_query_var( 'psr_rl_a' ) ) );
			if ( ! $v || 'publish' !== $v->visibility ) {
				return self::nf();
			}
			$view['v'] = $v;
		} elseif ( 'vs' === $k ) {
			$parts = explode( '-vs-', sanitize_title( get_query_var( 'psr_rl_a' ) ) );
			$a     = count( $parts ) === 2 ? PSR_DB::by_slug( $parts[0] ) : null;
			$b     = count( $parts ) === 2 ? PSR_DB::by_slug( $parts[1] ) : null;
			if ( ! $a || ! $b || $a->id === $b->id || 'publish' !== $a->visibility || 'publish' !== $b->visibility ) {
				return self::nf();
			}
			$view['a'] = $a;
			$view['b'] = $b;
		}
		self::$view = $view;
		global $wp_query;
		$wp_query->is_404  = false;
		$wp_query->is_home = false;
		status_header( 200 );
	}

	private static function nf() {
		global $wp_query;
		$wp_query->set_404();
		status_header( 404 );
	}

	public static function template( $tpl ) {
		return self::$view ? PSR_DIR . 'templates/redline.php' : $tpl;
	}

	public static function body_class( $c ) {
		if ( self::$view ) {
			$c[] = 'psr-canvas';
			$c[] = 'psr-redline';
		}
		return $c;
	}

	/* --------------------------------------------------------------- data */

	public static function lab() {
		if ( null === self::$lab ) {
			$f         = PSR_DIR . 'data/lab.json';
			self::$lab = file_exists( $f ) ? (array) json_decode( (string) file_get_contents( $f ), true ) : array();
		}
		return self::$lab;
	}

	/** Every published car with specs and lab results, keyed by id. */
	public static function cars() {
		static $out = null;
		if ( null !== $out ) {
			return $out;
		}
		$out = array();
		$lab = self::lab();
		foreach ( PSR_DB::query() as $v ) {
			if ( 'publish' !== $v->visibility ) {
				continue;
			}
			$st = PSR_Front::stats( $v );
			$x  = PSR_Front::extra( $v->id );
			$out[ (int) $v->id ] = array(
				'v'    => $v,
				'name' => PSR_DB::title( $v ),
				'hp'   => (int) ( $st['hp'] ?? 0 ),
				'l'    => (float) ( $st['l'] ?? 0 ),
				'kg'   => (int) ( $x['weight'] ?? 0 ),
				'acc'  => (float) ( $x['accel'] ?? 0 ),
				'vmax' => (int) ( $x['vmax'] ?? 0 ),
				'tq'   => (int) ( $x['torque'] ?? 0 ),
				'img'  => wp_get_attachment_image_url( PSR_DB::cover( $v ), 'large' ),
				'th'   => wp_get_attachment_image_url( PSR_DB::cover( $v ), 'medium_large' ),
				'lab'  => $lab[ (string) $v->id ] ?? null,
			);
		}
		return $out;
	}

	public static function tracks() {
		return array(
			'circuit' => array( 'Laqim Circuit', 'Tarmac, 1.1 km' ),
			'trail'   => array( 'Rift Valley Trail', 'Dirt, mud and a river, 1.4 km' ),
			'night'   => array( 'Nairobi Night Run', 'City streets, 1.0 km' ),
		);
	}

	/** Rank of a car's lap on a track, 1 = fastest. */
	public static function rank( $id, $trk ) {
		static $cache = array();
		if ( ! isset( $cache[ $trk ] ) ) {
			$l = array();
			foreach ( self::cars() as $cid => $c ) {
				if ( ! empty( $c['lab'][ $trk ]['lap'] ) ) {
					$l[ $cid ] = $c['lab'][ $trk ]['lap'];
				}
			}
			asort( $l );
			$cache[ $trk ] = array_flip( array_keys( $l ) );
		}
		return isset( $cache[ $trk ][ $id ] ) ? $cache[ $trk ][ $id ] + 1 : 0;
	}

	public static function lap( $s ) {
		if ( ! $s ) {
			return '—';
		}
		$m = floor( $s / 60 );
		return $m ? $m . ':' . str_pad( number_format( fmod( $s, 60 ), 2 ), 5, '0', STR_PAD_LEFT ) : number_format( $s, 2 ) . ' s';
	}

	/** Combined fuel use estimate, litres per 100 km, from mass, displacement and power. */
	public static function l100( $c ) {
		$fuel = strtolower( (string) $c['v']->fuel );
		if ( false !== strpos( $fuel, 'electric' ) && false === strpos( $fuel, 'hybrid' ) ) {
			return 0;
		}
		$kg = $c['kg'] ? $c['kg'] : 1600;
		$l  = $c['l'] ? $c['l'] : 2.5;
		$e  = 0.0035 * $kg + 1.1 * $l + 0.004 * $c['hp'];
		if ( false !== strpos( $fuel, 'hybrid' ) ) {
			$e *= 0.68;
		}
		if ( false !== strpos( $fuel, 'diesel' ) ) {
			$e *= 0.82;
		}
		return round( max( 4.2, $e ), 1 );
	}

	/** Nearest rivals by Laqim Circuit lap, falling back to power. */
	public static function rivals( $id, $n = 3 ) {
		$cars = self::cars();
		$me   = $cars[ $id ];
		$key  = function ( $c ) {
			return ! empty( $c['lab']['circuit']['lap'] ) ? $c['lab']['circuit']['lap'] : 200 - $c['hp'] / 10;
		};
		$k0 = $key( $me );
		$d  = array();
		foreach ( $cars as $cid => $c ) {
			if ( $cid !== $id ) {
				$d[ $cid ] = abs( $key( $c ) - $k0 ) + ( strtolower( (string) $c['v']->body ) === strtolower( (string) $me['v']->body ) ? 0 : 1.5 );
			}
		}
		asort( $d );
		$out = array();
		$names = array( $me['name'] => 1 );
		foreach ( array_keys( $d ) as $cid ) {
			if ( isset( $names[ $cars[ $cid ]['name'] ] ) ) {
				continue;
			}
			$names[ $cars[ $cid ]['name'] ] = 1;
			$out[] = $cid;
			if ( count( $out ) >= $n ) {
				break;
			}
		}
		return $out;
	}

	public static function vs_url( $a, $b ) {
		$s = array( $a->slug, $b->slug );
		sort( $s );
		return self::url( 'vs/' . $s[0] . '-vs-' . $s[1] );
	}

	/* ------------------------------------------------------- head and SEO */

	private static function meta_for() {
		$v = self::$view;
		$t = 'REDLINE | Laqim Autoworld';
		$d = 'Tested, costed, compared. Lap times from the Laqim physics lab, Kenyan import duty and running costs, and head-to-heads for every car in the collection.';
		$i = '';
		switch ( $v['k'] ) {
			case 'import-duty-calculator':
				$t = 'Kenya Car Import Duty Calculator 2026 (KRA) | REDLINE';
				$d = 'Estimate KRA import duty, excise, VAT, IDF and RDL on a car imported into Kenya, plus port, transport and registration costs. Updated for 2026.';
				break;
			case 'car-loan-calculator':
				$t = 'Car Loan Calculator Kenya: Monthly Repayments | REDLINE';
				$d = 'Work out monthly repayments, total interest and the real cost of financing a car in Kenya. Set the price, deposit, rate and term.';
				break;
			case 'fuel-cost-calculator':
				$t = 'Fuel Cost Calculator Kenya (Current Pump Prices) | REDLINE';
				$d = 'What a car really costs to run in Kenya: fuel per month and per year at current Nairobi pump prices, for any car in the collection or your own.';
				break;
			case 'lab':
				$t = 'Lab Tests: Lap Times for ' . count( self::cars() ) . ' Cars | REDLINE';
				$d = 'Every car in the collection, run through the same physics on the same three tracks: Laqim Circuit, Rift Valley Trail and Nairobi Night Run. Sort by lap, sprint or top speed.';
				break;
			case 'advertise':
				$t = 'Advertise on REDLINE | Laqim Autoworld';
				$d = 'Put your brand in front of Kenya\'s car people: on REDLINE pages, on track-side billboards inside Laqim Racing and in the weekly Dispatch.';
				break;
			case 'car':
				$c = self::cars()[ (int) $v['v']->id ];
				$t = $c['name'] . ' Lab Test: Lap Times and Running Costs | REDLINE';
				$lp = ! empty( $c['lab']['circuit']['lap'] ) ? ' Laqim Circuit lap ' . self::lap( $c['lab']['circuit']['lap'] ) . '.' : '';
				$d = 'The ' . $c['name'] . ' in the Laqim lab:' . $lp . ' Lap times on three tracks, sprint times, top speed and what it costs to run in Kenya.';
				$i = $c['img'];
				break;
			case 'vs':
				$ca = self::cars()[ (int) $v['a']->id ];
				$cb = self::cars()[ (int) $v['b']->id ];
				$t  = $ca['name'] . ' vs ' . $cb['name'] . ': Lab Test Head-to-Head | REDLINE';
				$d  = $ca['name'] . ' or ' . $cb['name'] . '? Lap times on three tracks, sprints, top speed, power-to-weight and running costs, side by side.';
				$i  = $ca['img'];
				break;
		}
		return array( $t, $d, $i );
	}

	public static function title( $t ) {
		return self::$view ? self::meta_for()[0] : $t;
	}

	public static function canonical() {
		$v = self::$view;
		switch ( $v['k'] ) {
			case 'hub':
				return self::url();
			case 'car':
				return self::url( 'lab/' . $v['v']->slug );
			case 'vs':
				return self::vs_url( $v['a'], $v['b'] );
			default:
				return self::url( $v['k'] );
		}
	}

	public static function head() {
		if ( ! self::$view ) {
			return;
		}
		list( $t, $d, $i ) = self::meta_for();
		echo '<meta name="description" content="' . esc_attr( $d ) . "\">\n";
		echo '<link rel="canonical" href="' . esc_url( self::canonical() ) . "\">\n";
		echo '<meta name="robots" content="index, follow, max-image-preview:large">' . "\n";
		echo '<meta property="og:type" content="article"><meta property="og:title" content="' . esc_attr( $t ) . '"><meta property="og:description" content="' . esc_attr( $d ) . '"><meta property="og:url" content="' . esc_url( self::canonical() ) . '">';
		if ( $i ) {
			echo '<meta property="og:image" content="' . esc_url( $i ) . '"><meta name="twitter:card" content="summary_large_image">';
		}
		echo "\n";
		$client = trim( (string) psr_settings( 'adsense_client' ) );
		if ( $client ) {
			echo '<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=' . esc_attr( $client ) . '" crossorigin="anonymous"></script>' . "\n";
		}
	}

	/* ------------------------------------------- sitemap, ads.txt, files */

	public static function files() {
		$path = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '', PHP_URL_PATH ), '/' );
		if ( 'ads.txt' === $path ) {
			$client = trim( (string) psr_settings( 'adsense_client' ) );
			if ( ! $client ) {
				return;
			}
			header( 'Content-Type: text/plain; charset=UTF-8' );
			echo 'google.com, ' . esc_html( str_replace( 'ca-', '', $client ) ) . ", DIRECT, f08c47fec0942fa0\n";
			exit;
		}
		if ( 'redline-sitemap.xml' !== $path ) {
			return;
		}
		header( 'Content-Type: application/xml; charset=UTF-8' );
		header( 'X-Robots-Tag: noindex' );
		$mod = gmdate( 'Y-m-d\TH:i:s+00:00', (int) get_option( 'psr_data_ver', time() ) );
		$u   = array( self::url(), self::url( 'import-duty-calculator' ), self::url( 'car-loan-calculator' ), self::url( 'fuel-cost-calculator' ), self::url( 'lab' ), self::url( 'advertise' ) );
		$cars = self::cars();
		$seen = array();
		foreach ( $cars as $id => $c ) {
			$u[] = self::url( 'lab/' . $c['v']->slug );
			foreach ( self::rivals( $id, 3 ) as $r ) {
				$k = min( $id, $r ) . '-' . max( $id, $r );
				if ( isset( $seen[ $k ] ) ) {
					continue;
				}
				$seen[ $k ] = 1;
				$u[]        = self::vs_url( $c['v'], $cars[ $r ]['v'] );
			}
		}
		echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
		foreach ( $u as $x ) {
			echo '<url><loc>' . esc_url( $x ) . '</loc><lastmod>' . esc_html( $mod ) . "</lastmod></url>\n";
		}
		echo '</urlset>';
		exit;
	}

	/* ------------------------------------------------------- newsletter */

	public static function rest() {
		register_rest_route(
			'psr/v1',
			'/subscribe',
			array(
				'methods'             => 'POST',
				'permission_callback' => '__return_true',
				'callback'            => array( __CLASS__, 'subscribe' ),
			)
		);
	}

	public static function subscribe( $req ) {
		$p = $req->get_json_params();
		$p = is_array( $p ) ? $p : $req->get_params();
		if ( ! empty( $p['website'] ) ) {
			return array( 'ok' => true );
		}
		$email = sanitize_email( (string) ( $p['email'] ?? '' ) );
		if ( ! is_email( $email ) ) {
			return new WP_Error( 'psr_email', 'Please enter a valid email address.', array( 'status' => 400 ) );
		}
		$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		$key = 'psr_sub_' . md5( $ip );
		$hit = (int) get_transient( $key );
		if ( $hit >= 5 ) {
			return array( 'ok' => true, 'message' => 'You are on the list.' );
		}
		set_transient( $key, $hit + 1, HOUR_IN_SECONDS );
		$list = (array) get_option( 'psr_dispatch', array() );
		if ( ! isset( $list[ strtolower( $email ) ] ) ) {
			$list[ strtolower( $email ) ] = current_time( 'mysql' );
			update_option( 'psr_dispatch', $list, false );
			PSR_DB::add_enquiry( array( 'kind' => 'newsletter', 'name' => 'Dispatch subscriber', 'email' => $email, 'message' => 'Subscribed to the REDLINE Dispatch.', 'source_url' => $req->get_header( 'referer' ) ) );
		}
		return array( 'ok' => true, 'message' => 'You are on the list. The first Dispatch lands soon.' );
	}

	public static function dispatch_box() {
		return '<section class="r8-news"><div><small>The REDLINE Dispatch</small><h2>New lab tests, duty changes and fuel price moves. Weekly, free.</h2></div><form class="r8-news__f" data-r8-news novalidate><input type="email" name="email" required placeholder="Your email" aria-label="Your email" autocomplete="email"><input type="text" name="website" tabindex="-1" autocomplete="off" class="psr-hp" aria-hidden="true"><button type="submit" class="r8-btn r8-btn--red">Subscribe</button><p data-note role="status" aria-live="polite"></p></form></section>';
	}

	/* ------------------------------------------------------------- ads */

	/** An ad slot: AdSense when a publisher ID is set, otherwise a house ad for sponsors. */
	public static function ad( $pos = 'in' ) {
		$client = trim( (string) psr_settings( 'adsense_client' ) );
		$slot   = trim( (string) psr_settings( 'adsense_slot' ) );
		if ( $client && $slot ) {
			return '<aside class="r8-ad r8-ad--' . esc_attr( $pos ) . '" aria-label="Advertisement"><small>Advertisement</small><ins class="adsbygoogle" style="display:block" data-ad-client="' . esc_attr( $client ) . '" data-ad-slot="' . esc_attr( $slot ) . '" data-ad-format="auto" data-full-width-responsive="true"></ins><script>(adsbygoogle=window.adsbygoogle||[]).push({});</script></aside>';
		}
		return '<aside class="r8-ad r8-ad--house r8-ad--' . esc_attr( $pos ) . '"><a href="' . esc_url( self::url( 'advertise' ) ) . '"><small>Sponsor slot</small><b>Your brand here.</b><span>Reach Kenya\'s car people on REDLINE and inside Laqim Racing.</span><i>See packages →</i></a></aside>';
	}

	public static function sc_ad() {
		return self::ad( 'in' );
	}

	/** Lead capture: stored with the site's other requests. */
	public static function lead( $topic, $title, $blurb, $vehicle_id = 0 ) {
		ob_start();
		?>
		<section class="r8-quote" id="quote">
			<div class="r8-quote__t"><small>Free, no obligation</small><h2><?php echo esc_html( $title ); ?></h2><p><?php echo esc_html( $blurb ); ?></p></div>
			<form class="psr-form r8-form" data-psr-form data-r8-lead="<?php echo esc_attr( $topic ); ?>" novalidate>
				<input type="hidden" name="vehicle_id" value="<?php echo (int) $vehicle_id; ?>">
				<input type="hidden" name="kind" value="lead">
				<div class="psr-hp" aria-hidden="true"><label>Leave empty<input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>
				<div class="psr-form__row">
					<label class="psr-field"><input type="text" name="name" required autocomplete="name" placeholder=" "><span>Full name</span></label>
					<label class="psr-field"><input type="tel" name="phone" required autocomplete="tel" placeholder=" "><span>Phone</span></label>
				</div>
				<div class="psr-form__row">
					<label class="psr-field"><input type="email" name="email" autocomplete="email" placeholder=" "><span>Email (optional)</span></label>
					<label class="psr-field"><input type="text" name="preferred" placeholder=" "><span>Car you have in mind</span></label>
				</div>
				<textarea name="message" hidden data-r8-summary></textarea>
				<div class="psr-form__foot">
					<button type="submit" class="psr-btn psr-btn--solid"><span>Get my quotes</span><?php echo PSR_Front::icon( 'arrow' ); // phpcs:ignore ?></button>
					<p class="psr-form__note" data-note role="status" aria-live="polite">We pass your request to vetted partners only. No spam.</p>
				</div>
			</form>
		</section>
		<?php
		return ob_get_clean();
	}
}
