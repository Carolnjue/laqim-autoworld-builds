<?php
/**
 * Admin screens: vehicles, viewing requests, settings, setup.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class PSR_Admin {

	const CAP = 'edit_pages';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_post_psr_save', array( __CLASS__, 'save' ) );
		add_action( 'admin_post_psr_delete', array( __CLASS__, 'delete' ) );
		add_action( 'admin_post_psr_toggle', array( __CLASS__, 'toggle' ) );
		add_action( 'admin_post_psr_settings', array( __CLASS__, 'save_settings' ) );
		add_action( 'admin_post_psr_enquiry', array( __CLASS__, 'enquiry_action' ) );
		add_action( 'admin_post_psr_export', array( __CLASS__, 'export' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'rest' ) );
		add_action( 'admin_bar_menu', array( __CLASS__, 'admin_bar' ), 91 );
	}

	public static function menu() {
		$new   = PSR_DB::count_new_enquiries();
		$badge = $new ? ' <span class="awaiting-mod">' . (int) $new . '</span>' : '';
		add_menu_page( 'Showroom', 'Showroom' . $badge, self::CAP, 'psr', array( __CLASS__, 'page_list' ), 'dashicons-car', 20 );
		add_submenu_page( 'psr', 'Vehicles', 'Vehicles', self::CAP, 'psr', array( __CLASS__, 'page_list' ) );
		add_submenu_page( 'psr', 'Add vehicle', 'Add vehicle', self::CAP, 'psr-edit', array( __CLASS__, 'page_edit' ) );
		add_submenu_page( 'psr', 'Requests', 'Requests' . $badge, self::CAP, 'psr-enquiries', array( __CLASS__, 'page_enquiries' ) );
		add_submenu_page( 'psr', 'Settings', 'Settings', 'manage_options', 'psr-settings', array( __CLASS__, 'page_settings' ) );
		add_submenu_page( 'psr', 'Setup & import', 'Setup & import', 'manage_options', 'psr-setup', array( __CLASS__, 'page_setup' ) );
	}

	public static function assets( $hook ) {
		if ( false === strpos( (string) $hook, 'psr' ) ) {
			return;
		}
		wp_enqueue_media();
		wp_enqueue_script( 'jquery-ui-sortable' );
		wp_enqueue_style( 'psr-admin', PSR_URL . 'assets/admin.css', array(), PSR_VERSION );
		wp_enqueue_script( 'psr-admin', PSR_URL . 'assets/admin.js', array( 'jquery', 'jquery-ui-sortable' ), PSR_VERSION, true );
		wp_add_inline_script(
			'psr-admin',
			'window.PSRA=' . wp_json_encode(
				array(
					'rest'  => esc_url_raw( rest_url( 'psr/v1/admin/' ) ),
					'nonce' => wp_create_nonce( 'wp_rest' ),
				)
			) . ';',
			'before'
		);
	}

	public static function admin_bar( $bar ) {
		if ( is_admin() || ! current_user_can( self::CAP ) || ! PSR_Front::$vehicle ) {
			return;
		}
		$bar->add_node(
			array(
				'id'    => 'psr-edit',
				'title' => '<span class="ab-icon dashicons dashicons-car" style="margin-top:2px"></span>Edit vehicle',
				'href'  => admin_url( 'admin.php?page=psr-edit&id=' . (int) PSR_Front::$vehicle->id ),
			)
		);
	}

	private static function url( $page, $args = array() ) {
		return add_query_arg( $args, admin_url( 'admin.php?page=' . $page ) );
	}

	private static function notice() {
		if ( empty( $_GET['psr_msg'] ) ) { // phpcs:ignore
			return;
		}
		echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['psr_msg'] ) ) ) . '</p></div>'; // phpcs:ignore
	}

	/* ------------------------------------------------------------ list */

	public static function page_list() {
		$status = isset( $_GET['status'] ) ? sanitize_key( $_GET['status'] ) : ''; // phpcs:ignore
		$vs     = PSR_DB::query( array( 'all' => true, 'status' => $status ) );
		echo '<div class="wrap psr-wrap"><h1 class="wp-heading-inline">Vehicles</h1> <a class="page-title-action" href="' . esc_url( self::url( 'psr-edit' ) ) . '">Add vehicle</a>';
		echo ' <a class="page-title-action" href="' . esc_url( PSR_Front::collection_url() ) . '" target="_blank">View collection</a><hr class="wp-header-end">';
		self::notice();
		echo '<ul class="subsubsub"><li><a href="' . esc_url( self::url( 'psr' ) ) . '"' . ( $status ? '' : ' class="current"' ) . '>All</a> | </li>';
		$i = 0;
		foreach ( PSR_DB::STATUSES as $k => $l ) {
			echo '<li><a href="' . esc_url( self::url( 'psr', array( 'status' => $k ) ) ) . '"' . ( $status === $k ? ' class="current"' : '' ) . '>' . esc_html( $l ) . '</a>' . ( ++$i < count( PSR_DB::STATUSES ) ? ' | ' : '' ) . '</li>';
		}
		echo '</ul><br class="clear">';
		if ( ! $vs ) {
			echo '<div class="psr-empty-admin"><p>No vehicles yet.</p><p><a class="button button-primary" href="' . esc_url( self::url( 'psr-setup' ) ) . '">Import from Motors</a> <a class="button" href="' . esc_url( self::url( 'psr-edit' ) ) . '">Add one by hand</a></p></div></div>';
			return;
		}
		echo '<table class="widefat striped psr-table"><thead><tr><th style="width:96px"></th><th>Vehicle</th><th>Status</th><th>Year</th><th>Photos</th><th>Featured</th><th>In hero</th><th>Views</th><th>Order</th><th></th></tr></thead><tbody>';
		foreach ( $vs as $v ) {
			$edit = self::url( 'psr-edit', array( 'id' => $v->id ) );
			$tog  = function ( $f ) use ( $v ) {
				$u = wp_nonce_url( admin_url( 'admin-post.php?action=psr_toggle&id=' . $v->id . '&f=' . $f ), 'psr_toggle' );
				return '<a class="psr-tog' . ( $v->$f ? ' on' : '' ) . '" href="' . esc_url( $u ) . '" title="Toggle"><span class="dashicons dashicons-star-' . ( $v->$f ? 'filled' : 'empty' ) . '"></span></a>';
			};
			echo '<tr><td>' . wp_get_attachment_image( PSR_DB::cover( $v ), array( 88, 60 ), false, array( 'class' => 'psr-thumb' ) ) . '</td>';
			echo '<td><strong><a href="' . esc_url( $edit ) . '">' . esc_html( PSR_DB::title( $v ) ) . '</a></strong>' . ( 'draft' === $v->visibility ? ' — <em>Hidden</em>' : '' ) . '<br><span class="description">' . esc_html( $v->variant ) . '</span></td>';
			echo '<td><span class="psr-pill psr-pill--' . esc_attr( $v->status ) . '">' . esc_html( PSR_Front::status_label( $v->status ) ) . '</span></td>';
			echo '<td>' . ( $v->year ? (int) $v->year : '—' ) . '</td><td>' . count( PSR_DB::media( $v->id ) ) . '</td><td>' . $tog( 'featured' ) . '</td><td>' . $tog( 'in_hero' ) . '</td><td>' . (int) $v->views . '</td><td>' . (int) $v->sort_order . '</td>'; // phpcs:ignore
			echo '<td class="psr-actions"><a href="' . esc_url( $edit ) . '">Edit</a> · <a href="' . esc_url( PSR_Front::url( $v ) ) . '" target="_blank">View</a> · <a class="psr-del" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=psr_delete&id=' . $v->id ), 'psr_delete' ) ) . '">Delete</a></td></tr>';
		}
		echo '</tbody></table></div>';
	}

	public static function toggle() {
		check_admin_referer( 'psr_toggle' );
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( 'Not allowed' );
		}
		$id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
		$f  = isset( $_GET['f'] ) && in_array( $_GET['f'], array( 'featured', 'in_hero' ), true ) ? sanitize_key( $_GET['f'] ) : '';
		$v  = PSR_DB::get( $id );
		if ( $v && $f ) {
			PSR_DB::save_vehicle( array( $f => $v->$f ? 0 : 1 ), $id );
		}
		wp_safe_redirect( wp_get_referer() ? wp_get_referer() : self::url( 'psr' ) );
		exit;
	}

	public static function delete() {
		check_admin_referer( 'psr_delete' );
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( 'Not allowed' );
		}
		PSR_DB::delete_vehicle( isset( $_GET['id'] ) ? (int) $_GET['id'] : 0 );
		wp_safe_redirect( self::url( 'psr', array( 'psr_msg' => 'Vehicle deleted. Its photos stay in the Media Library.' ) ) );
		exit;
	}

	/* ------------------------------------------------------------ edit */

	public static function page_edit() {
		$id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0; // phpcs:ignore
		$v  = $id ? PSR_DB::get( $id ) : null;
		$d  = $v ? (array) $v : array();
		$g  = function ( $k, $def = '' ) use ( $d ) {
			return isset( $d[ $k ] ) && null !== $d[ $k ] ? $d[ $k ] : $def;
		};
		$media = $v ? PSR_DB::media( $v->id ) : array();
		echo '<div class="wrap psr-wrap"><h1>' . ( $v ? 'Edit: ' . esc_html( PSR_DB::title( $v ) ) : 'Add vehicle' ) . '</h1>';
		self::notice();
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="psr-edit">';
		wp_nonce_field( 'psr_save' );
		echo '<input type="hidden" name="action" value="psr_save"><input type="hidden" name="id" value="' . (int) $id . '">';
		echo '<div class="psr-cols"><div class="psr-main">';

		echo '<div class="psr-box"><h2>Vehicle</h2><div class="psr-fields">';
		self::field( 'make', 'Marque', $g( 'make' ), 'e.g. Mercedes-AMG', true );
		self::field( 'model', 'Model', $g( 'model' ), 'e.g. G 63', true );
		self::field( 'variant', 'Variant / edition', $g( 'variant' ), 'e.g. AMG Line, W463' );
		self::field( 'year', 'Model year', $g( 'year' ) ? $g( 'year' ) : '', '2024', false, 'number' );
		self::field( 'body', 'Body', $g( 'body' ), 'SUV, Sedan, Coupé…', false, 'text', 'psr-bodies' );
		self::field( 'condition_label', 'Condition', $g( 'condition_label' ), 'New, Unregistered, Foreign used…', false, 'text', 'psr-conds' );
		self::field( 'tagline', 'One-line description (shown in the hero and on the page)', $g( 'tagline' ), '', false, 'text', '', 'wide' );
		echo '</div><datalist id="psr-bodies"><option>SUV<option>Sedan<option>Coupé<option>Convertible<option>Pick-up<option>Estate</datalist><datalist id="psr-conds"><option>New<option>Unregistered<option>Foreign used<option>Locally used<option>Sourced to order</datalist></div>';

		echo '<div class="psr-box"><h2>Photos</h2><p class="description">Drag to reorder. The first photo is the cover, unless you choose a different hero photo below.</p>';
		echo '<ul class="psr-gallery" data-psr-gallery>';
		foreach ( $media as $m ) {
			echo '<li data-id="' . (int) $m->attachment_id . '">' . wp_get_attachment_image( $m->attachment_id, 'thumbnail' ) . '<input type="hidden" name="gallery[]" value="' . (int) $m->attachment_id . '"><input type="hidden" name="gallery_credit[]" value="' . esc_attr( $m->credit ) . '"><button type="button" class="psr-x" aria-label="Remove">×</button></li>';
		}
		echo '</ul><p><button type="button" class="button button-secondary" data-psr-add>Add photos from the Media Library</button></p>';
		echo '<p><label>Hero photo (optional, a wide landscape shot works best)<br><span class="psr-hero-pick" data-psr-heropick>' . ( $g( 'hero_attachment' ) ? wp_get_attachment_image( (int) $g( 'hero_attachment' ), 'thumbnail' ) : '' ) . '</span><input type="hidden" name="hero_attachment" value="' . (int) $g( 'hero_attachment', 0 ) . '"> <button type="button" class="button" data-psr-hero>Choose</button> <button type="button" class="button-link" data-psr-heroclear>Use first photo</button></label></p></div>';

		echo '<div class="psr-box"><h2>Specification</h2><div class="psr-fields">';
		self::field( 'engine', 'Engine', $g( 'engine' ), '4.0L twin-turbo V8' );
		self::field( 'power', 'Power', $g( 'power' ), '585 hp' );
		self::field( 'transmission', 'Transmission', $g( 'transmission' ) );
		self::field( 'drivetrain', 'Drive', $g( 'drivetrain' ) );
		self::field( 'fuel', 'Fuel', $g( 'fuel' ) );
		self::field( 'consumption', 'Consumption', $g( 'consumption' ), '12–15 L/100 km' );
		self::field( 'mileage_km', 'Mileage (km, 0 = delivery mileage)', null === $g( 'mileage_km', null ) ? '' : $g( 'mileage_km' ), '', false, 'number' );
		self::field( 'seats', 'Seats', $g( 'seats' ) );
		self::field( 'exterior_color', 'Exterior colour', $g( 'exterior_color' ) );
		self::field( 'interior_color', 'Interior', $g( 'interior_color' ) );
		self::field( 'location', 'Photographed at', $g( 'location' ), 'Nairobi' );
		echo '</div></div>';

		echo '<div class="psr-box"><h2>Story</h2>';
		echo '<p><label><strong>Curator&rsquo;s note</strong></label></p>';
		wp_editor( (string) $g( 'summary' ), 'psr_summary', array( 'textarea_name' => 'summary', 'textarea_rows' => 6, 'media_buttons' => false, 'teeny' => true ) );
		echo '<div class="psr-fields psr-fields--2"><label><strong>Highlights</strong> (one per line)<textarea name="highlights" rows="6">' . esc_textarea( $g( 'highlights' ) ) . '</textarea></label>';
		echo '<label><strong>Equipment</strong> (one per line)<textarea name="features" rows="6">' . esc_textarea( $g( 'features' ) ) . '</textarea></label></div>';
		echo '<label><strong>Photo credits</strong> (one per line, shown under the gallery)<textarea name="credits" rows="2" class="large-text">' . esc_textarea( $g( 'credits' ) ) . '</textarea></label></div>';

		echo '</div><div class="psr-side">';
		echo '<div class="psr-box"><h2>Publish</h2>';
		echo '<p><label>Status<br><select name="status">';
		foreach ( PSR_DB::STATUSES as $k => $l ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $g( 'status', 'gallery' ), $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select></label></p><p class="description">Laqim Original: photographed by Laqim. Curated Icon: featured with credited photographs. Coming Up: feature in preparation. Archive: past features.</p>';
		echo '<p><label>Visibility<br><select name="visibility"><option value="publish"' . selected( $g( 'visibility', 'publish' ), 'publish', false ) . '>Shown on the site</option><option value="draft"' . selected( $g( 'visibility' ), 'draft', false ) . '>Hidden</option></select></label></p>';
		echo '<p><label><input type="checkbox" name="featured" value="1"' . checked( (int) $g( 'featured', 0 ), 1, false ) . '> Featured</label><br><label><input type="checkbox" name="in_hero" value="1"' . checked( (int) $g( 'in_hero', 0 ), 1, false ) . '> Show in the home hero</label></p>';
		echo '<p><label>Display order (lower first)<br><input type="number" name="sort_order" value="' . (int) $g( 'sort_order', 0 ) . '" class="small-text"></label></p>';
		echo '<p><label>Web address<br><code>/' . esc_html( PSR_Front::base() ) . '/</code><input type="text" name="slug" value="' . esc_attr( $g( 'slug' ) ) . '" placeholder="made from the name"></label></p>';
		submit_button( $v ? 'Save changes' : 'Add vehicle', 'primary large', 'submit', false );
		if ( $v ) {
			echo ' <a class="button" href="' . esc_url( PSR_Front::url( $v ) ) . '" target="_blank">View</a>';
		}
		echo '</div>';
		echo '<div class="psr-box"><h2>Reference value (private)</h2><p><input type="text" name="price" value="' . esc_attr( null === $g( 'price', null ) ? '' : number_format( (float) $g( 'price' ), 0, '.', ',' ) ) . '" class="widefat" placeholder="' . esc_attr( psr_settings( 'currency' ) ) . '"></p><p class="description">For your records only. Laqim never shows prices.</p></div>';
		if ( $v ) {
			echo '<div class="psr-box"><h2>Activity</h2><p>' . (int) $v->views . ' page views<br>Added ' . esc_html( mysql2date( 'j M Y', $v->created_at ) ) . '<br>Source: ' . esc_html( $v->source_ref ? $v->source_ref : 'manual' ) . '</p></div>';
		}
		echo '</div></div></form></div>';
	}

	private static function field( $name, $label, $val, $ph = '', $req = false, $type = 'text', $list = '', $class = '' ) {
		echo '<label class="psr-f ' . esc_attr( $class ) . '"><span>' . esc_html( $label ) . '</span><input type="' . esc_attr( $type ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( (string) $val ) . '" placeholder="' . esc_attr( $ph ) . '"' . ( $req ? ' required' : '' ) . ( $list ? ' list="' . esc_attr( $list ) . '"' : '' ) . '></label>';
	}

	public static function save() {
		check_admin_referer( 'psr_save' );
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( 'Not allowed' );
		}
		$p    = wp_unslash( $_POST ); // phpcs:ignore
		$id   = (int) ( $p['id'] ?? 0 );
		$data = array();
		foreach ( array_keys( PSR_DB::FIELDS ) as $f ) {
			if ( 'source_ref' === $f ) {
				continue;
			}
			if ( isset( $p[ $f ] ) ) {
				$data[ $f ] = $p[ $f ];
			}
		}
		$data['featured'] = ! empty( $p['featured'] );
		$data['in_hero']  = ! empty( $p['in_hero'] );
		if ( '' === trim( (string) ( $p['slug'] ?? '' ) ) ) {
			unset( $data['slug'] );
			if ( $id ) {
				$data['slug'] = PSR_DB::get( $id )->slug;
			}
		}
		$gal     = array();
		$credits = (array) ( $p['gallery_credit'] ?? array() );
		foreach ( (array) ( $p['gallery'] ?? array() ) as $i => $aid ) {
			$gal[] = array( 'attachment_id' => (int) $aid, 'credit' => $credits[ $i ] ?? '' );
		}
		$data['gallery'] = $gal;
		$new             = PSR_DB::save_vehicle( $data, $id );
		wp_safe_redirect( self::url( 'psr-edit', array( 'id' => $new, 'psr_msg' => 'Saved. The change is live on the site.' ) ) );
		exit;
	}

	/* ------------------------------------------------------- enquiries */

	public static function page_enquiries() {
		$status = isset( $_GET['status'] ) ? sanitize_key( $_GET['status'] ) : ''; // phpcs:ignore
		$rows   = PSR_DB::enquiries( $status );
		$labels = array( 'new' => 'New', 'contacted' => 'Replied', 'viewing' => 'Shoot planned', 'closed' => 'Closed' );
		echo '<div class="wrap psr-wrap"><h1 class="wp-heading-inline">Requests</h1> <a class="page-title-action" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=psr_export' ), 'psr_export' ) ) . '">Download CSV</a><hr class="wp-header-end">';
		self::notice();
		echo '<ul class="subsubsub"><li><a href="' . esc_url( self::url( 'psr-enquiries' ) ) . '"' . ( $status ? '' : ' class="current"' ) . '>All</a></li>';
		foreach ( $labels as $k => $l ) {
			echo '<li> | <a href="' . esc_url( self::url( 'psr-enquiries', array( 'status' => $k ) ) ) . '"' . ( $status === $k ? ' class="current"' : '' ) . '>' . esc_html( $l ) . '</a></li>';
		}
		echo '</ul><br class="clear">';
		if ( ! $rows ) {
			echo '<p>No requests yet. Messages and car submissions from the site appear here, and are also emailed to ' . esc_html( psr_settings( 'email' ) ) . '.</p></div>';
			return;
		}
		echo '<table class="widefat striped psr-table"><thead><tr><th>Received</th><th>Type</th><th>Name</th><th>Contact</th><th>Vehicle</th><th>Details</th><th>Status</th></tr></thead><tbody>';
		foreach ( $rows as $r ) {
			$wa = preg_replace( '/\D/', '', $r->phone );
			echo '<tr><td>' . esc_html( mysql2date( 'j M Y, H:i', $r->created_at ) ) . '</td><td>' . esc_html( ucfirst( $r->kind ) ) . '</td><td><strong>' . esc_html( $r->name ) . '</strong></td>';
			echo '<td><a href="tel:' . esc_attr( $r->phone ) . '">' . esc_html( $r->phone ) . '</a>' . ( $wa ? ' · <a href="https://wa.me/' . esc_attr( $wa ) . '" target="_blank">WhatsApp</a>' : '' ) . ( $r->email ? '<br><a href="mailto:' . esc_attr( $r->email ) . '">' . esc_html( $r->email ) . '</a>' : '' ) . '</td>';
			echo '<td>' . esc_html( $r->vehicle ? $r->vehicle : '—' ) . '</td><td>' . ( $r->preferred ? '<em>' . esc_html( $r->preferred ) . '</em><br>' : '' ) . nl2br( esc_html( $r->message ) ) . '</td>';
			echo '<td><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			wp_nonce_field( 'psr_enquiry' );
			echo '<input type="hidden" name="action" value="psr_enquiry"><input type="hidden" name="id" value="' . (int) $r->id . '"><select name="status" onchange="this.form.submit()">';
			foreach ( $labels as $k => $l ) {
				echo '<option value="' . esc_attr( $k ) . '"' . selected( $r->status, $k, false ) . '>' . esc_html( $l ) . '</option>';
			}
			echo '<option value="__delete">Delete…</option></select></form></td></tr>';
		}
		echo '</tbody></table></div>';
	}

	public static function enquiry_action() {
		check_admin_referer( 'psr_enquiry' );
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( 'Not allowed' );
		}
		global $wpdb;
		$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		$st = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : '';
		if ( '__delete' === sanitize_text_field( wp_unslash( $_POST['status'] ?? '' ) ) ) {
			$wpdb->delete( PSR_DB::t( 'enquiries' ), array( 'id' => $id ) );
		} elseif ( in_array( $st, array( 'new', 'contacted', 'viewing', 'closed' ), true ) ) {
			$wpdb->update( PSR_DB::t( 'enquiries' ), array( 'status' => $st ), array( 'id' => $id ) );
		}
		wp_safe_redirect( wp_get_referer() ? wp_get_referer() : self::url( 'psr-enquiries' ) );
		exit;
	}

	public static function export() {
		check_admin_referer( 'psr_export' );
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( 'Not allowed' );
		}
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=showroom-requests-' . gmdate( 'Y-m-d' ) . '.csv' );
		$out = fopen( 'php://output', 'w' ); // phpcs:ignore
		fputcsv( $out, array( 'Received', 'Type', 'Status', 'Name', 'Phone', 'Email', 'Vehicle', 'Preferred', 'Message' ) );
		foreach ( PSR_DB::enquiries() as $r ) {
			fputcsv( $out, array( $r->created_at, $r->kind, $r->status, $r->name, $r->phone, $r->email, $r->vehicle, $r->preferred, $r->message ) );
		}
		fclose( $out ); // phpcs:ignore
		exit;
	}

	/* -------------------------------------------------------- settings */

	public static function page_settings() {
		$s = psr_settings();
		echo '<div class="wrap psr-wrap"><h1>Showroom settings</h1>';
		self::notice();
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'psr_settings' );
		echo '<input type="hidden" name="action" value="psr_settings"><table class="form-table">';
		$row = function ( $k, $label, $help = '', $type = 'text' ) use ( $s ) {
			echo '<tr><th><label for="psr_' . esc_attr( $k ) . '">' . esc_html( $label ) . '</label></th><td>';
			if ( 'check' === $type ) {
				echo '<label><input type="checkbox" id="psr_' . esc_attr( $k ) . '" name="s[' . esc_attr( $k ) . ']" value="1"' . checked( (int) $s[ $k ], 1, false ) . '> ' . esc_html( $help ) . '</label>';
			} else {
				echo '<input type="' . esc_attr( $type ) . '" class="regular-text" id="psr_' . esc_attr( $k ) . '" name="s[' . esc_attr( $k ) . ']" value="' . esc_attr( $s[ $k ] ) . '">' . ( $help ? '<p class="description">' . esc_html( $help ) . '</p>' : '' );
			}
			echo '</td></tr>';
		};
		$row( 'brand', 'Name on the site' );
		$row( 'phone', 'Phone', 'Shown on vehicle pages.' );
		$row( 'whatsapp', 'WhatsApp number', 'International format, e.g. 254718933034.' );
		$row( 'email', 'Send requests to', 'Messages and car submissions are emailed here and kept under Showroom › Requests.' );
		$row( 'address', 'Address' );
						$row( 'canvas', 'Full-page design', 'Render pages with the Showroom canvas (header and footer from Live Edit)', 'check' );
		$row( 'strip_theme', 'Theme styles', 'Do not load the old theme and page-builder styles on canvas pages', 'check' );
		$row( 'hero_slices', 'Hero 3D slices', 'How many pillars turn on a slide change (3–12).', 'number' );
		$row( 'hero_seconds', 'Hero seconds per car', '', 'number' );
		echo '</table>';
		submit_button( 'Save settings' );
		echo '</form></div>';
	}

	public static function save_settings() {
		check_admin_referer( 'psr_settings' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed' );
		}
		$in  = isset( $_POST['s'] ) ? (array) wp_unslash( $_POST['s'] ) : array(); // phpcs:ignore
		$cur = psr_settings();
		$out = array();
		foreach ( $cur as $k => $v ) {
			if ( in_array( $k, array( 'show_prices', 'canvas', 'strip_theme' ), true ) ) {
				$out[ $k ] = empty( $in[ $k ] ) ? 0 : 1;
			} elseif ( in_array( $k, array( 'hero_slices', 'hero_seconds' ), true ) ) {
				$out[ $k ] = max( 'hero_slices' === $k ? 3 : 3, min( 'hero_slices' === $k ? 12 : 20, (int) ( $in[ $k ] ?? $v ) ) );
			} elseif ( 'email' === $k ) {
				$out[ $k ] = sanitize_email( $in[ $k ] ?? '' );
			} else {
				$out[ $k ] = sanitize_text_field( $in[ $k ] ?? $v );
			}
		}
		update_option( 'psr_settings', $out );
		do_action( 'litespeed_purge_all' );
		wp_safe_redirect( self::url( 'psr-settings', array( 'psr_msg' => 'Settings saved.' ) ) );
		exit;
	}

	/* ----------------------------------------------------------- setup */

	public static function page_setup() {
		$motors = post_type_exists( 'listings' ) || (bool) get_posts( array( 'post_type' => 'listings', 'numberposts' => 1, 'post_status' => 'any' ) );
		echo '<div class="wrap psr-wrap"><h1>Setup &amp; import</h1>';
		echo '<div class="psr-box"><h2>1. Vehicles</h2><p>Brings the Motors listings across as Laqim Originals with their photos (corrected details, duplicates merged) and adds Curated Icons with credited, freely licensed photographs. Existing vehicles are kept unless you tick overwrite.</p>';
		echo '<p><label><input type="checkbox" data-psr-over="import"> Overwrite details of vehicles already imported</label></p>';
		echo '<p><button class="button button-primary" data-psr-run="import">Import vehicles</button>' . ( $motors ? '' : ' <span class="description">Motors listings were not found; curated vehicles will still be added.</span>' ) . '</p><ol class="psr-log" data-psr-log="import"></ol></div>';
		echo '<div class="psr-box"><h2>2. Site design &amp; pages</h2>';
		if ( ! PSR_Kit::ple_ready() ) {
			echo '<p><strong>Install and activate Pentarch Live Edit first.</strong> The design is delivered as Live Edit blocks so every word and image can be edited on the page.</p>';
		} else {
			echo '<p>Creates the global head, header and footer, plus Home, The Collection, Feature Your Car, About and Contact, and sets Home as the front page. Existing blocks are kept unless you tick overwrite (the old version stays as a revision).</p>';
			echo '<p><label><input type="checkbox" data-psr-over="kit"> Overwrite existing blocks</label></p>';
			echo '<p><button class="button button-primary" data-psr-run="kit">Install design &amp; pages</button></p><ol class="psr-log" data-psr-log="kit"></ol>';
		}
		echo '</div></div>';
		echo '<script>window.PSR_KIT_STEPS=' . wp_json_encode( PSR_Kit::steps() ) . ';</script>';
	}

	public static function rest() {
		$can = function () {
			return current_user_can( 'manage_options' );
		};
		register_rest_route(
			'psr/v1',
			'/admin/blocktext',
			array(
				'methods'             => 'POST',
				'permission_callback' => $can,
				'callback'            => function ( $r ) {
					$b = get_page_by_path( sanitize_title( (string) $r['slug'] ), OBJECT, 'ple_block' );
					$from = (string) $r['from'];
					if ( ! $b || '' === $from ) {
						return new WP_Error( 'psr', 'Not found', array( 'status' => 404 ) );
					}
					$n = substr_count( $b->post_content, $from );
					if ( 1 !== $n ) {
						return array( 'matches' => $n );
					}
					wp_update_post( array( 'ID' => $b->ID, 'post_content' => wp_slash( str_replace( $from, (string) $r['to'], $b->post_content ) ) ) );
					PSR_Front::purge_cache();
					return array( 'ok' => 1 );
				},
			)
		);
		register_rest_route(
			'psr/v1',
			'/admin/glbgz',
			array(
				'methods'             => 'POST',
				'permission_callback' => $can,
				'callback'            => function ( $r ) {
					@set_time_limit( 90 ); // phpcs:ignore
					if ( isset( $r['ok'] ) ) {
						update_option( 'psr_glbgz_ok', $r['ok'] ? 1 : 0, true );
						update_option( 'psr_data_ver', (string) microtime( true ), false );
						return array( 'ok' => (int) get_option( 'psr_glbgz_ok' ) );
					}
					$out = PSR_Front::glb_build( 20 );
					if ( ! empty( $out['done'] ) && get_option( 'psr_glbgz_ok' ) ) {
						update_option( 'psr_data_ver', (string) microtime( true ), false );
					}
					return $out;
				},
			)
		);
		register_rest_route(
			'psr/v1',
			'/admin/import',
			array(
				'methods'             => 'POST',
				'permission_callback' => $can,
				'callback'            => function ( $r ) {
					@set_time_limit( 120 ); // phpcs:ignore
					return PSR_Importer::run( (int) $r['n'], ! empty( $r['overwrite'] ) );
				},
			)
		);
		register_rest_route(
			'psr/v1',
			'/admin/kit',
			array(
				'methods'             => 'POST',
				'permission_callback' => $can,
				'callback'            => function ( $r ) {
					@set_time_limit( 120 ); // phpcs:ignore
					$res = PSR_Kit::run( (string) $r['step'], ! empty( $r['overwrite'] ) );
					return is_wp_error( $res ) ? $res : array( 'msg' => $res );
				},
			)
		);
		register_rest_route(
			'psr/v1',
			'/admin/vehicles',
			array(
				'methods'             => 'GET',
				'permission_callback' => $can,
				'callback'            => function ( $r ) {
					$out = array();
					if ( $r['raw'] ) {
						return PSR_DB::query( array( 'all' => true ) );
					}
					foreach ( PSR_DB::query( array( 'all' => true ) ) as $v ) {
						$imgs = array();
						foreach ( PSR_DB::media( $v->id ) as $m ) {
							$meta   = wp_get_attachment_metadata( $m->attachment_id );
							$imgs[] = array( (int) $m->attachment_id, (int) ( $meta['width'] ?? 0 ), (int) ( $meta['height'] ?? 0 ) );
						}
						$out[] = array( 'id' => (int) $v->id, 'ref' => $v->source_ref, 'title' => PSR_DB::title( $v ), 'slug' => $v->slug, 'hero' => (int) $v->hero_attachment, 'imgs' => $imgs );
					}
					return $out;
				},
			)
		);
		register_rest_route(
			'psr/v1',
			'/admin/vehicle/(?P<id>\d+)',
			array(
				'methods'             => 'POST',
				'permission_callback' => $can,
				'callback'            => function ( $r ) {
					$data = (array) $r->get_json_params();
					unset( $data['id'] );
					return array( 'id' => PSR_DB::save_vehicle( $data, (int) $r['id'] ) );
				},
			)
		);
		register_rest_route(
			'psr/v1',
			'/admin/model',
			array(
				'methods'             => 'POST',
				'permission_callback' => $can,
				'callback'            => function ( $r ) {
					$p   = (array) $r->get_json_params();
					$all = get_option( 'psr_models', array() );
					$id  = (int) ( $p['vehicle'] ?? 0 );
					if ( ! $id ) {
						return $all;
					}
					if ( ! empty( $p['delete'] ) ) {
						unset( $all[ $id ] );
					} else {
						$row = array();
						foreach ( array( 'url', 'page', 'profile' ) as $k ) {
							$row[ $k ] = esc_url_raw( $p[ $k ] ?? '' );
						}
						foreach ( array( 'name', 'author', 'license', 'uid' ) as $k ) {
							$row[ $k ] = sanitize_text_field( $p[ $k ] ?? '' );
						}
						$row['flip'] = empty( $p['flip'] ) ? 0 : 1;
						$row['pmat'] = sanitize_text_field( $p['pmat'] ?? '' );
						$row['paint'] = ( isset( $p['paint'] ) && preg_match( '/^#[0-9a-f]{6}$/i', (string) $p['paint'] ) ) ? strtolower( $p['paint'] ) : '';
						$all[ $id ] = $row;
					}
					update_option( 'psr_models', $all, false ); PSR_Front::glb_build( 15 ); update_option( 'psr_data_ver', (string) microtime( true ), false );
					return $all;
				},
			)
		);
		register_rest_route(
			'psr/v1',
			'/admin/brand',
			array(
				'methods'             => 'POST',
				'permission_callback' => $can,
				'callback'            => function ( $r ) {
					$p = (array) $r->get_json_params();
					if ( ! empty( $p['logo'] ) ) {
						update_option( 'psr_logo', esc_url_raw( $p['logo'] ) );
					}
					if ( ! empty( $p['icon'] ) ) {
						update_option( 'site_icon', (int) $p['icon'] );
					}
					if ( isset( $p['settings'] ) && is_array( $p['settings'] ) ) {
						$s = get_option( 'psr_settings', array() );
						foreach ( array( 'phone', 'whatsapp', 'email', 'address', 'hours' ) as $k ) {
							if ( isset( $p['settings'][ $k ] ) ) {
								$s[ $k ] = sanitize_text_field( $p['settings'][ $k ] );
							}
						}
						update_option( 'psr_settings', $s );
					}
					return array( 'logo' => get_option( 'psr_logo' ), 'icon' => (int) get_option( 'site_icon' ), 'settings' => get_option( 'psr_settings' ) );
				},
			)
		);
	}
}
