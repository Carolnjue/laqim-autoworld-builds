<?php
/**
 * Front end: routes, canvas template, vehicle pages, shortcodes, enquiries.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class PSR_Front {

	/** Vehicle being shown on this request. */
	public static $vehicle = null;

	/** Whether the current request renders inside the canvas. */
	private static $canvas = null;

	/** Clear the page cache (SpeedyCache) so visitors see fresh data. */
	public static function purge_cache() {
		self::schedule_warm();
		if ( class_exists( '\\SpeedyCache\\Delete' ) && method_exists( '\\SpeedyCache\\Delete', 'run' ) ) {
			try {
				\SpeedyCache\Delete::run( array() );
			} catch ( \Throwable $e ) {
				unset( $e );
			}
		}
	}

	/** After a plugin update, purge once. */
	public static function purge_on_upgrade() {
		if ( get_option( 'psr_cache_ver' ) !== PSR_VERSION ) {
			update_option( 'psr_cache_ver', PSR_VERSION, false );
			self::favicon_file();
			self::purge_cache();
		}
	}

	/** Browsers and crawlers ask for /favicon.ico directly; the server answers that before WordPress, so keep a real file there. */
	public static function favicon_file() {
		$dest = ABSPATH . 'favicon.ico';
		$id   = (int) get_option( 'site_icon' );
		if ( file_exists( $dest ) || ! $id || ! is_writable( ABSPATH ) ) {
			return;
		}
		$meta = wp_get_attachment_metadata( $id );
		$file = get_attached_file( $id );
		if ( ! empty( $meta['sizes']['site_icon-32']['file'] ) ) {
			$file = path_join( dirname( $file ), $meta['sizes']['site_icon-32']['file'] );
		} elseif ( ! empty( $meta['sizes']['thumbnail']['file'] ) ) {
			$file = path_join( dirname( $file ), $meta['sizes']['thumbnail']['file'] );
		}
		if ( $file && file_exists( $file ) ) {
			@copy( $file, $dest ); // phpcs:ignore
		}
	}

	/** After a cache purge, revisit the pages in the background so the first visitors get cached pages. */
	public static function schedule_warm() {
		wp_clear_scheduled_hook( 'psr_warm' );
		wp_schedule_single_event( time(), 'psr_warm', array( 0 ) );
		self::kick_cron();
	}

	/** Nudge WP-Cron now (quiet sites rarely trigger it on their own). */
	public static function kick_cron() {
		wp_remote_post( site_url( 'wp-cron.php?doing_wp_cron=' . sprintf( '%.22F', microtime( true ) ) ), array( 'timeout' => 0.5, 'blocking' => false, 'sslverify' => false ) );
	}

	public static function warm( $offset = 0 ) {
		$urls = array( home_url( '/' ) );
		foreach ( array( 'collection', 'showroom', 'play', 'lab', 'parts', 'about', 'contact', 'feature-your-car' ) as $slug ) {
			$urls[] = home_url( '/' . $slug . '/' );
		}
		foreach ( PSR_DB::query() as $v ) {
			$urls[] = self::url( $v );
		}
		$offset = max( 0, (int) $offset );
		@set_time_limit( 320 ); // phpcs:ignore
		ignore_user_abort( true );
		if ( 0 === $offset ) {
			sleep( 25 ); /* let any follow-up cache purge finish first */
		}
		$t0     = microtime( true );
		$i      = $offset;
		for ( ; $i < count( $urls ) && microtime( true ) - $t0 < 240; $i++ ) {
			wp_remote_get( $urls[ $i ], array( 'timeout' => 20, 'redirection' => 0, 'sslverify' => false, 'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36 LaqimWarm' ) );
			usleep( 400000 ); /* stay gentle on the server */
		}
		if ( $i < count( $urls ) ) {
			wp_schedule_single_event( time() + 5, 'psr_warm', array( $i ) );
			delete_transient( 'doing_cron' );
			sleep( 6 );
			self::kick_cron();
		}
	}

	/** Drop WordPress emoji scripts (the site uses SVG icons). */
	public static function no_emoji() {
		remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
		remove_action( 'wp_print_styles', 'print_emoji_styles' );
		remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
		remove_action( 'admin_print_styles', 'print_emoji_styles' );
		remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
		remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
		remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
		add_filter( 'emoji_svg_url', '__return_false' );
	}

	public static function init() {
		add_action( 'init', array( __CLASS__, 'rewrites' ) );
		add_action( 'update_option_psr_data_ver', array( __CLASS__, 'purge_cache' ) );
		add_action( 'add_option_psr_data_ver', array( __CLASS__, 'purge_cache' ) );
		add_action( 'admin_init', array( __CLASS__, 'purge_on_upgrade' ) );
		add_action( 'psr_warm', array( __CLASS__, 'warm' ) );
		add_action( 'init', array( __CLASS__, 'no_emoji' ) );
		add_filter( 'query_vars', array( __CLASS__, 'query_vars' ) );
		add_action( 'template_redirect', array( __CLASS__, 'legacy_redirect' ), 1 );
		/* No blog here: feeds only listed the theme's demo posts. */
		remove_action( 'wp_head', 'feed_links', 2 );
		remove_action( 'wp_head', 'feed_links_extra', 3 );
		add_filter( 'option_blogdescription', array( __CLASS__, 'tagline' ) );
		/* Don't publish the admin's login name to visitors through the REST user list. */
		add_filter( 'rest_endpoints', function ( $e ) {
			if ( ! is_user_logged_in() ) {
				unset( $e['/wp/v2/users'], $e['/wp/v2/users/(?P<id>[\\d]+)'] );
			}
			return $e;
		} );
		add_filter( 'oembed_response_data', function ( $d ) {
			unset( $d['author_name'], $d['author_url'] );
			return $d;
		} );
		add_filter( 'pre_get_document_title', function ( $t ) {
			return is_404() ? 'Page not found | Laqim Autoworld' : $t;
		}, PHP_INT_MAX );
		add_action( 'parse_request', array( __CLASS__, 'car_sitemap' ), 1 );
		add_filter( 'robots_txt', array( __CLASS__, 'robots_sitemap' ), 99 );
		add_action( 'template_redirect', array( __CLASS__, 'resolve' ) );
		add_action( 'template_redirect', array( __CLASS__, 'clean_hooks' ), 999 );
		add_filter( 'template_include', array( __CLASS__, 'template' ), 99 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ), 20 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'strip_theme' ), 9999 );
		add_action( 'wp_print_styles', array( __CLASS__, 'strip_theme' ), 9999 );
		add_filter( 'pre_get_document_title', array( __CLASS__, 'doc_title' ), 20 );
		add_action( 'wp_head', array( __CLASS__, 'meta' ), 2 );
		add_action( 'wp_head', array( __CLASS__, 'page_meta' ), 2 );
		add_action( 'template_redirect', array( __CLASS__, 'head_buffer' ), 1000 );
		add_action( 'wp', array( __CLASS__, 'social_buffer' ), 0 );
		add_filter( 'get_post_metadata', array( __CLASS__, 'seo_meta' ), 10, 3 );
		add_action( 'wp_body_open', array( __CLASS__, 'hidden_h1' ), 1 );
		add_filter( 'body_class', array( __CLASS__, 'body_class' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'rest' ) );
		add_filter( 'show_admin_bar', array( __CLASS__, 'admin_bar' ) );

		add_shortcode( 'psr_hero', array( __CLASS__, 'sc_hero' ) );
		add_shortcode( 'psr_grid', array( __CLASS__, 'sc_grid' ) );
		add_shortcode( 'psr_collection', array( __CLASS__, 'sc_collection' ) );
		add_shortcode( 'psr_marques', array( __CLASS__, 'sc_marques' ) );
		add_shortcode( 'psr_engine', array( __CLASS__, 'sc_engine' ) );
		add_shortcode( 'psr_race', array( __CLASS__, 'sc_race' ) );
		add_shortcode( 'psr_silhouette', array( __CLASS__, 'sc_silhouette' ) );
		add_shortcode( 'psr_trumps', array( __CLASS__, 'sc_trumps' ) );
		add_shortcode( 'psr_brake', array( __CLASS__, 'sc_brake' ) );
		add_shortcode( 'psr_launch', array( __CLASS__, 'sc_launch' ) );
		add_shortcode( 'psr_hilo', array( __CLASS__, 'sc_hilo' ) );
		add_shortcode( 'psr_partsmap', array( __CLASS__, 'sc_partsmap' ) );
		add_shortcode( 'psr_league', array( __CLASS__, 'sc_league' ) );
		add_shortcode( 'psr_paint', array( __CLASS__, 'sc_paint' ) );
		add_shortcode( 'psr_sizeup', array( __CLASS__, 'sc_sizeup' ) );
		add_shortcode( 'psr_perfmap', array( __CLASS__, 'sc_perfmap' ) );
		add_shortcode( 'psr_builder', array( __CLASS__, 'sc_builder' ) );
		add_shortcode( 'psr_quiz', array( __CLASS__, 'sc_quiz' ) );
		add_shortcode( 'psr_hotlap', array( __CLASS__, 'sc_hotlap' ) );
		add_shortcode( 'psr_rally', array( __CLASS__, 'sc_rally' ) );
		add_shortcode( 'psr_drag', array( __CLASS__, 'sc_drag' ) );
		add_shortcode( 'psr_statband', array( __CLASS__, 'sc_statband' ) );
		add_shortcode( 'psr_cotd', array( __CLASS__, 'sc_cotd' ) );
		add_shortcode( 'psr_feature', array( __CLASS__, 'sc_feature' ) );
		add_shortcode( 'psr_count', array( __CLASS__, 'sc_count' ) );
		add_shortcode( 'psr_enquiry', array( __CLASS__, 'sc_enquiry' ) );
		add_shortcode( 'psr_reel', array( __CLASS__, 'sc_reel' ) );
		add_shortcode( 'psr_guess', array( __CLASS__, 'sc_guess' ) );
		add_shortcode( 'psr_search', array( __CLASS__, 'sc_search' ) );
		add_shortcode( 'psr_duel', array( __CLASS__, 'sc_duel' ) );
		add_shortcode( 'psr_finder', array( __CLASS__, 'sc_finder' ) );
		add_shortcode( 'psr_spotlight', array( __CLASS__, 'sc_spotlight' ) );
		add_shortcode( 'psr_tiles', array( __CLASS__, 'sc_tiles' ) );
		add_shortcode( 'psr_showroom', array( __CLASS__, 'sc_showroom' ) );
		add_shortcode( 'psr_tech', array( __CLASS__, 'sc_tech' ) );
		add_shortcode( 'psr_facts', array( __CLASS__, 'sc_facts' ) );
		add_shortcode( 'psr_parts', array( __CLASS__, 'sc_parts' ) );
		add_shortcode( 'psr_eng', array( __CLASS__, 'sc_eng' ) );
		add_action( 'wp_footer', array( __CLASS__, 'print_index' ), 4 );
		add_action( 'wp_footer', array( __CLASS__, 'print_chip_sprite' ), 3 );
	}

	/* ------------------------------------------------------------ routes */

	public static function base() {
		$b = trim( (string) psr_settings( 'base' ), '/' );
		return $b ? $b : 'collection';
	}

	public static function rewrites() {
		add_rewrite_rule( '^' . self::base() . '/([^/]+)/?$', 'index.php?psr_vehicle=$matches[1]', 'top' );
	}

	public static function flush_on_activate() {
		self::rewrites();
		flush_rewrite_rules();
	}

	public static function query_vars( $v ) {
		$v[] = 'psr_vehicle';
		return $v;
	}

	public static function url( $v ) {
		return home_url( '/' . self::base() . '/' . $v->slug . '/' );
	}

	public static function collection_url( $hash = '' ) {
		return home_url( '/' . self::base() . '/' ) . ( $hash ? '#' . $hash : '' );
	}

	public static function resolve() {
		$slug = get_query_var( 'psr_vehicle' );
		if ( ! $slug ) {
			return;
		}
		$v = PSR_DB::by_slug( sanitize_title( $slug ) );
		if ( ! $v || ( 'publish' !== $v->visibility && ! current_user_can( 'edit_pages' ) ) ) {
			global $wp_query;
			$wp_query->set_404();
			status_header( 404 );
			return;
		}
		self::$vehicle = $v;
		global $wp_query;
		$wp_query->is_404  = false;
		$wp_query->is_home = false;
		status_header( 200 );
		if ( ! current_user_can( 'edit_pages' ) ) {
			PSR_DB::bump_views( $v->id );
		}
	}

	/** Old Motors URLs (/listings/slug, /inventory/) go to their new home. */
	public static function tagline( $v ) {
		return is_admin() ? $v : 'Remarkable cars, curated in Nairobi';
	}

	public static function legacy_redirect() {
		global $wpdb;
		if ( is_feed() ) {
			wp_safe_redirect( home_url( '/' ), 301 );
			exit;
		}
		$path = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '', PHP_URL_PATH ), '/' );
		if ( preg_match( '~^listings/([^/]+)~', $path, $m ) ) {
			$id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_name = %s AND post_type = 'listings' LIMIT 1", sanitize_title( $m[1] ) ) );
			$v  = $id ? PSR_DB::by_ref( 'motors:' . $id ) : null;
			if ( ! $v && 3439 === $id ) {
				$v = PSR_DB::by_ref( 'motors:3616' );
			}
			wp_safe_redirect( $v ? self::url( $v ) : self::collection_url(), 301 );
			exit;
		}
		if ( in_array( $path, array( 'inventory', 'listings', 'imports', 'compare', 'compare-page', 'listings-page', 'listing-creation-page', 'profile-page', 'add-car', 'authorization' ), true ) ) {
			wp_safe_redirect( self::collection_url(), 301 );
			exit;
		}
		if ( in_array( $path, array( 'sample-page', 'sample-page-2' ), true ) ) {
			wp_safe_redirect( home_url( '/' ), 301 );
			exit;
		}
		if ( in_array( $path, array( 'aboutus', 'about-us' ), true ) ) {
			wp_safe_redirect( home_url( '/about/' ), 301 );
			exit;
		}
		/* the site has no blog: demo posts, categories, tags, authors and date archives go home */
		if ( ! is_admin() && ( is_singular( 'post' ) || is_category() || is_tag() || is_author() || is_date() ) ) {
			wp_safe_redirect( home_url( '/' ), 301 );
			exit;
		}
	}

	/** A sitemap of every car page, which the SEO plugin's sitemap cannot see. */
	public static function car_sitemap() {
		$path = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '', PHP_URL_PATH ), '/' );
		$ver = (float) get_option( 'psr_data_ver', time() );
		$mod = gmdate( 'Y-m-d\TH:i:s+00:00', $ver ? (int) $ver : time() );
		$icons = array( 'favicon.ico' => 32, 'apple-touch-icon.png' => 180, 'apple-touch-icon-precomposed.png' => 180 );
		if ( isset( $icons[ $path ] ) && get_site_icon_url( $icons[ $path ] ) ) {
			header( 'Cache-Control: public, max-age=604800' );
			wp_safe_redirect( get_site_icon_url( $icons[ $path ] ), 301 );
			exit;
		}
		/* The SEO plugin's sitemaps listed the theme's demo posts, categories and retired pages: serve a clean set. */
		if ( 'sitemaps.xml' === $path || 'sitemap.xml' === $path || 'sitemap_index.xml' === $path ) {
			header( 'Content-Type: application/xml; charset=UTF-8' );
			header( 'X-Robots-Tag: noindex' );
			echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
			foreach ( array( 'page-sitemap1.xml', 'laqim-cars-sitemap.xml', 'redline-sitemap.xml' ) as $sm ) {
				echo '<sitemap><loc>' . esc_url( home_url( '/' . $sm ) ) . '</loc><lastmod>' . esc_html( $mod ) . '</lastmod></sitemap>';
			}
			echo '</sitemapindex>';
			exit;
		}
		if ( 'page-sitemap1.xml' === $path ) {
			$skip = array( 'inventory', 'listings', 'imports', 'compare', 'compare-page', 'listings-page', 'listing-creation-page', 'profile-page', 'add-car', 'authorization', 'sample-page', 'sample-page-2', 'aboutus' );
			$front = (int) get_option( 'page_on_front' );
			header( 'Content-Type: application/xml; charset=UTF-8' );
			header( 'X-Robots-Tag: noindex' );
			echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
			echo '<url><loc>' . esc_url( home_url( '/' ) ) . '</loc><lastmod>' . esc_html( $mod ) . "</lastmod></url>\n";
			foreach ( get_pages( array( 'post_status' => 'publish' ) ) as $pg ) {
				if ( (int) $pg->ID === $front || in_array( $pg->post_name, $skip, true ) || post_password_required( $pg ) ) {
					continue;
				}
				echo '<url><loc>' . esc_url( get_permalink( $pg ) ) . '</loc><lastmod>' . esc_html( get_post_modified_time( 'Y-m-d\TH:i:s+00:00', true, $pg ) ) . "</lastmod></url>\n";
			}
			echo '</urlset>';
			exit;
		}
		if ( preg_match( '/^[a-z_]+-sitemap\d*\.xml$/', $path ) && 'laqim-cars-sitemap.xml' !== $path ) {
			status_header( 404 );
			header( 'Content-Type: application/xml; charset=UTF-8' );
			echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"></urlset>';
			exit;
		}
		if ( 'laqim-cars-sitemap.xml' !== $path ) {
			return;
		}
		header( 'Content-Type: application/xml; charset=UTF-8' );
		header( 'X-Robots-Tag: noindex' );
		echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">' . "\n";
		foreach ( PSR_DB::query() as $v ) {
			$img = wp_get_attachment_image_url( PSR_DB::cover( $v ), 'large' );
			echo '<url><loc>' . esc_url( self::url( $v ) ) . '</loc><lastmod>' . esc_html( $mod ) . '</lastmod>' . ( $img ? '<image:image><image:loc>' . esc_url( $img ) . '</image:loc></image:image>' : '' ) . "</url>\n";
		}
		echo '</urlset>';
		exit;
	}

	public static function robots_sitemap( $out ) {
		if ( false === strpos( $out, 'sitemaps.xml' ) ) {
			$out = rtrim( $out ) . "\nSitemap: " . home_url( '/sitemaps.xml' );
		}
		return rtrim( $out ) . "\n";
	}

	/**
	 * On canvas pages only the Live Edit header and footer should print. Page builders and
	 * themes that inject their own headers (Elementor Header & Footer, Motors) are unhooked.
	 */
	public static function clean_hooks() {
		if ( ! self::is_canvas() ) {
			return;
		}
		global $wp_filter;
		$bad = '/Header_Footer_Elementor|HFE|Hfe|ehf|Motors|STM|stm_|motors_|Elementor/';
		foreach ( array( 'wp_body_open', 'wp_footer', 'get_header', 'get_footer' ) as $hook ) {
			if ( empty( $wp_filter[ $hook ] ) ) {
				continue;
			}
			foreach ( $wp_filter[ $hook ]->callbacks as $prio => $cbs ) {
				foreach ( $cbs as $key => $cb ) {
					$f    = $cb['function'];
					$name = '';
					if ( is_string( $f ) ) {
						$name = $f;
					} elseif ( is_array( $f ) ) {
						$name = ( is_object( $f[0] ) ? get_class( $f[0] ) : (string) $f[0] ) . '::' . $f[1];
					} elseif ( $f instanceof Closure ) {
						$r    = new ReflectionFunction( $f );
						$name = (string) $r->getFileName();
					}
					$keep = false !== strpos( $name, 'Pentarch' ) || false !== strpos( $name, 'PSR_' ) || 'wp_admin_bar_render' === $name || 0 === strpos( $name, 'wp_' ) || 0 === strpos( $name, '_wp' );
					if ( 'wp_body_open' === $hook ) {
						$hit = ! $keep;
					} else {
						$hit = ! $keep && ( preg_match( $bad, $name ) || false !== strpos( $name, '/themes/' ) || false !== strpos( $name, 'header-footer-elementor' ) || false !== strpos( $name, 'motors-car-dealership' ) );
					}
					if ( $hit ) {
						unset( $wp_filter[ $hook ]->callbacks[ $prio ][ $key ] );
					}
				}
			}
		}
	}

	public static function is_canvas() {
		if ( null !== self::$canvas ) {
			return self::$canvas;
		}
		if ( is_admin() ) {
			return false;
		}
		self::$canvas = (bool) ( self::$vehicle || PSR_Redline::$view || ( psr_settings( 'canvas' ) && ( is_page() || is_front_page() || is_404() || is_search() || is_singular( 'post' ) || is_home() || is_archive() ) ) );
		return self::$canvas;
	}

	public static function template( $tpl ) {
		if ( ! is_admin() && is_page( 'play' ) ) {
			return PSR_DIR . 'templates/arcade.php';
		}
		if ( self::$vehicle ) {
			return PSR_DIR . 'templates/vehicle.php';
		}
		if ( self::is_canvas() ) {
			return PSR_DIR . 'templates/canvas.php';
		}
		return $tpl;
	}

	public static function body_class( $c ) {
		if ( self::is_canvas() ) {
			$c[] = 'psr-canvas';
		}
		if ( self::$vehicle ) {
			$c[] = 'psr-single';
		}
		return $c;
	}

	public static function admin_bar( $show ) {
		return $show;
	}

	/**
	 * In canvas mode the active theme's styles and scripts are not used. Remove them
	 * (and those of the old page builders) so nothing fights the design.
	 */
	public static function strip_theme() {
		if ( ! self::is_canvas() || ! psr_settings( 'strip_theme' ) ) {
			return;
		}
		$needles = apply_filters( 'psr_strip_sources', array( '/wp-content/themes/', 'motors-car-dealership', '/elementor/', 'header-footer-elementor', '/pagelayer', 'wp-block-library', 'classic-theme-styles', 'global-styles' ) );
		foreach ( array( wp_styles(), wp_scripts() ) as $deps ) {
			foreach ( (array) $deps->queue as $h ) {
				$src = isset( $deps->registered[ $h ] ) ? (string) $deps->registered[ $h ]->src : '';
				$hit = in_array( $h, array( 'wp-block-library', 'classic-theme-styles', 'global-styles', 'wp-block-library-theme' ), true );
				foreach ( $needles as $n ) {
					if ( $src && false !== strpos( $src, $n ) ) {
						$hit = true;
					}
				}
				if ( $hit ) {
					$deps->dequeue( $h );
				}
			}
		}
		/* Plugin assets the showroom pages never use: forms, social feeds, icon fonts for visitors. */
		$post    = get_post();
		$content = $post ? (string) $post->post_content : '';
		$unused  = array();
		if ( false === strpos( $content, 'contact-form-7' ) ) {
			$unused = array_merge( $unused, array( 'contact-form-7', 'swv', 'wpcf7-recaptcha' ) );
		}
		if ( false === strpos( $content, 'socialfeeds' ) ) {
			$unused = array_merge( $unused, array( 'socialfeeds-frontend', 'socialfeeds-pro-frontend' ) );
		}
		if ( false === strpos( $content, 'formlayer' ) ) {
			$unused[] = 'formlayer-frontend';
		}
		if ( ! is_user_logged_in() ) {
			$unused = array_merge( $unused, array( 'dashicons', 'jquery', 'jquery-core', 'jquery-migrate' ) );
		}
		foreach ( $unused as $h ) {
			wp_dequeue_style( $h );
			wp_dequeue_script( $h );
		}
	}

	public static function assets() {
		if ( ! self::is_canvas() && ! self::has_shortcode_on_page() && ! PSR_Redline::$view ) {
			return;
		}
		$min = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) || ! file_exists( PSR_DIR . 'assets/front.min.js' ) ? '' : '.min';
		wp_enqueue_style( 'psr-front', PSR_URL . 'assets/front' . $min . '.css', array(), PSR_VERSION );
		wp_enqueue_script( 'psr-front', PSR_URL . 'assets/front' . $min . '.js', array(), PSR_VERSION, true );
		wp_add_inline_script(
			'psr-front',
			'window.PSR=' . wp_json_encode(
				array(
					'rest'  => esc_url_raw( rest_url( 'psr/v1/' ) ),
					'play'  => home_url( '/play/' ),
					'showroom' => home_url( '/showroom/' ),
					'redline'  => home_url( '/redline/' ),
					'boards'   => array_values( array_filter( array_map( 'trim', explode( '|', (string) psr_settings( 'billboards' ) ) ) ) ),
					'champs'   => array_slice( PSR_Redline::champs(), 0, 12 ),
					'assets'   => PSR_URL . 'assets/',
					'ver'      => PSR_VERSION,
				)
			) . ';',
			'before'
		);
	}

	private static function has_shortcode_on_page() {
		$p = get_post();
		return $p && false !== strpos( $p->post_content, '[psr_' );
	}

	/* ------------------------------------------------------------- SEO */

	public static function doc_title( $t ) {
		if ( self::$vehicle ) {
			$v = self::$vehicle;
			return trim( PSR_DB::title( $v ) . ' ' . ( $v->year ? $v->year : '' ) ) . ' | ' . psr_settings( 'brand' );
		}
		return $t;
	}

	/** Search and share descriptions for the main pages (car pages have their own in meta()). */
	public static function page_desc() {
		if ( self::$vehicle || is_admin() ) {
			return '';
		}
		$d = array(
			'home'             => 'Laqim Autoworld is a Nairobi showcase of remarkable cars, with full specifications, 3D models to spin, engineering explainers and driving games.',
			'collection'       => 'Browse the Laqim collection by marque, body and year. Compare specifications side by side, save favourites and spin over a hundred cars in 3D.',
			'showroom'         => 'Walk a virtual 3D hall of the Laqim collection. Look around, stroll between the marques and open any car for its full story.',
			'play'             => 'Laqim Play: a 3D showroom, Laqim Racing, a story-driven Laqim Rally career across Kenya and Laqim Football with the Laqim Cup. Free, in the browser, with phone and controller support.',
			'lab'              => 'How cars really work: animated engine cutaways, an engine builder with a live dyno chart, stopping distances and a performance map of the collection.',
			'parts'            => 'Every part has a story. Explore the rare and significant parts of remarkable cars, what they do and why they are hard to find.',
			'about'            => 'Laqim Autoworld is a showcase of remarkable cars for enthusiasts who love the details: the stance, the cabin, the numbers and the story.',
			'contact'          => 'Talk cars with Laqim Autoworld in Nairobi. Questions about a car in the showcase, ideas, collaborations or press: we reply personally.',
			'feature-your-car' => 'Own something remarkable? Send a few photos and its story. The best cars join the Laqim showcase, presented with photographs and specifications.',
		);
		$slug = is_front_page() ? 'home' : ( is_page() ? (string) get_post_field( 'post_name', get_queried_object_id() ) : '' );
		return $d[ $slug ] ?? '';
	}

	/** Hand the SEO plugin our page descriptions so it stops printing empty ones. */
	public static function seo_meta( $val, $id, $key ) {
		if ( is_admin() || ! is_string( $key ) || ! preg_match( '/^_(?:siteseo|seopress)_(?:titles_desc|titles_title|social_fb_desc|social_twitter_desc)$/', $key ) ) {
			return $val;
		}
		if ( (int) $id !== (int) get_queried_object_id() ) {
			return $val;
		}
		if ( preg_match( '/titles_title$/', $key ) ) {
			if ( is_front_page() ) {
				return array( 'Laqim Autoworld | Remarkable cars, curated in Nairobi' );
			}
			if ( is_page() && ! self::$vehicle ) {
				remove_filter( 'get_post_metadata', array( __CLASS__, 'seo_meta' ), 10 );
				$own = get_post_meta( $id, $key, true );
				add_filter( 'get_post_metadata', array( __CLASS__, 'seo_meta' ), 10, 3 );
				if ( '' !== (string) $own ) {
					return $val;
				}
				return array( wp_strip_all_tags( get_the_title( $id ) ) . ' | Laqim Autoworld' );
			}
			return $val;
		}
		$d = self::page_desc();
		return $d ? array( $d ) : $val;
	}

	public static function page_meta() {
		$desc = self::page_desc();
		if ( ! $desc ) {
			return;
		}
		$img = '';
		$hero = PSR_DB::query( array( 'limit' => 1 ) );
		if ( $hero ) {
			$img = wp_get_attachment_image_url( PSR_DB::cover( $hero[0] ), 'large' );
		}
		/* the SEO plugin prints the description tags (see seo_meta); we add the share image */
		if ( $img ) {
			echo '<meta property="og:image" content="' . esc_url( $img ) . '"><meta name="twitter:card" content="summary_large_image">';
		}
		echo "\n";
	}

	/** Drop the SEO plugin's empty description tags and its light theme colour, which sit beside ours. */
	public static function head_buffer() {
		if ( is_admin() || wp_doing_ajax() || is_feed() || is_customize_preview() ) {
			return;
		}
		ob_start(
			function ( $html ) {
				$end = stripos( $html, '</head>' );
				if ( false === $end ) {
					return $html;
				}
				$head = substr( $html, 0, $end );
				$head = preg_replace( '#<meta\s+(?:name|property)="(?:description|og:description|twitter:description)"\s+content=""\s*/?>\s*#i', '', $head );
				$head = preg_replace( '#<meta\s+name="twitter:card"\s+content="summary"\s*/?>\s*#i', '', $head );
				$head = preg_replace( '#(<meta\s+name="theme-color"\s+content=")\#faf7f2(")#i', '${1}#0b0b0d$2', $head );
				/* an old wide logo was still registered as a favicon, and the theme repeats the viewport tag */
				$head = preg_replace( '#<link\s+rel="icon"\s+href="[^"]*laqimlogo-[^"]*"\s*/?>\s*#i', '', $head );
				if ( substr_count( $head, 'name="viewport"' ) > 1 ) {
					$head = preg_replace( '#<meta\s+name="viewport"\s+content="width=device-width, initial-scale=1"\s*/?>\s*#i', '', $head, 1 );
				}
				return self::slim_header_images( $head . substr( $html, $end ) );
			}
		);
	}

	/**
	 * The header menu shows small car cards and a 114px logo, but the saved header points at the
	 * full-size uploads (600 KB+ each). Swap in WordPress's own smaller copies of the same images.
	 */
	public static function slim_header_images( $html ) {
		$cut  = stripos( $html, '<main' );
		$top  = false === $cut ? $html : substr( $html, 0, $cut );
		$rest = false === $cut ? '' : substr( $html, $cut );
		$map  = get_transient( 'psr_slim_imgs' );
		$map  = is_array( $map ) ? $map : array();
		$new  = false;
		$swap = function ( $url, $size ) use ( &$map, &$new ) {
			$k = $size . '|' . $url;
			if ( ! isset( $map[ $k ] ) ) {
				$id        = attachment_url_to_postid( preg_replace( '/-scaled(\.\w+)$/', '$1', $url ) );
				$id        = $id ? $id : attachment_url_to_postid( $url );
				$small     = $id ? wp_get_attachment_image_url( $id, $size ) : '';
				$map[ $k ] = $small ? $small : $url;
				$new       = true;
			}
			return $map[ $k ];
		};
		$top = preg_replace_callback(
			'#(<img\b[^>]*\bsrc=")([^"]+/wp-content/uploads/[^"]+\.(?:jpe?g|png|webp))(")#i',
			function ( $m ) use ( $swap ) {
				return $m[1] . $swap( $m[2], false !== stripos( $m[2], 'logo' ) ? 'medium' : 'medium_large' ) . $m[3];
			},
			$top
		);
		/* page blocks built from the kit point at full-size uploads with no srcset: use the 1024px copy */
		$rest = preg_replace_callback(
			'#<img\b(?![^>]*\bsrcset=)[^>]*>#i',
			function ( $t ) use ( $swap ) {
				return preg_replace_callback(
					'#(\bsrc=")([^"]+/wp-content/uploads/[^"]+\.(?:jpe?g|webp))(")#i',
					function ( $m ) use ( $swap ) {
						if ( preg_match( '/-\d+x\d+\.\w+$/', $m[2] ) ) {
							return $m[0]; // already a resized copy
						}
						return $m[1] . $swap( $m[2], 'large' ) . $m[3];
					},
					$t[0]
				);
			},
			$rest
		);
		$rest = preg_replace_callback(
			'#(<img\b[^>]*\bsrc=")([^"]+/wp-content/uploads/[^"]*logo[^"]*\.png)(")#i',
			function ( $m ) use ( $swap ) {
				return $m[1] . $swap( $m[2], 'medium' ) . $m[3];
			},
			$rest
		);
		/* section backgrounds set inline (e.g. --finder-bg:url(...)) */
		$rest = preg_replace_callback(
			'#url\(([\'"]?)(https?://[^)\'"]+/wp-content/uploads/[^)\'"]+\.(?:jpe?g|webp))\1\)#i',
			function ( $m ) use ( $swap ) {
				if ( preg_match( '/-\d+x\d+\.\w+$/', $m[2] ) ) {
					return $m[0];
				}
				return 'url(' . $m[1] . $swap( $m[2], '1536x1536' ) . $m[1] . ')';
			},
			$rest
		);
		if ( $new ) {
			set_transient( 'psr_slim_imgs', $map, DAY_IN_SECONDS );
		}
		return $top . $rest;
	}

	/**
	 * The SEO plugin injects its social tags late, from its own output buffer, so this buffer has to
	 * start before it. On car pages those tags describe the wrong post (the old demo post), so they go;
	 * elsewhere only its empty descriptions go.
	 */
	public static function social_buffer() {
		if ( is_admin() || wp_doing_ajax() || is_feed() || is_customize_preview() ) {
			return;
		}
		ob_start(
			function ( $html ) {
				$end = stripos( $html, '</head>' );
				if ( false === $end ) {
					return $html;
				}
				$head = substr( $html, 0, $end );
				$head = preg_replace( '#<meta\s+(?:name|property)="(?:description|og:description|twitter:description)"\s+content=""\s*/?>\s*#i', '', $head );
				/* SEO plugin's Organization block ships with an empty name and a logo without a URL: complete it. */
				$head = preg_replace_callback(
					'#(<script[^>]+application/ld\+json[^>]*>)(\{[^<]*"@type":"Organization"[^<]*\})(</script>)#',
					function ( $m ) {
						$j = json_decode( $m[2], true );
						if ( ! is_array( $j ) ) {
							return $m[0];
						}
						$j['name']        = 'Laqim Autoworld';
						$j['description'] = 'Remarkable cars, curated in Nairobi';
						$logo             = get_theme_mod( 'custom_logo' ) ? wp_get_attachment_image_url( get_theme_mod( 'custom_logo' ), 'medium' ) : get_site_icon_url( 512 );
						if ( $logo ) {
							$j['logo'] = array_merge( is_array( $j['logo'] ?? null ) ? $j['logo'] : array(), array( '@type' => 'ImageObject', 'url' => $logo ) );
						} else {
							unset( $j['logo'] );
						}
						return $m[1] . wp_json_encode( $j, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . $m[3];
					},
					$head
				);
				if ( self::$vehicle ) {
					$v     = self::$vehicle;
					$title = PSR_DB::title( $v ) . ' ' . $v->year . ' | ' . psr_settings( 'brand' );
					/* the plugin's tags are self-closing ("/>"); ours are not */
					$head = preg_replace( '#<meta\s+(?:property|name)="(?:og|twitter):(?:title|description|url|type)"\s+content="[^"]*"\s*/>\s*#i', '', $head );
					$demo = get_post_field( 'post_title', get_queried_object_id() );
					if ( $demo ) {
						$head = str_replace( array( wp_json_encode( $demo ), '"' . esc_attr( $demo ) . '"' ), array( wp_json_encode( $title ), '"' . esc_attr( $title ) . '"' ), $head );
					}
					if ( false === stripos( $head, 'property="og:url"' ) ) {
						$head .= '<meta property="og:url" content="' . esc_url( self::url( $v ) ) . '"><meta name="twitter:title" content="' . esc_attr( $title ) . '">' . "\n";
					}
				}
				return $head . substr( $html, $end );
			}
		);
	}

	/** Home and the 3D showroom open with a carousel or canvas, so give them a heading for search engines and screen readers. */
	public static function hidden_h1() {
		echo '<a class="psr-skip" href="#main">' . esc_html__( 'Skip to content', 'pentarch-showroom' ) . '</a>';
		if ( is_front_page() ) {
			echo '<h1 class="screen-reader-text psr-sr">Laqim Autoworld: remarkable cars, curated in Nairobi</h1>';
		} elseif ( is_page( 'showroom' ) ) {
			echo '<h1 class="screen-reader-text psr-sr">The Laqim 3D Showroom</h1>';
		}
	}

	public static function meta() {
		if ( ! self::$vehicle ) {
			return;
		}
		$v    = self::$vehicle;
		$desc = $v->tagline ? $v->tagline : wp_trim_words( wp_strip_all_tags( (string) $v->summary ), 28 );
		if ( ! $desc ) {
			$desc = trim( implode( ' · ', array_filter( array( $v->year, $v->engine, $v->exterior_color ) ) ) );
		}
		/* Search snippet: name the car, then the story line and the headline figures. */
		$st    = self::stats( $v );
		$acc   = (float) ( self::extra( $v->id )['accel'] ?? 0 );
		$facts = array_filter( array( ! empty( $st['hp'] ) ? (int) $st['hp'] . ' hp' : '', $acc ? '0-100 km/h in ' . rtrim( rtrim( number_format( $acc, 1 ), '0' ), '.' ) . ' s' : '' ) );
		$lead  = trim( ( $v->year ? $v->year . ' ' : '' ) . PSR_DB::title( $v ) );
		$long  = $lead . ': ' . rtrim( $desc, '. ' ) . '.' . ( $facts ? ' ' . implode( ', ', $facts ) . '.' : '' ) . ( self::model( $v->id ) ? ' Specs, photos and a 3D model to spin.' : ' Specs and photos.' );
		if ( mb_strlen( $long ) > 160 ) {
			$long = $lead . ': ' . rtrim( $desc, '. ' ) . '.' . ( $facts ? ' ' . implode( ', ', $facts ) . '.' : '' );
		}
		if ( mb_strlen( $long ) <= 160 ) {
			$desc = $long;
		}
		$img = wp_get_attachment_image_url( PSR_DB::cover( $v ), 'large' );
		echo '<meta name="description" content="' . esc_attr( $desc ) . "\">\n";
		echo '<link rel="canonical" href="' . esc_url( self::url( $v ) ) . "\">\n";
		echo '<meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1">' . "\n";
		echo '<meta property="og:type" content="article"><meta property="og:title" content="' . esc_attr( PSR_DB::title( $v ) ) . '"><meta property="og:description" content="' . esc_attr( $desc ) . '"><meta property="og:url" content="' . esc_url( self::url( $v ) ) . '">';
		if ( $img ) {
			echo '<meta property="og:image" content="' . esc_url( $img ) . '"><meta name="twitter:card" content="summary_large_image">';
		}
		echo "\n";
		$ld = array(
			'@context'     => 'https://schema.org',
			'@type'        => 'Car',
			'name'         => PSR_DB::title( $v ),
			'description'  => $desc,
			'brand'        => array( '@type' => 'Brand', 'name' => $v->make ),
			'model'        => $v->model,
			'vehicleModelDate' => $v->year ? (string) $v->year : null,
			'color'        => $v->exterior_color ? $v->exterior_color : null,
			'bodyType'     => $v->body ? $v->body : null,
			'fuelType'     => $v->fuel ? $v->fuel : null,
			'image'        => $img ? $img : null,
			'url'          => self::url( $v ),
		);
		echo '<script type="application/ld+json">' . wp_json_encode( array_filter( $ld ) ) . "</script>\n";
	}

	/* ---------------------------------------------------------- helpers */

	public static function img( $id, $size = 'large', $attr = array() ) {
		if ( ! $id ) {
			return '<span class="psr-noimg"></span>';
		}
		$attr = wp_parse_args( $attr, array( 'loading' => 'lazy', 'decoding' => 'async' ) );
		return wp_get_attachment_image( $id, $size, false, $attr );
	}

	public static function status_label( $s ) {
		return PSR_DB::STATUSES[ $s ] ?? ucfirst( $s );
	}

	public static function km( $v ) {
		if ( null === $v->mileage_km || '' === $v->mileage_km ) {
			return '';
		}
		return 0 === (int) $v->mileage_km ? __( 'Delivery mileage', 'pentarch-showroom' ) : number_format_i18n( (int) $v->mileage_km ) . ' km';
	}

	public static function price( $v ) {
		// Laqim curates and showcases; prices are kept for records only and never shown.
		return apply_filters( 'psr_public_price', '', $v );
	}

	public static function whatsapp( $text = '' ) {
		$n = preg_replace( '/\D/', '', (string) psr_settings( 'whatsapp' ) );
		if ( ! $n ) {
			return '';
		}
		return 'https://wa.me/' . $n . ( $text ? '?text=' . rawurlencode( $text ) : '' );
	}

	public static function icon( $name ) {
		$i = array(
			'arrow' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>',
			'left'  => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M19 12H5M11 6l-6 6 6 6" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>',
			'wa'    => '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Zm0 18.2a8.2 8.2 0 0 1-4.2-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2Zm4.5-6.1c-.2-.1-1.5-.7-1.7-.8s-.4-.1-.6.1-.7.8-.8 1-.3.2-.5.1a6.7 6.7 0 0 1-3.3-2.9c-.3-.4.2-.4.7-1.4.1-.2 0-.3 0-.4l-.8-1.8c-.2-.5-.4-.4-.6-.4h-.5a1 1 0 0 0-.7.3 3 3 0 0 0-.9 2.2 5.2 5.2 0 0 0 1.1 2.7 11.8 11.8 0 0 0 4.5 4c1.7.7 2.3.8 3.1.7a2.7 2.7 0 0 0 1.8-1.3 2.2 2.2 0 0 0 .2-1.3c-.1-.1-.3-.2-.5-.3Z"/></svg>',
			'phone' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>',
			'expand'=> '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>',
		);
		return $i[ $name ] ?? '';
	}

	/* -------------------------------------------------------------- card */

	public static $chip_sprite = false;

	public static function chip_icons() {
		return array(
			'year'  => '<svg viewBox="0 0 24 24"><rect x="4" y="5" width="16" height="15" rx="2" fill="none" stroke="currentColor" stroke-width="1.5"/><path d="M4 10h16M9 3v4M15 3v4" stroke="currentColor" stroke-width="1.5"/></svg>',
			'gear'  => '<svg viewBox="0 0 24 24"><path d="M6 4v16M12 4v16M18 4v8M6 12h12" fill="none" stroke="currentColor" stroke-width="1.5"/></svg>',
			'drive' => '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8" fill="none" stroke="currentColor" stroke-width="1.5"/><circle cx="12" cy="12" r="2.5" fill="none" stroke="currentColor" stroke-width="1.5"/><path d="M12 4v5.5M5 15l5-2M19 15l-5-2" stroke="currentColor" stroke-width="1.5"/></svg>',
			'fuel'  => '<svg viewBox="0 0 24 24"><path d="M5 20V5a1 1 0 0 1 1-1h7a1 1 0 0 1 1 1v15M3 20h13M14 9h2l2 2v6a1.5 1.5 0 0 0 3 0V8l-3-3" fill="none" stroke="currentColor" stroke-width="1.5"/><path d="M7 7h5v4H7z" fill="none" stroke="currentColor" stroke-width="1.5"/></svg>',
			'seats' => '<svg viewBox="0 0 24 24"><path d="M8 3h5l1 9H8zM7 12h9l2 5H7zM8 17v4M16 17v4" fill="none" stroke="currentColor" stroke-width="1.5"/></svg>',
			'eng'   => '<svg viewBox="0 0 24 24"><path d="M4 10h2V8h3V6h6v2h2l2 3h2v5h-2l-2 2H9l-3-3H4z" fill="none" stroke="currentColor" stroke-width="1.5"/></svg>',
		);
	}

	/** Print the spec-chip icon sprite once per page (footer). */
	public static function print_chip_sprite() {
		if ( ! self::$chip_sprite ) {
			return;
		}
		$o = '<svg xmlns="http://www.w3.org/2000/svg" style="position:absolute;width:0;height:0;overflow:hidden" aria-hidden="true">';
		foreach ( self::chip_icons() as $k => $svg ) {
			$o .= '<symbol id="psr-ic-' . $k . '" viewBox="0 0 24 24">' . preg_replace( '#^<svg[^>]*>|</svg>$#', '', $svg ) . '</symbol>';
		}
		echo $o . '</svg>'; // phpcs:ignore
	}

	public static function spec_chips( $v ) {
		self::$chip_sprite = true;
		$st    = self::stats( $v );
		$trans = $v->transmission ? ( preg_match( '/CVT/i', $v->transmission ) ? 'CVT' : ( preg_match( '/dual|PDK|DCT/i', $v->transmission ) ? 'Dual-clutch' : ( preg_match( '/^\d-speed manual or/i', $v->transmission ) ? 'Manual' : ( preg_match( '/automated|sequential|SMG/i', $v->transmission ) ? 'Sequential' : ( preg_match( '/manual/i', $v->transmission ) ? 'Manual' : ( preg_match( '/single|direct|1-speed/i', $v->transmission ) ? 'Single-speed' : 'Automatic' ) ) ) ) ) ) : '';
		$drive = $v->drivetrain ? ( preg_match( '/2WD/i', $v->drivetrain ) ? '2WD' : ( preg_match( '/4WD|4MATIC|all-wheel|AWD|4x4/i', $v->drivetrain ) ? ( preg_match( '/4WD/i', $v->drivetrain ) ? '4WD' : 'AWD' ) : ( preg_match( '/rear|RWD/i', $v->drivetrain ) ? 'RWD' : ( preg_match( '/front|FWD/i', $v->drivetrain ) ? 'FWD' : $v->drivetrain ) ) ) ) : '';
		$fuel  = $v->fuel ? trim( preg_replace( '/\s*\(.*\)/', '', $v->fuel ) ) : '';
		$chips = array_filter(
			array(
				'year'  => $v->year ? (string) $v->year : '',
				'gear'  => $trans,
				'drive' => $drive,
				'fuel'  => $fuel,
				'seats' => $v->seats ? $v->seats . ' seats' : '',
				'eng'   => $st['l'] ? number_format( $st['l'], 1 ) . 'L' . ( $st['cyl'] ? ' · ' . ( $st['cyl'] >= 8 ? 'V' : '' ) . $st['cyl'] . ( $st['cyl'] < 8 ? ' cyl' : '' ) : '' ) : '',
			)
		);
		$out = '<ul class="psr-specs">';
		foreach ( array_slice( $chips, 0, 6, true ) as $k => $t ) {
			$out .= '<li><svg viewBox="0 0 24 24" aria-hidden="true"><use href="#psr-ic-' . $k . '"></use></svg><span>' . esc_html( $t ) . '</span></li>';
		}
		return $out . '</ul>';
	}

	public static function card( $v, $class = '' ) {
		$m     = PSR_DB::media( $v->id );
		$cover = PSR_DB::cover( $v );
		$alt   = 0;
		foreach ( $m as $x ) {
			if ( (int) $x->attachment_id !== $cover ) {
				$alt = (int) $x->attachment_id;
				break;
			}
		}
		$data  = array(
			'id'     => (int) $v->id,
			'make'   => $v->make,
			'body'   => $v->body,
			'status' => $v->status,
			'year'   => (int) $v->year,
			'name'   => strtolower( PSR_DB::title( $v ) . ' ' . $v->variant . ' ' . $v->exterior_color ),
		);
		$attrs = '';
		foreach ( $data as $k => $val ) {
			$attrs .= ' data-' . $k . '="' . esc_attr( $val ) . '"';
		}
		ob_start();
		?>
		<article class="psr-card <?php echo esc_attr( $class ); ?>"<?php echo $attrs; // phpcs:ignore ?>>
			<a class="psr-card__media" href="<?php echo esc_url( self::url( $v ) ); ?>" aria-label="<?php echo esc_attr( PSR_DB::title( $v ) ); ?>">
				<?php echo self::img( $cover, 'large', array( 'class' => 'psr-card__img', 'sizes' => '(max-width:700px) 92vw, 33vw' ) ); // phpcs:ignore ?>
				<?php if ( $alt ) : ?><?php echo self::img( $alt, 'large', array( 'class' => 'psr-card__img psr-card__img--alt', 'sizes' => '(max-width:700px) 92vw, 33vw', 'alt' => '' ) ); // phpcs:ignore ?><?php endif; ?>
				<span class="psr-chip psr-chip--<?php echo esc_attr( $v->status ); ?>"><?php echo esc_html( self::status_label( $v->status ) ); ?></span>
				<span class="psr-card__count"><?php echo (int) count( $m ); ?> photos</span>
				<?php if ( self::model( $v->id ) ) : ?><span class="psr-card__3d">3D</span><?php endif; ?>
			</a>
			<div class="psr-card__body">
				<p class="psr-card__make"><?php echo esc_html( $v->make ); ?></p>
				<h3 class="psr-card__title"><a href="<?php echo esc_url( self::url( $v ) ); ?>"><?php echo esc_html( $v->model ); ?></a></h3>
				<?php if ( $v->variant ) : ?><p class="psr-card__variant"><?php echo esc_html( $v->variant ); ?></p><?php endif; ?>
				<?php echo self::spec_chips( $v ); // phpcs:ignore ?>
				<?php $xx = self::extra( $v->id ); $ss = self::stats( $v ); $perf = array_filter( array( $ss['hp'] ? array( $ss['hp'], 'hp' ) : null, ! empty( $xx['accel'] ) ? array( number_format( $xx['accel'], 1 ), 's 0–100' ) : null, ! empty( $xx['vmax'] ) ? array( $xx['vmax'], 'km/h max' ) : ( ! empty( $xx['torque'] ) ? array( $xx['torque'], 'Nm' ) : null ) ) ); if ( $perf ) : ?>
				<div class="psr-card__perf"><?php foreach ( $perf as $pp ) : ?><span><b><?php echo esc_html( $pp[0] ); ?></b><small><?php echo esc_html( $pp[1] ); ?></small></span><?php endforeach; ?></div>
				<?php endif; ?>
				<div class="psr-card__acts">
					<a class="psr-card__view" href="<?php echo esc_url( self::url( $v ) ); ?>"><span><?php esc_html_e( 'Explore', 'pentarch-showroom' ); ?></span><?php echo self::icon( 'arrow' ); // phpcs:ignore ?></a>
					<button type="button" class="psr-ico" data-fav="<?php echo (int) $v->id; ?>" aria-pressed="false" aria-label="<?php esc_attr_e( 'Save to my garage', 'pentarch-showroom' ); ?>" title="Save to my garage"><svg viewBox="0 0 24 24"><path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z" fill="none" stroke="currentColor" stroke-width="1.6"/></svg></button>
					<button type="button" class="psr-ico" data-cmp="<?php echo (int) $v->id; ?>" aria-pressed="false" aria-label="<?php esc_attr_e( 'Add to compare', 'pentarch-showroom' ); ?>" title="Compare"><svg viewBox="0 0 24 24"><path d="M7 4v16M17 4v16M4 8h6M14 16h6" fill="none" stroke="currentColor" stroke-width="1.6"/></svg></button>
				</div>
			</div>
		</article>
		<?php
		return ob_get_clean();
	}

	/* -------------------------------------------------------- shortcodes */

	/**
	 * Widest landscape photo of a car (ratio 1.45+), cover photo first.
	 *
	 * @param object $v Vehicle.
	 */
	public static function wide_image( $v ) {
		/* Only the main exterior (cover) photo, and only when it is landscape. */
		$id = (int) PSR_DB::cover( $v );
		$m  = $id ? wp_get_attachment_metadata( $id ) : array();
		if ( ! empty( $m['width'] ) && ! empty( $m['height'] ) && $m['width'] >= 1200 && $m['width'] / $m['height'] >= 1.45 ) {
			return $id;
		}
		return 0;
	}

	/** Phone hero photo: the car's main exterior (cover) photo when it is landscape 4:3-ish; frames the whole car in a taller card. */
	public static function mobile_image( $v, $fallback ) {
		$id = (int) PSR_DB::cover( $v );
		$m  = $id ? wp_get_attachment_metadata( $id ) : array();
		if ( ! empty( $m['width'] ) && ! empty( $m['height'] ) && $m['width'] / $m['height'] >= 1.2 && $m['width'] / $m['height'] <= 1.6 ) {
			return $id;
		}
		return (int) $fallback;
	}

	public static function sc_hero( $atts ) {
		$a  = shortcode_atts( array( 'limit' => 8, 'seconds' => psr_settings( 'hero_seconds' ), 'boxed' => '', 'pick' => '' ), $atts );
		/* Hero uses only wide photos so every car fills the screen without blur or boxing. */
		$vs   = array();
		$wide = array();
		$seen = array();
		if ( $a['pick'] ) { // explicit "vehicleId:attachmentId" pairs, in order
			foreach ( explode( ',', $a['pick'] ) as $pair ) {
				list( $vid, $att ) = array_map( 'intval', array_pad( explode( ':', trim( $pair ) ), 2, 0 ) );
				$v = $vid ? PSR_DB::get( $vid ) : null;
				if ( $v && $att && ! isset( $wide[ $v->id ] ) ) {
					$wide[ $v->id ] = $att;
					$vs[]           = $v;
				}
			}
		}
		$pool = $vs ? array() : PSR_DB::query( array( 'limit' => 100 ) );
		usort( $pool, function ( $x, $y ) { return (int) $y->id - (int) $x->id; } ); // newest (curated supercars) first
		foreach ( $pool as $v ) {
			$key = strtolower( $v->make . '|' . $v->model );
			if ( isset( $wide[ $v->id ] ) || isset( $seen[ $key ] ) || count( $vs ) >= (int) $a['limit'] ) {
				continue;
			}
			$seen[ $key ] = 1;
			$img = self::wide_image( $v );
			if ( $img ) {
				$wide[ $v->id ] = $img;
				$vs[]           = $v;
			}
		}
		if ( ! $vs ) {
			return '';
		}
		ob_start();
		?>
		<section class="psr-hero psr-poster" data-psr-hero data-interval="<?php echo (int) $a['seconds'] * 1000; ?>" aria-roledescription="carousel" aria-label="<?php esc_attr_e( 'Featured cars', 'pentarch-showroom' ); ?>">
			<div class="pp-shade" aria-hidden="true"></div>
			<div class="pp-stage" aria-hidden="true">
				<?php foreach ( $vs as $i => $v ) : ob_start(); ?>
					<figure class="pp-car<?php echo 0 === $i ? ' is-on' : ''; ?>"><picture><?php $mob = self::mobile_image( $v, $wide[ $v->id ] ); if ( $mob ) : ?><source media="(max-width: 900px)" srcset="<?php echo esc_url( wp_get_attachment_image_url( $mob, 'large' ) ); ?>"><?php endif; ?><?php echo wp_get_attachment_image( $wide[ $v->id ], 'full', false, array( 'loading' => 0 === $i ? 'eager' : 'lazy', 'fetchpriority' => 0 === $i ? 'high' : 'low', 'sizes' => '100vw', 'alt' => '' ) ); ?></picture><span class="pp-sheen"></span></figure>
				<?php $fig = ob_get_clean(); echo 0 === $i ? $fig : preg_replace( '/\s(src|srcset)="/', ' data-p$1="', $fig ); // phpcs:ignore -- later slides load just before they show ?>
				<?php endforeach; ?>
				<div class="pp-floor"></div>
			</div>
			<div class="psr-hero__slides">
				<?php
				foreach ( $vs as $i => $v ) :
					$st = self::stats( $v );
					$mini = array_filter( array( $v->year ? $v->year : '', $st['hp'] ? $st['hp'] . ' hp' : '', $st['l'] ? number_format( $st['l'], 1 ) . 'L' . ( $st['cyl'] ? ( $st['cyl'] >= 8 ? ' V' . $st['cyl'] : ' ' . $st['cyl'] . '-cyl' ) : '' ) : '', $v->body ) );
					?>
					<article class="psr-hero__slide<?php echo 0 === $i ? ' is-active' : ''; ?>" aria-roledescription="slide" aria-label="<?php echo esc_attr( ( $i + 1 ) . ' / ' . count( $vs ) ); ?>">
						<p class="psr-hero__eyebrow"><span><?php echo esc_html( $v->make ); ?></span></p>
						<h2 class="psr-hero__title"><span><?php echo esc_html( $v->model ); ?></span></h2>
						<?php if ( $v->tagline ) : ?><p class="psr-hero__line"><?php echo esc_html( $v->tagline ); ?></p><?php endif; ?>
						<ul class="pp-mini"><?php foreach ( $mini as $m ) : ?><li><?php echo esc_html( $m ); ?></li><?php endforeach; ?></ul>
						<a class="psr-hero__cta" href="<?php echo esc_url( self::url( $v ) ); ?>"><span><?php esc_html_e( 'Explore the car', 'pentarch-showroom' ); ?></span><?php echo self::icon( 'arrow' ); // phpcs:ignore ?></a>
					</article>
				<?php endforeach; ?>
			</div>
			<div class="psr-hero__ui">
				<div class="psr-hero__count"><b data-psr-cur>01</b><span>/</span><span><?php echo esc_html( str_pad( (string) count( $vs ), 2, '0', STR_PAD_LEFT ) ); ?></span></div>
				<ol class="psr-hero__nav">
					<?php foreach ( $vs as $i => $v ) : ?>
						<li><button type="button" data-go="<?php echo (int) $i; ?>"<?php echo 0 === $i ? ' aria-current="true"' : ''; ?>><i></i><span><?php echo esc_html( $v->model ); ?></span></button></li>
					<?php endforeach; ?>
				</ol>
				<div class="psr-hero__arrows">
					<button type="button" data-prev aria-label="<?php esc_attr_e( 'Previous', 'pentarch-showroom' ); ?>"><?php echo self::icon( 'left' ); // phpcs:ignore ?></button>
					<button type="button" data-next aria-label="<?php esc_attr_e( 'Next', 'pentarch-showroom' ); ?>"><?php echo self::icon( 'arrow' ); // phpcs:ignore ?></button>
				</div>
			</div>
		</section>
		<?php
		return ob_get_clean();
	}

	public static function sc_grid( $atts ) {
		$a  = shortcode_atts(
			array(
				'status'   => '',
				'make'     => '',
				'body'     => '',
				'featured' => '',
				'limit'    => 6,
				'orderby'  => 'curated',
				'layout'   => 'grid',
				'exclude'  => 0,
				'ids'      => '',
			),
			$atts
		);
		if ( $a['ids'] ) {
			$vs = array_values( array_filter( array_map( array( 'PSR_DB', 'get' ), array_map( 'intval', explode( ',', $a['ids'] ) ) ) ) );
		} else {
		$vs = PSR_DB::query(
			array(
				'status'   => $a['status'],
				'make'     => $a['make'],
				'body'     => $a['body'],
				'featured' => '' === $a['featured'] ? null : $a['featured'],
				'limit'    => (int) $a['limit'],
				'orderby'  => $a['orderby'],
				'exclude'  => (int) $a['exclude'],
			)
		);
		}
		if ( ! $vs ) {
			return '';
		}
		$out = '<div class="psr-grid psr-grid--' . esc_attr( $a['layout'] ) . '">';
		foreach ( $vs as $i => $v ) {
			$out .= self::card( $v, 'psr-reveal' );
		}
		return $out . '</div>';
	}

	public static function sc_reel( $atts ) {
		$a  = shortcode_atts( array( 'status' => '', 'limit' => 12 ), $atts );
		$vs = PSR_DB::query( array( 'status' => $a['status'], 'limit' => (int) $a['limit'] ) );
		if ( ! $vs ) {
			return '';
		}
		$out = '<div class="psr-reel" data-psr-reel><div class="psr-reel__track">';
		foreach ( $vs as $v ) {
			$out .= self::card( $v, 'psr-card--reel' );
		}
		$out .= '</div><div class="psr-reel__ctrl"><button type="button" data-reel="-1" aria-label="Previous">' . self::icon( 'left' ) . '</button><button type="button" data-reel="1" aria-label="Next">' . self::icon( 'arrow' ) . '</button></div></div>';
		return $out;
	}

	public static function sc_collection( $atts ) {
		$vs = PSR_DB::query();
		if ( ! $vs ) {
			return '<p class="psr-empty">' . esc_html__( 'The collection is being curated.', 'pentarch-showroom' ) . '</p>';
		}
		$makes  = array();
		$bodies = array();
		$years  = array();
		$counts = array();
		foreach ( $vs as $v ) {
			$makes[ $v->make ]   = ( $makes[ $v->make ] ?? 0 ) + 1;
			if ( $v->body ) {
				$bodies[ $v->body ] = ( $bodies[ $v->body ] ?? 0 ) + 1;
			}
			if ( $v->year ) {
				$years[] = (int) $v->year;
			}
			$counts[ $v->status ] = ( $counts[ $v->status ] ?? 0 ) + 1;
		}
		ksort( $makes );
		ksort( $bodies );
		$ymin = $years ? min( $years ) : 2015;
		$ymax = $years ? max( $years ) : (int) gmdate( 'Y' );
		ob_start();
		?>
		<div class="psr-collection" data-psr-collection>
			<aside class="psr-side" data-psr-side aria-label="<?php esc_attr_e( 'Filters', 'pentarch-showroom' ); ?>">
				<div class="psr-side__head"><b><?php esc_html_e( 'Filter', 'pentarch-showroom' ); ?></b><button type="button" class="psr-side__reset" data-f-reset><?php esc_html_e( 'Reset', 'pentarch-showroom' ); ?></button><button type="button" class="psr-side__close" data-side-close aria-label="Close filters">×</button></div>
				<label class="psr-side__search"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M16 16l5 5" stroke="currentColor" stroke-width="1.6"/></svg><input type="search" data-f-q placeholder="<?php esc_attr_e( 'Search model, colour…', 'pentarch-showroom' ); ?>" aria-label="Search"></label>
				<fieldset<?php echo count( $counts ) < 2 ? ' hidden' : ''; ?>><legend><?php esc_html_e( 'Type', 'pentarch-showroom' ); ?></legend>
					<?php foreach ( PSR_DB::STATUSES as $k => $label ) : if ( empty( $counts[ $k ] ) ) { continue; } ?>
						<label class="psr-check"><input type="checkbox" data-f-status value="<?php echo esc_attr( $k ); ?>"><i></i><span><?php echo esc_html( $label ); ?></span><em><?php echo (int) $counts[ $k ]; ?></em></label>
					<?php endforeach; ?>
				</fieldset>
				<fieldset class="psr-mk"><legend><?php esc_html_e( 'Marque', 'pentarch-showroom' ); ?></legend>
					<?php $mi = 0; foreach ( $makes as $mk => $n ) : $mi++; ?>
						<label class="psr-check<?php echo $mi > 8 ? ' psr-check--more' : ''; ?>"><input type="checkbox" data-f-make value="<?php echo esc_attr( $mk ); ?>"><i></i><span class="psr-mono" aria-hidden="true"><?php echo esc_html( mb_substr( $mk, 0, 1 ) ); ?></span><span><?php echo esc_html( $mk ); ?></span><em><?php echo (int) $n; ?></em></label>
					<?php endforeach; ?>
					<?php if ( count( $makes ) > 8 ) : ?><button type="button" class="psr-mk__more" data-mk-more aria-expanded="false"><span><?php echo esc_html( sprintf( /* translators: %d marques */ __( 'Show all %d marques', 'pentarch-showroom' ), count( $makes ) ) ); ?></span><span hidden><?php esc_html_e( 'Show fewer', 'pentarch-showroom' ); ?></span></button><?php endif; ?>
				</fieldset>
				<fieldset><legend><?php esc_html_e( 'Body', 'pentarch-showroom' ); ?></legend>
					<div class="psr-pills">
					<?php foreach ( $bodies as $bd => $n ) : ?>
						<label class="psr-pill"><input type="checkbox" data-f-body value="<?php echo esc_attr( $bd ); ?>"><span><?php echo esc_html( $bd ); ?> <em><?php echo (int) $n; ?></em></span></label>
					<?php endforeach; ?>
					</div>
				</fieldset>
				<fieldset><legend><?php esc_html_e( 'Model year', 'pentarch-showroom' ); ?></legend>
					<div class="psr-years"><label><span>From</span><input type="number" data-f-ymin min="1950" max="2100" placeholder="<?php echo (int) $ymin; ?>"></label><label><span>To</span><input type="number" data-f-ymax min="1950" max="2100" placeholder="<?php echo (int) $ymax; ?>"></label></div>
					<p class="psr-side__note"><?php esc_html_e( 'Curated Icons have no single year and stay visible.', 'pentarch-showroom' ); ?></p>
				</fieldset>
				<button type="button" class="psr-btn psr-btn--solid psr-side__apply" data-side-close><span><?php esc_html_e( 'Show cars', 'pentarch-showroom' ); ?></span></button>
			</aside>
			<div class="psr-results">
				<h2 class="screen-reader-text psr-sr">Cars in the collection</h2>
				<div class="psr-bar">
					<button type="button" class="psr-bar__filter" data-side-open><svg viewBox="0 0 24 24"><path d="M4 6h16M7 12h10M10 18h4" stroke="currentColor" stroke-width="1.6"/></svg><span><?php esc_html_e( 'Filters', 'pentarch-showroom' ); ?></span><b data-f-n hidden></b></button>
					<p class="psr-found" aria-live="polite"><b data-found><?php echo (int) count( $vs ); ?></b> <?php esc_html_e( 'cars', 'pentarch-showroom' ); ?></p>
					<div class="psr-active" data-f-active></div>
					<label class="psr-sort"><span><?php esc_html_e( 'Sort', 'pentarch-showroom' ); ?></span><select data-f-sort><option value=""><?php esc_html_e( 'Curated order', 'pentarch-showroom' ); ?></option><option value="year"><?php esc_html_e( 'Newest model year', 'pentarch-showroom' ); ?></option><option value="name"><?php esc_html_e( 'Marque A–Z', 'pentarch-showroom' ); ?></option><option value="hp"><?php esc_html_e( 'Most powerful', 'pentarch-showroom' ); ?></option></select></label>
				</div>
				<div class="psr-grid psr-grid--collection" data-psr-items>
					<?php foreach ( $vs as $v ) { $st = self::stats( $v ); echo str_replace( '<article ', '<article data-hp="' . (int) $st['hp'] . '" ', self::card( $v ) ); } // phpcs:ignore ?>
				</div>
				<div class="psr-empty" data-empty hidden><p><?php esc_html_e( 'Nothing matches yet. Know a car that belongs here? Tell us about it.', 'pentarch-showroom' ); ?></p><p class="psr-empty__acts"><button type="button" class="lx-btn lx-btn--gold" data-empty-reset><?php esc_html_e( 'Clear the filters', 'pentarch-showroom' ); ?></button><a class="lx-btn lx-btn--dark" href="<?php echo esc_url( home_url( '/feature-your-car/' ) ); ?>"><?php esc_html_e( 'Feature your car', 'pentarch-showroom' ); ?></a></p></div>
			</div>
			<div class="psr-scrim" data-side-close></div>
		</div>
		<?php
		return ob_get_clean();
	}

	/** Home-page search panel, Khushi-style: marque chips, selects, type checkboxes. */
	public static function sc_finder() {
		$vs = PSR_DB::query();
		if ( ! $vs ) {
			return '';
		}
		$makes  = array();
		$bodies = array();
		$years  = array();
		$counts = array();
		foreach ( $vs as $v ) {
			$makes[ $v->make ] = ( $makes[ $v->make ] ?? 0 ) + 1;
			if ( $v->body ) {
				$bodies[ $v->body ] = 1;
			}
			if ( $v->year ) {
				$years[ (int) $v->year ] = 1;
			}
			$counts[ $v->status ] = ( $counts[ $v->status ] ?? 0 ) + 1;
		}
		ksort( $makes );
		ksort( $bodies );
		krsort( $years );
		ob_start();
		?>
		<form class="psr-finder" data-psr-finder action="<?php echo esc_url( self::collection_url() ); ?>">
			<div class="psr-finder__head"><h2><?php esc_html_e( 'Search the collection', 'pentarch-showroom' ); ?></h2><p><b data-fd-n><?php echo (int) count( $vs ); ?></b> <span data-fd-lbl><?php esc_html_e( 'cars match', 'pentarch-showroom' ); ?></span></p></div>
			<p class="psr-finder__lbl"><?php esc_html_e( 'Browse by marque', 'pentarch-showroom' ); ?></p>
			<div class="psr-finder__chips" role="group" aria-label="Marques">
				<button type="button" class="is-on" data-fd-make=""><span><?php esc_html_e( 'All marques', 'pentarch-showroom' ); ?></span><em><?php echo (int) count( $vs ); ?></em></button>
				<?php foreach ( $makes as $mk => $n ) : ?><button type="button" data-fd-make="<?php echo esc_attr( $mk ); ?>"><i class="psr-mono" aria-hidden="true"><?php echo esc_html( mb_substr( $mk, 0, 1 ) ); ?></i><span><?php echo esc_html( $mk ); ?></span><em><?php echo (int) $n; ?></em></button><?php endforeach; ?>
			</div>
			<div class="psr-finder__row">
				<label><span class="screen-reader-text">Body</span><select data-fd-body><option value=""><?php esc_html_e( 'Any body style', 'pentarch-showroom' ); ?></option><?php foreach ( array_keys( $bodies ) as $b ) : ?><option><?php echo esc_html( $b ); ?></option><?php endforeach; ?></select></label>
				<label><span class="screen-reader-text">From year</span><select data-fd-ymin><option value=""><?php esc_html_e( 'From year', 'pentarch-showroom' ); ?></option><?php foreach ( array_keys( $years ) as $y ) : ?><option><?php echo (int) $y; ?></option><?php endforeach; ?></select></label>
				<label><span class="screen-reader-text">To year</span><select data-fd-ymax><option value=""><?php esc_html_e( 'To year', 'pentarch-showroom' ); ?></option><?php foreach ( array_keys( $years ) as $y ) : ?><option><?php echo (int) $y; ?></option><?php endforeach; ?></select></label>
				<label class="psr-finder__q"><span class="screen-reader-text">Keyword</span><input type="search" data-fd-q placeholder="<?php esc_attr_e( 'Model or keyword, e.g. G 63', 'pentarch-showroom' ); ?>"></label>
			</div>
			<p class="psr-finder__lbl"<?php echo count( $counts ) < 2 ? ' hidden' : ''; ?>><?php esc_html_e( 'Type', 'pentarch-showroom' ); ?></p>
			<div class="psr-finder__types"<?php echo count( $counts ) < 2 ? ' hidden' : ''; ?>>
				<?php foreach ( PSR_DB::STATUSES as $k => $label ) : if ( empty( $counts[ $k ] ) ) { continue; } ?>
					<label class="psr-check psr-check--box"><input type="checkbox" data-fd-status value="<?php echo esc_attr( $k ); ?>"><i></i><span><?php echo esc_html( $label ); ?></span><em><?php echo (int) $counts[ $k ]; ?></em></label>
				<?php endforeach; ?>
			</div>
			<div class="psr-finder__go"><button type="submit" class="psr-btn psr-btn--solid"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M16 16l5 5" stroke="currentColor" stroke-width="1.6"/></svg><span><?php esc_html_e( 'Search cars', 'pentarch-showroom' ); ?></span></button><button type="button" class="psr-btn" data-fd-surprise><span><?php esc_html_e( 'Surprise me', 'pentarch-showroom' ); ?></span></button></div>
		</form>
		<?php
		return ob_get_clean();
	}

	/** Dark spotlight band: one featured car, framed, with spec tags. */
	public static function sc_spotlight() {
		$vs = PSR_DB::query( array( 'featured' => 1, 'limit' => 1, 'orderby' => 'random' ) );
		if ( ! $vs ) {
			$vs = PSR_DB::query( array( 'limit' => 1, 'orderby' => 'random' ) );
		}
		if ( ! $vs ) {
			return '';
		}
		$v    = $vs[0];
		$tags = array_filter( array( $v->year ? $v->year : '', $v->body, $v->engine, $v->power, $v->drivetrain ) );
		ob_start();
		?>
		<div class="lx-spot">
			<div class="lx-spot__frame lx-reveal"><span class="lx-spot__dots"><i></i><i></i><i></i></span><a href="<?php echo esc_url( self::url( $v ) ); ?>"><?php echo self::img( PSR_DB::cover( $v ), 'full', array( 'sizes' => '(max-width:900px) 100vw, 55vw' ) ); // phpcs:ignore ?></a></div>
			<div class="lx-spot__txt lx-reveal">
				<p class="lx-eyebrow"><?php echo esc_html( $v->make . ' · ' . ( $v->body ? $v->body : 'Spotlight' ) ); ?></p>
				<h3><?php echo esc_html( $v->model ); ?></h3>
				<?php if ( $v->tagline ) : ?><p class="lx-spot__lead"><?php echo esc_html( $v->tagline ); ?></p><?php endif; ?>
				<ul class="lx-tags"><?php foreach ( $tags as $t ) : ?><li><?php echo esc_html( $t ); ?></li><?php endforeach; ?></ul>
				<p class="lx-spot__links"><a href="<?php echo esc_url( self::url( $v ) ); ?>">See the full feature <span>→</span></a><button type="button" data-cmp="<?php echo (int) $v->id; ?>">Add to compare <span>⇄</span></button></p>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/** Rounded marque tiles with a car photo, numbered, Johms-style. */
	public static function sc_tiles( $atts ) {
		$a     = shortcode_atts( array( 'limit' => 6, 'order' => 'count' ), $atts );
		$seen  = array();
		$tiles = array();
		foreach ( PSR_DB::query() as $v ) {
			if ( isset( $seen[ $v->make ] ) ) {
				$seen[ $v->make ]['n']++;
				continue;
			}
			$seen[ $v->make ] = array( 'v' => $v, 'n' => 1 );
		}
		if ( 'prestige' === $a['order'] ) {
			$rank = array_flip( array( 'Rolls-Royce', 'Ferrari', 'Lamborghini', 'Bentley', 'Aston Martin', 'Porsche', 'Mercedes-Maybach', 'Mercedes-AMG', 'Land Rover', 'Mercedes-Benz', 'Lexus', 'Toyota' ) );
			uksort( $seen, function ( $x, $y ) use ( $rank ) { return ( $rank[ $x ] ?? 99 ) - ( $rank[ $y ] ?? 99 ); } );
		} else {
			uasort( $seen, function ( $x, $y ) { return $y['n'] - $x['n']; } );
		}
		$i   = 0;
		$out = '<div class="lx-tiles">';
		foreach ( array_slice( $seen, 0, (int) $a['limit'], true ) as $make => $row ) {
			$i++;
			$out .= '<a class="lx-tile lx-reveal" href="' . esc_url( self::collection_url( 'make=' . rawurlencode( $make ) ) ) . '">' . self::img( PSR_DB::cover( $row['v'] ), 'large' ) . '<span class="lx-tile__n">' . sprintf( '%02d', $i ) . '</span><span class="lx-tile__t">' . esc_html( $make ) . '<small>' . (int) $row['n'] . ( 1 === $row['n'] ? ' car' : ' cars' ) . '</small></span><span class="lx-tile__go">↗</span></a>';
		}
		return $out . '</div>';
	}

	/** Walkable 3D showroom (Three.js, loaded on demand). */
	/** Extended profile data (data/extra.php). */
	public static function extra( $id ) {
		static $all = null;
		if ( null === $all ) {
			$all = is_readable( PSR_DIR . 'data/extra.php' ) ? include PSR_DIR . 'data/extra.php' : array();
		}
		if ( isset( $all[ (int) $id ] ) ) {
			return $all[ (int) $id ];
		}
		static $memo = array();
		if ( ! array_key_exists( (int) $id, $memo ) ) {
			$v                    = PSR_DB::get( (int) $id );
			$memo[ (int) $id ] = ( $v && $v->source_ref && isset( $all[ $v->source_ref ] ) ) ? $all[ $v->source_ref ] : array();
		}
		return $memo[ (int) $id ];
	}

	/** Rich profile section for a car page. */
	public static function profile_block( $v ) {
		$x  = self::extra( $v->id );
		$st = self::stats( $v );
		if ( ! $x && ! $st['hp'] ) {
			return '';
		}
		/* collection ranges for the comparison bars */
		$all = PSR_DB::query( array( 'limit' => 200 ) );
		$max = array( 'hp' => 1, 'tq' => 1, 'vmax' => 1 );
		$min = array( 'acc' => 99 );
		$lst = array( 'acc' => array(), 'vmax' => array(), 'hp' => array(), 'tq' => array() );
		foreach ( $all as $o ) {
			$so = self::stats( $o ); $xo = self::extra( $o->id );
			if ( ! empty( $xo['accel'] ) ) { $lst['acc'][] = (float) $xo['accel']; }
			if ( ! empty( $xo['vmax'] ) ) { $lst['vmax'][] = (int) $xo['vmax']; }
			if ( ! empty( $so['hp'] ) ) { $lst['hp'][] = (int) $so['hp']; }
			if ( ! empty( $xo['torque'] ) ) { $lst['tq'][] = (int) $xo['torque']; }
			$max['hp']   = max( $max['hp'], (int) $so['hp'] );
			$max['tq']   = max( $max['tq'], (int) ( $xo['torque'] ?? 0 ) );
			$max['vmax'] = max( $max['vmax'], (int) ( $xo['vmax'] ?? 0 ) );
			if ( ! empty( $xo['accel'] ) ) { $min['acc'] = min( $min['acc'], (float) $xo['accel'] ); }
		}
		$big = array();
		if ( ! empty( $x['accel'] ) ) { $big[] = array( '0–100 km/h' . ( in_array( 'accel', $x['est'] ?? array(), true ) ? ' (est.)' : '' ), ( in_array( 'accel', $x['est'] ?? array(), true ) ? '≈' : '' ) . number_format( $x['accel'], 1 ), 's', min( 100, round( $min['acc'] / $x['accel'] * 100 ) ) ); }
		if ( ! empty( $x['vmax'] ) ) { $big[] = array( 'Top speed', $x['vmax'], 'km/h', round( $x['vmax'] / $max['vmax'] * 100 ) ); }
		if ( $st['hp'] ) { $big[] = array( 'Power', $st['hp'], 'hp', round( $st['hp'] / $max['hp'] * 100 ) ); }
		if ( ! empty( $x['torque'] ) ) { $big[] = array( 'Torque', $x['torque'], 'Nm', round( $x['torque'] / $max['tq'] * 100 ) ); }
		/* rank line under each bar: "12th of 128 · best 1.8 s" */
		$ord = function ( $n ) { $n = (int) $n; $t = $n % 100; $sfx = ( $t >= 11 && $t <= 13 ) ? 'th' : ( array( 'th', 'st', 'nd', 'rd' )[ $n % 10 ] ?? 'th' ); return $n . $sfx; };
		$rk = function ( $k, $val, $low, $unit ) use ( $lst, $ord ) {
			$l = $lst[ $k ]; if ( ! $l ) { return ''; }
			$r = 1; foreach ( $l as $o ) { if ( $low ? $o < $val : $o > $val ) { $r++; } }
			$best = $low ? min( $l ) : max( $l );
			return $r === 1 ? sprintf( 'Best of %d in the collection', count( $l ) ) : sprintf( '%s of %d · best %s %s', $ord( $r ), count( $l ), $low ? number_format( $best, 1 ) : number_format( $best ), $unit );
		};
		$rks = array();
		if ( ! empty( $x['accel'] ) ) { $rks[] = $rk( 'acc', (float) $x['accel'], true, 's' ); }
		if ( ! empty( $x['vmax'] ) ) { $rks[] = $rk( 'vmax', (int) $x['vmax'], false, 'km/h' ); }
		if ( $st['hp'] ) { $rks[] = $rk( 'hp', (int) $st['hp'], false, 'hp' ); }
		if ( ! empty( $x['torque'] ) ) { $rks[] = $rk( 'tq', (int) $x['torque'], false, 'Nm' ); }
		foreach ( $big as $i => $bb ) { $big[ $i ][4] = $rks[ $i ] ?? ''; }
		ob_start();
		?>
		<section class="pf" id="profile">
			<div class="pf__in">
				<?php if ( $big ) : ?>
				<div class="pf__big">
					<?php foreach ( $big as $b ) : ?>
						<div class="pf__num lx-reveal"><small><?php echo esc_html( $b[0] ); ?></small><b data-count="<?php echo esc_attr( $b[1] ); ?>"><?php echo esc_html( $b[1] ); ?></b><em><?php echo esc_html( $b[2] ); ?></em><i class="pf__bar"><i style="--w:<?php echo (int) $b[3]; ?>%"></i></i><span class="pf__vs"><?php echo esc_html( $b[4] ); ?></span></div>
					<?php endforeach; ?>
				</div>
				<div class="pf__cta"><a class="lx-btn lx-btn--gold" href="<?php echo esc_url( home_url( '/play/' ) . '#race=' . (int) $v->id ); ?>">Race the <?php echo esc_html( $v->model ); ?> ⚑</a><a class="lx-btn lx-btn--dark" href="<?php echo esc_url( home_url( '/play/' ) . '#launch=' . (int) $v->id ); ?>">Launch it, you shift</a><?php if ( self::model( $v->id ) ) : ?><a class="lx-btn lx-btn--dark" href="#spin">Spin it in 3D</a><?php endif; ?><?php if ( self::model( $v->id ) ) : ?><a class="lx-btn lx-btn--dark" href="<?php echo esc_url( home_url( '/play/' ) . '#paint=' . (int) $v->id ); ?>">Paint it</a><a class="lx-btn lx-btn--dark" href="<?php echo esc_url( home_url( '/parts/' ) . '#map=' . (int) $v->id ); ?>">Its parts in 3D</a><?php else : ?><a class="lx-btn lx-btn--dark" href="<?php echo esc_url( home_url( '/parts/' ) ); ?>">Parts rarity</a><?php endif; ?><?php $lay = preg_match( '/V12|W12/i', $v->engine ) ? 'v12' : ( preg_match( '/V8/i', $v->engine ) ? 'v8' : ( preg_match( '/911/', $v->model ) ? 'f6' : ( preg_match( '/V6/i', $v->engine ) ? 'v6' : ( preg_match( '/inline-6|inline 6|I6/i', $v->engine ) ? 'v6' : 'i4' ) ) ) ); ?><a class="lx-btn lx-btn--dark" href="<?php echo esc_url( home_url( '/lab/' ) . '#engine=' . $lay ); ?>">Its engine in 3D</a><a class="lx-btn lx-btn--dark" href="<?php echo esc_url( home_url( '/lab/' ) . '#build=' . (int) $v->id ); ?>">Rebuild its engine</a><button type="button" class="lx-btn lx-btn--dark" data-psr-print>Print the spec sheet</button><button type="button" class="lx-btn lx-btn--dark" data-hear-car="<?php echo (int) $v->id; ?>">🔊 Hear it rev</button></div>
				<?php endif; ?>
				<div class="pf__grid">
					<div class="pf__story lx-reveal">
						<p class="lx-eyebrow">The story</p>
						<h2 class="v-h2"><?php echo esc_html( $v->make ); ?> <em><?php echo esc_html( $v->model ); ?></em></h2>
						<?php foreach ( (array) ( $x['story'] ?? array() ) as $para ) : ?><p><?php echo esc_html( $para ); ?></p><?php endforeach; ?>
						<dl class="pf__meta">
							<?php foreach ( array( 'Generation' => $x['gen'] ?? '', 'Built in' => $x['built'] ?? '', 'Gearbox' => $x['gearbox'] ?? $v->transmission, 'Kerb weight' => ! empty( $x['weight'] ) ? number_format( $x['weight'] ) . ' kg' : '' ) as $k => $val ) : if ( ! $val ) { continue; } ?>
								<div><dt><?php echo esc_html( $k ); ?></dt><dd><?php echo esc_html( $val ); ?></dd></div>
							<?php endforeach; ?>
						</dl>
					</div>
					<?php if ( ! empty( $x['score'] ) ) : $labels = array( 'Comfort', 'Pace', 'Off-road', 'Tech', 'Presence' ); ?>
					<div class="pf__radar lx-reveal">
						<p class="lx-eyebrow">Character</p>
						<svg viewBox="-130 -125 260 250" class="pf__svg" aria-label="Character rating">
							<?php for ( $ring = 1; $ring <= 5; $ring++ ) : $pts = array(); for ( $i = 0; $i < 5; $i++ ) { $a = -M_PI / 2 + $i * 2 * M_PI / 5; $r = $ring * 18; $pts[] = round( cos( $a ) * $r, 1 ) . ',' . round( sin( $a ) * $r, 1 ); } ?>
								<polygon points="<?php echo esc_attr( implode( ' ', $pts ) ); ?>" class="pf__ring"/>
							<?php endfor; ?>
							<?php $pts = array(); foreach ( $x['score'] as $i => $sc ) { $a = -M_PI / 2 + $i * 2 * M_PI / 5; $r = $sc * 9; $pts[] = round( cos( $a ) * $r, 1 ) . ',' . round( sin( $a ) * $r, 1 ); } ?>
							<polygon points="<?php echo esc_attr( implode( ' ', $pts ) ); ?>" class="pf__shape"/>
							<?php foreach ( $labels as $i => $lb ) : $a = -M_PI / 2 + $i * 2 * M_PI / 5; ?>
								<text x="<?php echo esc_attr( round( cos( $a ) * 112, 1 ) ); ?>" y="<?php echo esc_attr( round( sin( $a ) * 108 + 4, 1 ) ); ?>" class="pf__lbl"><?php echo esc_html( $lb . ' ' . $x['score'][ $i ] ); ?></text>
							<?php endforeach; ?>
						</svg>
					</div>
					<?php endif; ?>
				</div>
				<?php if ( ! empty( $x['length'] ) ) : $L = (int) $x['length']; $H = (int) ( $x['height'] ?? 0 ); $WB = (int) ( $x['wheelbase'] ?? 0 ); $tall = $H > 1650; ?>
				<div class="pf__dims lx-reveal">
					<p class="lx-eyebrow">Dimensions</p>
					<svg viewBox="-30 0 1070 335" class="pf__dsvg" aria-label="Dimensions drawing">
						<?php if ( $tall ) : ?>
							<path class="pf__car" d="M110 250 L110 175 Q112 150 140 146 L230 140 L300 78 Q312 66 340 64 L700 62 Q735 62 752 82 L815 142 L880 152 Q905 157 905 185 L905 250"/>
						<?php else : ?>
							<path class="pf__car" d="M95 250 L95 205 Q98 186 130 180 L285 165 Q360 105 450 100 L640 100 Q700 102 760 160 L870 178 Q910 186 910 215 L910 250"/>
						<?php endif; ?>
						<line x1="80" y1="250" x2="925" y2="250" class="pf__ground"/>
						<circle cx="245" cy="250" r="48" class="pf__wheel"/><circle cx="760" cy="250" r="48" class="pf__wheel"/>
						<circle cx="245" cy="250" r="20" class="pf__hub"/><circle cx="760" cy="250" r="20" class="pf__hub"/>
						<g class="pf__dim"><line x1="95" y1="300" x2="910" y2="300"/><path d="M95 292v16M910 292v16"/><text x="502" y="322"><?php echo esc_html( number_format( $L ) ); ?> mm long</text></g>
						<?php if ( $WB ) : ?><g class="pf__dim pf__dim--gold"><line x1="245" y1="276" x2="760" y2="276"/><path d="M245 268v16M760 268v16"/><text x="502" y="270"><?php echo esc_html( number_format( $WB ) ); ?> mm wheelbase</text></g><?php endif; ?>
						<?php if ( $H ) : ?><g class="pf__dim"><line x1="955" y1="<?php echo $tall ? 62 : 100; ?>" x2="955" y2="250"/><path d="M947 <?php echo $tall ? 62 : 100; ?>h16M947 250h16"/><text x="955" y="<?php echo $tall ? 50 : 88; ?>" text-anchor="middle"><?php echo esc_html( number_format( $H ) ); ?> mm</text></g><?php endif; ?>
						<?php if ( ! empty( $x['width'] ) ) : ?><text x="80" y="40" class="pf__w">Width <?php echo esc_html( number_format( (int) $x['width'] ) ); ?> mm</text><?php endif; ?>
					</svg>
				</div>
				<?php endif; ?>
				<div class="pf__acc lx-reveal" data-psr-accel="<?php echo (int) $v->id; ?>"></div>
				<?php if ( ! empty( $x['facts'] ) ) : ?>
				<div class="pf__facts">
					<?php foreach ( $x['facts'] as $i => $f ) : ?><div class="pf__fact lx-reveal"><span><?php echo esc_html( str_pad( (string) ( $i + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span><p><?php echo esc_html( $f ); ?></p></div><?php endforeach; ?>
				</div>
				<?php endif; ?>
				<?php if ( ! empty( $x['rivals'] ) ) : ?>
				<div class="pf__rivals">
					<p class="lx-eyebrow">Rivals in the collection</p>
					<div class="pf__rgrid">
					<?php foreach ( $x['rivals'] as $rid ) : $r = PSR_DB::get( $rid ); if ( ! $r ) { continue; } $rs = self::stats( $r ); ?>
						<a class="pf__rival lx-reveal" href="<?php echo esc_url( self::url( $r ) ); ?>"><?php echo self::img( PSR_DB::cover( $r ), 'medium_large' ); // phpcs:ignore ?><span><small><?php echo esc_html( $r->make ); ?></small><b><?php echo esc_html( $r->model ); ?></b><em><?php echo $rs['hp'] ? esc_html( $rs['hp'] . ' hp' ) : ''; ?></em></span><i class="pf__duel" data-href="<?php echo esc_url( home_url( '/play/' ) . '#race=' . (int) $v->id . ',' . (int) $r->id ); ?>">Race it ⚑</i></a>
					<?php endforeach; ?>
					</div>
				</div>
				<?php endif; ?>
			</div>
		</section>
		<?php
		return ob_get_clean();
	}

	/** 3D model registry: option psr_models = { vehicleId: {url,name,author,profile,license,page} }. */
	public static function model( $id ) {
		static $memo = array();
		$id = (int) $id;
		if ( array_key_exists( $id, $memo ) ) {
			return $memo[ $id ];
		}
		$all = get_option( 'psr_models', array() );
		$m   = isset( $all[ $id ] ) && ! empty( $all[ $id ]['url'] ) ? $all[ $id ] : null;
		if ( $m && get_option( 'psr_glbgz_ok' ) ) {
			$gz = self::glb_gz( $m['url'] );
			if ( $gz ) {
				$m['url'] = $gz;
				$p        = self::glb_paths( $all[ $id ]['url'] );
				$m['mb']  = $p ? round( filesize( $p[1] ) / 1048576 ) : 0;
			}
		}
		return $memo[ $id ] = $m;
	}

	/** Paths for the pre-compressed copy of an uploaded 3D model: array( src, gz file, gz url ) or null. */
	public static function glb_paths( $url ) {
		$up = wp_upload_dir();
		if ( ! empty( $up['error'] ) ) {
			return null;
		}
		$base = preg_replace( '#^https?:#', '', trailingslashit( $up['baseurl'] ) );
		$u    = preg_replace( '#^https?:#', '', strtok( (string) $url, '?' ) );
		if ( 0 !== strpos( $u, $base ) ) {
			return null;
		}
		$rel = substr( $u, strlen( $base ) );
		if ( false !== strpos( $rel, '..' ) || ! preg_match( '/\.glb$/i', $rel ) ) {
			return null;
		}
		$name = sanitize_file_name( basename( $rel ) ) . '.gz';
		$orig = strtok( (string) $url, '?' ); /* keep the model's own scheme and host */
		return array( trailingslashit( $up['basedir'] ) . $rel, trailingslashit( $up['basedir'] ) . 'psr/glb/' . $name, substr( $orig, 0, strlen( $orig ) - strlen( $rel ) ) . 'psr/glb/' . $name );
	}

	/** URL of a ready, up-to-date gzip copy of the model, or ''. */
	public static function glb_gz( $url ) {
		$p = self::glb_paths( $url );
		if ( ! $p || ! file_exists( $p[1] ) || ! file_exists( $p[0] ) || filemtime( $p[1] ) < filemtime( $p[0] ) ) {
			return '';
		}
		return $p[2];
	}

	/** Build gzip copies of the 3D models, a few per call. */
	public static function glb_build( $budget = 20 ) {
		$t0  = microtime( true );
		$up  = wp_upload_dir();
		$dir = trailingslashit( $up['basedir'] ) . 'psr/glb';
		if ( ! wp_mkdir_p( $dir ) ) {
			return array( 'error' => 'mkdir' );
		}
		$ht = "<IfModule mod_mime.c>\nAddEncoding gzip .gz\nAddType model/gltf-binary .glb\n</IfModule>\n<IfModule mod_expires.c>\nExpiresActive On\nExpiresDefault \"access plus 1 year\"\n</IfModule>\n<IfModule mod_headers.c>\nHeader always set Cache-Control \"public, max-age=31536000, immutable\"\n</IfModule>\n";
		if ( ! file_exists( $dir . '/.htaccess' ) || file_get_contents( $dir . '/.htaccess' ) !== $ht ) { // phpcs:ignore
			file_put_contents( $dir . '/.htaccess', $ht ); // phpcs:ignore
		}
		$done = 0;
		$left = 0;
		$saved = 0;
		foreach ( (array) get_option( 'psr_models', array() ) as $m ) {
			if ( empty( $m['url'] ) ) {
				continue;
			}
			$p = self::glb_paths( $m['url'] );
			if ( ! $p || ! file_exists( $p[0] ) || ( file_exists( $p[1] ) && filemtime( $p[1] ) >= filemtime( $p[0] ) ) ) {
				continue;
			}
			if ( microtime( true ) - $t0 > $budget ) {
				$left++;
				continue;
			}
			$raw = file_get_contents( $p[0] ); // phpcs:ignore
			$gz  = gzencode( $raw, 6 );
			if ( $gz && strlen( $gz ) < strlen( $raw ) ) {
				file_put_contents( $p[1] . '.tmp', $gz ); // phpcs:ignore
				rename( $p[1] . '.tmp', $p[1] );
				$saved += strlen( $raw ) - strlen( $gz );
			} else {
				@unlink( $p[1] ); // phpcs:ignore -- not worth compressing.
			}
			unset( $raw, $gz );
			$done++;
		}
		return array( 'done' => $done, 'left' => $left, 'savedMB' => round( $saved / 1048576, 1 ) );
	}

	public static function credit( $m ) {
		return trim( sprintf( '3D model "%s" by %s (%s), via Sketchfab', $m['name'] ?? '', $m['author'] ?? 'unknown', $m['license'] ?? 'CC BY' ) );
	}

	/** "Spin in 3D" viewer block for a car page. */
	public static function viewer_block( $v ) {
		$m = self::model( $v->id );
		if ( ! $m ) {
			return '';
		}
		$page = ! empty( $m['page'] ) ? '<a href="' . esc_url( $m['page'] ) . '" target="_blank" rel="noopener nofollow">' . esc_html( self::credit( $m ) ) . '</a>' : esc_html( self::credit( $m ) );
		return '<section class="v3d" id="spin"><div class="v3d__head"><p class="lx-eyebrow">Spin in 3D</p><h2 class="lx-h2">Walk around the <em>' . esc_html( $v->model ) . '</em></h2><p class="v3d__tip">Drag to turn · <span class="sr__kb">scroll</span><span class="sr__touch">pinch</span> to zoom<span class="sr__kb"> · right-drag to move</span></p></div>'
			. '<div class="v3d__stage" data-psr-3d="' . esc_url( $m['url'] ) . '"><div class="v3d__load"><span class="sr__ring"></span><p>Loading the 3D model…</p><button type="button" class="lx-btn lx-btn--gold" data-v3d-go>Load 3D model' . ( ! empty( $m['mb'] ) ? ' <small class="v3d__mb">' . (int) max( 1, $m['mb'] ) . ' MB</small>' : '' ) . '</button></div></div>'
			. '<p class="v3d__credit">' . $page . '</p></section>';
	}

	public static function sc_showroom( $atts ) {
		$a = shortcode_atts( array( 'mode' => 'full' ), $atts );
		ob_start();
		?>
		<div class="sr<?php echo 'teaser' === $a['mode'] ? ' sr--teaser' : ''; ?>" data-psr-showroom data-mode="<?php echo esc_attr( $a['mode'] ); ?>">
			<canvas class="sr__canvas" aria-label="3D showroom"></canvas>
			<div class="sr__load" data-sr-load><span class="sr__ring"></span><p>Opening the showroom doors…</p></div>
			<div class="sr__hud">
				<div class="sr__help"><span class="sr__kb"><b>Drag</b> to look · <b>W A S D</b> or arrows to walk · <b>Click</b> a car to open it</span><span class="sr__touch"><b>Drag</b> to look · arrow pad to walk · <b>tap</b> a car to open it</span></div>
				<div class="sr__brands" data-sr-brands role="toolbar" aria-label="Jump to a brand"></div>
				<div class="sr__pad" aria-label="Walk"><button type="button" data-mv="f" aria-label="Forward">▲</button><button type="button" data-mv="l" aria-label="Turn left">◀</button><button type="button" data-mv="b" aria-label="Back">▼</button><button type="button" data-mv="r" aria-label="Turn right">▶</button></div>
				<button type="button" class="sr__fs" data-sr-fs aria-label="Full screen">⤢</button>
				<div class="sr__nav"><?php if ( 'teaser' !== $a['mode'] ) : ?><button type="button" data-sr-tour aria-pressed="false">▶ Guided tour</button><?php endif; ?><button type="button" data-sr-reset>⟲ Reset view</button><a href="<?php echo esc_url( home_url( '/' ) ); ?>" data-sr-exit>Exit showroom ✕</a></div>
			</div>
			<aside class="sr__card" data-sr-card hidden>
				<button type="button" class="sr__x" data-sr-close aria-label="Back to the showroom">×</button>
				<img alt="" data-sr-img>
				<div class="sr__body"><small data-sr-make></small><h3 data-sr-model></h3><p data-sr-tag></p><ul class="sr__specs" data-sr-specs></ul>
				<div class="sr__acts"><button type="button" class="lx-btn lx-btn--dark" data-sr-spin hidden>Spin in 3D</button><a class="lx-btn lx-btn--dark" data-sr-race href="#">Race it ⚑</a><a class="lx-btn lx-btn--gold" data-sr-link href="#">Full feature</a><button type="button" class="psr-ico" data-sr-fav aria-label="Save">♥</button><button type="button" class="psr-ico" data-sr-cmp aria-label="Compare">⇄</button></div></div>
			</aside>
			<div class="sr__modal" data-sr-modal hidden><div class="sr__mstage" data-sr-mstage></div><button type="button" class="sr__x sr__mx" data-sr-mclose aria-label="Close 3D view">×</button><p class="sr__mtip">Drag to turn · scroll to zoom</p><p class="sr__mcred" data-sr-mcred></p></div>
			<?php if ( 'teaser' === $a['mode'] ) : ?><a class="sr__enter lx-btn lx-btn--gold" href="<?php echo esc_url( home_url( '/showroom/' ) ); ?>">Enter the 3D Showroom</a><?php endif; ?>
		</div>
		<?php
		return ob_get_clean();
	}

	/** Car of the day: deterministic daily pick. */
	public static function sc_cotd() {
		$all = array_values( array_filter( PSR_DB::query( array( 'limit' => 300 ) ), function ( $v ) { return (bool) self::extra( $v->id ); } ) );
		if ( ! $all ) { return ''; }
		$v  = $all[ (int) floor( current_time( 'timestamp' ) / DAY_IN_SECONDS ) % count( $all ) ];
		$x  = self::extra( $v->id ); $st = self::stats( $v );
		$img = self::wide_image( $v ) ? self::wide_image( $v ) : PSR_DB::cover( $v );
		$fact = ! empty( $x['facts'] ) ? $x['facts'][ (int) gmdate( 'j' ) % count( $x['facts'] ) ] : '';
		ob_start();
		?>
		<div class="cotd">
			<div class="cotd__img"><?php echo self::img( $img, 'full', array( 'sizes' => '(max-width:900px) 100vw, 60vw' ) ); // phpcs:ignore ?><span class="cotd__badge">Car of the day · <?php echo esc_html( wp_date( 'j M' ) ); ?></span></div>
			<div class="cotd__txt">
				<p class="lx-eyebrow"><?php echo esc_html( $v->make ); ?></p>
				<h2 class="cotd__h"><?php echo esc_html( $v->model ); ?></h2>
				<?php if ( $v->tagline ) : ?><p class="cotd__tag"><?php echo esc_html( $v->tagline ); ?></p><?php endif; ?>
				<div class="cotd__nums">
					<?php foreach ( array_filter( array( $st['hp'] ? array( $st['hp'], 'hp' ) : null, ! empty( $x['torque'] ) ? array( $x['torque'], 'Nm' ) : null, ! empty( $x['accel'] ) ? array( number_format( $x['accel'], 1 ), 's 0–100' ) : null ) ) as $n ) : ?><span><b><?php echo esc_html( $n[0] ); ?></b><small><?php echo esc_html( $n[1] ); ?></small></span><?php endforeach; ?>
				</div>
				<?php if ( $fact ) : ?><p class="cotd__fact"><b>Did you know?</b> <?php echo esc_html( $fact ); ?></p><?php endif; ?>
				<div class="cotd__acts"><a class="lx-btn lx-btn--gold" href="<?php echo esc_url( self::url( $v ) ); ?>">Explore it</a><a class="lx-btn lx-btn--dark" href="<?php echo esc_url( home_url( '/play/' ) . '#race=' . (int) $v->id ); ?>">Race it ⚑</a><?php if ( self::model( $v->id ) ) : ?><a class="lx-btn lx-btn--dark" href="<?php echo esc_url( self::url( $v ) . '#spin' ); ?>">Spin it in 3D</a><?php endif; ?></div>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/** Collection stats band. */
	public static function sc_statband() {
		$all = PSR_DB::query( array( 'limit' => 300 ) );
		$hp = 0; $m3 = 0; $best = 99; $bestc = ''; $makes = array();
		foreach ( $all as $v ) {
			$st = self::stats( $v ); $x = self::extra( $v->id ); $hp += (int) $st['hp']; $makes[ $v->make ] = 1;
			if ( self::model( $v->id ) ) { $m3++; }
			if ( ! empty( $x['accel'] ) && $x['accel'] < $best ) { $best = $x['accel']; $bestc = $v->model; }
		}
		$items = array( array( count( $all ), 'cars in the collection' ), array( count( $makes ), 'marques' ), array( $m3, 'you can spin in 3D' ), array( number_format( $hp ), 'horsepower combined' ) );
		if ( $bestc ) { $items[] = array( number_format( $best, 1 ) . ' s', 'quickest 0–100 · ' . $bestc ); }
		$out = '<div class="sb">';
		foreach ( $items as $it ) { $out .= '<div class="sb__i lx-reveal"><b>' . esc_html( $it[0] ) . '</b><span>' . esc_html( $it[1] ) . '</span></div>'; }
		return $out . '</div>';
	}

	/** Launch control: start lights, reaction time, then the car's real 0-100. */
	public static function sc_launch() {
		return '<div class="lc" data-psr-launch><div class="lc__top"><label class="lc__pick"><span>Your car</span><select data-lc-car aria-label="Car"></select></label><div class="lc__stats"><div><small>Reaction</small><b data-lc-rt>–</b></div><div><small>0–100</small><b data-lc-acc>–</b></div><div><small>Lights to 100</small><b data-lc-tot>–</b></div><div><small>Your best</small><b data-lc-best>–</b></div></div></div>'
			. '<div class="lc__rig"><div class="lc__lights" data-lc-lights><i></i><i></i><i></i><i></i><i></i></div><button type="button" class="lc__pad" data-lc-pad><span data-lc-say>Tap to arm the lights</span><small data-lc-sub>Then tap again the instant they go out. Space bar works too.</small></button>'
			. '<div class="lc__strip"><div class="lc__car" data-lc-car-img></div><div class="lc__road"><i data-lc-bar></i></div><span class="lc__kmh" data-lc-kmh>0 km/h</span></div></div>'
			. '<p class="lc__msg" data-lc-msg>Formula 1 drivers react in about 0.2 seconds. Jump the lights and the run does not count.</p></div>';
	}

	/** Higher or lower: guess the next car's number. */
	public static function sc_hilo() {
		return '<div class="hl" data-psr-hilo><div class="hl__bar"><p class="hl__q" data-hl-q>Which has more power?</p><div class="hl__sc"><div><small>Streak</small><b data-hl-streak>0</b></div><div><small>Best</small><b data-hl-best>0</b></div></div></div>'
			. '<div class="hl__duo"><div class="hl__car" data-hl-a></div><div class="hl__mid"><span>VS</span></div><div class="hl__car hl__car--b" data-hl-b></div></div>'
			. '<div class="hl__act" data-hl-act><button type="button" class="lx-btn lx-btn--gold" data-hl-hi>Higher ▲</button><button type="button" class="lx-btn lx-btn--dark" data-hl-lo>Lower ▼</button></div>'
			. '<p class="hl__msg" data-hl-msg>The right-hand car’s figure is hidden. Higher or lower than the left?</p></div>';
	}

	/** 3D parts rarity heat-map. */
	public static function sc_partsmap() {
		return '<div class="pm" data-psr-partsmap><div class="pm__main"><div class="pm__bar"><label><span>Car</span><select data-pm-car aria-label="Car"></select></label><div class="pm__key"><i style="--c:#3ddc6a"></i>Easy<i style="--c:#f1d27a"></i>Patience<i style="--c:#ff9a3c"></i>Import<i style="--c:#ff4d4d"></i>Rare</div></div>'
			. '<div class="pm__stage" data-pm-stage><div class="pm__dots" data-pm-dots></div><p class="pm__hint">Drag to orbit. Tap a glowing point.</p></div></div><aside class="pm__info" data-pm-info></aside></div>';
	}

	/** Parts rarity league table. */
	public static function sc_league() {
		return '<div class="rl" data-psr-league><ol class="rl__list" data-rl></ol><p class="rl__note">Average of the parts each car actually uses, from the same rarity model as the finder above. A guide for curiosity, not a quote.</p></div>';
	}

	/** Paint Studio: repaint a 3D car. */
	public static function sc_paint() {
		return '<div class="ps" data-psr-paint><div class="ps__main"><div class="ps__stage" data-ps-stage><p class="ps__hint">Drag to orbit · tap any panel to paint that part instead</p><p class="ps__name" data-ps-name></p></div></div>'
			. '<aside class="ps__side"><label class="ps__car"><span>Car</span><select data-ps-car aria-label="Car"></select></label>'
			. '<p class="ps__h">Factory colours</p><div class="ps__sw" data-ps-sw></div>'
			. '<p class="ps__h">Finish</p><div class="ps__seg"><button type="button" data-ps-fin="gloss" aria-pressed="false">Gloss</button><button type="button" data-ps-fin="metallic" aria-pressed="true">Metallic</button><button type="button" data-ps-fin="matte" aria-pressed="false">Matte</button><button type="button" data-ps-fin="chrome" aria-pressed="false">Chrome</button></div>'
			. '<p class="ps__h">Light</p><div class="ps__seg"><button type="button" data-ps-light="studio" aria-pressed="true">Studio</button><button type="button" data-ps-light="sunset" aria-pressed="false">Sunset</button><button type="button" data-ps-light="night" aria-pressed="false">Night</button></div>'
			. '<div class="ps__row"><label class="e3__tg"><input type="checkbox" data-ps-spin checked><span>Turntable</span></label><button type="button" class="lx-btn lx-btn--gold" data-ps-shot>Save a photo</button><button type="button" class="lx-btn fx-share" data-ps-share>Share my spec</button></div></aside></div>';
	}

	/** Size Up: two cars at true scale. */
	public static function sc_sizeup() {
		return '<div class="su" data-psr-sizeup><div class="su__bar"><label><span>Left</span><select data-su-a aria-label="First car"></select></label><span class="su__vs">VS</span><label><span>Right</span><select data-su-b aria-label="Second car"></select></label><div class="ps__seg su__views"><button type="button" data-su-view="side" aria-pressed="true">Side</button><button type="button" data-su-view="front" aria-pressed="false">Front</button><button type="button" data-su-view="top" aria-pressed="false">Top</button><button type="button" data-su-view="free" aria-pressed="false">Free</button></div></div>'
			. '<div class="su__stage" data-su-stage><div class="su__labels" data-su-labels></div></div><div class="su__nums" data-su-nums></div><p class="su__note">Both models are scaled to the manufacturer’s published length, so you are seeing the real difference. The figure is 1.75 m tall.</p></div>';
	}

	/** Performance map: interactive scatter of the collection. */
	public static function sc_hotlap() {
		return '<div class="hl" data-psr-hotlap></div>';
	}

	public static function sc_rally() {
		return '<div class="hl hl--rally" data-psr-hotlap data-rally></div>';
	}

	public static function sc_quiz() {
		return '<div class="qz" data-psr-quiz></div>';
	}

	public static function sc_builder() {
		return '<div class="eb" data-psr-builder></div>';
	}

	public static function sc_perfmap() {
		$ax = array( 'acc' => '0–100 km/h (s)', 'hp' => 'Power (hp)', 'tq' => 'Torque (Nm)', 'vmax' => 'Top speed (km/h)', 'kg' => 'Weight (kg)', 'l' => 'Engine size (L)', 'php' => 'Power to weight (hp/tonne)' );
		$o = function ( $sel ) use ( $ax ) { $h = ''; foreach ( $ax as $k => $l ) { $h .= '<option value="' . esc_attr( $k ) . '"' . ( $k === $sel ? ' selected' : '' ) . '>' . esc_html( $l ) . '</option>'; } return $h; };
		return '<div class="pmap" data-psr-perfmap><div class="pmap__bar"><label><span>Across</span><select data-pm-x>' . $o( 'acc' ) . '</select></label><label><span>Up</span><select data-pm-y>' . $o( 'hp' ) . '</select></label><div class="pmap__key" data-pm-key></div></div>'
			. '<div class="pmap__plot"><svg data-pm-svg viewBox="0 0 1000 560" preserveAspectRatio="xMidYMid meet" role="img" aria-label="Scatter chart of the collection"></svg><div class="pmap__tip" data-pm-tip hidden></div></div><p class="pmap__note" data-pm-note></p></div>';
	}

	/** Stopping distance simulator. */
	public static function sc_brake() {
		return '<div class="bk" data-psr-brake><div class="bk__ctl"><label><span>Car</span><select data-bk-car></select></label>'
			. '<label><span>Speed <b data-bk-sv>80</b> km/h</span><input type="range" min="30" max="200" step="5" value="80" data-bk-speed></label>'
			. '<div class="rc__grp"><p>Surface</p><div><button type="button" data-bk-s="dry" aria-pressed="true">Dry</button><button type="button" data-bk-s="wet" aria-pressed="false">Wet</button><button type="button" data-bk-s="gravel" aria-pressed="false">Gravel</button><button type="button" data-bk-s="snow" aria-pressed="false">Snow</button></div></div>'
			. '<div class="rc__grp"><p>Driver</p><div><button type="button" data-bk-r="0.7" aria-pressed="false">Sharp</button><button type="button" data-bk-r="0.9" aria-pressed="true">Normal</button><button type="button" data-bk-r="1.6" aria-pressed="false">On the phone</button></div></div>'
			. '<button type="button" class="lx-btn lx-btn--gold" data-bk-go>Hit the brakes</button></div>'
			. '<div class="bk__out"><canvas class="bk__cv" data-bk-cv></canvas><div class="bk__nums"><div><small>Thinking</small><b data-bk-react>–</b></div><div><small>Braking</small><b data-bk-brake>–</b></div><div><small>Total</small><b data-bk-tot>–</b></div></div><p class="bk__verdict" data-bk-verdict></p></div></div>';
	}

	/** Every car, one 0-100 drag. */
	public static function sc_drag() {
		return '<div class="da" data-psr-drag><div class="da__bar"><button type="button" class="lx-btn lx-btn--gold" data-da-go>Launch every car</button><span class="da__clock" data-da-t>0.00 s</span></div><div class="da__lanes" data-da-lanes></div></div>';
	}

	/** 3D silhouette guessing game. */
	public static function sc_silhouette() {
		return '<div class="sil" data-psr-sil><div class="sil__stage" data-sil-stage><div class="sil__glow"></div><button type="button" class="lx-btn lx-btn--gold sil__start" data-sil-start>Show me a shadow</button></div><div class="sil__side"><div class="sil__score"><div><small>Streak</small><b data-sil-streak>0</b></div><div><small>Best</small><b data-sil-best>0</b></div></div><p class="sil__msg" data-sil-msg>A real 3D car spins in silhouette. Name it in one guess.</p><div class="sil__opts" data-sil-opts></div><button type="button" class="lx-btn lx-btn--gold" data-sil-next hidden>Next shadow</button></div></div>';
	}

	/** Top Trumps card battle. */
	public static function sc_trumps() {
		return '<div class="tt" data-psr-tt><div class="tt__table"><div class="tt__seat"><p>Your card</p><div class="tt__card" data-tt-you></div></div><div class="tt__mid"><span class="rc__vs">VS</span><p class="tt__score" data-tt-score>Ten rounds. Best stat wins.</p><button type="button" class="lx-btn lx-btn--gold" data-tt-deal>Deal the cards</button><button type="button" class="lx-btn lx-btn--gold" data-tt-next hidden>Next round</button></div><div class="tt__seat"><p>The house</p><div class="tt__card" data-tt-cpu></div></div></div><p class="tt__msg" data-tt-msg>Lower is better for 0–100 and weight. Everything else, bigger wins.</p></div>';
	}

	/** 3D race simulator. */
	public static function sc_race() {
		$conds = array( 'dry' => 'Dry tarmac', 'wet' => 'Wet', 'gravel' => 'Gravel', 'snow' => 'Snow', 'nairobi' => 'Nairobi altitude', 'hot' => 'Hot day', 'night' => 'Night' );
		$ic    = array( 'dry' => '☀', 'wet' => '☂', 'gravel' => '⛰', 'snow' => '❄', 'nairobi' => '▲', 'hot' => '♨', 'night' => '☾' );
		ob_start();
		?>
		<div class="rc" data-psr-race>
			<div class="rc__setup">
				<div class="rc__pick"><label>Lane 1<select data-race-a aria-label="First car"></select></label><div class="rc__card" data-race-ca></div></div>
				<div class="rc__mid"><span class="rc__vs">VS</span><button type="button" class="rc__mini" data-race-swap aria-label="Swap cars">⇄ Swap</button><button type="button" class="rc__mini" data-race-rand>🎲 Random</button></div>
				<div class="rc__pick"><label>Lane 2<select data-race-b aria-label="Second car"></select></label><div class="rc__card rc__card--b" data-race-cb></div></div>
			</div>
			<div class="rc__opts">
				<div class="rc__grp"><p>Conditions</p><div><?php foreach ( $conds as $k => $lb ) : ?><button type="button" data-cond="<?php echo esc_attr( $k ); ?>" aria-pressed="<?php echo 'dry' === $k ? 'true' : 'false'; ?>"><span><?php echo esc_html( $ic[ $k ] ); ?></span><?php echo esc_html( $lb ); ?></button><?php endforeach; ?></div></div>
				<div class="rc__grp"><p>Distance</p><div><button type="button" data-dist="100" aria-pressed="false">0–100 km/h</button><button type="button" data-dist="400" aria-pressed="true">Quarter mile</button><button type="button" data-dist="1000" aria-pressed="false">1 km</button><button type="button" data-dist="80" aria-pressed="false">Overtake 80–120</button></div></div>
				<div class="rc__btns"><button type="button" class="rc__mini rc__mute" data-race-mute aria-pressed="false" onclick="this.setAttribute('aria-pressed',this.getAttribute('aria-pressed')==='true'?'false':'true');this.textContent=this.getAttribute('aria-pressed')==='true'?'🔇 Engine muted':'🔊 Engine sound';">🔊 Engine sound</button><button type="button" class="lx-btn lx-btn--dark rc__tourb" data-race-tour>🏆 8-car tournament</button><button type="button" class="lx-btn lx-btn--gold rc__go" data-race-go>Start the race</button></div>
			</div>
			<div class="rc__stage" data-race-stage>
				<div class="rc__lights" data-race-lights hidden><i></i><i></i><i></i></div>
				<div class="rc__hud" data-race-hud hidden><div><small data-hud-na></small><b data-hud-a>0</b><em>km/h</em><i class="rc__tele" data-hud-ga></i></div><div class="rc__clock" data-hud-t>0.00 s</div><div class="rc__hb"><small data-hud-nb></small><b data-hud-b>0</b><em>km/h</em><i class="rc__tele" data-hud-gb></i></div></div>
				<div class="rc__ld"><span class="sr__ring"></span>Preparing the proving ground…</div>
			</div>
			<div class="rc__res" data-race-res hidden></div>
			<div class="rc__res tour" data-tour-out hidden></div>
		</div>
		<?php
		return ob_get_clean();
	}

	/** Engine simulator + turbo lag demo (canvas). */
	public static function sc_engine( $atts = array() ) {
		$a = shortcode_atts( array( 'mode' => 'full' ), $atts );
		$lays = array( 'i4' => 'Inline-4', 'v6' => 'V6', 'f6' => 'Flat-6', 'v8' => 'V8', 'v12' => 'V12' );
		ob_start();
		?>
		<div class="eng eng--<?php echo esc_attr( $a['mode'] ); ?>" data-psr-engine>
			<div class="e3">
				<div class="e3__main">
					<div class="e3__bar">
						<div class="e3__lays" role="group" aria-label="Engine layout"><?php foreach ( $lays as $k => $lb ) : ?><button type="button" data-e3-lay="<?php echo esc_attr( $k ); ?>" aria-pressed="<?php echo 'v8' === $k ? 'true' : 'false'; ?>"><?php echo esc_html( $lb ); ?></button><?php endforeach; ?></div>
						<button type="button" class="e3__snd" data-e3-snd aria-pressed="false">🔈 Hear it</button>
					</div>
					<div class="e3__stage" data-e3-stage>
						<div class="e3__hud" data-e3-hud></div>
						<p class="e3__hint">Drag to orbit · scroll or pinch to zoom</p>
						<span class="e3__load">Assembling the engine…</span>
					</div>
					<div class="e3__fo"><small>Firing sequence</small><div data-e3-fo></div></div>
					<div class="e3__ctl">
						<label class="e3__rpm">Engine speed <b data-e3-rpmv>1,200</b> rpm<input type="range" min="700" max="8000" step="50" value="1200" data-e3-rpm></label>
						<label class="e3__tg"><input type="checkbox" data-e3-slow checked><span>Slow motion</span></label>
						<label class="e3__tg"><input type="checkbox" data-e3-xray><span>X-ray (hide covers)</span></label><label class="e3__rpm e3__exp">Exploded view<input type="range" min="0" max="100" step="1" value="0" data-e3-exp></label>
						<button type="button" class="e3__mini" data-e3-reset>Reset view</button>
					</div>
					<div class="e3__legend"><span class="p">Power</span><span class="e">Exhaust</span><span class="i">Intake</span><span class="c">Compression</span><span class="s">Spark</span></div>
				</div>
				<aside class="e3__info" data-e3-info></aside>
			</div>
			<?php if ( 'full' === $a['mode'] ) : ?>
			<div class="bl" data-psr-boost>
				<div class="bl__head"><div><p class="lx-eyebrow">Boost Lab</p><h3>Feel turbo lag, then kill it.</h3><p class="bl__desc" data-bl-desc></p></div><button type="button" class="e3__snd" data-bl-snd aria-pressed="false">🔈 Sound</button></div>
				<div class="bl__ks" role="group" aria-label="Engine setup"><button type="button" data-bl-k="na">Naturally aspirated</button><button type="button" data-bl-k="single">Single big turbo</button><button type="button" data-bl-k="twin" aria-pressed="true">Twin-turbo V8</button><button type="button" data-bl-k="hybrid">Twin-turbo + 48V</button><button type="button" data-bl-k="eturbo">Electric turbo</button></div>
				<canvas class="bl__cv" data-bl-cv aria-label="Turbocharger cutaway, gauges and live trace"></canvas>
				<div class="bl__row"><button type="button" class="bl__pedal" data-bl-pedal><span>Hold to floor it</span><small>Mouse, finger or space bar</small></button><div class="bl__side"><p class="bl__msg" data-bl-msg></p><p class="bl__tt">Your best 0–100 km/h per setup</p><ul class="bl__table" data-bl-table></ul><button type="button" class="e3__mini" data-bl-reset>Reset run</button></div></div>
				<p class="bl__note">Exhaust gas spins the turbine at up to 190,000 rpm. On the same shaft the compressor packs air into the engine. Until the exhaust has enough energy, boost lags behind your foot. Smaller twin turbos, a 48-volt motor or an electric motor on the shaft all close that gap.</p>
			</div>
			<div class="eq" data-eq><div class="eq__l"><p class="lx-eyebrow">Ear test</p><h3>Name the car by its engine note</h3><p class="eq__msg" data-eq-msg>Eight rounds. You hear an idle, a throttle blip and a run to the redline, and watch the waveform. Then pick which showcase car it was.</p><div class="eq__sc"><div><small>Round</small><b data-eq-round>0 / 8</b></div><div><small>Score</small><b data-eq-score>0</b></div><div><small>Streak</small><b data-eq-streak>0</b></div></div><button type="button" class="lx-btn lx-btn--gold" data-eq-play>▶ Play the first engine</button></div><div class="eq__r"><canvas class="eq__cv" data-eq-cv aria-label="Engine sound waveform"></canvas><div class="eq__opts" data-eq-opts hidden></div></div></div>
			<?php endif; ?>
		</div>
		<?php
		return ob_get_clean();
	}

	/** Tech Lab: car silhouette with hotspots and animated diagrams. */
	public static function sc_tech() {
		$topics = array(
			'v8'     => array( 'Twin-turbo V8', 'Eight cylinders in two banks of four, fed by two turbochargers. The exhaust spins each turbine, which drives a compressor that packs more air into the engine, so a smaller engine makes big power.', 'Engine bay', 30, 46 ),
			'v12'    => array( 'The V12', 'Twelve cylinders, two banks of six. Firing pulses overlap so smoothly that the engine is almost vibration-free: the reason Rolls-Royce and Ferrari still build them.', 'Engine', 22, 40 ),
			'turbo'  => array( 'Hybrid boost', 'A 48-volt electric motor sits between engine and gearbox. It fills the gap before the turbo spools, restarts the engine silently and recovers energy when you brake.', 'Drivetrain', 45, 54 ),
			'air'    => array( 'Air suspension', 'Instead of steel springs, rubber air bellows. A compressor raises the car for rough tracks and lowers it at speed or for getting in, while dampers adjust many times a second.', 'Suspension', 76, 66 ),
			'awd'    => array( 'All-wheel drive', 'A centre differential or clutch pack splits torque between the axles, sending more to the wheels with grip. Locking differentials force wheels to turn together off-road.', 'Axles', 54, 74 ),
			'brakes' => array( 'Carbon-ceramic brakes', 'Discs made of carbon fibre fused with silicon carbide. Lighter than iron, they shrug off heat that would make steel brakes fade, and can outlast the car.', 'Wheels', 20, 74 ),
		);
		ob_start();
		?>
		<div class="tl" data-psr-tech>
			<div class="tl__car">
				<svg viewBox="0 0 100 60" class="tl__sil" aria-hidden="true"><defs><linearGradient id="tlg" x1="0" x2="1"><stop offset="0" stop-color="#6b4a12"/><stop offset=".45" stop-color="#e6c46a"/><stop offset=".55" stop-color="#fff1b8"/><stop offset="1" stop-color="#8a611a"/></linearGradient></defs>
					<path d="M6 44 L8 36 Q10 32 18 31 L30 29 Q38 20 50 19 L66 19 Q74 20 80 27 L90 30 Q95 32 95 38 L95 44 Z" fill="none" stroke="url(#tlg)" stroke-width=".7"/>
					<path d="M34 29 Q40 22 50 21.5 L64 21.5 Q71 22 76 28 Z" fill="none" stroke="url(#tlg)" stroke-width=".5" opacity=".7"/>
					<circle cx="22" cy="44" r="7.5" fill="none" stroke="url(#tlg)" stroke-width=".7"/><circle cx="22" cy="44" r="4" fill="none" stroke="url(#tlg)" stroke-width=".4"/>
					<circle cx="78" cy="44" r="7.5" fill="none" stroke="url(#tlg)" stroke-width=".7"/><circle cx="78" cy="44" r="4" fill="none" stroke="url(#tlg)" stroke-width=".4"/>
					<path d="M2 52 H98" stroke="url(#tlg)" stroke-width=".3" opacity=".5"/>
				</svg>
				<?php foreach ( $topics as $k => $t ) : ?><button type="button" class="tl__dot" style="left:<?php echo (int) $t[3]; ?>%;top:<?php echo (int) $t[4]; ?>%" data-tl="<?php echo esc_attr( $k ); ?>" aria-label="<?php echo esc_attr( $t[0] ); ?>"><i></i><span><?php echo esc_html( $t[2] ); ?></span></button><?php endforeach; ?>
			</div>
			<div class="tl__tabs" role="tablist"><?php foreach ( $topics as $k => $t ) : ?><button type="button" role="tab" data-tl="<?php echo esc_attr( $k ); ?>"><?php echo esc_html( $t[0] ); ?></button><?php endforeach; ?></div>
			<div class="tl__panel">
				<div class="tl__fig" data-tl-fig aria-hidden="true"></div>
				<div class="tl__txt"><p class="lx-eyebrow" data-tl-eb>Under the Hood</p><h3 data-tl-h></h3><p data-tl-p></p><p class="tl__in">In the showcase</p><div class="tl__cars" data-tl-cars></div></div>
			</div>
			<script type="application/json" data-tl-data><?php echo wp_json_encode( $topics ); ?></script>
		</div>
		<?php
		return ob_get_clean();
	}

	/** Parts Hunt: rarity estimator + "which is harder to find?" game. */
	public static function sc_parts() {
		ob_start();
		?>
		<div class="ph" data-psr-parts>
			<div class="ph__tool">
				<div class="ph__pick">
					<div class="ph__car" data-ph-img></div>
					<label><span>1 · Choose a car</span><select data-ph-car></select></label>
					<p class="ph__lbl">2 · Choose a part</p>
					<div class="ph__parts" data-ph-parts role="group" aria-label="Parts"></div>
				</div>
				<div class="ph__out" aria-live="polite">
					<p class="ph__k">Parts rarity index</p>
					<div class="ph__gauge"><svg viewBox="0 0 200 110" aria-hidden="true"><path d="M15 100 A85 85 0 0 1 185 100" fill="none" stroke="var(--lx-line)" stroke-width="14" stroke-linecap="round"/><path data-ph-arc d="M15 100 A85 85 0 0 1 185 100" fill="none" stroke="url(#phg)" stroke-width="14" stroke-linecap="round" pathLength="100" stroke-dasharray="0 100"/><defs><linearGradient id="phg"><stop offset="0" stop-color="#6b4a12"/><stop offset=".5" stop-color="#e6c46a"/><stop offset="1" stop-color="#b5121b"/></linearGradient></defs></svg><b data-ph-score>–</b><span>/ 10</span></div>
					<p class="ph__verdict" data-ph-verdict>Pick a car and a part.</p>
					<dl class="ph__facts"><div><dt>Typical wait</dt><dd data-ph-wait>–</dd></div><div><dt>Original part</dt><dd data-ph-oem>–</dd></div><div><dt>Alternatives</dt><dd data-ph-alt>–</dd></div></dl>
					<p class="ph__k">Where to look, in order</p>
					<ol class="ph__where" data-ph-where></ol>
					<p class="ph__note">Estimates from a simple model of brand volume, part type and model age, for fun and orientation. Always confirm the exact part number from your VIN.</p>
				</div>
			</div>
			<div class="ph__game">
				<div><p class="lx-eyebrow">Rare parts · the game</p><h3>Which is harder to find?</h3><p class="ph__score">Score <b data-pg-score>0</b> · Streak <b data-pg-streak>0</b></p></div>
				<div class="ph__duel" data-pg></div>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/** Engineering numbers: power-to-weight, specific output, per-cylinder. */
	public static function sc_eng() {
		return '<div class="eg" data-psr-eng><div class="eg__ctrl"><label><span>Rank the showcase by</span><select data-eg-sort><option value="spec">Specific output (hp per litre)</option><option value="cyl">Power per cylinder</option><option value="hp">Total power</option><option value="l">Displacement</option></select></label><p class="eg__hint">By the numbers: specific output shows how hard an engine works for its size. Turbocharged engines usually win. Hybrids and EVs sit out the per-litre and per-cylinder ranks.</p></div><ol class="eg__list" data-eg-list></ol></div>';
	}

	/** Flip cards with fun facts. */
	public static function sc_facts( $atts ) {
		$a     = shortcode_atts( array( 'limit' => 12 ), $atts );
		$facts = array(
			array( '3,106', 'carats', 'Why is it called the Cullinan?', 'It is named after the Cullinan diamond, found in South Africa in 1905: at 3,106 carats, the largest gem-quality rough diamond ever found.' ),
			array( '1979', 'since', 'How old is the G-Class?', 'The G-Class has been built in Graz, Austria since 1979, much of it still by hand, and the shape has barely changed.' ),
			array( '1954', 'the name', 'When did the Land Cruiser get its name?', 'Toyota renamed its BJ off-roader "Land Cruiser" in 1954. It is now Toyota’s longest-running model name.' ),
			array( '725', 'PS', 'Does the Purosangue have a turbo?', 'No. Its 6.5-litre V12 is naturally aspirated and makes 725 PS, which is rare for any SUV.' ),
			array( '1970', 'launch', 'When did the first Range Rover arrive?', 'The original Range Rover launched in 1970 and was once displayed at the Louvre as an example of industrial design.' ),
			array( 'LM002', 'the ancestor', 'Was the Urus Lamborghini’s first SUV?', 'No. The V12 LM002 “Rambo Lambo” came first, built from 1986 to 1993.' ),
			array( '1963', 'debut', 'Why was the 911 almost called 901?', 'Porsche showed it as the 901 in 1963, but Peugeot claimed three-digit names with a zero in the middle, so it became the 911.' ),
			array( 'Roque', 'Bentayga', 'Where does the name Bentayga come from?', 'From the Roque Bentayga, a rock peak in Gran Canaria, mixed with “taiga”, the snowy northern forest.' ),
			array( '1909', 'founded', 'Is Maybach a new brand?', 'Maybach was founded in 1909. Mercedes-Benz revived the name in the 2000s and today uses it for its most luxurious cars.' ),
			array( 'Wales', 'St Athan', 'Where is the Aston Martin DBX built?', 'In a new factory at St Athan, Wales, set up in former RAF hangars for Aston Martin’s first SUV.' ),
			array( 'Hidden', 'the lady', 'Can the Spirit of Ecstasy hide?', 'Yes. The famous mascot on a Rolls-Royce retracts into the grille when the car is locked or if it is knocked.' ),
			array( '3', 'locking diffs', 'How many locking differentials does a G 63 have?', 'Three: front, centre and rear, each engaged with a button on the dashboard.' ),
		);
		$out = '<div class="ff">';
		foreach ( array_slice( $facts, 0, (int) $a['limit'] ) as $i => $f ) {
			$out .= '<button type="button" class="ff__card lx-reveal" aria-pressed="false"><span class="ff__in"><span class="ff__front"><small>Fact ' . sprintf( '%02d', $i + 1 ) . '</small><b>' . esc_html( $f[0] ) . '</b><em>' . esc_html( $f[1] ) . '</em><span class="ff__q">' . esc_html( $f[2] ) . '</span><span class="ff__flip">Tap to reveal ↻</span></span><span class="ff__back"><small>Did you know?</small><span>' . esc_html( $f[3] ) . '</span></span></span></button>';
		}
		return $out . '</div>';
	}

	/** All published cars as JSON, for search, saved cars and compare. */
	public static function print_index() {
		if ( ! self::is_canvas() ) {
			return;
		}
		$ck  = 'psr_index_' . md5( PSR_VERSION . '|' . get_option( 'psr_data_ver', '0' ) );
		$hit = get_transient( $ck );
		if ( is_string( $hit ) && '' !== $hit ) {
			echo $hit; // phpcs:ignore -- cached JSON block built below.
			return;
		}
		ob_start();
		self::print_index_build();
		$html = (string) ob_get_clean();
		set_transient( $ck, $html, DAY_IN_SECONDS );
		echo $html; // phpcs:ignore
	}

	private static function print_index_build() {
		$out = array();
		foreach ( PSR_DB::query() as $v ) {
			$st    = self::stats( $v );
			$out[] = array(
				'id'     => (int) $v->id,
				'make'   => $v->make,
				'model'  => $v->model,
				'variant'=> $v->variant,
				'year'   => $v->year ? (int) $v->year : '',
				'body'   => $v->body,
				'status' => $v->status,
				'tag'    => self::status_label( $v->status ),
				'color'  => $v->exterior_color,
				'url'    => self::url( $v ),
				'img'    => wp_get_attachment_image_url( PSR_DB::cover( $v ), 'medium_large' ),
				'big'    => wp_get_attachment_image_url( PSR_DB::cover( $v ), 'large' ),
				'th'     => wp_get_attachment_image_url( PSR_DB::cover( $v ), 'medium' ),
				'hp'     => $st['hp'],
				'l'      => $st['l'],
				'cyl'    => $st['cyl'],
				'engine' => $v->engine,
				'power'  => $v->power,
				'drive'  => $v->drivetrain,
				'fuel'   => $v->fuel,
				'tagline'=> $v->tagline,
				'hl'     => str_replace( "\n", ' · ', (string) $v->highlights ),
				'glb'    => self::model( $v->id ) ? self::model( $v->id )['url'] : '',
				'fl'     => self::model( $v->id ) && ! empty( self::model( $v->id )['flip'] ) ? 1 : 0,
				'pc'     => self::model( $v->id ) && ! empty( self::model( $v->id )['paint'] ) ? self::model( $v->id )['paint'] : '',
				'pm'     => self::model( $v->id ) && ! empty( self::model( $v->id )['pmat'] ) ? self::model( $v->id )['pmat'] : '',
				'tq'     => (int) ( self::extra( $v->id )['torque'] ?? 0 ),
				'gear'   => (string) ( self::extra( $v->id )['gearbox'] ?? $v->transmission ),
				'acc'    => (float) ( self::extra( $v->id )['accel'] ?? 0 ),
				'vmax'   => (int) ( self::extra( $v->id )['vmax'] ?? 0 ),
				'kg'     => (int) ( self::extra( $v->id )['weight'] ?? 0 ),
				'dim'    => array( (int) ( self::extra( $v->id )['length'] ?? 0 ), (int) ( self::extra( $v->id )['width'] ?? 0 ), (int) ( self::extra( $v->id )['height'] ?? 0 ), (int) ( self::extra( $v->id )['wheelbase'] ?? 0 ) ),
				'score'  => self::extra( $v->id )['score'] ?? array(),
				'm3d'    => self::model( $v->id ) ? self::credit( self::model( $v->id ) ) : '',
			);
		}
		$json = (string) wp_json_encode( $out );
		/* Serve the index as a small static file the browser caches across pages. */
		$up = wp_upload_dir();
		if ( empty( $up['error'] ) ) {
			$dir  = trailingslashit( $up['basedir'] ) . 'psr';
			$name = 'psr-index-' . substr( md5( $json ), 0, 12 ) . '.js';
			if ( wp_mkdir_p( $dir ) ) {
				$file = $dir . '/' . $name;
				if ( ! file_exists( $file ) ) {
					foreach ( (array) glob( $dir . '/psr-index-*.js' ) as $old ) {
						@unlink( $old ); // phpcs:ignore
					}
					file_put_contents( $file, 'window.PSR_INDEX=' . $json . ';' ); // phpcs:ignore
				}
				if ( file_exists( $file ) ) {
					echo '<script id="psr-index-js" src="' . esc_attr( preg_replace( '#^https?:#', '', trailingslashit( $up['baseurl'] ) . 'psr/' . $name ) ) . '"></script>' . "\n";
					return;
				}
			}
		}
		echo '<script id="psr-index" type="application/json">' . $json . "</script>\n"; // phpcs:ignore
	}

	public static function sc_marques() {
		$rows = PSR_DB::distinct( 'make' );
		if ( ! $rows ) {
			return '';
		}
		$out = '<ul class="psr-marques">';
		foreach ( $rows as $r ) {
			$out .= '<li><a href="' . esc_url( self::collection_url( 'make=' . rawurlencode( $r->v ) ) ) . '"><span>' . esc_html( $r->v ) . '</span><sup>' . (int) $r->n . '</sup></a></li>';
		}
		return $out . '</ul>';
	}

	public static function sc_feature( $atts ) {
		$a  = shortcode_atts( array( 'status' => 'gallery', 'label' => '' ), $atts );
		$vs = PSR_DB::query( array( 'status' => $a['status'], 'featured' => 1, 'limit' => 1, 'orderby' => 'random' ) );
		if ( ! $vs ) {
			$vs = PSR_DB::query( array( 'status' => $a['status'], 'limit' => 1, 'orderby' => 'random' ) );
		}
		if ( ! $vs ) {
			return '';
		}
		$v = $vs[0];
		return '<a class="psr-feature" href="' . esc_url( self::url( $v ) ) . '">' . self::img( PSR_DB::cover( $v ), 'large' ) . '<span class="psr-feature__txt"><small>' . esc_html( $a['label'] ? $a['label'] : self::status_label( $v->status ) ) . '</small><b>' . esc_html( $v->make ) . '</b><em>' . esc_html( $v->model ) . '</em></span></a>';
	}

	public static function sc_count( $atts ) {
		$a = shortcode_atts( array( 'status' => '', 'distinct' => '' ), $atts );
		if ( $a['distinct'] ) {
			return (string) count( PSR_DB::distinct( $a['distinct'] ) );
		}
		return (string) count( PSR_DB::query( array( 'status' => $a['status'] ) ) );
	}

	public static function sc_enquiry( $atts ) {
		$a = shortcode_atts(
			array(
				'kind'    => 'general',
				'vehicle' => 0,
				'button'  => '',
			),
			$atts
		);
		return self::form( (int) $a['vehicle'], $a['kind'], $a['button'] );
	}

	public static function form( $vehicle_id = 0, $kind = 'enquiry', $button = '' ) {
		$kind   = in_array( $kind, array( 'enquiry', 'feature', 'general' ), true ) ? $kind : 'general';
		$labels = array(
			'enquiry' => __( 'Ask about this car', 'pentarch-showroom' ),
			'feature' => __( 'Submit my car', 'pentarch-showroom' ),
			'general' => __( 'Send message', 'pentarch-showroom' ),
		);
		$button = $button ? $button : $labels[ $kind ];
		$msg    = array(
			'enquiry' => __( 'Your question about this car', 'pentarch-showroom' ),
			'feature' => __( 'Tell us its story: history, modifications, where it lives', 'pentarch-showroom' ),
			'general' => __( 'Your message', 'pentarch-showroom' ),
		);
		ob_start();
		?>
		<form class="psr-form" data-psr-form novalidate>
			<input type="hidden" name="vehicle_id" value="<?php echo (int) $vehicle_id; ?>">
			<input type="hidden" name="kind" value="<?php echo esc_attr( $kind ); ?>">
			<div class="psr-hp" aria-hidden="true"><label>Leave empty<input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>
			<div class="psr-form__row">
				<label class="psr-field"><input type="text" name="name" required autocomplete="name" placeholder=" "><span><?php esc_html_e( 'Full name', 'pentarch-showroom' ); ?></span></label>
				<label class="psr-field"><input type="tel" name="phone" required autocomplete="tel" placeholder=" "><span><?php esc_html_e( 'Phone / WhatsApp', 'pentarch-showroom' ); ?></span></label>
			</div>
			<div class="psr-form__row">
				<label class="psr-field"><input type="email" name="email" autocomplete="email" placeholder=" "><span><?php esc_html_e( 'Email (optional)', 'pentarch-showroom' ); ?></span></label>
				<?php if ( 'feature' === $kind ) : ?>
					<label class="psr-field"><input type="text" name="preferred" placeholder=" "><span><?php esc_html_e( 'Your car: make, model, year', 'pentarch-showroom' ); ?></span></label>
				<?php else : ?>
					<label class="psr-field"><input type="text" name="preferred" placeholder=" "><span><?php esc_html_e( 'Instagram or site (optional)', 'pentarch-showroom' ); ?></span></label>
				<?php endif; ?>
			</div>
			<label class="psr-field psr-field--area"><textarea name="message" rows="3" placeholder=" "></textarea><span><?php echo esc_html( $msg[ $kind ] ); ?></span></label>
			<div class="psr-form__foot">
				<button type="submit" class="psr-btn psr-btn--solid"><span><?php echo esc_html( $button ); ?></span><?php echo self::icon( 'arrow' ); // phpcs:ignore ?></button>
				<p class="psr-form__note" data-note role="status" aria-live="polite"><?php esc_html_e( 'A curator replies personally, usually the same day.', 'pentarch-showroom' ); ?></p>
			</div>
		</form>
		<?php
		return ob_get_clean();
	}

	/* -------------------------------------------------------------- PLAY */

	/** Numbers for the spec duel, parsed from the free-text specification. */
	public static function stats( $v ) {
		$hp = null;
		if ( preg_match_all( '/(\d{2,4})/', (string) $v->power, $m ) ) {
			$hp = max( array_map( 'intval', $m[1] ) );
			if ( preg_match( '/\b(PS|CV)\b/', (string) $v->power ) ) {
				$hp = (int) round( $hp * 0.9863 );
			}
		}
		$l = preg_match( '/(\d+(?:\.\d+)?)\s*L/i', (string) $v->engine, $m ) ? (float) $m[1] : null;
		$cyl = null;
		if ( preg_match( '/\b[VW](\d{1,2})\b/i', (string) $v->engine, $m ) ) {
			$cyl = (int) $m[1];
		} elseif ( preg_match( '/(inline|flat)[- ]?(6|six)/i', (string) $v->engine ) ) {
			$cyl = 6;
		} elseif ( preg_match( '/(inline|flat)[- ]?(4|four)/i', (string) $v->engine ) || preg_match( '/^\s*2\.0L/', (string) $v->engine ) ) {
			$cyl = 4;
		}
		$seats = null;
		if ( preg_match_all( '/\d+/', (string) $v->seats, $m ) ) {
			$seats = false !== strpos( $v->seats, '+' ) ? array_sum( array_map( 'intval', $m[0] ) ) : max( array_map( 'intval', $m[0] ) );
		}
		return array(
			'hp'    => $hp,
			'l'     => $l,
			'cyl'   => $cyl,
			'seats' => $seats,
			'year'  => $v->year ? (int) $v->year : null,
		);
	}

	/** A JSON data tag; large sets go to a cached static file instead of the page. */
	private static function json_tag( $attr, $name, $data ) {
		$json = (string) wp_json_encode( $data );
		$up   = wp_upload_dir();
		if ( strlen( $json ) > 20000 && empty( $up['error'] ) ) {
			$dir  = trailingslashit( $up['basedir'] ) . 'psr';
			$file = $name . '-' . substr( md5( $json ), 0, 12 ) . '.json';
			if ( wp_mkdir_p( $dir ) ) {
				if ( ! file_exists( $dir . '/' . $file ) ) {
					foreach ( (array) glob( $dir . '/' . $name . '-*.json' ) as $old ) {
						@unlink( $old ); // phpcs:ignore
					}
					file_put_contents( $dir . '/' . $file, $json ); // phpcs:ignore
				}
				if ( file_exists( $dir . '/' . $file ) ) {
					return '<script type="application/json" ' . $attr . ' data-src="' . esc_attr( preg_replace( '#^https?:#', '', trailingslashit( $up['baseurl'] ) . 'psr/' . $file ) ) . '"></script>';
				}
			}
		}
		return '<script type="application/json" ' . $attr . '>' . $json . '</script>';
	}

	private static function play_data( $need_stats = false ) {
		$out = array();
		foreach ( PSR_DB::query() as $v ) {
			$cover = PSR_DB::cover( $v );
			if ( ! $cover ) {
				continue;
			}
			$m    = PSR_DB::media( $v->id );
			$pics = array();
			foreach ( $m as $x ) {
				$meta = wp_get_attachment_metadata( $x->attachment_id );
				if ( ! empty( $meta['width'] ) && $meta['width'] >= $meta['height'] ) {
					$pics[] = wp_get_attachment_image_url( $x->attachment_id, '1536x1536' );
				}
				if ( count( $pics ) >= 4 ) {
					break;
				}
			}
			if ( ! $pics ) {
				$pics[] = wp_get_attachment_image_url( $cover, 'large' );
			}
			$row = array(
				'id'    => (int) $v->id,
				'make'  => $v->make,
				'model' => $v->model,
				'year'  => $v->year ? (int) $v->year : '',
				'url'   => self::url( $v ),
				'img'   => wp_get_attachment_image_url( $cover, 'large' ),
				'pics'  => $pics,
				'tag'   => self::status_label( $v->status ),
			);
			if ( $need_stats ) {
				$row['s']      = self::stats( $v );
				$row['engine'] = $v->engine;
				$row['power']  = $v->power;
			}
			$out[] = $row;
		}
		return $out;
	}

	public static function sc_search() {
		$makes  = PSR_DB::distinct( 'make' );
		$bodies = PSR_DB::distinct( 'body' );
		$years  = PSR_DB::distinct( 'year' );
		ob_start();
		?>
		<form class="psr-search" data-psr-search action="<?php echo esc_url( self::collection_url() ); ?>">
			<div class="psr-search__head"><span class="psr-search__ic"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M20 20l-4-4" stroke="currentColor" stroke-width="1.8"/></svg></span><div><h2>Find a car in the collection</h2><p><?php echo (int) count( PSR_DB::query() ); ?> cars, <?php echo (int) count( $makes ); ?> marques</p></div></div>
			<label class="psr-search__q"><span>Keyword</span><input type="search" name="q" placeholder="Try “G 63”, “V12” or “Range Rover”" autocomplete="off"></label>
			<div class="psr-search__grid">
				<label><span>Marque</span><select name="make"><option value="">All marques</option><?php foreach ( $makes as $m ) { echo '<option value="' . esc_attr( $m->v ) . '">' . esc_html( $m->v . ' (' . $m->n . ')' ) . '</option>'; } ?></select></label>
				<label><span>Body</span><select name="body"><option value="">Any body</option><?php foreach ( $bodies as $m ) { echo '<option value="' . esc_attr( $m->v ) . '">' . esc_html( $m->v . ' (' . $m->n . ')' ) . '</option>'; } ?></select></label>
				<label><span>Model year</span><select name="year"><option value="">Any year</option><?php foreach ( array_reverse( $years ) as $m ) { if ( (int) $m->v ) { echo '<option value="' . (int) $m->v . '">' . (int) $m->v . '</option>'; } } ?></select></label>
			</div>
			<fieldset class="psr-search__chips"><legend>Show</legend>
				<label><input type="radio" name="status" value="" checked><span>Everything</span></label>
				<label><input type="radio" name="status" value="gallery"><span><i class="g"></i>Laqim Originals</span></label>
				<label><input type="radio" name="status" value="commission"><span><i class="c"></i>Curated Icons</span></label>
			</fieldset>
			<div class="psr-search__foot"><button type="submit" class="psr-btn psr-btn--solid"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M20 20l-4-4" stroke="currentColor" stroke-width="1.8"/></svg><span>Search cars</span></button><a class="psr-btn" href="<?php echo esc_url( self::collection_url() ); ?>"><span>Browse everything</span></a></div>
		</form>
		<?php
		return ob_get_clean();
	}

	public static function sc_guess() {
		$data = self::play_data();
		if ( count( $data ) < 4 ) {
			return '';
		}
		ob_start();
		?>
		<div class="psr-guess" data-psr-guess>
			<div class="psr-guess__lens" aria-hidden="true"><div class="psr-guess__img" data-g-img></div><div class="psr-guess__ring"></div><span class="psr-guess__hint" data-g-hint>Zoomed in</span></div>
			<div class="psr-guess__panel">
				<div class="psr-guess__score"><div><b data-g-score>0</b><span>Score</span></div><div><b data-g-streak>0</b><span>Streak</span></div><div><b data-g-best>0</b><span>Best streak</span></div></div>
				<p class="psr-guess__q" data-g-q>Which car is this?</p>
				<div class="psr-guess__opts" data-g-opts role="group" aria-label="Answers"></div>
				<p class="psr-guess__msg" aria-live="polite" data-g-msg></p>
				<div class="psr-guess__foot"><button type="button" class="psr-btn psr-btn--solid" data-g-next><span>Next car</span><?php echo self::icon( 'arrow' ); // phpcs:ignore ?></button><button type="button" class="psr-btn" data-g-zoom><span>Zoom out a little</span></button></div>
			</div>
			<?php echo self::json_tag( 'data-g-data', 'psr-guess', $data ); // phpcs:ignore ?>
		</div>
		<?php
		return ob_get_clean();
	}

	public static function sc_duel() {
		$data = array_values(
			array_filter(
				self::play_data( true ),
				function ( $r ) {
					return null !== $r['s']['hp'];
				}
			)
		);
		if ( count( $data ) < 2 ) {
			return '';
		}
		$opts = '';
		foreach ( $data as $i => $r ) {
			$opts .= '<option value="' . (int) $i . '">' . esc_html( $r['make'] . ' ' . $r['model'] . ( $r['year'] ? ' ' . $r['year'] : '' ) ) . '</option>';
		}
		ob_start();
		?>
		<div class="psr-duel" data-psr-duel>
			<div class="psr-duel__pick">
				<div class="psr-duel__side" data-d-side="a"><figure><img alt="" data-d-img></figure><label><span class="screen-reader-text">First car</span><select data-d-sel><?php echo $opts; // phpcs:ignore ?></select></label></div>
				<div class="psr-duel__vs" aria-hidden="true">vs</div>
				<div class="psr-duel__side" data-d-side="b"><figure><img alt="" data-d-img></figure><label><span class="screen-reader-text">Second car</span><select data-d-sel><?php echo $opts; // phpcs:ignore ?></select></label></div>
			</div>
			<div class="psr-duel__go"><button type="button" class="psr-btn psr-btn--solid" data-d-go><span>Duel</span><?php echo self::icon( 'arrow' ); // phpcs:ignore ?></button><button type="button" class="psr-btn" data-d-rand><span>Random match-up</span></button></div>
			<div class="psr-duel__rows" data-d-rows></div>
			<p class="psr-duel__verdict" aria-live="polite" data-d-verdict></p>
			<p class="psr-duel__note">Figures from manufacturer specifications. Power shown in hp. Just for fun: there is no prize, and nothing is for sale.</p>
			<?php echo self::json_tag( 'data-d-data', 'psr-duel', $data ); // phpcs:ignore ?>
		</div>
		<?php
		return ob_get_clean();
	}

	/* -------------------------------------------------------------- REST */

	public static function rest() {
		register_rest_route(
			'psr/v1',
			'/vehicles',
			array(
				'methods'             => 'GET',
				'permission_callback' => '__return_true',
				'callback'            => function () {
					$out = array();
					foreach ( PSR_DB::query() as $v ) {
						$out[] = array(
							't' => PSR_DB::title( $v ),
							'm' => $v->make,
							'o' => $v->model,
							'v' => $v->variant,
							'y' => $v->year ? (int) $v->year : '',
							'b' => $v->body,
							'e' => $v->engine,
							'c' => $v->exterior_color,
							's' => self::status_label( $v->status ),
							'u' => self::url( $v ),
							'i' => wp_get_attachment_image_url( PSR_DB::cover( $v ), 'medium_large' ),
						);
					}
					$r = new WP_REST_Response( $out );
					$r->header( 'Cache-Control', 'public, max-age=300' );
					return $r;
				},
			)
		);
		register_rest_route(
			'psr/v1',
			'/pad',
			array(
				array(
					'methods'             => 'POST',
					'callback'            => array( __CLASS__, 'rest_pad_post' ),
					'permission_callback' => '__return_true',
				),
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'rest_pad_get' ),
					'permission_callback' => '__return_true',
				),
			)
		);
		register_rest_route(
			'psr/v1',
			'/enquiry',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_enquiry' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	/* phone controller pairing: a short-lived mailbox that only carries the WebRTC handshake between a phone and the screen */
	private static function pad_ok( $v, $n = 24 ) {
		return is_string( $v ) && preg_match( '/^[A-Za-z0-9]{3,' . $n . '}$/', $v );
	}
	private static function pad_limit() {
		$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		$key = 'psr_padrl_' . md5( $ip );
		$hit = (int) get_transient( $key );
		if ( $hit > 600 ) {
			return false;
		}
		set_transient( $key, $hit + 1, 10 * MINUTE_IN_SECONDS );
		return true;
	}
	public static function rest_pad_post( $req ) {
		$p = $req->get_json_params();
		$p = is_array( $p ) ? $p : array();
		$room = (string) ( $p['room'] ?? '' );
		$to   = (string) ( $p['to'] ?? '' );
		$from = (string) ( $p['from'] ?? '' );
		$kind = (string) ( $p['kind'] ?? '' );
		$data = (string) ( $p['data'] ?? '' );
		if ( ! self::pad_ok( $room, 8 ) || ! self::pad_ok( $to ) || ! self::pad_ok( $from ) || ! in_array( $kind, array( 'offer', 'answer', 'bye' ), true ) || strlen( $data ) > 12000 ) {
			return new WP_Error( 'psr_pad', 'Bad pairing message.', array( 'status' => 400 ) );
		}
		if ( ! self::pad_limit() ) {
			return new WP_Error( 'psr_slow', 'Too many requests.', array( 'status' => 429 ) );
		}
		$key = 'psr_pad_' . strtoupper( $room );
		$box = get_transient( $key );
		$box = is_array( $box ) ? $box : array();
		$box[] = array( 'to' => $to, 'from' => $from, 'kind' => $kind, 'data' => $data, 't' => time() );
		$box   = array_slice( $box, -40 );
		set_transient( $key, $box, 15 * MINUTE_IN_SECONDS );
		$r = new WP_REST_Response( array( 'ok' => true ) );
		$r->header( 'Cache-Control', 'no-store' );
		return $r;
	}
	public static function rest_pad_get( $req ) {
		$room = (string) $req->get_param( 'room' );
		$me   = (string) $req->get_param( 'me' );
		if ( ! self::pad_ok( $room, 8 ) || ! self::pad_ok( $me ) ) {
			return new WP_Error( 'psr_pad', 'Bad pairing request.', array( 'status' => 400 ) );
		}
		if ( ! self::pad_limit() ) {
			return new WP_Error( 'psr_slow', 'Too many requests.', array( 'status' => 429 ) );
		}
		$key  = 'psr_pad_' . strtoupper( $room );
		$box  = get_transient( $key );
		$box  = is_array( $box ) ? $box : array();
		$mine = array();
		$rest = array();
		foreach ( $box as $m ) {
			if ( $m['to'] === $me ) {
				$mine[] = $m;
			} else {
				$rest[] = $m;
			}
		}
		if ( $mine ) {
			set_transient( $key, $rest, 15 * MINUTE_IN_SECONDS );
		}
		$r = new WP_REST_Response( array( 'msgs' => $mine ) );
		$r->header( 'Cache-Control', 'no-store' );
		return $r;
	}

	public static function rest_enquiry( $req ) {
		$p = $req->get_json_params();
		$p = is_array( $p ) ? $p : $req->get_params();
		if ( ! empty( $p['website'] ) ) {
			return array( 'ok' => true );
		}
		$name  = trim( (string) ( $p['name'] ?? '' ) );
		$phone = trim( (string) ( $p['phone'] ?? '' ) );
		if ( strlen( $name ) < 2 || strlen( preg_replace( '/\D/', '', $phone ) ) < 7 ) {
			return new WP_Error( 'psr_invalid', __( 'Please add your name and a phone number we can reach.', 'pentarch-showroom' ), array( 'status' => 400 ) );
		}
		$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		$key = 'psr_rl_' . md5( $ip );
		$hit = (int) get_transient( $key );
		if ( $hit >= 6 ) {
			return new WP_Error( 'psr_slow', __( 'Thank you, we already have your requests. A curator will be in touch.', 'pentarch-showroom' ), array( 'status' => 429 ) );
		}
		set_transient( $key, $hit + 1, HOUR_IN_SECONDS );
		$p['source_url'] = $req->get_header( 'referer' );
		$id              = PSR_DB::add_enquiry( $p );
		$v               = ! empty( $p['vehicle_id'] ) ? PSR_DB::get( (int) $p['vehicle_id'] ) : null;
		$to              = psr_settings( 'email' );
		if ( $to ) {
			$kind  = sanitize_key( $p['kind'] ?? 'general' );
			$lines = array(
				'Request: ' . ucfirst( $kind ),
				'Vehicle: ' . ( $v ? PSR_DB::title( $v ) . ' ' . $v->year . ' — ' . self::url( $v ) : '—' ),
				'Name: ' . sanitize_text_field( $name ),
				'Phone: ' . sanitize_text_field( $phone ),
				'Email: ' . sanitize_email( $p['email'] ?? '' ),
				'Preferred: ' . sanitize_text_field( $p['preferred'] ?? '' ),
				'',
				sanitize_textarea_field( $p['message'] ?? '' ),
				'',
				'Manage: ' . admin_url( 'admin.php?page=psr-enquiries' ),
			);
			$hdr   = array();
			if ( ! empty( $p['email'] ) && is_email( $p['email'] ) ) {
				$hdr[] = 'Reply-To: ' . sanitize_text_field( $name ) . ' <' . sanitize_email( $p['email'] ) . '>';
			}
			wp_mail( $to, '[' . psr_settings( 'brand' ) . '] ' . ucfirst( $kind ) . ' request' . ( $v ? ': ' . PSR_DB::title( $v ) : '' ), implode( "\n", $lines ), $hdr );
		}
		return array(
			'ok'      => true,
			'id'      => $id,
			'message' => __( 'Thank you. A curator will contact you shortly to confirm the details.', 'pentarch-showroom' ),
		);
	}
}
