<?php
/**
 * Database: vehicles, their media, and viewing / commission requests.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class PSR_DB {

	/** Vehicle columns that may be written from forms or imports (column => type). */
	const FIELDS = array(
		'slug'           => 'slug',
		'status'         => 'key',
		'visibility'     => 'key',
		'featured'       => 'bool',
		'in_hero'        => 'bool',
		'sort_order'     => 'int',
		'make'           => 'text',
		'model'          => 'text',
		'variant'        => 'text',
		'tagline'        => 'text',
		'year'           => 'int',
		'body'           => 'text',
		'condition_label'=> 'text',
		'mileage_km'     => 'intnull',
		'engine'         => 'text',
		'power'          => 'text',
		'transmission'   => 'text',
		'drivetrain'     => 'text',
		'fuel'           => 'text',
		'consumption'    => 'text',
		'exterior_color' => 'text',
		'interior_color' => 'text',
		'seats'          => 'text',
		'location'       => 'text',
		'price'          => 'intnull',
		'summary'        => 'html',
		'highlights'     => 'lines',
		'features'       => 'lines',
		'credits'        => 'lines',
		'hero_attachment'=> 'int',
		'source_ref'     => 'text',
	);

	const STATUSES = array(
		'gallery'    => 'Showcase',
		'commission' => 'Icon',
		'reserved'   => 'Coming soon',
		'placed'     => 'Archive',
	);

	public static function t( $name ) {
		global $wpdb;
		return $wpdb->prefix . 'psr_' . $name;
	}

	/* ------------------------------------------------------------ schema */

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c = $wpdb->get_charset_collate();
		$v = self::t( 'vehicles' );
		$m = self::t( 'media' );
		$e = self::t( 'enquiries' );

		dbDelta(
			"CREATE TABLE $v (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			slug varchar(191) NOT NULL,
			status varchar(20) NOT NULL DEFAULT 'gallery',
			visibility varchar(20) NOT NULL DEFAULT 'publish',
			featured tinyint(1) NOT NULL DEFAULT 0,
			in_hero tinyint(1) NOT NULL DEFAULT 0,
			sort_order int(11) NOT NULL DEFAULT 0,
			make varchar(80) NOT NULL DEFAULT '',
			model varchar(120) NOT NULL DEFAULT '',
			variant varchar(160) NOT NULL DEFAULT '',
			tagline varchar(255) NOT NULL DEFAULT '',
			year smallint(4) NOT NULL DEFAULT 0,
			body varchar(40) NOT NULL DEFAULT '',
			condition_label varchar(60) NOT NULL DEFAULT '',
			mileage_km int(11) DEFAULT NULL,
			engine varchar(160) NOT NULL DEFAULT '',
			power varchar(80) NOT NULL DEFAULT '',
			transmission varchar(120) NOT NULL DEFAULT '',
			drivetrain varchar(60) NOT NULL DEFAULT '',
			fuel varchar(60) NOT NULL DEFAULT '',
			consumption varchar(60) NOT NULL DEFAULT '',
			exterior_color varchar(80) NOT NULL DEFAULT '',
			interior_color varchar(120) NOT NULL DEFAULT '',
			seats varchar(20) NOT NULL DEFAULT '',
			location varchar(120) NOT NULL DEFAULT '',
			price bigint(20) DEFAULT NULL,
			summary text,
			highlights text,
			features text,
			credits text,
			hero_attachment bigint(20) unsigned NOT NULL DEFAULT 0,
			source_ref varchar(80) NOT NULL DEFAULT '',
			views int(11) NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY slug (slug),
			KEY status (status),
			KEY make (make),
			KEY source_ref (source_ref)
			) $c;"
		);

		dbDelta(
			"CREATE TABLE $m (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			vehicle_id bigint(20) unsigned NOT NULL,
			attachment_id bigint(20) unsigned NOT NULL DEFAULT 0,
			credit varchar(255) NOT NULL DEFAULT '',
			sort_order int(11) NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			KEY vehicle_id (vehicle_id)
			) $c;"
		);

		dbDelta(
			"CREATE TABLE $e (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			vehicle_id bigint(20) unsigned NOT NULL DEFAULT 0,
			kind varchar(20) NOT NULL DEFAULT 'viewing',
			name varchar(120) NOT NULL DEFAULT '',
			phone varchar(60) NOT NULL DEFAULT '',
			email varchar(160) NOT NULL DEFAULT '',
			preferred varchar(120) NOT NULL DEFAULT '',
			message text,
			status varchar(20) NOT NULL DEFAULT 'new',
			notes text,
			source_url varchar(255) NOT NULL DEFAULT '',
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY status (status),
			KEY vehicle_id (vehicle_id)
			) $c;"
		);

		update_option( 'psr_db_version', PSR_DB_VERSION );
	}

	public static function maybe_upgrade() {
		if ( get_option( 'psr_db_version' ) !== PSR_DB_VERSION ) {
			self::install();
		}
	}

	/* ----------------------------------------------------------- helpers */

	private static function clean( $type, $val ) {
		switch ( $type ) {
			case 'slug':
				return sanitize_title( $val );
			case 'key':
				return sanitize_key( $val );
			case 'bool':
				return empty( $val ) ? 0 : 1;
			case 'int':
				return (int) $val;
			case 'intnull':
				$val = is_string( $val ) ? preg_replace( '/[^\d]/', '', $val ) : $val;
				return ( '' === $val || null === $val ) ? null : (int) $val;
			case 'html':
				return wp_kses_post( $val );
			case 'lines':
				$lines = is_array( $val ) ? $val : preg_split( '/\r\n|\r|\n/', (string) $val );
				$lines = array_filter( array_map( 'sanitize_text_field', $lines ), 'strlen' );
				return implode( "\n", $lines );
			default:
				return sanitize_text_field( $val );
		}
	}

	public static function title( $v ) {
		$v = (object) $v;
		return trim( $v->make . ' ' . $v->model );
	}

	public static function unique_slug( $slug, $id = 0 ) {
		global $wpdb;
		$base = $slug ? $slug : 'vehicle';
		$try  = $base;
		$i    = 2;
		while ( $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . self::t( 'vehicles' ) . ' WHERE slug = %s AND id <> %d', $try, $id ) ) ) { // phpcs:ignore WordPress.DB.PreparedSQL
			$try = $base . '-' . $i++;
		}
		return $try;
	}

	/* ------------------------------------------------------------- write */

	/**
	 * Insert or update a vehicle.
	 *
	 * @param array $data Field values.
	 * @param int   $id   Existing id to update, 0 to insert.
	 * @return int Vehicle id.
	 */
	public static function save_vehicle( $data, $id = 0 ) {
		update_option( 'psr_data_ver', (string) microtime( true ), false );
		global $wpdb;
		$row = array();
		foreach ( self::FIELDS as $f => $type ) {
			if ( array_key_exists( $f, $data ) ) {
				$row[ $f ] = self::clean( $type, $data[ $f ] );
			}
		}
		if ( isset( $row['status'] ) && ! isset( self::STATUSES[ $row['status'] ] ) ) {
			$row['status'] = 'gallery';
		}
		if ( isset( $row['visibility'] ) && ! in_array( $row['visibility'], array( 'publish', 'draft' ), true ) ) {
			$row['visibility'] = 'draft';
		}
		if ( empty( $row['slug'] ) && ! $id ) {
			$row['slug'] = sanitize_title( trim( ( $data['make'] ?? '' ) . ' ' . ( $data['model'] ?? '' ) . ' ' . ( $data['year'] ?? '' ) ) );
		}
		if ( isset( $row['slug'] ) ) {
			$row['slug'] = self::unique_slug( $row['slug'], $id );
		}
		$row['updated_at'] = current_time( 'mysql' );
		if ( $id ) {
			$wpdb->update( self::t( 'vehicles' ), $row, array( 'id' => $id ) );
		} else {
			$row['created_at'] = $row['updated_at'];
			$wpdb->insert( self::t( 'vehicles' ), $row );
			$id = (int) $wpdb->insert_id;
		}
		if ( isset( $data['gallery'] ) ) {
			self::set_media( $id, $data['gallery'] );
		}
		wp_cache_delete( 'psr_all', 'psr' );
		do_action( 'psr_vehicle_saved', $id );
		return $id;
	}

	/**
	 * Replace a vehicle's gallery.
	 *
	 * @param int   $id    Vehicle id.
	 * @param array $items Attachment ids, or arrays with attachment_id + credit.
	 */
	public static function set_media( $id, $items ) {
		update_option( 'psr_data_ver', (string) microtime( true ), false );
		global $wpdb;
		$wpdb->delete( self::t( 'media' ), array( 'vehicle_id' => $id ) );
		$i = 0;
		foreach ( (array) $items as $it ) {
			$aid    = is_array( $it ) ? (int) ( $it['attachment_id'] ?? 0 ) : (int) $it;
			$credit = is_array( $it ) ? sanitize_text_field( $it['credit'] ?? '' ) : '';
			if ( ! $aid ) {
				continue;
			}
			$wpdb->insert(
				self::t( 'media' ),
				array(
					'vehicle_id'    => $id,
					'attachment_id' => $aid,
					'credit'        => $credit,
					'sort_order'    => $i++,
				)
			);
		}
	}

	public static function delete_vehicle( $id ) {
		update_option( 'psr_data_ver', (string) microtime( true ), false );
		global $wpdb;
		$wpdb->delete( self::t( 'media' ), array( 'vehicle_id' => (int) $id ) );
		$wpdb->delete( self::t( 'vehicles' ), array( 'id' => (int) $id ) );
		wp_cache_delete( 'psr_all', 'psr' );
	}

	/* -------------------------------------------------------------- read */

	public static function get( $id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'vehicles' ) . ' WHERE id = %d', $id ) ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	public static function by_slug( $slug ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'vehicles' ) . ' WHERE slug = %s', $slug ) ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	public static function by_ref( $ref ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'vehicles' ) . ' WHERE source_ref = %s', $ref ) ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/**
	 * Query vehicles.
	 *
	 * @param array $args status, make, body, featured, in_hero, limit, exclude, all (include drafts), orderby.
	 * @return array
	 */
	public static function query( $args = array() ) {
		global $wpdb;
		$a     = wp_parse_args(
			$args,
			array(
				'status'   => '',
				'make'     => '',
				'body'     => '',
				'featured' => null,
				'in_hero'  => null,
				'limit'    => 0,
				'exclude'  => 0,
				'all'      => false,
				'orderby'  => 'curated',
			)
		);
		$where = array( '1=1' );
		$vals  = array();
		if ( ! $a['all'] ) {
			$where[] = "visibility = 'publish'";
		}
		if ( $a['status'] ) {
			$st      = array_map( 'sanitize_key', explode( ',', $a['status'] ) );
			$where[] = 'status IN (' . implode( ',', array_fill( 0, count( $st ), '%s' ) ) . ')';
			$vals    = array_merge( $vals, $st );
		}
		foreach ( array( 'make', 'body' ) as $f ) {
			if ( $a[ $f ] ) {
				$where[] = "$f = %s";
				$vals[]  = $a[ $f ];
			}
		}
		foreach ( array( 'featured', 'in_hero' ) as $f ) {
			if ( null !== $a[ $f ] && '' !== $a[ $f ] ) {
				$where[] = "$f = %d";
				$vals[]  = (int) (bool) $a[ $f ];
			}
		}
		if ( $a['exclude'] ) {
			$where[] = 'id <> %d';
			$vals[]  = (int) $a['exclude'];
		}
		$order = array(
			'curated' => "FIELD(status,'gallery','reserved','commission','placed'), sort_order ASC, featured DESC, year DESC, id DESC",
			'newest'  => 'created_at DESC',
			'year'    => 'year DESC',
			'make'    => 'make ASC, model ASC',
			'random'  => 'RAND()',
		);
		$sql = 'SELECT * FROM ' . self::t( 'vehicles' ) . ' WHERE ' . implode( ' AND ', $where ) . ' ORDER BY ' . ( $order[ $a['orderby'] ] ?? $order['curated'] );
		if ( $a['limit'] ) {
			$sql .= ' LIMIT ' . (int) $a['limit'];
		}
		return $vals ? $wpdb->get_results( $wpdb->prepare( $sql, $vals ) ) : $wpdb->get_results( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	public static function media( $vehicle_id ) {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'media' ) . ' WHERE vehicle_id = %d ORDER BY sort_order ASC, id ASC', $vehicle_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/** First image attachment id for a vehicle. */
	public static function cover( $v ) {
		if ( ! empty( $v->hero_attachment ) ) {
			return (int) $v->hero_attachment;
		}
		$m = self::media( $v->id );
		return $m ? (int) $m[0]->attachment_id : 0;
	}

	public static function distinct( $col ) {
		global $wpdb;
		$col = in_array( $col, array( 'make', 'body', 'year', 'status' ), true ) ? $col : 'make';
		return $wpdb->get_results( "SELECT $col AS v, COUNT(*) AS n FROM " . self::t( 'vehicles' ) . " WHERE visibility='publish' AND $col <> '' GROUP BY $col ORDER BY $col ASC" ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	public static function bump_views( $id ) {
		global $wpdb;
		$wpdb->query( $wpdb->prepare( 'UPDATE ' . self::t( 'vehicles' ) . ' SET views = views + 1 WHERE id = %d', $id ) ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/* --------------------------------------------------------- enquiries */

	public static function add_enquiry( $d ) {
		global $wpdb;
		$wpdb->insert(
			self::t( 'enquiries' ),
			array(
				'vehicle_id' => (int) ( $d['vehicle_id'] ?? 0 ),
				'kind'       => sanitize_key( $d['kind'] ?? 'viewing' ),
				'name'       => sanitize_text_field( $d['name'] ?? '' ),
				'phone'      => sanitize_text_field( $d['phone'] ?? '' ),
				'email'      => sanitize_email( $d['email'] ?? '' ),
				'preferred'  => sanitize_text_field( $d['preferred'] ?? '' ),
				'message'    => sanitize_textarea_field( $d['message'] ?? '' ),
				'source_url' => esc_url_raw( $d['source_url'] ?? '' ),
				'status'     => 'new',
				'created_at' => current_time( 'mysql' ),
			)
		);
		return (int) $wpdb->insert_id;
	}

	public static function enquiries( $status = '' ) {
		global $wpdb;
		$t = self::t( 'enquiries' );
		$v = self::t( 'vehicles' );
		$w = $status ? $wpdb->prepare( 'WHERE e.status = %s', $status ) : '';
		return $wpdb->get_results( "SELECT e.*, CONCAT(v.make,' ',v.model) AS vehicle FROM $t e LEFT JOIN $v v ON v.id = e.vehicle_id $w ORDER BY e.created_at DESC LIMIT 500" ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	public static function count_new_enquiries() {
		global $wpdb;
		return (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::t( 'enquiries' ) . " WHERE status = 'new'" ); // phpcs:ignore WordPress.DB.PreparedSQL
	}
}
