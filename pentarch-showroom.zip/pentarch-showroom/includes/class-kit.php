<?php
/**
 * Site kit: installs the design (Pentarch Live Edit blocks) and the pages that use it.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class PSR_Kit {

	/** Pages created by the kit: slug => [title, block slug]. */
	const PAGES = array(
		'home'             => array( 'Home', 'home' ),
		'collection'       => array( 'The Collection', 'collection' ),
		'feature-your-car' => array( 'Feature Your Car', 'feature-your-car' ),
		'showroom'         => array( '3D Showroom', 'showroom' ),
		'lab'              => array( 'Under the Hood', 'lab' ),
		'parts'            => array( 'Rare Parts', 'parts' ),
		'about'            => array( 'About', 'about' ),
		'play'             => array( 'Play', 'play' ),
		'contact'          => array( 'Contact', 'contact' ),
	);

	/** Images the kit places, fetched once into the Media Library: key => URL. */
	const MEDIA = array(
		'curator-carol'  => 'https://pentarchcommunications.com/wp-content/uploads/2026/11/caroline-njue-pentarch-communications-director.jpg',
		'curator-steve'  => 'https://lfesolutions.co.ke/wp-content/uploads/2026/10/lfe-team-stevedenzel-mungai-hd.jpg',
	);

	public static function ple_ready() {
		return post_type_exists( 'ple_block' ) && class_exists( 'Pentarch_Live_Edit' );
	}

	public static function blocks() {
		$out = array();
		foreach ( glob( PSR_DIR . 'kit/*.html' ) as $f ) {
			$out[] = basename( $f, '.html' );
		}
		return $out;
	}

	public static function steps() {
		return array_merge( array( 'media' ), self::blocks(), array( 'pages' ) );
	}

	/**
	 * Run one kit step.
	 *
	 * @param string $step      Step name.
	 * @param bool   $overwrite Replace blocks that already exist (keeps a revision).
	 */
	public static function run( $step, $overwrite = false ) {
		if ( ! self::ple_ready() ) {
			return new WP_Error( 'psr_ple', 'Activate Pentarch Live Edit first.' );
		}
		if ( 'media' === $step ) {
			return self::media();
		}
		if ( 'pages' === $step ) {
			return self::pages();
		}
		return self::block( sanitize_title( $step ), $overwrite );
	}

	private static function media() {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$map  = (array) get_option( 'psr_kit_media', array() );
		$done = array();
		foreach ( self::MEDIA as $key => $url ) {
			if ( ! empty( $map[ $key ] ) && get_post( $map[ $key ] ) ) {
				$done[] = $key . ' (kept)';
				continue;
			}
			$tmp = download_url( $url, 45 );
			if ( is_wp_error( $tmp ) ) {
				$done[] = $key . ' failed: ' . $tmp->get_error_message();
				continue;
			}
			$aid = media_handle_sideload( array( 'name' => $key . '.jpg', 'tmp_name' => $tmp ), 0, ucwords( str_replace( '-', ' ', $key ) ) );
			if ( is_wp_error( $aid ) ) {
				wp_delete_file( $tmp );
				$done[] = $key . ' failed: ' . $aid->get_error_message();
				continue;
			}
			$map[ $key ] = (int) $aid;
			$done[]      = $key;
		}
		update_option( 'psr_kit_media', $map );
		return 'Media: ' . implode( ', ', $done );
	}

	/** Replace {{tokens}} in kit HTML. */
	public static function fill( $html ) {
		$s    = psr_settings();
		$map  = (array) get_option( 'psr_kit_media', array() );
		$tels = preg_replace( '/[^\d+]/', '', (string) $s['phone'] );
		$rep  = array(
			'{{home}}'       => esc_url( home_url( '/' ) ),
			'{{collection}}' => esc_url( PSR_Front::collection_url() ),
			'{{brand}}'      => esc_html( $s['brand'] ),
			'{{phone}}'      => esc_html( $s['phone'] ),
			'{{tel}}'        => esc_attr( $tels ),
			'{{whatsapp}}'   => esc_url( PSR_Front::whatsapp( 'Hello Laqim, ' ) ),
			'{{email}}'      => esc_html( $s['email'] ),
			'{{address}}'    => esc_html( $s['address'] ),
			'{{hours}}'      => esc_html( $s['hours'] ),
			'{{year}}'       => gmdate( 'Y' ),
			'{{plugin}}'     => esc_url( PSR_URL ),
			'{{logo}}'       => esc_url( get_option( 'psr_logo', home_url( '/wp-content/uploads/2024/09/laqimlogo-300x100.png' ) ) ),
		);
		foreach ( $map as $k => $aid ) {
			$u                       = wp_get_attachment_image_url( (int) $aid, 'large' );
			$rep[ '{{img:' . $k . '}}' ] = $u ? esc_url( $u ) : '';
		}
		$html = strtr( $html, $rep );
		// Car photos by vehicle reference: {{car:motors:3645:1}} => second image of that vehicle.
		return preg_replace_callback(
			'/\{\{car:([a-z]+:[a-z0-9-]+)(?::(\d+))?\}\}/',
			function ( $m ) {
				$v = PSR_DB::by_ref( $m[1] );
				if ( ! $v ) {
					return '';
				}
				$media = PSR_DB::media( $v->id );
				$i     = isset( $m[2] ) ? (int) $m[2] : 0;
				$aid   = isset( $media[ $i ] ) ? $media[ $i ]->attachment_id : PSR_DB::cover( $v );
				return esc_url( (string) wp_get_attachment_image_url( (int) $aid, 'full' ) );
			},
			$html
		);
	}

	private static function block( $slug, $overwrite ) {
		$file = PSR_DIR . 'kit/' . $slug . '.html';
		if ( ! file_exists( $file ) ) {
			return new WP_Error( 'psr_kit', 'Unknown block ' . $slug );
		}
		$html = self::fill( (string) file_get_contents( $file ) ); // phpcs:ignore
		$old  = get_page_by_path( $slug, OBJECT, 'ple_block' );
		if ( $old && ! $overwrite ) {
			return 'Block kept: ' . $slug;
		}
		$loc  = 0 === strpos( $slug, 'global-header' ) ? 'body_open' : ( 0 === strpos( $slug, 'global-footer' ) ? 'footer' : ( 0 === strpos( $slug, 'global-head' ) ? 'head' : 'none' ) );
		$args = array(
			'post_type'    => 'ple_block',
			'post_status'  => 'publish',
			'post_name'    => $slug,
			'post_title'   => ucwords( str_replace( '-', ' ', $slug ) ),
			'post_content' => wp_slash( $html ),
		);
		if ( $old ) {
			$args['ID'] = $old->ID;
			$id         = wp_update_post( $args, true );
		} else {
			$id = wp_insert_post( $args, true );
		}
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		update_post_meta( $id, '_ple_location', $loc );
		do_action( 'litespeed_purge_all' );
		return ( $old ? 'Block updated: ' : 'Block created: ' ) . $slug;
	}

	private static function pages() {
		$ids = array();
		foreach ( self::PAGES as $slug => $p ) {
			$page = get_page_by_path( $slug );
			$body = '[ple id="' . $p[1] . '"]';
			if ( $page ) {
				if ( false === strpos( $page->post_content, $body ) ) {
					wp_update_post( array( 'ID' => $page->ID, 'post_content' => $body, 'post_status' => 'publish' ) );
				}
				$ids[ $slug ] = $page->ID;
			} else {
				$ids[ $slug ] = wp_insert_post(
					array(
						'post_type'    => 'page',
						'post_status'  => 'publish',
						'post_title'   => $p[0],
						'post_name'    => $slug,
						'post_content' => $body,
					)
				);
			}
		}
		foreach ( $ids as $pid ) {
			// Hand pages built earlier with Elementor back to their own content.
			delete_post_meta( (int) $pid, '_elementor_edit_mode' );
			delete_post_meta( (int) $pid, '_elementor_data' );
			update_post_meta( (int) $pid, '_wp_page_template', 'default' );
		}
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', (int) $ids['home'] );
		$s         = (array) get_option( 'psr_settings', array() );
		$s['base'] = 'collection';
		update_option( 'psr_settings', $s );
		PSR_Front::rewrites();
		flush_rewrite_rules();
		do_action( 'litespeed_purge_all' );
		return 'Pages ready, home page set: ' . implode( ', ', array_keys( $ids ) );
	}
}
