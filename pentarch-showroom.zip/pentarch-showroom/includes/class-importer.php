<?php
/**
 * Importer: brings Motors listings across, and adds the curated "By Commission" vehicles.
 * Each step is small so it finishes well inside PHP time limits; the Setup screen runs them in turn.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class PSR_Importer {

	public static function seed() {
		static $s = null;
		if ( null === $s ) {
			$s = include PSR_DIR . 'data/seed.php';
		}
		return $s;
	}

	/** Ordered list of import steps: array of [type, key]. */
	public static function steps() {
		$s     = self::seed();
		$steps = array();
		foreach ( array_keys( $s['motors'] ) as $id ) {
			$steps[] = array( 'motors', $id );
		}
		foreach ( $s['curated'] as $i => $c ) {
			$steps[] = array( 'curated', $i );
		}
		return $steps;
	}

	/**
	 * Run one step.
	 *
	 * @param int  $n         Step index.
	 * @param bool $overwrite Replace details of vehicles that already exist.
	 * @return array Result message.
	 */
	public static function run( $n, $overwrite = false ) {
		$steps = self::steps();
		if ( ! isset( $steps[ $n ] ) ) {
			return array( 'done' => true, 'msg' => 'Finished' );
		}
		list( $type, $key ) = $steps[ $n ];
		$msg   = 'motors' === $type ? self::motors( (int) $key, $overwrite ) : self::curated( (int) $key, $overwrite );
		$again = is_array( $msg );
		if ( $again ) {
			$msg = $msg[0];
		}
		return array(
			'done'  => ! $again && $n + 1 >= count( $steps ),
			'next'  => $again ? $n : $n + 1,
			'total' => count( $steps ),
			'msg'   => $msg,
		);
	}

	/** Attachment ids of a Motors listing: featured image first, then its gallery. */
	public static function motors_images( $post_id ) {
		$ids   = array();
		$thumb = (int) get_post_thumbnail_id( $post_id );
		if ( $thumb ) {
			$ids[] = $thumb;
		}
		$g = get_post_meta( $post_id, 'gallery', true );
		if ( is_string( $g ) ) {
			$g = array_filter( array_map( 'intval', explode( ',', $g ) ) );
		}
		foreach ( (array) $g as $a ) {
			$a = (int) $a;
			if ( $a && ! in_array( $a, $ids, true ) && wp_attachment_is_image( $a ) ) {
				$ids[] = $a;
			}
		}
		if ( count( $ids ) < 2 ) {
			$kids = get_children(
				array(
					'post_parent'    => $post_id,
					'post_type'      => 'attachment',
					'post_mime_type' => 'image',
					'orderby'        => 'menu_order ID',
					'order'          => 'ASC',
					'fields'         => 'ids',
				)
			);
			foreach ( (array) $kids as $a ) {
				if ( ! in_array( (int) $a, $ids, true ) ) {
					$ids[] = (int) $a;
				}
			}
		}
		return $ids;
	}

	private static function motors( $post_id, $overwrite ) {
		$seed = self::seed()['motors'][ $post_id ];
		$post = get_post( $post_id );
		$ref  = 'motors:' . $post_id;
		$old  = PSR_DB::by_ref( $ref );
		if ( $old && ! $overwrite ) {
			return 'Kept existing: ' . PSR_DB::title( $old );
		}
		$imgs = $post ? self::motors_images( $post_id ) : array();
		foreach ( (array) ( $seed['merge'] ?? array() ) as $dup ) {
			foreach ( self::motors_images( (int) $dup ) as $a ) {
				if ( ! in_array( $a, $imgs, true ) ) {
					$imgs[] = $a;
				}
			}
		}
		unset( $seed['merge'] );
		$data               = $seed;
		$data['status']     = 'gallery';
		$data['visibility'] = 'publish';
		$data['source_ref'] = $ref;
		$data['gallery']    = $imgs;
		if ( ! $old ) {
			$data['slug'] = sanitize_title( $seed['make'] . ' ' . $seed['model'] . ' ' . ( $seed['year'] ? $seed['year'] : '' ) . ' ' . ( $seed['exterior_color'] ?? '' ) );
		}
		$id = PSR_DB::save_vehicle( $data, $old ? (int) $old->id : 0 );
		return ( $old ? 'Updated' : 'Imported' ) . ': ' . $seed['make'] . ' ' . $seed['model'] . ' (' . count( $imgs ) . ' photos)' . ( $post ? '' : ' — Motors listing not found, no photos' );
	}

	private static function curated( $i, $overwrite ) {
		$s    = self::seed();
		$seed = $s['curated'][ $i ];
		$ref  = 'curated:' . $seed['slug'];
		$old  = PSR_DB::by_ref( $ref );
		if ( $old && ! $overwrite ) {
			return 'Kept existing: ' . PSR_DB::title( $old );
		}
		$media   = $old ? PSR_DB::media( $old->id ) : array();
		$gallery = array();
		$credits = array();
		if ( $media ) {
			foreach ( $media as $m ) {
				$gallery[] = array( 'attachment_id' => $m->attachment_id, 'credit' => $m->credit );
				$credits[] = $m->credit;
			}
		} else {
			$fresh = 0;
			foreach ( $seed['images'] as $img ) {
				$had = self::find_commons( $img[0] );
				if ( ! $had && $fresh >= 2 ) {
					return array( 'Downloading photos for ' . $seed['make'] . ' ' . $seed['model'] . '…' );
				}
				$aid = $had ? $had : self::sideload_commons( $s['commons'], $img[0], $seed['make'] . ' ' . $seed['model'], $img[1] );
				if ( ! $had ) {
					$fresh++;
				}
				if ( is_wp_error( $aid ) ) {
					continue;
				}
				$gallery[] = array( 'attachment_id' => $aid, 'credit' => $img[1] );
				$credits[] = $img[1];
			}
		}
		$data = $seed;
		unset( $data['images'] );
		$data['status']          = 'commission';
		$data['visibility']      = 'publish';
		$data['condition_label'] = '';
		$data['source_ref']      = $ref;
		$data['gallery']         = $gallery;
		$data['credits']         = array_values( array_unique( $credits ) );
		PSR_DB::save_vehicle( $data, $old ? (int) $old->id : 0 );
		return ( $old ? 'Updated' : 'Curated' ) . ': ' . $seed['make'] . ' ' . $seed['model'] . ' (' . count( $gallery ) . ' photos)';
	}

	/** Attachment already downloaded for a Commons path, or 0. */
	public static function find_commons( $path ) {
		$found = get_posts(
			array(
				'post_type'   => 'attachment',
				'post_status' => 'inherit',
				'meta_key'    => '_psr_source', // phpcs:ignore
				'meta_value'  => $path, // phpcs:ignore
				'fields'      => 'ids',
				'numberposts' => 1,
			)
		);
		return $found ? (int) $found[0] : 0;
	}

	/**
	 * Download a Wikimedia Commons image (2400px rendition) into the Media Library.
	 *
	 * @param string $base   Commons upload base URL.
	 * @param string $path   "a/ab/File_name.jpg".
	 * @param string $title  Alt / title text.
	 * @param string $credit Credit line (author, licence).
	 * @return int|WP_Error Attachment id.
	 */
	public static function sideload_commons( $base, $path, $title, $credit ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$name  = basename( $path );
		$found = self::find_commons( $path );
		if ( $found ) {
			return $found;
		}
		$thumb = $base . 'thumb/' . $path . '/1920px-' . $name;
		$tmp   = download_url( $thumb, 60 );
		if ( is_wp_error( $tmp ) ) {
			$tmp = download_url( $base . $path, 90 );
		}
		if ( is_wp_error( $tmp ) ) {
			return $tmp;
		}
		$clean = sanitize_file_name( strtolower( preg_replace( '/[^A-Za-z0-9._-]+/', '-', rawurldecode( $name ) ) ) );
		$file  = array(
			'name'     => 'curated-' . $clean,
			'tmp_name' => $tmp,
		);
		$aid = media_handle_sideload( $file, 0, $title );
		if ( is_wp_error( $aid ) ) {
			wp_delete_file( $tmp );
			return $aid;
		}
		update_post_meta( $aid, '_wp_attachment_image_alt', $title );
		update_post_meta( $aid, '_psr_source', $path );
		wp_update_post(
			array(
				'ID'           => $aid,
				'post_excerpt' => 'Photo: ' . $credit . ', via Wikimedia Commons',
			)
		);
		return (int) $aid;
	}
}
