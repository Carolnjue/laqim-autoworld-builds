<?php
/**
 * Seed data for the first install.
 *
 * - 'motors': corrected details for vehicles that already exist in the Motors plugin, keyed by the
 *   Motors listing id. Photos are taken from the Motors gallery during import. 'merge' adds the photos
 *   of a duplicate listing.
 * - 'curated': vehicles shown "By Commission", illustrated with freely licensed photographs from
 *   Wikimedia Commons (credited on the vehicle page as the licences require).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$c = 'https://upload.wikimedia.org/wikipedia/commons/';

return array(
	'motors'  => array(
		3645 => array(
			'make' => 'Mercedes-AMG', 'model' => 'G 63', 'variant' => 'AMG G-Class, W463', 'year' => 2024, 'body' => 'SUV',
			'tagline' => 'Hand-built V8, square-shouldered presence. The G 63 as it should be kept.',
			'condition_label' => 'Foreign used', 'mileage_km' => 43000, 'engine' => '4.0L twin-turbo V8', 'power' => '585 hp',
			'transmission' => '9-speed AMG SPEEDSHIFT TCT', 'drivetrain' => '4MATIC all-wheel drive', 'fuel' => 'Petrol', 'consumption' => '15–20 L/100 km',
			'exterior_color' => 'Obsidian Black', 'interior_color' => 'Black leather', 'seats' => '5', 'price' => 56999999,
			'highlights' => "Three locking differentials\nAMG Ride Control suspension\nSide-exit exhaust\nWidescreen digital cockpit",
			'summary' => '<p>Forty-five years after the first G-Class, the G 63 is still the reference for an off-roader with character: hand-built twin-turbo V8, three locking differentials and a shape that refuses to change. We photographed this 2024 example in black over black.</p>',
			'featured' => 1, 'in_hero' => 1, 'sort_order' => 1,
		),
		3616 => array(
			'make' => 'Land Rover', 'model' => 'Range Rover P360', 'variant' => 'L460, Batumi Gold', 'year' => 2025, 'body' => 'SUV',
			'tagline' => 'Batumi Gold over Perlino. Fifth-generation calm.',
			'condition_label' => 'New', 'mileage_km' => 0, 'engine' => '3.0L Ingenium inline-6 turbo, mild hybrid', 'power' => '360 PS',
			'transmission' => '8-speed automatic', 'drivetrain' => 'All-wheel drive', 'fuel' => 'Petrol (MHEV)',
			'exterior_color' => 'Batumi Gold', 'interior_color' => 'Perlino / cream leather', 'seats' => '5', 'price' => 70500000,
			'highlights' => "Dynamic Air Suspension\nAll-wheel steering\nMeridian sound\nPixel LED headlights",
			'summary' => '<p>The fifth-generation Range Rover is the quietest it has ever been, and Batumi Gold over Perlino is one of its most elegant combinations. A study in reduction: flush glass, hidden door handles, a single unbroken waistline.</p>',
			'featured' => 1, 'in_hero' => 1, 'sort_order' => 2, 'merge' => array( 3439 ),
		),
		3483 => array(
			'make' => 'Lexus', 'model' => 'LX 600', 'variant' => 'VIP four-seat', 'year' => 2024, 'body' => 'SUV',
			'tagline' => 'A rear cabin built like a first-class suite, on Land Cruiser foundations.',
			'condition_label' => 'Unregistered', 'mileage_km' => 3000, 'engine' => '3.5L twin-turbo V6', 'power' => '409 hp',
			'transmission' => '10-speed automatic', 'drivetrain' => 'Full-time 4WD', 'fuel' => 'Petrol', 'consumption' => '12–15 L/100 km',
			'exterior_color' => 'Black', 'interior_color' => 'Heated leather', 'seats' => '4', 'price' => 42500000,
			'highlights' => "VIP rear seats with ottoman\nRear entertainment screens\nMark Levinson audio\nAdaptive variable suspension",
			'featured' => 1, 'in_hero' => 1, 'sort_order' => 3,
		),
		3637 => array(
			'make' => 'Mercedes-Benz', 'model' => 'S 500 4MATIC', 'variant' => 'AMG Line, W223', 'year' => 2021, 'body' => 'Sedan',
			'tagline' => 'The flagship saloon, in white over black Nappa.',
			'condition_label' => 'Foreign used', 'mileage_km' => 44000, 'engine' => '3.0L inline-6 turbo with EQ Boost', 'power' => '435 hp',
			'transmission' => '9G-TRONIC automatic', 'drivetrain' => '4MATIC all-wheel drive', 'fuel' => 'Petrol (mild hybrid)', 'consumption' => '9–10 L/100 km',
			'exterior_color' => 'White', 'interior_color' => 'Black Nappa leather', 'seats' => '5', 'price' => 19500000,
			'highlights' => "MBUX with OLED central display\nAMG Line exterior\nBurmester surround sound\nAmbient lighting",
			'featured' => 1, 'in_hero' => 1, 'sort_order' => 4,
		),
		3479 => array(
			'make' => 'Toyota', 'model' => 'Land Cruiser 300 GR Sport', 'variant' => 'J300', 'year' => 2023, 'body' => 'SUV',
			'tagline' => 'Rally-bred GR Sport: E-KDSS and twin-turbo diesel torque.',
			'condition_label' => 'Foreign used', 'mileage_km' => 64000, 'engine' => '3.3L twin-turbo V6 diesel', 'power' => '309 hp',
			'transmission' => '10-speed automatic', 'drivetrain' => 'Full-time 4WD', 'fuel' => 'Diesel',
			'exterior_color' => 'Black', 'interior_color' => 'Black leather', 'seats' => '5', 'price' => 23500000,
			'highlights' => "E-KDSS stabiliser system\nFront and rear locking differentials\nGR Sport styling\nMulti-Terrain Select",
			'in_hero' => 1, 'sort_order' => 5,
		),
		3475 => array(
			'make' => 'Toyota', 'model' => 'Land Cruiser 300 ZX', 'variant' => 'J300, petrol', 'year' => 2023, 'body' => 'SUV',
			'tagline' => 'The ZX: the most luxurious Land Cruiser yet.',
			'condition_label' => 'Foreign used', 'mileage_km' => 18000, 'engine' => '3.5L twin-turbo V6', 'power' => '409 hp',
			'transmission' => '10-speed automatic', 'drivetrain' => 'Full-time 4WD', 'fuel' => 'Petrol', 'consumption' => '12–15 L/100 km',
			'exterior_color' => 'Black', 'interior_color' => 'Beige leather', 'seats' => '5', 'price' => 24999999,
			'featured' => 1, 'sort_order' => 6,
		),
		3454 => array(
			'make' => 'Toyota', 'model' => 'Land Cruiser 300 ZX', 'variant' => '70th Anniversary specification', 'year' => 2022, 'body' => 'SUV',
			'tagline' => 'Pearl white with beige hide, from the 70th anniversary year.',
			'condition_label' => 'Foreign used', 'mileage_km' => 32000, 'engine' => '3.5L twin-turbo V6', 'power' => '409 hp',
			'transmission' => '10-speed automatic', 'drivetrain' => 'Full-time 4WD', 'fuel' => 'Petrol', 'consumption' => '12–15 L/100 km',
			'exterior_color' => 'Pearl White', 'interior_color' => 'Beige leather', 'seats' => '5', 'price' => 24999999,
			'sort_order' => 7,
		),
		3471 => array(
			'make' => 'Toyota', 'model' => 'Land Cruiser Prado 250', 'variant' => 'J250 ZX, Japan specification', 'year' => 2024, 'body' => 'SUV',
			'tagline' => 'The all-new Prado, back to its boxy roots. Japan-spec ZX.',
			'condition_label' => 'Foreign used', 'mileage_km' => 8000, 'engine' => '2.8L turbo diesel', 'power' => '201 hp',
			'transmission' => '8-speed automatic', 'drivetrain' => 'Full-time 4WD', 'fuel' => 'Diesel', 'consumption' => '9–10 L/100 km',
			'exterior_color' => 'White', 'interior_color' => 'Brown leather', 'seats' => '7', 'price' => 23500000,
			'sort_order' => 8,
		),
		3604 => array(
			'make' => 'Lexus', 'model' => 'LX 500d', 'variant' => 'J310', 'year' => 2023, 'body' => 'SUV',
			'tagline' => 'Twin-turbo diesel LX: effortless range, quiet authority.',
			'condition_label' => 'Unregistered', 'mileage_km' => null, 'engine' => '3.3L twin-turbo V6 diesel', 'power' => '304 hp',
			'transmission' => '10-speed automatic', 'drivetrain' => 'Full-time 4WD', 'fuel' => 'Diesel',
			'exterior_color' => 'Black', 'interior_color' => 'Leather', 'seats' => '5', 'price' => 40500000,
			'featured' => 1, 'sort_order' => 9,
		),
		3625 => array(
			'make' => 'Land Rover', 'model' => 'Range Rover P360', 'variant' => 'L460, Charente Grey', 'year' => 0, 'body' => 'SUV',
			'tagline' => 'Charente Grey: understated and architectural.',
			'condition_label' => 'New', 'mileage_km' => 0, 'engine' => '3.0L Ingenium inline-6 turbo, mild hybrid', 'power' => '360 PS',
			'transmission' => '8-speed automatic', 'drivetrain' => 'All-wheel drive', 'fuel' => 'Petrol (MHEV)',
			'exterior_color' => 'Charente Grey', 'interior_color' => 'Beige leather', 'seats' => '5', 'price' => 70500000,
			'sort_order' => 10,
		),
		3620 => array(
			'make' => 'Land Rover', 'model' => 'Range Rover P360', 'variant' => 'L460, Varesine Blue', 'year' => 0, 'body' => 'SUV',
			'tagline' => 'Varesine Blue over a pale cabin.',
			'condition_label' => 'New', 'mileage_km' => 0, 'engine' => '3.0L Ingenium inline-6 turbo, mild hybrid', 'power' => '360 PS',
			'transmission' => '8-speed automatic', 'drivetrain' => 'All-wheel drive', 'fuel' => 'Petrol (MHEV)',
			'exterior_color' => 'Varesine Blue', 'interior_color' => 'Light leather', 'seats' => '5', 'price' => 72500000,
			'sort_order' => 11,
		),
		3641 => array(
			'make' => 'Mercedes-Benz', 'model' => 'GLE 350d', 'variant' => 'AMG Line', 'year' => 0, 'body' => 'SUV',
			'tagline' => 'Diesel 4MATIC comfort in polar white.',
			'condition_label' => 'Foreign used', 'mileage_km' => 36000, 'engine' => '3.0L V6 turbo diesel', 'power' => '258 hp',
			'transmission' => '9-speed automatic', 'drivetrain' => '4MATIC all-wheel drive', 'fuel' => 'Diesel',
			'exterior_color' => 'White', 'interior_color' => 'Leather', 'seats' => '5', 'price' => 15000000,
			'sort_order' => 12,
		),
		3633 => array(
			'make' => 'Toyota', 'model' => 'Harrier Turbo Premium', 'variant' => 'XU60', 'year' => 2019, 'body' => 'SUV',
			'tagline' => 'The turbocharged Harrier, with purple Alcantara detailing.',
			'condition_label' => 'Foreign used', 'mileage_km' => 63000, 'engine' => '2.0L turbo', 'power' => '228 hp',
			'transmission' => '6-speed automatic', 'drivetrain' => '2WD', 'fuel' => 'Petrol', 'consumption' => '9–12 L/100 km',
			'exterior_color' => 'Black', 'interior_color' => 'Black half-leather with purple Alcantara', 'seats' => '5', 'price' => 4700000,
			'sort_order' => 13,
		),
		3612 => array(
			'make' => 'Toyota', 'model' => 'RAV4 Adventure', 'variant' => 'XA50, Red', 'year' => 2019, 'body' => 'SUV',
			'tagline' => 'Adventure-grade RAV4 with dynamic torque-vectoring AWD.',
			'condition_label' => 'Foreign used', 'mileage_km' => 43000, 'engine' => '2.0L Dynamic Force', 'power' => '171 hp',
			'transmission' => 'Direct Shift CVT', 'drivetrain' => 'AWD', 'fuel' => 'Petrol', 'consumption' => '6–7 L/100 km',
			'exterior_color' => 'Red', 'interior_color' => 'Leather', 'seats' => '5', 'price' => 5800000,
			'sort_order' => 14,
		),
		3608 => array(
			'make' => 'Toyota', 'model' => 'RAV4 Adventure', 'variant' => 'XA50, Black', 'year' => 2019, 'body' => 'SUV',
			'tagline' => 'The Adventure grade in black, built for the weekend.',
			'condition_label' => 'Foreign used', 'mileage_km' => 76000, 'engine' => '2.0L Dynamic Force', 'power' => '171 hp',
			'transmission' => 'Direct Shift CVT', 'drivetrain' => 'AWD', 'fuel' => 'Petrol', 'consumption' => '6–7 L/100 km',
			'exterior_color' => 'Black', 'interior_color' => 'Leather', 'seats' => '5', 'price' => 6000000,
			'sort_order' => 15,
		),
	),

	'curated' => array(
		array(
			'slug' => 'rolls-royce-cullinan', 'make' => 'Rolls-Royce', 'model' => 'Cullinan', 'variant' => 'Black Badge and Series II', 'body' => 'SUV',
			'tagline' => 'The first Rolls-Royce built to leave the road.',
			'engine' => '6.75L twin-turbo V12', 'power' => '571 PS', 'transmission' => '8-speed automatic', 'drivetrain' => 'All-wheel drive', 'fuel' => 'Petrol', 'seats' => '4–5',
			'highlights' => "Starlight headliner\nViewing Suite tailgate seats\nPlanar suspension\nBespoke colour and hide",
			'summary' => '<p>Named after the largest diamond ever found, the Cullinan brought the Architecture of Luxury to an all-wheel-drive SUV. Almost every one is commissioned through Bespoke, so no two are quite alike.</p>',
			'featured' => 1, 'in_hero' => 1, 'sort_order' => 20,
			'images' => array(
				array( '9/9c/Rolls-Royce_Cullinan_001.jpg', 'Jengtingchen, CC BY-SA 4.0' ),
				array( '4/4b/Rolls-Royce_Cullinan_002.jpg', 'Jengtingchen, CC BY-SA 4.0' ),
				array( '4/4b/Rolls_Royce_Cullinan_Interior.jpg', 'Kārlis Dambrāns, CC BY 2.0' ),
				array( 'b/b1/Rolls-Royce_Cullinan_009.jpg', 'Jengtingchen, CC BY-SA 4.0' ),
			),
		),
		array(
			'slug' => 'ferrari-purosangue', 'make' => 'Ferrari', 'model' => 'Purosangue', 'variant' => 'Ferrari’s first four-door', 'body' => 'SUV',
			'tagline' => 'Four doors, four seats, a naturally aspirated V12.',
			'engine' => '6.5L naturally aspirated V12', 'power' => '725 PS', 'transmission' => '8-speed dual-clutch', 'drivetrain' => 'All-wheel drive', 'fuel' => 'Petrol', 'seats' => '4',
			'highlights' => "Rear-hinged welcome doors\nActive suspension\nCarbon-fibre roof\n0–100 km/h in 3.3 s",
			'summary' => '<p>Ferrari refuses to call it an SUV. The Purosangue keeps a naturally aspirated front-mid V12, rear-hinged doors and active suspension that lets it corner like a GT. Production is capped and allocation is by invitation.</p>',
			'featured' => 1, 'in_hero' => 1, 'sort_order' => 21,
			'images' => array(
				array( 'b/b5/Ferrari_Purosangue_IMG_9554.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '5/53/Ferrari_Purosangue_IMG_9563.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( 'c/cb/Ferrari_Purosangue_DSC_7008.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '4/47/Ferrari_Purosangue_DSC_7003.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
			),
		),
		array(
			'slug' => 'lamborghini-urus', 'make' => 'Lamborghini', 'model' => 'Urus', 'variant' => 'S or Performante', 'body' => 'SUV',
			'tagline' => 'The super SUV: twin-turbo V8 drama with a usable boot.',
			'engine' => '4.0L twin-turbo V8', 'power' => '650–666 PS', 'transmission' => '8-speed automatic', 'drivetrain' => 'All-wheel drive', 'fuel' => 'Petrol', 'seats' => '4–5',
			'highlights' => "ANIMA drive modes\nCarbon-ceramic brakes\nRear-wheel steering\nAkrapovič exhaust (Performante)",
			'summary' => '<p>The Urus turned Lamborghini into a brand you could drive every day, and the Performante sharpened it back into a weapon. It remains the benchmark for the super SUV.</p>',
			'featured' => 1, 'in_hero' => 1, 'sort_order' => 22,
			'images' => array(
				array( 'e/ee/Lamborghini_Urus_20180306_Genf_2018.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '6/66/Geneva_International_Motor_Show_2018%2C_Le_Grand-Saconnex_%281X7A1485%29.jpg', 'Matti Blume, CC BY-SA 4.0' ),
				array( '7/7c/Geneva_International_Motor_Show_2018%2C_Le_Grand-Saconnex_%281X7A1505%29.jpg', 'Matti Blume, CC BY-SA 4.0' ),
				array( '0/0a/Lamborghini_Urus_Performante_1X7A6805.jpg', 'Alexander-93, CC BY-SA 4.0' ),
			),
		),
		array(
			'slug' => 'mercedes-maybach-gls-600', 'make' => 'Mercedes-Maybach', 'model' => 'GLS 600 4MATIC', 'variant' => 'X167, Manufaktur colours available', 'body' => 'SUV',
			'tagline' => 'Chauffeur-grade comfort, executive-lounge rear seats.',
			'engine' => '4.0L V8 biturbo with EQ Boost', 'power' => '557 PS', 'transmission' => '9G-TRONIC automatic', 'drivetrain' => '4MATIC all-wheel drive', 'fuel' => 'Petrol (mild hybrid)', 'seats' => '4–5',
			'highlights' => "Executive rear seats with calf rests\nE-ACTIVE BODY CONTROL\nRear MBUX tablet\nChampagne refrigerator",
			'summary' => '<p>The Maybach GLS 600 is built for owners who are driven more than they drive: executive rear seats, a champagne cooler between them and Manufaktur two-tone paint for those who want to be noticed.</p>',
			'featured' => 1, 'sort_order' => 23,
			'images' => array(
				array( 'd/de/Mercedes-Maybach_X167_FL_GLS_600_MANUFAKTUR_Cote_d%27Azur_Light_Blue_%283%29.jpg', 'Damian B Oh, CC BY-SA 4.0' ),
				array( '2/2f/Mercedes-Maybach_X167_FL_GLS_600_MANUFAKTUR_Cote_d%27Azur_Light_Blue_%287%29.jpg', 'Damian B Oh, CC BY-SA 4.0' ),
				array( '1/1f/Teh_interior_of_Mercedes-Maybach_GLS_600_%28X167%29.jpg', 'Tokumeigakarinoaoshima, CC0' ),
				array( '6/6e/Mercedes-Maybach_GLS_600_%28X167%29_interior.jpg', 'Tokumeigakarinoaoshima, CC0' ),
			),
		),
		array(
			'slug' => 'bentley-bentayga', 'make' => 'Bentley', 'model' => 'Bentayga V8', 'variant' => 'Third-generation facelift', 'body' => 'SUV',
			'tagline' => 'Crewe craftsmanship with twin-turbo V8 pace.',
			'engine' => '4.0L twin-turbo V8', 'power' => '550 PS', 'transmission' => '8-speed automatic', 'drivetrain' => 'All-wheel drive', 'fuel' => 'Petrol', 'seats' => '4–7',
			'highlights' => "Mulliner specification options\nBentley Dynamic Ride\nNaim for Bentley audio\nHand-stitched hides",
			'sort_order' => 24,
			'images' => array(
				array( 'e/e5/2021_Bentley_Bentayga_V8_Auto_1.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( 'f/f6/Bentley_Bentayga_V8_%28FL%29_IMG_4122.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( 'e/e2/Bentley_Bentayga_V8_%28FL%29_IMG_4117.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '2/29/Bentley_Bentayga_V8_2021_First_Edition.jpg', 'Alexandre Prevot, CC BY-SA 4.0' ),
			),
		),
		array(
			'slug' => 'rolls-royce-ghost', 'make' => 'Rolls-Royce', 'model' => 'Ghost', 'variant' => 'Second generation', 'body' => 'Sedan',
			'tagline' => 'Post-opulent design, V12 serenity.',
			'engine' => '6.75L twin-turbo V12', 'power' => '571 PS', 'transmission' => '8-speed automatic', 'drivetrain' => 'All-wheel drive, all-wheel steering', 'fuel' => 'Petrol', 'seats' => '5',
			'highlights' => "Planar suspension system\nIlluminated fascia\nCoach doors\nSatellite-aided transmission",
			'sort_order' => 25,
			'images' => array(
				array( 'd/d5/2021_Rolls-Royce_Ghost_V12_4x4_Auto.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( '9/94/Rolls-Royce_Ghost_II_IAA_2021_1X7A0008.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( 'c/c7/2021_Rolls_Royce_Ghost_V12_4x4_Auto_1.jpg', 'Calreyn88, CC BY-SA 4.0' ),
			),
		),
		array(
			'slug' => 'porsche-911-turbo-s', 'make' => 'Porsche', 'model' => '911 Turbo S', 'variant' => '992 generation', 'body' => 'Coupé',
			'tagline' => 'The everyday supercar, now in its finest form.',
			'engine' => '3.8L twin-turbo flat-six (T-Hybrid from 2025)', 'power' => '650–711 PS', 'transmission' => '8-speed PDK', 'drivetrain' => 'All-wheel drive', 'fuel' => 'Petrol', 'seats' => '2+2',
			'highlights' => "Active aerodynamics\nPorsche Ceramic Composite Brakes\nSport Chrono package\nRear-axle steering",
			'sort_order' => 26,
			'images' => array(
				array( '8/86/2025_Porsche_992_Turbo_S_coupes_IAA_2025_DSC_1835.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '5/57/2025_Porsche_992_Turbo_S_coupes_IAA_2025_DSC_1840.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '2/23/2025_Porsche_992_Turbo_S_coupes_IAA_2025_DSC_1841.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( 'c/c7/Porsche_992_Turbo_S_1X7A6046.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
			),
		),
		array(
			'slug' => 'aston-martin-dbx707', 'make' => 'Aston Martin', 'model' => 'DBX707', 'variant' => 'DBX or DBX707', 'body' => 'SUV',
			'tagline' => 'Gaydon’s grand tourer, raised and given 707 PS.',
			'engine' => '4.0L twin-turbo V8', 'power' => '707 PS', 'transmission' => '9-speed wet-clutch automatic', 'drivetrain' => 'All-wheel drive', 'fuel' => 'Petrol', 'seats' => '5',
			'highlights' => "Electronic rear limited-slip differential\nCarbon-ceramic brakes\nTriple-chamber air suspension\nHand-finished cabin",
			'sort_order' => 27,
			'images' => array(
				array( '0/09/Aston_Martin_DBX_707_3.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( 'f/ff/2024_Aston_Martin_DBX_707.jpg', 'Calreyn88, CC0' ),
				array( '5/5b/Aston_Martin_DBX_DSC_7246.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '2/2d/Aston_Martin_DBX_1X7A0838.jpg', 'Alexander-93, CC BY-SA 4.0' ),
			),
		),
		array(
			'slug' => 'bentley-continental-gt', 'make' => 'Bentley', 'model' => 'Continental GT', 'variant' => 'Third generation', 'body' => 'Coupé',
			'tagline' => 'The definitive grand tourer, for crossing continents in comfort.',
			'engine' => '6.0L twin-turbo W12 or 4.0L V8', 'power' => '550–659 PS', 'transmission' => '8-speed dual-clutch', 'drivetrain' => 'All-wheel drive', 'fuel' => 'Petrol', 'seats' => '2+2',
			'highlights' => "Bentley Rotating Display\nDiamond-knurled switchgear\nThree-chamber air springs\nMulliner Driving Specification",
			'sort_order' => 28,
			'images' => array(
				array( '9/9e/2018_Bentley_Continental_GT_%2837965556312%29.jpg', 'More Cars, CC BY 2.0' ),
				array( '3/31/Bentley_Continental_GT_at_Legendy_2018_in_Prague.jpg', 'Jiří Sedláček, CC BY-SA 4.0' ),
				array( '1/19/2018_Bentley_Continental_GT_%2837965555952%29.jpg', 'More Cars, CC BY 2.0' ),
				array( 'a/a5/2018_Bentley_Continental_GT_Auto_%2833850%29.jpg', 'Calreyn88, CC BY-SA 4.0' ),
			),
		),
		array(
			'slug' => 'lamborghini-revuelto', 'make' => 'Lamborghini', 'model' => 'Revuelto', 'variant' => 'First generation', 'year' => 2024, 'body' => 'Coupé',
			'tagline' => 'A V12 and three electric motors: the first plug-in hybrid flagship from Sant’Agata.',
			'engine' => '6.5L naturally aspirated V12 plug-in hybrid', 'power' => '1015 CV', 'transmission' => '8-speed dual-clutch', 'drivetrain' => 'All-wheel drive', 'fuel' => 'Petrol plug-in hybrid', 'consumption' => '11.9 L/100 km (WLTP)', 'seats' => '2',
			'highlights' => "Three electric motors
Carbon-fibre monofuselage
Scissor doors
Transverse 8-speed gearbox behind the V12",
			'summary' => '<p>The Revuelto replaced the Aventador and kept the thing Lamborghini fans care about most, a naturally aspirated V12, then added three electric motors for 1,015 CV in total. The gearbox sits behind the engine where the tunnel used to be, freeing space for the battery.</p>',
			'sort_order' => 40,
			'images' => array(
				array( '6/62/Lamborghini_Revuelto_DSC_6985.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '9/97/Lamborghini_Revuelto_DSC_6986.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '9/96/Lamborghini_Revuelto_IMG_0562.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '2/24/Lamborghini_Revuelto_Auto_Zuerich_2023_1X7A1103.jpg', 'Alexander-93, CC BY-SA 4.0' ),
			),
		),
		array(
			'slug' => 'ferrari-sf90-stradale', 'make' => 'Ferrari', 'model' => 'SF90 Stradale', 'variant' => 'Plug-in hybrid flagship', 'year' => 2023, 'body' => 'Coupé',
			'tagline' => 'One thousand horsepower and an electric front axle.',
			'engine' => '4.0L twin-turbo V8 plug-in hybrid', 'power' => '1000 CV', 'transmission' => '8-speed dual-clutch', 'drivetrain' => 'All-wheel drive', 'fuel' => 'Petrol plug-in hybrid', 'consumption' => '6.1 L/100 km (WLTP, weighted)', 'seats' => '2',
			'highlights' => "Three electric motors
eDrive electric-only mode
Shut-off Gurney aerodynamics
Assetto Fiorano package option",
			'summary' => '<p>Ferrari’s first series-production plug-in hybrid was also its most powerful road car when it arrived. A 780 CV twin-turbo V8 works with three electric motors, two of them on the front axle for torque vectoring.</p>',
			'sort_order' => 41,
			'images' => array(
				array( '4/45/Ferrari_SF90%2C_BAS_24%2C_Brussels_%28P1170486-RR%29.jpg', 'Matti Blume, CC BY-SA 4.0' ),
				array( 'a/aa/Ferrari_SF90%2C_BAS_24%2C_Brussels_%28P1170502-RR%29.jpg', 'Matti Blume, CC BY-SA 4.0' ),
				array( '5/51/Ferrari_SF90_Stradale_Washington_DC_Metro_Area%2C_USA_%282.1%29.jpg', 'OWS Photography, CC BY 4.0' ),
				array( '2/22/Ferrari_SF90_Stradale_Washington_DC_Metro_Area%2C_USA_%282.6%29.jpg', 'OWS Photography, CC BY 4.0' ),
			),
		),
		array(
			'slug' => 'mclaren-750s', 'make' => 'McLaren', 'model' => '750S', 'variant' => 'Coupé', 'year' => 2024, 'body' => 'Coupé',
			'tagline' => 'The lightest, sharpest McLaren supercar in its class.',
			'engine' => '4.0L twin-turbo V8', 'power' => '750 PS', 'transmission' => '7-speed dual-clutch', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '12.2 L/100 km (WLTP)', 'seats' => '2',
			'highlights' => "Carbon-fibre Monocage II-T tub
Proactive Chassis Control III
Dihedral doors
Centre-exit exhaust",
			'summary' => '<p>The 750S took the 720S and changed almost a third of it: more power, less weight, quicker steering and a stiffer chassis. It remains one of the lightest cars in its class by a clear margin.</p>',
			'sort_order' => 42,
			'images' => array(
				array( '9/92/2024_McLaren_750S_2.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( 'f/fd/2023_McLaren_750S_Yellow.jpg', 'MrWalkr, CC BY-SA 4.0' ),
				array( '4/45/2024_McLaren_750S_4.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( 'c/c3/2024_McLaren_750S_3.jpg', 'Calreyn88, CC BY-SA 4.0' ),
			),
		),
		array(
			'slug' => 'porsche-911-gt3-rs', 'make' => 'Porsche', 'model' => '911 GT3 RS', 'variant' => '992 generation', 'year' => 2023, 'body' => 'Coupé',
			'tagline' => 'A road-legal race car with a wing taller than the roof.',
			'engine' => '4.0L naturally aspirated flat-six', 'power' => '525 PS', 'transmission' => '7-speed PDK', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '13.4 L/100 km (WLTP)', 'seats' => '2',
			'highlights' => "Active aerodynamics with DRS
860 kg of downforce at 285 km/h
Steering-wheel suspension adjustment
Carbon-fibre bonnet, roof and doors",
			'summary' => '<p>The 992 GT3 RS is the most track-focused road Porsche of its generation. A 9,000 rpm naturally aspirated flat-six, a swan-neck rear wing that rises above the roofline and a drag reduction system borrowed from racing.</p>',
			'sort_order' => 43,
			'images' => array(
				array( '7/77/Porsche_992_GT3_RS_MYLE_Festival_2025_DSC_9584.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( 'd/d3/Porsche_911_GT3_RS_%282022%29_1X7A7164.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '0/07/Porsche_992_GT3_RS_MYLE_Festival_2025_DSC_9585.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( 'b/b3/Porsche_911_GT3_RS_992_HCC24.jpg', 'MrWalkr, CC BY-SA 4.0' ),
			),
		),
		array(
			'slug' => 'bugatti-chiron-sport', 'make' => 'Bugatti', 'model' => 'Chiron', 'variant' => 'Chiron Sport', 'year' => 2019, 'body' => 'Coupé',
			'tagline' => 'Sixteen cylinders, four turbos, 1,500 horsepower.',
			'engine' => '8.0L quad-turbo W16', 'power' => '1500 PS', 'transmission' => '7-speed dual-clutch', 'drivetrain' => 'All-wheel drive', 'fuel' => 'Petrol', 'consumption' => '22.5 L/100 km (combined)', 'seats' => '2',
			'highlights' => "Quad-turbo W16
Carbon-fibre monocoque
Speed key for top-speed mode
Titanium exhaust",
			'summary' => '<p>The Chiron Sport is a sharper Chiron: stiffer springs, quicker steering and lighter parts, around the same 1,500 PS quad-turbo W16. In standard trim its top speed is electronically held at 420 km/h.</p>',
			'sort_order' => 44,
			'images' => array(
				array( '3/34/Bugatti_Chiron_Sport_Les_Legendes_Du_Ciel.jpg', 'MrWalkr, CC BY-SA 4.0' ),
				array( 'a/ad/Bugatti_Chiron_110_Ans%2C_GIMS_2019%2C_Le_Grand-Saconnex_%28GIMS9979%29.jpg', 'Matti Blume, CC BY-SA 4.0' ),
				array( 'f/fa/Bugatti_Chiron_Sport_Les_Legendes_du_Ciel.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( '7/7d/Bugatti_Chiron_Sport_Les_Legendes_du_Ciel_2.jpg', 'Calreyn88, CC BY-SA 4.0' ),
			),
		),
		array(
			'slug' => 'rolls-royce-spectre', 'make' => 'Rolls-Royce', 'model' => 'Spectre', 'variant' => 'First electric Rolls-Royce', 'year' => 2024, 'body' => 'Coupé',
			'tagline' => 'The silent Rolls-Royce: an all-electric super coupé.',
			'engine' => 'Two electric motors, 102 kWh battery', 'power' => '584 hp', 'transmission' => 'Single-speed', 'drivetrain' => 'All-wheel drive', 'fuel' => 'Electric', 'consumption' => '22.2–23.6 kWh/100 km (WLTP)', 'seats' => '4',
			'highlights' => "Starlight doors
Planar suspension with road scanning
Coach doors
Up to 530 km range (WLTP)",
			'summary' => '<p>Spectre is the first electric Rolls-Royce and the spiritual successor to the Phantom Coupé. Its two motors are almost silent, which suits a brand that once boasted the loudest sound in its cars was the clock.</p>',
			'sort_order' => 45,
			'images' => array(
				array( '8/87/2023_Rolls-Royce_Spectre.jpg', 'User3204, CC BY-SA 4.0' ),
				array( '4/4e/Rolls_Royce_Spectre_002.jpg', 'JustAnotherCarDesigner, CC BY-SA 4.0' ),
				array( 'f/fb/Rolls_Royce_Spectre_001.jpg', 'JustAnotherCarDesigner, CC BY-SA 4.0' ),
				array( '5/5f/Rolls-Royce_Spectre_IAA_2023_1X7A0753.jpg', 'Alexander-93, CC BY-SA 4.0' ),
			),
		),
		array(
			'slug' => 'bentley-flying-spur', 'make' => 'Bentley', 'model' => 'Flying Spur', 'variant' => 'Third generation, W12', 'year' => 2021, 'body' => 'Sedan',
			'tagline' => 'A four-door Bentley with a W12 and a rotating dashboard.',
			'engine' => '6.0L twin-turbo W12', 'power' => '635 PS', 'transmission' => '8-speed dual-clutch', 'drivetrain' => 'All-wheel drive', 'fuel' => 'Petrol', 'consumption' => '14.8 L/100 km (WLTP)', 'seats' => '5',
			'highlights' => "Bentley Rotating Display
All-wheel steering
48-volt anti-roll control
Flying B mascot that rises from the bonnet",
			'summary' => '<p>The third-generation Flying Spur shares its platform with the Continental GT and adds rear doors, all-wheel steering and a retractable Flying B mascot. With the W12 it is one of the fastest four-door cars on sale.</p>',
			'sort_order' => 46,
			'images' => array(
				array( 'c/c2/Bentley_Flying_Spur_%282019%29_IMG_2635.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '3/3d/Bentley_Flying_Spur_3.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( 'a/af/Bentley_Flying_Spur_V8_Azure_III_Meteor_%285%29.jpg', 'Damian B Oh, CC BY-SA 4.0' ),
				array( 'f/f6/Bentley_Flying_Spur_%282019%29_Retro_Classics_2020_IMG_0140.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
			),
		),
		array(
			'slug' => 'aston-martin-db12', 'make' => 'Aston Martin', 'model' => 'DB12', 'variant' => 'Super Tourer', 'year' => 2024, 'body' => 'Coupé',
			'tagline' => 'Aston Martin’s self-styled super tourer, with 680 PS.',
			'engine' => '4.0L twin-turbo V8', 'power' => '680 PS', 'transmission' => '8-speed automatic', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '12.2 L/100 km (WLTP)', 'seats' => '2+2',
			'highlights' => "Electronic rear differential
All-new infotainment
Adaptive dampers
Bridge of Weir leather",
			'summary' => '<p>The DB12 is the first of a new generation of Aston Martins, with a stiffer structure, an electronic rear differential and much more power than the DB11. Aston calls it the world’s first super tourer.</p>',
			'sort_order' => 47,
			'images' => array(
				array( 'c/ca/Aston_Martin_DB12_1X7A1921.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( 'f/fc/Aston_Martin_DB12_1X7A1928.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '1/10/Aston_Martin_DB12_1X7A1922.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( 'd/df/Aston_Martin_DB12_1X7A1927.jpg', 'Alexander-93, CC BY-SA 4.0' ),
			),
		),
		array(
			'slug' => 'nissan-gt-r-nismo', 'make' => 'Nissan', 'model' => 'GT-R Nismo', 'variant' => 'R35', 'year' => 2022, 'body' => 'Coupé',
			'tagline' => 'Godzilla, hand-built and turned up by Nismo.',
			'engine' => '3.8L twin-turbo V6', 'power' => '600 PS', 'transmission' => '6-speed dual-clutch', 'drivetrain' => 'All-wheel drive', 'fuel' => 'Petrol', 'consumption' => '14.2 L/100 km (combined)', 'seats' => '4',
			'highlights' => "Hand-built VR38DETT engine
Carbon-ceramic brakes
GT3-derived turbochargers
Carbon-fibre bonnet and roof",
			'summary' => '<p>The R35 GT-R has been on sale since 2007 and the Nismo is its sharpest form, with turbochargers from the GT3 race car, carbon-ceramic brakes and a carbon-fibre bonnet with cooling vents.</p>',
			'sort_order' => 48,
			'images' => array(
				array( 'e/ea/Nissan_GT-R_NISMO_%284BA-R35%29_front.jpg', 'Tokumeigakarinoaoshima, CC BY-SA 4.0' ),
				array( 'd/dc/Nissan_GT-R_Nismo_%28R35%29%2C_2022%2C_front.jpg', 'Kazyakuruma, CC BY-SA 4.0' ),
				array( '0/01/Nissan_GT-R_Nismo_%28R35%29%2C_2022%2C_rear.jpg', 'Kazyakuruma, CC BY-SA 4.0' ),
				array( '4/4e/Nissan_GT-R_NISMO_Special_edition_%284BA-R35%29_rear.jpg', 'Tokumeigakarinoaoshima, CC BY-SA 4.0' ),
			),
		),
		array(
			'slug' => 'lexus-lc-500', 'make' => 'Lexus', 'model' => 'LC 500', 'variant' => 'Coupé', 'year' => 2023, 'body' => 'Coupé',
			'tagline' => 'A concept car that made it to the road, with a 7,100 rpm V8.',
			'engine' => '5.0L naturally aspirated V8', 'power' => '477 PS', 'transmission' => '10-speed automatic', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '12.7 L/100 km (WLTP)', 'seats' => '2+2',
			'highlights' => "Naturally aspirated 5.0 V8
Takumi-crafted cabin
Carbon-fibre roof option
Active exhaust valve",
			'summary' => '<p>The LC 500 grew out of the LF-LC concept with almost no changes to its shape. Under the long bonnet is one of the last naturally aspirated V8s on sale, with an exhaust that sings to 7,100 rpm.</p>',
			'sort_order' => 49,
			'images' => array(
				array( '6/6b/2017_Lexus_LC_500_in_Radiant_Red_Contrast_Layering%2C_front_right.jpg', 'Ethan Llamas, CC BY-SA 4.0' ),
				array( '4/44/Lexus_LC_500_URZ100_Radiant_Red_Contrast_Layering.jpg', 'Ethan Llamas, CC BY-SA 4.0' ),
				array( '0/08/Lexus_LC_500_URZ100_Nightfall_Mica_02.jpg', 'Ethan Llamas, CC BY-SA 4.0' ),
				array( 'e/ef/2023_Lexus_LC_500_in_White_Nova_Glass_Flake%2C_front_left.jpg', 'Ethan Llamas, CC BY-SA 4.0' ),
			),
		),
		array(
			'slug' => 'toyota-gr-supra', 'make' => 'Toyota', 'model' => 'GR Supra', 'variant' => 'A90, 3.0', 'year' => 2020, 'body' => 'Coupé',
			'tagline' => 'The Supra name returns, with a turbo straight-six.',
			'engine' => '3.0L turbo inline-6', 'power' => '340 PS', 'transmission' => '8-speed automatic', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '8.2 L/100 km (WLTP)', 'seats' => '2',
			'highlights' => "Turbo straight-six
Active rear differential
50:50 weight distribution
Adaptive Variable Suspension",
			'summary' => '<p>Seventeen years after the A80, Toyota brought the Supra back with Gazoo Racing, sharing its engine and platform with the BMW Z4. The short wheelbase and 50:50 balance make it a proper driver’s car.</p>',
			'sort_order' => 50,
			'images' => array(
				array( '1/10/Osaka_Auto_Messe_2020_%28115%29_-_Toyota_GR_Supra_%28A90%29_with_TRD_parts.jpg', 'Tokumeigakarinoaoshima, CC BY-SA 4.0' ),
				array( 'c/c7/Osaka_Auto_Messe_2020_%28116%29_-_Toyota_GR_Supra_%28A90%29_with_TRD_parts.jpg', 'Tokumeigakarinoaoshima, CC BY-SA 4.0' ),
			),
		),
		array(
			'slug' => 'range-rover-sport-sv', 'make' => 'Land Rover', 'model' => 'Range Rover Sport SV', 'variant' => 'L461, Edition One', 'year' => 2024, 'body' => 'SUV',
			'tagline' => 'The fastest Range Rover yet, on hydraulically linked suspension.',
			'engine' => '4.4L twin-turbo V8 mild hybrid', 'power' => '635 PS', 'transmission' => '8-speed automatic', 'drivetrain' => 'All-wheel drive', 'fuel' => 'Petrol (MHEV)', 'consumption' => '12.9 L/100 km (WLTP)', 'seats' => '5',
			'highlights' => "6D Dynamics hydraulic suspension
Carbon-ceramic brakes
Body and Soul Seats with haptic speakers
Carbon-fibre wheels option",
			'summary' => '<p>The SV is the most powerful Range Rover ever made. Its 6D Dynamics system links the dampers hydraulically, so the body stays flat without anti-roll bars, and the seats vibrate in time with the music.</p>',
			'sort_order' => 51,
			'images' => array(
				array( '7/7b/Range_Rover_Sport_SV_Edition_One_L461_Carbon_Bronze_Matte_%2824%29.jpg', 'Damian B Oh, CC BY 4.0' ),
				array( 'd/d1/Range_Rover_Sport_SV_Edition_One_L461_Carbon_Bronze_Matte_%2823%29.jpg', 'Damian B Oh, CC BY 4.0' ),
				array( '5/51/Range_Rover_Sport_SV_Edition_One_L461_Carbon_Bronze_Matte_%2814%29.jpg', 'Damian B Oh, CC BY 4.0' ),
			),
		),
		array(
			'slug' => 'ferrari-296-gtb', 'make' => 'Ferrari', 'model' => '296 GTB', 'variant' => 'V6 plug-in hybrid', 'year' => 2023, 'body' => 'Coupé',
			'tagline' => 'A V6 Ferrari again, with 830 CV and electric help.',
			'engine' => '3.0L twin-turbo V6 plug-in hybrid', 'power' => '830 CV', 'transmission' => '8-speed dual-clutch', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol plug-in hybrid', 'consumption' => '6.4 L/100 km (WLTP, weighted)', 'seats' => '2',
			'highlights' => "120-degree twin-turbo V6
eDrive electric mode
Short wheelbase
Assetto Fiorano package option",
			'summary' => '<p>The 296 GTB brought the V6 back to a Ferrari road car for the first time since the Dino. With an electric motor between engine and gearbox it makes 830 CV, and it sounds, Ferrari says, like a small V12.</p>',
			'sort_order' => 52,
			'images' => array(
				array( '5/51/Ferrari_296_GTB_1X7A6377.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '4/41/Ferrari_296_GTB_1X7A6379.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '5/56/Ferrari_296_GTB_3.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( 'c/ce/Ferrari_296_GTB_IMG_8865.jpg', 'Alexander-93, CC BY-SA 4.0' ),
			),
		),
		array(
			'slug' => 'lamborghini-huracan-sto', 'make' => 'Lamborghini', 'model' => 'Huracán STO', 'variant' => 'Super Trofeo Omologata', 'year' => 2022, 'body' => 'Coupé',
			'tagline' => 'A race car with number plates and a V10.',
			'engine' => '5.2L naturally aspirated V10', 'power' => '640 CV', 'transmission' => '7-speed dual-clutch', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '13.9 L/100 km (WLTP)', 'seats' => '2',
			'highlights' => "One-piece carbon cofango bonnet
Shark fin and adjustable rear wing
CCM-R carbon-ceramic brakes
Rear-wheel drive",
			'summary' => '<p>STO stands for Super Trofeo Omologata: a road-legal take on the Huracán race cars. The bonnet, wings and bumper are one carbon piece that lifts as a unit, called the cofango.</p>',
			'sort_order' => 53,
			'images' => array(
				array( 'a/a3/Lamborghini_Huracan_STO_Auto_Zuerich_2021_IMG_0266.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '6/68/Lamborghini_Huracan_STO_1X7A0297.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '2/22/Lamborghini_Huracan_STO_1X7A7216.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '6/6b/Lamborghini_Huracan_STO_15.jpg', 'Calreyn88, CC BY-SA 4.0' ),
			),
		),
		array(
			'slug' => 'porsche-taycan-turbo-s', 'make' => 'Porsche', 'model' => 'Taycan Turbo S', 'variant' => 'J1, first generation', 'year' => 2021, 'body' => 'Sedan',
			'tagline' => 'Porsche’s first electric car, and still one of the quickest.',
			'engine' => 'Two electric motors, 93.4 kWh battery', 'power' => '761 PS (overboost)', 'transmission' => '2-speed (rear axle)', 'drivetrain' => 'All-wheel drive', 'fuel' => 'Electric', 'consumption' => '28.0 kWh/100 km (WLTP)', 'seats' => '4',
			'highlights' => "800-volt architecture
Two-speed rear gearbox
Adaptive air suspension
Up to 270 kW charging",
			'summary' => '<p>The Taycan was Porsche’s first electric car and introduced an 800-volt system that lets it charge quickly and repeat full-power launches without fading. The Turbo S makes up to 761 PS on overboost.</p>',
			'sort_order' => 54,
			'images' => array(
				array( 'd/d7/Porsche_Taycan_Turbo_S_%2848769113873%29.jpg', 'Rutger van der Maar, CC BY 2.0' ),
				array( '4/47/Porsche_Taycan_Turbo_S_%2848769973948%29.jpg', 'Rutger van der Maar, CC BY 2.0' ),
				array( '1/13/Porsche_Taycan_Turbo_S_White_%281%29.jpg', 'Damian B Oh, CC BY-SA 4.0' ),
				array( '2/24/Porsche_Taycan_Turbo_S_%2848769974448%29.jpg', 'Rutger van der Maar, CC BY 2.0' ),
			),
		),
		array(
			'slug' => 'pagani-utopia', 'make' => 'Pagani', 'model' => 'Utopia', 'variant' => 'Coupé', 'year' => 2023, 'body' => 'Coupé',
			'tagline' => 'A twin-turbo V12, a gated manual and Horacio Pagani’s idea of simplicity.',
			'engine' => '6.0L twin-turbo V12', 'power' => '864 CV', 'transmission' => '7-speed manual or automated manual', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => 'Not published by Pagani', 'seats' => '2',
			'highlights' => "Mercedes-AMG V12 built for Pagani
Xtrac gearbox with a true manual option
Butterfly doors
Forged aluminium double-wishbone suspension",
			'summary' => '<p>The Utopia is Pagani’s third model line after the Zonda and Huayra. Its 6.0-litre Mercedes-AMG V12 makes 864 CV, and buyers can choose a proper seven-speed manual, a rarity at this level.</p>',
			'sort_order' => 55,
			'images' => array(
				array( '1/18/Pagani_Utopia_Auto_Zuerich_2023_1X7A1185.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '7/71/Pagani_Utopia_Auto_Zuerich_2023_1X7A1183.jpg', 'Alexander-93, CC BY-SA 4.0' ),
			),
		),
		array(
			'slug' => 'mclaren-senna', 'make' => 'McLaren', 'model' => 'Senna', 'variant' => 'Ultimate Series', 'year' => 2019, 'body' => 'Coupé',
			'tagline' => 'Built for the lap, then made road-legal.',
			'engine' => '4.0L twin-turbo V8 (M840TR)', 'power' => '800 PS', 'transmission' => '7-speed dual-clutch', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '12.4 L/100 km (combined)', 'seats' => '2',
			'highlights' => "800 kg of downforce at 250 km/h
Active rear wing and front aero blades
Optional glass lower door panels
Carbon-fibre Monocage III tub",
			'summary' => '<p>The Senna is McLaren’s track-focused Ultimate Series car, named after Ayrton Senna. Its body is shaped for downforce first, and the M840TR V8 sends 800 PS to the rear wheels through a seven-speed dual-clutch gearbox.</p>',
			'sort_order' => 56,
			'images' => array(
				array( '6/6e/McLaren_Senna_16.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( '1/10/McLaren_Senna_Genf_2018.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( 'c/ca/2019_McLaren_Senna%2C_front_left_%28Greenwich_2019%29.jpg', 'Mr.choppers, CC BY-SA 3.0' ),
				array( '0/04/2019_McLaren_Senna_V8_S-A.jpg', 'Vauxford, CC BY-SA 4.0' ),
			),
		),
		array(
			'slug' => 'rimac-nevera', 'make' => 'Rimac', 'model' => 'Nevera', 'variant' => 'Electric hypercar', 'year' => 2023, 'body' => 'Coupé',
			'tagline' => 'Four motors, 1,914 PS and a string of electric speed records.',
			'engine' => 'Four electric motors, 120 kWh battery', 'power' => '1914 PS', 'transmission' => 'Single-speed per motor', 'drivetrain' => 'All-wheel drive', 'fuel' => 'Electric', 'consumption' => '21.8 kWh/100 km (WLTP)', 'seats' => '2',
			'highlights' => "One motor at each wheel
All-wheel torque vectoring
Carbon-fibre monocoque with integrated battery
490 km WLTP range",
			'summary' => '<p>The Nevera is the production version of the Rimac C_Two shown in Geneva in 2018. A motor at each wheel gives it 1,914 PS and full torque vectoring, and it has set records for acceleration and top speed among electric cars.</p>',
			'sort_order' => 57,
			'images' => array(
				array( 'b/b9/Rimac_-_Nevera_10.jpg', 'Miroslav.vajdic, CC BY-SA 4.0' ),
				array( '0/0b/Rimac_-_Nevera_01.jpg', 'Miroslav.vajdic, CC BY-SA 4.0' ),
				array( '2/22/Rimac_Nevera.jpg', 'MrWalkr, CC BY-SA 4.0' ),
			),
		),
		array(
			'slug' => 'aston-martin-valkyrie', 'make' => 'Aston Martin', 'model' => 'Valkyrie', 'variant' => 'Coupé', 'year' => 2022, 'body' => 'Coupé',
			'tagline' => 'A Formula One mind and an 11,100 rpm V12, made road-legal.',
			'engine' => '6.5L naturally aspirated V12 hybrid', 'power' => '1155 PS', 'transmission' => '7-speed single-clutch automated manual', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol hybrid', 'consumption' => 'Not published by Aston Martin', 'seats' => '2',
			'highlights' => "Cosworth V12 revving to 11,100 rpm
Aerodynamics by Adrian Newey
Gull-wing doors
Carbon-fibre Multimatic monocell",
			'summary' => '<p>The Valkyrie was designed with Red Bull’s Adrian Newey and behaves more like a racing prototype than a road car. A Cosworth-built 6.5-litre V12 revs to 11,100 rpm and works with a Rimac-supplied hybrid system.</p>',
			'sort_order' => 58,
			'images' => array(
				array( 'a/a0/Aston_Martin_Valkyrie_GIMS_2024_1X7A2266.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '9/96/Aston_Martin_Valkyrie%2C_TC_24%2C_Essen_%28TCE42947%29.jpg', 'Matti Blume, CC BY-SA 4.0' ),
				array( 'c/c6/Aston_Martin_Valkyrie%2C_BAS_24%2C_Brussels_%28P1170224-RR%29.jpg', 'Matti Blume, CC BY-SA 4.0' ),
			),
		),
		array(
			'slug' => 'ferrari-12cilindri', 'make' => 'Ferrari', 'model' => '12Cilindri', 'variant' => 'Berlinetta', 'year' => 2025, 'body' => 'Coupé',
			'tagline' => 'The naturally aspirated V12 front-engined Ferrari lives on.',
			'engine' => '6.5L naturally aspirated V12', 'power' => '830 CV', 'transmission' => '8-speed dual-clutch', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '15.5 L/100 km (WLTP)', 'seats' => '2',
			'highlights' => "9,500 rpm F140 V12
Active rear aero flaps
Four-wheel steering
Daytona-inspired black bonnet band",
			'summary' => '<p>The 12Cilindri replaced the 812 Superfast and kept the recipe of a big naturally aspirated V12 in the nose. Its 830 CV engine is joined by a new 8-speed dual-clutch gearbox and styling that nods to the 365 GTB/4 Daytona.</p>',
			'sort_order' => 59,
			'images' => array(
				array( 'd/dd/2025_Ferrari_12Cilindri_1.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( '2/2a/Ferrari_12Cilindri_at_Maranello.jpg', 'Russell Bray\'s Ghost, CC BY-SA 4.0' ),
				array( '8/87/Ferrari_12Cilindri_at_the_2025_Shannons_Adelaide_Rally_%28028A4546%29.jpg', 'Yu Chu Chin, CC BY 4.0' ),
				array( '8/81/2025_Ferrari_12Cilindri_gfos25.jpg', 'Calreyn88, CC BY-SA 4.0' ),
			),
		),
		array(
			'slug' => 'lamborghini-temerario', 'make' => 'Lamborghini', 'model' => 'Temerario', 'variant' => 'Plug-in hybrid V8', 'year' => 2025, 'body' => 'Coupé',
			'tagline' => 'A twin-turbo V8 that revs past 10,000 rpm, plus three electric motors.',
			'engine' => '4.0L twin-turbo V8 plug-in hybrid', 'power' => '920 CV', 'transmission' => '8-speed dual-clutch', 'drivetrain' => 'All-wheel drive', 'fuel' => 'Petrol plug-in hybrid', 'consumption' => '11.2 L/100 km (WLTP, weighted)', 'seats' => '2',
			'highlights' => "10,000 rpm twin-turbo V8
Three axial-flux electric motors
Hot-vee turbo layout
Revuelto-derived 8-speed gearbox",
			'summary' => '<p>The Temerario replaced the Huracán and swapped its V10 for a new twin-turbo V8 that revs to 10,000 rpm. Three electric motors bring the total to 920 CV, with the front pair driving the front wheels.</p>',
			'sort_order' => 60,
			'images' => array(
				array( 'c/cf/Lamborghini_Temerario_IMG_5361.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '2/29/Lamborghini_Temerario_2025.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( '3/3d/Lamborghini_Temerario_2025_4.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( 'd/dc/Lamborghini_Temerario_2025_1.jpg', 'Calreyn88, CC BY-SA 4.0' ),
			),
		),
		array(
			'slug' => 'porsche-918-spyder', 'make' => 'Porsche', 'model' => '918 Spyder', 'variant' => 'Plug-in hybrid hypercar', 'year' => 2014, 'body' => 'Roadster',
			'tagline' => 'The hybrid that broke seven minutes at the Nürburgring.',
			'engine' => '4.6L naturally aspirated V8 plug-in hybrid', 'power' => '887 PS', 'transmission' => '7-speed PDK', 'drivetrain' => 'All-wheel drive', 'fuel' => 'Petrol plug-in hybrid', 'consumption' => '3.0 L/100 km (NEDC, weighted)', 'seats' => '2',
			'highlights' => "9,150 rpm racing-derived V8
Two electric motors
Top-exit exhausts
Optional Weissach package",
			'summary' => '<p>The 918 Spyder was one of the hypercar trio that brought hybrid power to the top of the performance world. A racing-derived V8 and two electric motors together make 887 PS, and it was the first road car to lap the Nordschleife in under seven minutes.</p>',
			'sort_order' => 61,
			'images' => array(
				array( '5/54/2015_Porsche_918_Spyder_4.6.jpg', 'Chelsea Jay, CC BY-SA 4.0' ),
				array( '6/65/Porsche_918_Spyder_IAA_2013_%28Zuschnitt%29.jpg', 'Thomas Wolf, www.foto-tw.de, CC BY-SA 3.0 DE' ),
				array( '9/91/Porsche_918_Spyder_IAA_2013.jpg', 'Thomas Wolf, www.foto-tw.de, CC BY-SA 3.0 DE' ),
			),
		),
		array(
			'slug' => 'mercedes-amg-gt-black-series', 'make' => 'Mercedes-AMG', 'model' => 'GT Black Series', 'variant' => 'C190, Black Series', 'year' => 2021, 'body' => 'Coupé',
			'tagline' => 'The most powerful AMG V8 of its time, with a flat-plane crank.',
			'engine' => '4.0L twin-turbo V8 (flat-plane crank)', 'power' => '730 PS', 'transmission' => '7-speed dual-clutch', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '12.8 L/100 km (WLTP)', 'seats' => '2',
			'highlights' => "Flat-plane crankshaft V8
Manually adjustable twin-plane rear wing
Carbon-fibre roof, bonnet and boot lid
Adjustable coil-over suspension",
			'summary' => '<p>The GT Black Series is the most extreme version of the Mercedes-AMG GT. Its V8 gained a flat-plane crankshaft and 730 PS, and the bodywork was reworked for downforce with a two-tier rear wing and an adjustable front splitter.</p>',
			'sort_order' => 62,
			'images' => array(
				array( '5/5a/Mercedes-AMG_GT_Black_Series_IMG_0324.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( 'd/d9/Mercedes-AMG_GT_Black_Series_Classic-Gala_2025_DSC_0768.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '4/4f/Mercedes-AMG_GT_Black_Series_Classic-Gala_2025_DSC_0767.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '5/56/2022_Mercedes-AMG_GT_Black_Series_Supercarfest24.jpg', 'MrWalkr, CC BY-SA 4.0' ),
			),
		),
		array(
			'slug' => 'bmw-m5', 'make' => 'BMW', 'model' => 'M5', 'variant' => 'G90 saloon', 'year' => 2025, 'body' => 'Saloon',
			'tagline' => 'The first M5 with a plug: a twin-turbo V8 and 727 PS.',
			'engine' => '4.4L twin-turbo V8 plug-in hybrid', 'power' => '727 PS', 'transmission' => '8-speed M Steptronic automatic', 'drivetrain' => 'All-wheel drive', 'fuel' => 'Petrol plug-in hybrid', 'consumption' => '1.7 L/100 km (WLTP, weighted)', 'seats' => '5',
			'highlights' => "M HYBRID V8 drivetrain
Up to 69 km electric range
M xDrive with 2WD mode
Integral active steering",
			'summary' => '<p>The seventh-generation M5 is the most powerful series-production BMW M car yet. Its twin-turbo V8 works with an electric motor in the gearbox for 727 PS and 1,000 Nm, and it can drive on electricity alone for short trips.</p>',
			'sort_order' => 63,
			'images' => array(
				array( '7/70/BMW_M5_%28G90%29_MYLE_Festival_2025_DSC_9765.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '0/0b/BMW_M5_%28G90%29_MYLE_Festival_2025_DSC_9764.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '8/80/BMW_M5_%28G90%29_MYLE_Festival_2025_DSC_9648.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( 'd/d1/BMW_M5_%28G90%29_MYLE_Festival_2025_DSC_9582.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
			),
		),
		array(
			'slug' => 'audi-rs6-avant-performance', 'make' => 'Audi', 'model' => 'RS 6 Avant', 'variant' => 'C8 performance', 'year' => 2023, 'body' => 'Estate',
			'tagline' => 'A family estate with 630 PS and a twin-turbo V8.',
			'engine' => '4.0L twin-turbo V8 mild hybrid', 'power' => '630 PS', 'transmission' => '8-speed tiptronic automatic', 'drivetrain' => 'All-wheel drive', 'fuel' => 'Petrol mild hybrid', 'consumption' => '12.2–12.7 L/100 km (WLTP)', 'seats' => '5',
			'highlights' => "Twin-turbo 4.0 V8 with cylinder deactivation
quattro with sport differential
Widened RS-only bodywork
48-volt mild hybrid system",
			'summary' => '<p>The RS 6 Avant performance sharpened Audi’s super estate with more boost, a quicker-shifting gearbox and less sound deadening. Its 630 PS twin-turbo V8 makes it one of the fastest load-luggers ever built.</p>',
			'sort_order' => 64,
			'images' => array(
				array( '0/0a/Audi_RS_6_Avant_Performance_%282024%29_%2854091034791%29.jpg', 'Charles from Port Chester, New York, CC BY 2.0' ),
				array( 'a/af/AUDI_RS6_AVANT_C8_China.jpg', 'Dinkun Chen, CC BY-SA 4.0' ),
				array( 'f/f6/AUDI_RS6_AVANT_C8_China_%283%29.jpg', 'Dinkun Chen, CC BY-SA 4.0' ),
			),
		),
		array(
			'slug' => 'chevrolet-corvette-z06', 'make' => 'Chevrolet', 'model' => 'Corvette Z06', 'variant' => 'C8', 'year' => 2023, 'body' => 'Coupé',
			'tagline' => 'America’s mid-engined sports car with a flat-plane V8 from racing.',
			'engine' => '5.5L naturally aspirated flat-plane-crank V8', 'power' => '670 hp', 'transmission' => '8-speed dual-clutch', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '15 mpg US combined (EPA)', 'seats' => '2',
			'highlights' => "LT6 V8 revving to 8,600 rpm
Optional Z07 aero and carbon package
Magnetic Ride Control
Electronic limited-slip differential",
			'summary' => '<p>The C8 Z06 takes the mid-engined Corvette and gives it the LT6, a 5.5-litre flat-plane-crank V8 developed alongside the C8.R race car. With 670 hp it is described by Chevrolet as the most powerful naturally aspirated production V8.</p>',
			'sort_order' => 65,
			'images' => array(
				array( '6/6e/Chevrolet_Corvette_Z06_%28C8%29_Washington_DC_Metro_Area%2C_USA_%283%29.jpg', 'OWS Photography, CC BY 4.0' ),
				array( '9/92/Chevrolet_Corvette_Z06_%28C8%29_Washington_DC_Metro_Area%2C_USA_%285%29.jpg', 'OWS Photography, CC BY 4.0' ),
				array( '9/99/Chevrolet_Corvette_Z06_%28C8%29_Miami_Metro_Area%2C_USA.jpg', 'OWS Photography, CC BY 4.0' ),
				array( '5/5a/Chevrolet_Corvette_Z06_%28C8%29_Washington_DC_Metro_Area%2C_USA.jpg', 'OWS Photography, CC BY 4.0' ),
			),
		),
		array(
			'slug' => 'ford-mustang-dark-horse', 'make' => 'Ford', 'model' => 'Mustang Dark Horse', 'variant' => 'S650', 'year' => 2024, 'body' => 'Coupé',
			'tagline' => 'The track-focused seventh-generation Mustang, with a manual gearbox.',
			'engine' => '5.0L naturally aspirated V8', 'power' => '453 PS', 'transmission' => '6-speed manual', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '12.0 L/100 km (WLTP, manual)', 'seats' => '2+2',
			'highlights' => "Coyote V8 with forged connecting rods
Tremec 6-speed manual
MagneRide dampers
Titanium gear knob",
			'summary' => '<p>The Dark Horse sits at the top of the seventh-generation Mustang line-up. Its 5.0-litre Coyote V8 uses forged connecting rods from the Shelby GT500, and it was developed for road courses as much as straight lines.</p>',
			'sort_order' => 66,
			'images' => array(
				array( '1/11/Ford_Mustang_Dark_Horse_Rutesheimer_Autoschau_2025_DSC_9229.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( 'b/b7/2025_Ford_Mustang_Dark_Horse_CS800.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( '5/54/2025_Ford_Mustang_Dark_Horse_2.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( '4/49/Ford_Mustang_Dark_Horse_Rutesheimer_Autoschau_2025_DSC_9225.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
			),
		),
		array(
			'slug' => 'lexus-lfa', 'make' => 'Lexus', 'model' => 'LFA', 'variant' => 'Coupé', 'year' => 2011, 'body' => 'Coupé',
			'tagline' => 'A Yamaha-tuned V10 that revs from idle to 9,000 rpm in 0.6 seconds.',
			'engine' => '4.8L naturally aspirated V10', 'power' => '560 PS', 'transmission' => '6-speed automated sequential', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '13 mpg US combined (EPA)', 'seats' => '2',
			'highlights' => "Yamaha co-developed V10
Carbon-fibre-reinforced body
Digital tachometer
Nürburgring Package option",
			'summary' => '<p>The LFA took Lexus nearly a decade to develop and was built by hand at a rate of about 20 a month. Its V10, developed with Yamaha, became famous for its sound and for revving so fast that an analogue needle could not keep up.</p>',
			'sort_order' => 67,
			'images' => array(
				array( '6/62/2011_Lexus_LFA_Low.jpg', 'MrWalkr, CC BY-SA 4.0' ),
				array( '8/82/Lexus_LFA_001.JPG', 'Tennen-Gas, CC BY-SA 3.0' ),
			),
		),
		array(
			'slug' => 'ferrari-f40', 'make' => 'Ferrari', 'model' => 'F40', 'variant' => 'Twin-turbo V8', 'year' => 1990, 'body' => 'Coupé',
			'tagline' => 'The last Ferrari approved by Enzo himself, raw and turbocharged.',
			'engine' => '2.9L twin-turbo V8', 'power' => '478 CV', 'transmission' => '5-speed manual', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '18.1 L/100 km (EPA, US-spec car)', 'seats' => '2',
			'highlights' => "Kevlar, carbon and aluminium body
No power steering or ABS
Sliding plastic side windows
Built for Ferrari’s 40th anniversary",
			'summary' => '<p>The F40 was built to mark Ferrari’s 40th anniversary and was the last new car Enzo Ferrari approved. Light, turbocharged and stripped of comfort features, it was Ferrari’s fastest and most powerful road car when it arrived.</p>',
			'sort_order' => 68,
			'images' => array(
				array( '9/90/1990_Ferrari_F40_front.jpg', 'TTTNIS, CC0' ),
				array( 'c/cb/F40_Ferrari_20090509.jpg', 'Will ainsworth, CC BY-SA 3.0' ),
				array( 'f/f0/Ferrari_F40_GIMS_2024_1X7A2271.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( 'a/a1/Ferrari_F40%2C_TC_24%2C_Essen_%28TCE43319-RR%29.jpg', 'Matti Blume, CC BY-SA 4.0' ),
			),
		),
		array(
			'slug' => 'mclaren-p1', 'make' => 'McLaren', 'model' => 'P1', 'variant' => 'Plug-in hybrid hypercar', 'year' => 2014, 'body' => 'Coupé',
			'tagline' => 'McLaren’s hybrid successor to the F1, with racing-style DRS.',
			'engine' => '3.8L twin-turbo V8 plug-in hybrid', 'power' => '916 PS', 'transmission' => '7-speed dual-clutch', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol plug-in hybrid', 'consumption' => '8.3 L/100 km (NEDC)', 'seats' => '2',
			'highlights' => "Instant Power Assist System
Drag Reduction System on the rear wing
600 kg of downforce
Carbon-fibre MonoCage tub",
			'summary' => '<p>The P1 was McLaren’s first hypercar since the F1 and one of the hybrid trio alongside the Porsche 918 and LaFerrari. A twin-turbo V8 and an electric motor together make 916 PS, with racing-style buttons for instant boost and reduced drag.</p>',
			'sort_order' => 69,
			'images' => array(
				array( '6/61/2013_McLaren_P1.jpg', 'MrWalkr, CC BY-SA 4.0' ),
				array( '4/42/2014_McLaren_P1_3.8.jpg', 'Chelsea Jay, CC BY-SA 4.0' ),
				array( 'b/b6/2015_Track_Silver_McLaren_P1.jpg', 'MrWalkr, CC BY-SA 4.0' ),
				array( 'c/c7/2013_McLaren_P1_MSO.jpg', 'MrWalkr, CC BY-SA 4.0' ),
			),
		),
		array(
			'slug' => 'toyota-gr-yaris', 'make' => 'Toyota', 'model' => 'GR Yaris', 'variant' => 'GXPA16, European specification', 'year' => 2021, 'body' => 'Hatchback',
			'tagline' => 'A homologation special in the old tradition, born from Toyota’s World Rally Championship programme.',
			'engine' => '1.6L turbocharged three-cylinder (G16E-GTS)', 'power' => '261 PS', 'transmission' => '6-speed manual', 'drivetrain' => 'GR-Four all-wheel drive', 'fuel' => 'Petrol', 'consumption' => '8.2 L/100 km (WLTP)', 'seats' => '4',
			'highlights' => "Rally-bred GR-Four all-wheel drive
Carbon-fibre roof and aluminium panels
Three-door body unique to the GR Yaris
Built on a dedicated GR Factory line",
			'summary' => '<p>The GR Yaris shares little more than its name with the everyday Yaris. Its three-cylinder 1.6-litre turbo makes 261 PS, and the GR-Four system can shift drive between the axles, giving it the feel of a road-going rally car.</p>',
			'sort_order' => 70,
			'images' => array(
				array( '6/6f/Toyota_GR_Yaris_GXPA16_1.6L_GR-Four_Emotional_Red_0.jpg', 'Ethan Llamas, CC BY-SA 4.0' ),
				array( '0/0d/Toyota_GR_Yaris_GXPA16_1.6L_GR-Four_Super_White_II.jpg', 'Ethan Llamas, CC BY-SA 4.0' ),
				array( '8/87/Toyota_GR_YARIS_RZ_High_performance_%284BA-GXPA16-AGFGZ%28H%29%29_front.jpg', 'Tokumeigakarinoaoshima, CC BY-SA 4.0' ),
				array( '9/9f/Toyota_GR_Yaris_GXPA16_FL_1.6L_GR-Four_Precious_Metal.jpg', 'Ethan Llamas, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'subaru-wrx-sti', 'make' => 'Subaru', 'model' => 'WRX STI', 'variant' => 'VA, European specification', 'year' => 2018, 'body' => 'Saloon',
			'tagline' => 'The last of the boxer-engined STI saloons, with a manual gearbox and a driver-adjustable centre differential.',
			'engine' => '2.5L turbocharged flat-four (EJ257)', 'power' => '300 PS', 'transmission' => '6-speed manual', 'drivetrain' => 'Symmetrical all-wheel drive', 'fuel' => 'Petrol', 'consumption' => '10.9–11.2 L/100 km (combined)', 'seats' => '5',
			'highlights' => "Driver-controlled centre differential (DCCD)
Turbocharged EJ boxer engine
Brembo brakes
Large rear wing",
			'summary' => '<p>The VA-generation WRX STI was the final STI saloon built around Subaru’s long-serving EJ turbo boxer engine. It kept a six-speed manual and a centre differential the driver can adjust, a direct link to Subaru’s rally years.</p>',
			'sort_order' => 71,
			'images' => array(
				array( 'a/a6/Subaru_WRX_STI_-_Blue_%28cropped%29.jpg', 'Motor Verso, CC BY 2.0' ),
				array( 'd/dd/Subaru_WRX_STI_%28VA%29_Washington_DC_Metro_Area%2C_USA.jpg', 'OWS Photography, CC BY 4.0' ),
				array( '8/88/Subaru_WRX_STI_%28VA%29_Washington_DC_Metro_Area%2C_USA_%281%29.jpg', 'OWS Photography, CC BY 4.0' ),
				array( 'e/e3/Subaru_WRX_STI_%28VA%29_Washington_DC_Metro_Area%2C_USA_%282%29.jpg', 'OWS Photography, CC BY 4.0' )
			),
		),
		array(
			'slug' => 'mitsubishi-lancer-evolution-x', 'make' => 'Mitsubishi', 'model' => 'Lancer Evolution X', 'variant' => 'GSR TC-SST, European specification', 'year' => 2008, 'body' => 'Saloon',
			'tagline' => 'The final Evo, with an aluminium-block engine and an advanced all-wheel-drive brain.',
			'engine' => '2.0L turbocharged four-cylinder (4B11T)', 'power' => '295 PS', 'transmission' => '6-speed TC-SST dual-clutch', 'drivetrain' => 'S-AWC all-wheel drive', 'fuel' => 'Petrol', 'consumption' => '10.5 L/100 km (NEDC)', 'seats' => '5',
			'highlights' => "Super All-Wheel Control (S-AWC)
Active Yaw Control rear differential
Aluminium roof, bonnet and front wings
Twin-clutch SST gearbox option",
			'summary' => '<p>The Evolution X was the tenth and last of Mitsubishi’s rally-bred Lancer Evolutions. It introduced the all-aluminium 4B11T engine and the S-AWC system, which manages drive and braking at each wheel to sharpen cornering.</p>',
			'sort_order' => 72,
			'images' => array(
				array( '3/39/Mitsubishi_Lancer_Evolution_X_%28Bahrain%29.jpg', 'Mohammed Hamad, CC BY-SA 4.0' ),
				array( '8/8b/Mitsubishi_Lancer_EVO_X.jpg', 'IFCAR, Public domain' ),
				array( '3/31/20071001_Lancer_Evolution_X-front.jpg', 'baku13, CC BY-SA 3.0' ),
				array( 'd/d1/Mitsubishi_Lancer_Evolution_X_%288159251566%29.jpg', 'Davi Sanchez, CC BY 2.0' )
			),
		),
		array(
			'slug' => 'toyota-land-cruiser-79', 'make' => 'Toyota', 'model' => 'Land Cruiser 79', 'variant' => 'GXL single-cab chassis, Australian specification', 'year' => 2023, 'body' => 'Pick-up',
			'tagline' => 'The workhorse Land Cruiser, with a turbo-diesel V8 and a ladder frame built for the hardest roads.',
			'engine' => '4.5L turbo-diesel V8 (1VD-FTV)', 'power' => '205 PS', 'transmission' => '5-speed manual', 'drivetrain' => 'Part-time 4WD with low range', 'fuel' => 'Diesel', 'consumption' => '10.7 L/100 km (ADR combined)', 'seats' => '2',
			'highlights' => "Turbo-diesel 1VD-FTV V8
Solid front and rear axles
Ladder-frame chassis
Part-time four-wheel drive with low range",
			'summary' => '<p>The 79 is the pick-up version of the 70 Series, the most traditional Land Cruiser still in production. Its 4.5-litre turbo-diesel V8, solid axles and ladder frame put durability and load-carrying ahead of comfort.</p>',
			'sort_order' => 73,
			'images' => array(
				array( '5/5a/Toyota_Land_Cruiser_79_Simple_cabine_GRJ_facelift_2024_version_Afrique.jpg', '4x4pro, CC BY-SA 4.0' ),
				array( '9/95/Toyota_Land_Cruiser_16.09.20_JM_%283%29.jpg', 'Johannes Maximilian, CC BY-SA 4.0' ),
				array( 'a/a9/Toyota_Land_Cruiser_79_Double_cabine_facelift_2024_version_Afrique.jpg', '4x4pro, CC BY-SA 4.0' ),
				array( '4/4a/2022_Toyota_Land_Cruiser_79_pickup_truck%2C_06-30-2024.jpg', 'Ethan Llamas, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'nissan-patrol-nismo', 'make' => 'Nissan', 'model' => 'Patrol Nismo', 'variant' => 'Y62, 2021 update', 'year' => 2021, 'body' => 'SUV',
			'tagline' => 'Nissan’s flagship 4x4 given a NISMO V8 and a sharper stance for the Gulf.',
			'engine' => '5.6L naturally aspirated V8 (VK56VD)', 'power' => '428 hp', 'transmission' => '7-speed automatic', 'drivetrain' => 'Four-wheel drive with low range', 'fuel' => 'Petrol', 'consumption' => '17.0 L/100 km (tested, DriveArabia)', 'seats' => '7',
			'highlights' => "NISMO-tuned 5.6-litre V8
Bilstein dampers
Aerodynamic NISMO body kit
Hydraulic Body Motion Control",
			'summary' => '<p>The Patrol Nismo is the most powerful version of the Y62 Patrol, tuned by Nissan’s motorsport division for the Middle East. Its 5.6-litre V8 makes 428 hp, and the body gains a deeper front end, side skirts and 22-inch wheels.</p>',
			'sort_order' => 74,
			'images' => array(
				array( '2/21/2018_Nissan_Patrol_Nismo_%28front%29.jpg', 'User3204, CC BY 4.0' ),
				array( '6/65/Nissan_Patrol_Y62_Nismo_China_2017-03-19.jpg', 'Navigator84, CC BY-SA 4.0' ),
				array( 'f/f0/2018_Nissan_Patrol_Nismo_%28rear%29.jpg', 'User3204, CC BY 4.0' )
			),
		),
		array(
			'slug' => 'ford-ranger-raptor', 'make' => 'Ford', 'model' => 'Ranger Raptor', 'variant' => 'Double cab, European specification', 'year' => 2023, 'body' => 'Pick-up',
			'tagline' => 'A desert-racing pick-up with a twin-turbo V6 and long-travel Fox suspension.',
			'engine' => '3.0L twin-turbo V6 (EcoBoost)', 'power' => '292 PS', 'transmission' => '10-speed automatic', 'drivetrain' => 'Full-time four-wheel drive', 'fuel' => 'Petrol', 'consumption' => '13.8 L/100 km (WLTP)', 'seats' => '5',
			'highlights' => "Fox Live Valve dampers
Twin-turbo EcoBoost V6 with anti-lag
Front and rear locking differentials
Baja drive mode",
			'summary' => '<p>The second-generation Ranger Raptor swapped the original’s diesel for a 3.0-litre twin-turbo petrol V6. Ford Performance developed it for fast running on rough ground, with long-travel suspension and electronically controlled Fox dampers.</p>',
			'sort_order' => 75,
			'images' => array(
				array( '3/3c/2023_Ford_Ranger_Raptor_front.jpg', 'LuvsMG481, CC BY-SA 4.0' ),
				array( 'c/c0/2023_Ford_Ranger_Raptor_rear.jpg', 'LuvsMG481, CC BY-SA 4.0' ),
				array( '8/8d/2023_Ford_Ranger_Raptor_Ecoboost_Auto.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( '3/3f/Ford_Ranger_Raptor_%28P703%29_1X7A6774.jpg', 'Alexander-93, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'toyota-hilux-gr-sport', 'make' => 'Toyota', 'model' => 'Hilux GR Sport', 'variant' => 'Double cab 2.8 D-4D automatic, European specification', 'year' => 2025, 'body' => 'Pick-up',
			'tagline' => 'The Hilux with Gazoo Racing styling and tuning, inspired by Toyota’s Dakar Rally trucks.',
			'engine' => '2.8L turbo-diesel four-cylinder (1GD-FTV)', 'power' => '204 PS', 'transmission' => '6-speed automatic', 'drivetrain' => 'Part-time 4WD with low range', 'fuel' => 'Diesel', 'consumption' => '10.0 L/100 km (WLTP)', 'seats' => '5',
			'highlights' => "GR-tuned suspension
GR front grille and badging
GR sports seats
Rear differential lock",
			'summary' => '<p>The Hilux GR Sport is a sportier take on Toyota’s long-running pick-up, styled after the Gazoo Racing Hilux that competes in the Dakar Rally. It uses the 204 PS version of the 2.8-litre diesel and keeps full off-road hardware.</p>',
			'sort_order' => 76,
			'images' => array(
				array( '8/81/Toyota_HiLux_GR_Sport_1X7A7281.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( 'e/ee/2024_Toyota_HiLux_GR_Sport_front.jpg', 'LuvsMG481, CC BY-SA 4.0' ),
				array( '1/1a/Toyota_Hilux_GR-Sport_IV_TC2000_safety_car._TC2000_2024_Fecha_2%2C_Buenos_Aires.jpg', 'Just a Man, CC BY 4.0' ),
				array( '2/2e/Toyota_Hilux_GR_Sport_IV_in_Maldonado_-_front.jpg', 'NaBUru38, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'honda-civic-type-r', 'make' => 'Honda', 'model' => 'Civic Type R', 'variant' => 'FL5', 'year' => 2023, 'body' => 'Hatchback',
			'tagline' => 'Honda’s most powerful Type R, and a front-wheel-drive lap record holder.',
			'engine' => '2.0L turbocharged four-cylinder (K20C1)', 'power' => '329 PS', 'transmission' => '6-speed manual', 'drivetrain' => 'Front-wheel drive', 'fuel' => 'Petrol', 'consumption' => '8.2 L/100 km (WLTP)', 'seats' => '4',
			'highlights' => "Rev-matching six-speed manual
Helical limited-slip differential
Adaptive dampers
LogR data logger",
			'summary' => '<p>The FL5 Civic Type R is a calmer-looking but faster successor to the winged FK8. Its 2.0-litre turbo makes 329 PS in Europe and goes to the front wheels only, through a six-speed manual with automatic rev-matching.</p>',
			'sort_order' => 77,
			'images' => array(
				array( '0/03/HONDA_CIVIC_TYPE_R_FL5_China.jpg', 'Dinkun Chen, CC BY-SA 4.0' ),
				array( 'c/ce/HONDA_CIVIC_TYPE_R_FL5_China_%285%29.jpg', 'Dinkun Chen, CC BY-SA 4.0' ),
				array( 'f/f3/HONDA_CIVIC_TYPE_R_FL5_China_%282%29.jpg', 'Dinkun Chen, CC BY-SA 4.0' ),
				array( 'b/bf/HONDA_CIVIC_TYPE_R_FL5_China_%2812%29.jpg', 'Dinkun Chen, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'volkswagen-golf-r', 'make' => 'Volkswagen', 'model' => 'Golf R', 'variant' => 'Mk8.5, 4MOTION DSG', 'year' => 2024, 'body' => 'Hatchback',
			'tagline' => 'The all-weather hot hatch, with torque-vectoring all-wheel drive and 333 PS.',
			'engine' => '2.0L turbocharged four-cylinder (EA888 evo4)', 'power' => '333 PS', 'transmission' => '7-speed DSG dual-clutch', 'drivetrain' => '4MOTION all-wheel drive', 'fuel' => 'Petrol', 'consumption' => '8.1–8.5 L/100 km (WLTP)', 'seats' => '5',
			'highlights' => "R-Performance Torque Vectoring
Drift and Special driving modes
Adaptive Chassis Control
Four exhaust tailpipes",
			'summary' => '<p>The facelifted Mk8.5 Golf R gained 13 PS over the original Mk8 and kept its clever rear-axle torque vectoring, which can send almost all rear drive to the outside wheel. It is the most powerful series-production Golf R to date.</p>',
			'sort_order' => 78,
			'images' => array(
				array( 'f/f0/Volkswagen_Golf_VIII_R_IMG_4065.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '6/6c/Volkswagen_Golf_VIII_R_20_Years_Auto_Zuerich_2023_1X7A1359.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( 'e/ed/Volkswagen_Golf_VIII_R_20_Years_Auto_Zuerich_2023_1X7A1358.jpg', 'Alexander-93, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'porsche-911-carrera-s', 'make' => 'Porsche', 'model' => '911 Carrera S', 'variant' => '992.2 Coupé', 'year' => 2025, 'body' => 'Coupé',
			'tagline' => 'The benchmark sports car, with a twin-turbo flat-six now making 480 PS.',
			'engine' => '3.0L twin-turbo flat-six', 'power' => '480 PS', 'transmission' => '8-speed PDK dual-clutch', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '10.3–10.9 L/100 km (WLTP)', 'seats' => '2+2',
			'highlights' => "Rear-mounted twin-turbo flat-six
Porsche Torque Vectoring Plus
GTS-specification brakes
Optional rear-axle steering",
			'summary' => '<p>The updated 992.2 Carrera S gained 30 PS over the first 992, reaching 480 PS from its 3.0-litre twin-turbo flat-six. It borrows the brakes of the Carrera GTS and remains the everyday core of the 911 range.</p>',
			'sort_order' => 79,
			'images' => array(
				array( '3/38/Porsche_992_Carrera_S_coupe_IMG_5832.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '5/5c/Porsche_992_Carrera_S_%281%29.jpg', 'Nick.Pr, CC BY-SA 4.0' ),
				array( 'c/c5/Porsche_992_Carrera_S_coupe_IMG_5843.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( 'd/da/Porsche_992_Carrera_S_%285%29.jpg', 'Nick.Pr, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'ferrari-roma', 'make' => 'Ferrari', 'model' => 'Roma', 'variant' => 'Coupé', 'year' => 2020, 'body' => 'Coupé',
			'tagline' => 'A front-engined V8 grand tourer inspired by 1960s Rome.',
			'engine' => '3.9L twin-turbo V8 (F154)', 'power' => '620 CV', 'transmission' => '8-speed dual-clutch', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '11.2 L/100 km (WLTP)', 'seats' => '2+2',
			'highlights' => "Twin-turbo V8 from the F154 family
Active rear spoiler
Dual-cockpit cabin design
8-speed dual-clutch from the SF90 Stradale",
			'summary' => '<p>The Roma brought a softer, more elegant look to Ferrari’s front-engined line-up. Its 620 CV twin-turbo V8 is mounted behind the front axle, and its styling recalls the grand tourers of 1950s and 1960s Rome.</p>',
			'sort_order' => 80,
			'images' => array(
				array( '9/9b/Ferrari_Roma_IMG_9620.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( 'e/ef/Ferrari_Roma_Auto_Zuerich_2021_IMG_0414.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '7/79/Ferrari_Roma_1X7A0309.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( 'b/bb/Ferrari_Roma_IMG_9627.jpg', 'Alexander-93, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'lamborghini-countach-lpi-800-4', 'make' => 'Lamborghini', 'model' => 'Countach LPI 800-4', 'variant' => 'Limited series', 'year' => 2022, 'body' => 'Coupé',
			'tagline' => 'A modern tribute to the wedge that defined the supercar, with a hybrid-assisted V12.',
			'engine' => '6.5L V12 with 48V e-motor and supercapacitor', 'power' => '814 CV', 'transmission' => '7-speed ISR automated manual', 'drivetrain' => 'All-wheel drive', 'fuel' => 'Petrol hybrid', 'consumption' => '19.5 L/100 km (WLTP)', 'seats' => '2',
			'highlights' => "780 CV naturally aspirated V12
Supercapacitor hybrid system
Scissor doors
Periscopio roof channel",
			'summary' => '<p>The Countach LPI 800-4 revives the name of Lamborghini’s most famous wedge for a limited run. It uses the hybrid V12 drivetrain of the Sián, where a supercapacitor feeds a small electric motor to add 34 CV to the V12’s 780 CV.</p>',
			'sort_order' => 81,
			'images' => array(
				array( '2/2e/Lamborghini_Countach_LPI_800-4_IMG_8019.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '4/44/Lamborghini_Countach_LPI_800-4_2.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( '6/65/Lamborghini_Countach_LPI_800-4_IMG_8009.jpg', 'Alexander-93, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'mercedes-amg-c63-s-e-performance', 'make' => 'Mercedes-AMG', 'model' => 'C 63 S E Performance', 'variant' => 'W206 saloon', 'year' => 2023, 'body' => 'Saloon',
			'tagline' => 'The four-cylinder plug-in hybrid C 63, with 680 PS and Formula One-derived hardware.',
			'engine' => '2.0L turbo four-cylinder plug-in hybrid (M139l)', 'power' => '680 PS', 'transmission' => '9-speed MCT plus 2-speed rear e-drive', 'drivetrain' => '4MATIC+ all-wheel drive', 'fuel' => 'Petrol plug-in hybrid', 'consumption' => '6.9 L/100 km (WLTP, weighted)', 'seats' => '5',
			'highlights' => "Electric exhaust-gas turbocharger
Rear-mounted electric motor
6.1 kWh high-performance battery
Rear-axle steering",
			'summary' => '<p>This C 63 replaced the twin-turbo V8 with a 2.0-litre four-cylinder and a rear-mounted electric motor. Together they make 680 PS and 1,020 Nm, making it the most powerful C-Class yet.</p>',
			'sort_order' => 82,
			'images' => array(
				array( 'b/b8/Mercedes-AMG_C_63_S_E_Performance_%28W206%29_front.jpg', 'Tokumeigakarinoaoshima, CC BY-SA 4.0' ),
				array( '2/21/Mercedes-AMG_C_63_S_E_Performance_%2725_%281%29.jpg', 'Oq10pass, CC0' ),
				array( '1/1b/Mercedes-AMG_C_63_S_E_Performance_%28W206%29.jpg', 'Tokumeigakarinoaoshima, CC0' ),
				array( 'c/cb/Mercedes-AMG_C_63_S_E_Performance_%284LA-206080C%29_front.jpg', 'Tokumeigakarinoaoshima, CC0' )
			),
		),
		array(
			'slug' => 'porsche-cayenne-turbo-gt', 'make' => 'Porsche', 'model' => 'Cayenne Turbo GT', 'variant' => 'Coupé', 'year' => 2021, 'body' => 'Coupé SUV',
			'tagline' => 'The fastest Cayenne, built to lap the Nürburgring like a sports car.',
			'engine' => '4.0L twin-turbo V8', 'power' => '640 PS', 'transmission' => '8-speed Tiptronic S automatic', 'drivetrain' => 'All-wheel drive', 'fuel' => 'Petrol', 'consumption' => '14.1 L/100 km (WLTP)', 'seats' => '4',
			'highlights' => "Titanium exhaust system
Carbon-fibre roof
Carbon-ceramic brakes as standard
Four individual seats",
			'summary' => '<p>The Cayenne Turbo GT is the most track-focused version of Porsche’s large SUV, offered only with the Coupé body. Its 4.0-litre twin-turbo V8 makes 640 PS, and the chassis was retuned throughout for sharper handling.</p>',
			'sort_order' => 83,
			'images' => array(
				array( '6/60/Porsche_Cayenne_Turbo_GT_Auto_Zuerich_2021_IMG_0298.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( 'b/b3/Porsche_Cayenne_Turbo_GT_DSC_7899.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '3/33/Porsche_Cayenne_Turbo_GT_DSC_7901.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '6/6d/Porsche_Cayenne_Turbo_GT_%289YB%29_Greater_Toronto_Area%2C_Canada.jpg', 'OWS Photography, CC BY 4.0' )
			),
		),
		array(
			'slug' => 'toyota-gr86', 'make' => 'Toyota', 'model' => 'GR86', 'variant' => 'ZN8, manual', 'year' => 2022, 'body' => 'Coupé',
			'tagline' => 'A light, rear-drive sports car with a bigger boxer engine and a proper manual gearbox.',
			'engine' => '2.4L naturally aspirated flat-four (FA24)', 'power' => '234 PS', 'transmission' => '6-speed manual', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '8.8 L/100 km (WLTP)', 'seats' => '2+2',
			'highlights' => "2.4-litre boxer engine
Torsen limited-slip differential
Low centre of gravity
Track mode for stability control",
			'summary' => '<p>The GR86 is the second generation of the sports coupé Toyota develops with Subaru, sister car to the BRZ. A bigger 2.4-litre boxer engine fixed the original’s mid-range dip, while the car stays light and rear-driven.</p>',
			'sort_order' => 84,
			'images' => array(
				array( '0/09/Toyota_GR86.jpg', 'MrWalkr, CC BY-SA 4.0' ),
				array( '3/39/Toyota_GR86_IMG_7863.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '5/50/2022_Toyota_GR86_Premium_in_Halo%2C_Front_Right%2C_04-10-2022.jpg', 'Elise240SX, CC BY-SA 4.0' ),
				array( '5/55/Toyota_GR86_SZ.jpg', 'TTTNIS, CC0' )
			),
		),
		array(
			'slug' => 'lamborghini-miura-sv', 'make' => 'Lamborghini', 'model' => 'Miura', 'variant' => 'P400 SV', 'year' => 1971, 'body' => 'Coupé',
			'tagline' => 'The final and most powerful Miura, the car that set the template for the mid-engined supercar.',
			'engine' => '3.9L naturally aspirated V12, transverse mid-mounted', 'power' => '385 CV', 'transmission' => '5-speed manual', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '21.0 L/100 km (road test, P400 S)', 'seats' => '2',
			'highlights' => "Transverse mid-mounted V12
Marcello Gandini design for Bertone
Wider rear arches and wheels
Headlamps without the earlier ‘eyelashes’",
			'summary' => '<p>The SV was the last and most developed version of the Miura. Its 3.9-litre V12 made 385 CV, the rear track and wheels grew wider, and the car lost the slatted trim around its headlamps that marked the earlier P400 and P400 S.</p>',
			'sort_order' => 90,
			'images' => array(
				array( '3/3b/Lamborghini_Miura_SV_2.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( 'e/e0/1971_Lamborghini_Miura_P400_SV.jpg', 'Chelsea Jay, CC BY-SA 4.0' ),
				array( '7/74/Lamborghini_Miura_SV.jpg', 'MrWalkr, CC BY-SA 4.0' ),
				array( 'b/b7/1971_Lamborghini_Miura_P400_SV_Speciale.jpg', 'MrWalkr, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'ferrari-testarossa', 'make' => 'Ferrari', 'model' => 'Testarossa', 'variant' => 'Original 1984 model', 'year' => 1985, 'body' => 'Coupé',
			'tagline' => 'The flat-12 Ferrari with side strakes that became the poster car of the 1980s.',
			'engine' => '4.9L naturally aspirated flat-12 (F113A)', 'power' => '390 CV', 'transmission' => '5-speed manual', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '21.4 L/100 km (EPA, US-market car)', 'seats' => '2',
			'highlights' => "Mid-mounted 4.9-litre flat-12
Side strakes feeding side-mounted radiators
Pininfarina design
Red-painted cam covers that gave it its name",
			'summary' => '<p>The Testarossa replaced the 512 BBi in 1984 with a wider, more refined mid-engined flat-12. Its 4.9-litre engine made 390 CV, and the long side strakes fed air to radiators moved from the nose to the flanks.</p>',
			'sort_order' => 91,
			'images' => array(
				array( '9/95/Ferrari_Testarossa_01.jpg', 'TTTNIS, Public domain' ),
				array( '9/9a/Ferrari_Testarossa-20190419-2.jpg', 'JoachimKohler-HB, CC BY-SA 4.0' ),
				array( 'f/fc/Ferrari_Testarossa_Toulouse.jpg', 'Handelsgeselschaft, CC BY-SA 4.0' ),
				array( '6/68/Ferrari_Testarossa_IAA_2019_JM_0399.jpg', 'Johannes Maximilian, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'porsche-959', 'make' => 'Porsche', 'model' => '959', 'variant' => 'Komfort', 'year' => 1987, 'body' => 'Coupé',
			'tagline' => 'Porsche’s technology flagship of the 1980s, born for Group B and proven in the Paris–Dakar.',
			'engine' => '2.85L twin-turbo flat-six', 'power' => '450 PS', 'transmission' => '6-speed manual', 'drivetrain' => 'Variable all-wheel drive (PSK)', 'fuel' => 'Petrol', 'consumption' => '17.5 L/100 km (ECE urban cycle)', 'seats' => '2+2',
			'highlights' => "Sequential twin turbochargers
Electronically variable all-wheel drive
Adjustable ride height and damping
Aramid and aluminium body panels",
			'summary' => '<p>The 959 was Porsche’s showcase of everything it could do in the mid-1980s. Its 2.85-litre twin-turbo flat-six made 450 PS, and a computer-controlled all-wheel-drive system varied the torque split to suit grip.</p>',
			'sort_order' => 92,
			'images' => array(
				array( '2/27/Porsche%2C_Paris_Motor_Show_2018%2C_Paris_%281Y7A1089%29.jpg', 'Matti Blume, CC BY-SA 4.0' ),
				array( '5/5e/Porsche_959_S_1X7A7874.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( 'd/de/Porsche_959_GIMS_2024_1X7A2269.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '3/3e/Classic_Gallery%2C_GIMS_2024%2C_Le_Grand-Saconnex_%28GIMS0181%29.jpg', 'Matti Blume, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'mercedes-benz-300-sl-gullwing', 'make' => 'Mercedes-Benz', 'model' => '300 SL', 'variant' => 'W198 Gullwing coupé', 'year' => 1955, 'body' => 'Coupé',
			'tagline' => 'The racing-derived coupé whose upward-opening doors became an icon of 1950s design.',
			'engine' => '3.0L straight-six with direct fuel injection (M198)', 'power' => '215 PS', 'transmission' => '4-speed manual', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '17.0 L/100 km (factory, approx.)', 'seats' => '2',
			'highlights' => "Gullwing doors
Tubular spaceframe chassis
Bosch mechanical direct fuel injection
Engine canted to lower the bonnet line",
			'summary' => '<p>The 300 SL coupé brought Mercedes-Benz racing technology to the road. A light tubular spaceframe with high sills meant conventional doors would not work, so the doors were hinged in the roof and opened upwards.</p>',
			'sort_order' => 93,
			'images' => array(
				array( '2/24/Mercedes-Benz_W198_300_SL_Gullwing_Genf_2019_1Y7A4987.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '3/36/Mercedes-Benz_W198_300_SL_Gullwing_1X7A0196.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '4/4d/Mercedes-Benz_300_SL%2C_TC_24%2C_Essen_%28TCE42870-RR%29.jpg', 'Matti Blume, CC BY-SA 4.0' ),
				array( '8/85/Mercedes-Benz_W198_300_SL_Gullwing_Genf_2019_1Y7A5009.jpg', 'Alexander Migl, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'jaguar-e-type', 'make' => 'Jaguar', 'model' => 'E-Type', 'variant' => 'Series 1 4.2 fixed-head coupé', 'year' => 1965, 'body' => 'Coupé',
			'tagline' => 'Long bonnet, fastback roof and race-bred engineering: the shape that defined 1960s Britain.',
			'engine' => '4.2L straight-six (XK)', 'power' => '265 bhp', 'transmission' => '4-speed manual, all-synchromesh', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '15.7 L/100 km (road test, Motor Sport 1967)', 'seats' => '2',
			'highlights' => "XK straight-six with triple SU carburettors
Monocoque cabin with front subframe
Independent rear suspension
Covered headlamps on Series 1 cars",
			'summary' => '<p>The 4.2-litre Series 1 kept the E-Type’s original shape but added a bigger engine with more torque, an all-synchromesh gearbox, better brakes and more comfortable seats. The fixed-head coupé adds a fastback roof with a side-hinged tailgate.</p>',
			'sort_order' => 94,
			'images' => array(
				array( '0/04/Jaguar_E-Type_series_1_coup%C3%A9_1964.jpg', 'DeFacto, CC BY-SA 4.0' ),
				array( '6/6d/Jaguar_E-Type_Series_1_3.8_Litre_1961.jpg', 'DeFacto, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'ford-gt', 'make' => 'Ford', 'model' => 'GT', 'variant' => 'Second generation', 'year' => 2017, 'body' => 'Coupé',
			'tagline' => 'A carbon-fibre road racer built to win Le Mans again, 50 years after the GT40.',
			'engine' => '3.5L twin-turbo V6 (EcoBoost)', 'power' => '647 hp', 'transmission' => '7-speed dual-clutch', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '16.8 L/100 km (EPA)', 'seats' => '2',
			'highlights' => "Carbon-fibre monocoque
Flying-buttress bodywork
Active rear wing and aerodynamics
Adjustable ride height with Track mode",
			'summary' => '<p>The second-generation Ford GT was developed alongside a Le Mans racer. Its twin-turbo V6 makes 647 hp, and its teardrop cabin and open flying buttresses channel air through the body for downforce and cooling.</p>',
			'sort_order' => 95,
			'images' => array(
				array( 'f/f5/Ford_GT_%282nd_generation%29_coupes_IMG_0224.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '4/40/2017_Ford_GT_%2894302%29.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( '7/7a/2017_Ford_GT_front.JPG', 'Latvian98, CC BY-SA 4.0' ),
				array( '3/3d/2017_Ford_GT%2C_CAS_2015.jpg', 'Ghostofakina, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'nissan-skyline-gt-r-r34', 'make' => 'Nissan', 'model' => 'Skyline GT-R', 'variant' => 'BNR34 V-Spec, Japanese specification', 'year' => 1999, 'body' => 'Coupé',
			'tagline' => 'The last Skyline GT-R, with a twin-turbo straight-six and a computer-controlled all-wheel-drive system.',
			'engine' => '2.6L twin-turbo straight-six (RB26DETT)', 'power' => '280 PS', 'transmission' => '6-speed manual (Getrag)', 'drivetrain' => 'ATTESA E-TS Pro all-wheel drive', 'fuel' => 'Petrol', 'consumption' => '12.3 L/100 km (10-15 mode)', 'seats' => '4',
			'highlights' => "RB26DETT twin-turbo straight-six
ATTESA E-TS Pro with active rear LSD
Multi-function display for live data
V-Spec aero diffuser and firmer suspension",
			'summary' => '<p>The R34 was the final Skyline GT-R before the name split from the Skyline line. The V-Spec added firmer suspension, a rear diffuser and the ATTESA E-TS Pro system, whose active rear differential works with the all-wheel drive.</p>',
			'sort_order' => 96,
			'images' => array(
				array( 'c/cf/2001_Nissan_Skyline_GT-R_V-Spec_II_R34_%2879241%29.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( '2/25/Nissan_Skyline_GT-R_R34%2C_09-21-2025.jpg', '2000chevymontecarlo, CC BY-SA 4.0' ),
				array( 'a/a7/Nissan_Skyline_GT-R_V-spec%2C_BAS_24%2C_Brussels_%28P1170369-RR%29.jpg', 'Matti Blume, CC BY-SA 4.0' ),
				array( '9/90/1999_Nissan_Skyline_GT-R.jpg', 'Calreyn88, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'toyota-supra-a80', 'make' => 'Toyota', 'model' => 'Supra', 'variant' => 'JZA80 Twin Turbo, European specification', 'year' => 1994, 'body' => 'Coupé',
			'tagline' => 'The fourth-generation Supra and its famously strong 2JZ twin-turbo straight-six.',
			'engine' => '3.0L twin-turbo straight-six (2JZ-GTE)', 'power' => '330 PS', 'transmission' => '6-speed manual (Getrag V160)', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '11.1 L/100 km (combined, European car)', 'seats' => '2+2',
			'highlights' => "2JZ-GTE with sequential twin turbos
Getrag six-speed manual
Aluminium bonnet and suspension parts
Large hoop rear spoiler",
			'summary' => '<p>The A80 Supra was Toyota’s flagship sports car of the 1990s. In European form its 3.0-litre twin-turbo straight-six made 330 PS, delivered through a six-speed manual developed with Getrag.</p>',
			'sort_order' => 97,
			'images' => array(
				array( 'b/bc/1996_Toyota_Supra_A80_%28front%29.jpg', 'User3204, CC BY 3.0' ),
				array( 'd/dc/TOYOTA_SUPRA_%28A80%29_HONG_KONG.jpg', 'Dinkun Chen, CC BY-SA 4.0' ),
				array( 'd/dd/Toyota_Supra_A80.jpg', 'Accord14, CC BY-SA 4.0' ),
				array( '4/47/1996-2002_Toyota_Supra_rear.jpg', 'TTTNIS, CC0' )
			),
		),
		array(
			'slug' => 'honda-nsx-na1', 'make' => 'Honda', 'model' => 'NSX', 'variant' => 'NA1 manual, Japanese specification', 'year' => 1991, 'body' => 'Coupé',
			'tagline' => 'The everyday supercar, with an aluminium body and handling honed with input from Ayrton Senna.',
			'engine' => '3.0L V6 with VTEC (C30A)', 'power' => '280 PS', 'transmission' => '5-speed manual', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '13.1 L/100 km (EPA, US-market car)', 'seats' => '2',
			'highlights' => "All-aluminium monocoque body
Mid-mounted VTEC V6 with titanium connecting rods
Aluminium suspension arms
Wide-visibility cockpit inspired by fighter jets",
			'summary' => '<p>The NSX showed that a mid-engined supercar could be reliable and easy to live with. Its body was built almost entirely from aluminium, and its 3.0-litre VTEC V6 sits behind the cabin.</p>',
			'sort_order' => 98,
			'images' => array(
				array( 'a/aa/Honda_E-NA1_NSX_%2824010610243%29.jpg', '先従隗始, CC0' ),
				array( '7/7c/Honda_E-NA1_NSX_%2822022010314%29.jpg', '先従隗始, CC0' ),
				array( '4/42/Honda_E-NA1_NSX_%2823110313234%29.jpg', '先従隗始, CC0' ),
				array( '1/14/Honda_E-NA1_NSX_%2822022010324%29.jpg', '先従隗始, CC0' )
			),
		),
		array(
			'slug' => 'mazda-rx-7-fd', 'make' => 'Mazda', 'model' => 'RX-7', 'variant' => 'FD3S, European specification', 'year' => 1993, 'body' => 'Coupé',
			'tagline' => 'A light, balanced sports car powered by a twin-turbo rotary engine.',
			'engine' => '1.3L twin-rotor Wankel, sequential twin turbo (13B-REW)', 'power' => '239 PS', 'transmission' => '5-speed manual', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '13.1 L/100 km (EPA, US-market car)', 'seats' => '2',
			'highlights' => "Twin-rotor Wankel engine
Sequential twin turbochargers
Engine set behind the front axle
Double-wishbone suspension all round",
			'summary' => '<p>The third-generation RX-7 used a compact twin-turbo rotary engine set low and well back in the chassis, giving near-even weight distribution. In European form it made 239 PS.</p>',
			'sort_order' => 99,
			'images' => array(
				array( '8/8c/1994_Mazda_RX-7_R2_in_Vintage_Red%2C_front_left_%28Lime_Rock%29.jpg', 'Mr.choppers, CC BY-SA 3.0' ),
				array( '2/2a/Mazda_RX-7_Spirit_R_%28FD3S%29_%28front_three-quarter_view%29_at_Mazda_Museum.jpg', 'Aos.1905, CC BY 4.0' ),
				array( 'c/cc/Mazda_RX-7_FD3S%2C_front_right%2C_05-05-2024.jpg', 'Ethan Llamas, CC BY-SA 4.0' ),
				array( '5/57/Mazda_RX-7_FD3S%2C_rear_right%2C_05-05-2024.jpg', 'Ethan Llamas, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'bmw-m3-e30', 'make' => 'BMW', 'model' => 'M3', 'variant' => 'E30, European specification without catalyst', 'year' => 1987, 'body' => 'Coupé',
			'tagline' => 'The original M3, a homologation special that dominated touring-car racing.',
			'engine' => '2.3L four-cylinder, 16-valve (S14)', 'power' => '200 PS', 'transmission' => '5-speed manual (dog-leg)', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '8.3 L/100 km (combined)', 'seats' => '4',
			'highlights' => "High-revving S14 four-cylinder
Box-flared wheel arches
Raised boot lid with rear spoiler
Dog-leg five-speed gearbox",
			'summary' => '<p>The first M3 was built so BMW could race the 3 Series in Group A touring cars. Its 2.3-litre 16-valve engine made 200 PS, and almost every body panel differed from the regular E30 to improve aerodynamics.</p>',
			'sort_order' => 100,
			'images' => array(
				array( '1/14/BMW_M3_E30%2C_Pau_2015_2.jpg', 'Handelsgeselschaft, CC BY-SA 4.0' ),
				array( 'a/ae/BMW_M3_E30%2C_Pau_2015.jpg', 'Handelsgeselschaft, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'lancia-delta-integrale', 'make' => 'Lancia', 'model' => 'Delta HF Integrale', 'variant' => 'Evoluzione (Evo 1)', 'year' => 1992, 'body' => 'Hatchback',
			'tagline' => 'The road version of the most successful car in World Rally Championship history.',
			'engine' => '2.0L turbocharged four-cylinder, 16-valve', 'power' => '210 CV', 'transmission' => '5-speed manual', 'drivetrain' => 'Permanent all-wheel drive', 'fuel' => 'Petrol', 'consumption' => '13.0 L/100 km (ECE urban cycle)', 'seats' => '5',
			'highlights' => "Widened tracks and flared arches
Adjustable roof spoiler
Torsen rear differential
Bonnet louvres for engine cooling",
			'summary' => '<p>The Evoluzione was the final homologation version of the Delta, with wider tracks, bigger arches and a roof spoiler. Its 2.0-litre turbo four made 210 CV, sent to all four wheels.</p>',
			'sort_order' => 101,
			'images' => array(
				array( '3/3a/1993_Lancia_Delta_HF_Integrale_Evoluzione_II_HCC24.jpg', 'MrWalkr, CC BY-SA 4.0' ),
				array( '6/69/1992_Lancia_Delta_HF_Integrale_Evoluzione_HCC23.jpg', 'MrWalkr, CC BY-SA 4.0' ),
				array( '5/5a/1994_Lancia_Delta_HF_Integrale_Evo_LC23.jpg', 'MrWalkr, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'audi-quattro', 'make' => 'Audi', 'model' => 'Quattro', 'variant' => 'Typ 85, 10-valve', 'year' => 1983, 'body' => 'Coupé',
			'tagline' => 'The car that brought permanent four-wheel drive to performance cars and rewrote rallying.',
			'engine' => '2.1L turbocharged five-cylinder, 10-valve (WR)', 'power' => '200 PS', 'transmission' => '5-speed manual', 'drivetrain' => 'Permanent quattro all-wheel drive', 'fuel' => 'Petrol', 'consumption' => '15.4 L/100 km (ECE urban cycle)', 'seats' => '4',
			'highlights' => "Permanent four-wheel drive
Turbocharged five-cylinder engine
Box-flared wheel arches
Lockable centre and rear differentials",
			'summary' => '<p>The original Audi Quattro, or Ur-quattro, combined a turbocharged five-cylinder with permanent four-wheel drive in a sporting coupé. It proved that all-wheel drive could transform grip on any surface.</p>',
			'sort_order' => 102,
			'images' => array(
				array( '8/88/1980-1991_Audi_Quattro.jpg', 'kieranwhite599, CC BY 2.0' ),
				array( 'e/e4/1980-1991_Audi_Quattro_NEC_Restoration_Show.jpg', 'kieranwhite599, CC BY 2.0' ),
				array( 'c/cf/1980-1991_Audi_Quattro_-_53037114378.jpg', 'kieranwhite599, CC BY 2.0' )
			),
		),
		array(
			'slug' => 'lamborghini-diablo', 'make' => 'Lamborghini', 'model' => 'Diablo', 'variant' => 'Original rear-wheel-drive model', 'year' => 1991, 'body' => 'Coupé',
			'tagline' => 'The Countach’s successor, and a V12 wedge capable of more than 320 km/h.',
			'engine' => '5.7L naturally aspirated V12', 'power' => '492 CV', 'transmission' => '5-speed manual', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '23.5 L/100 km (EPA, US-market car)', 'seats' => '2',
			'highlights' => "Mid-mounted 5.7-litre V12
Scissor doors
Design by Marcello Gandini
Tubular steel frame with composite panels",
			'summary' => '<p>The Diablo took over from the Countach in 1990 as Lamborghini’s V12 flagship. Its 5.7-litre engine made 492 CV, and Lamborghini quoted a top speed of 325 km/h for the original rear-wheel-drive car.</p>',
			'sort_order' => 103,
			'images' => array(
				array( '1/1d/Lamborghini_Diablo%2C_Motortreff_Bella_Italia_2024%2C_Munich_%28P1190396%29.jpg', 'Matti Blume, CC BY-SA 4.0' ),
				array( 'b/bd/Motikon%2C_TC_24%2C_Essen_%28TCE42876%29.jpg', 'Matti Blume, CC BY-SA 4.0' ),
				array( 'd/d4/Lamborghini_Diablo_%2814486997194%29.jpg', 'Rutger van der Maar from Leiden, The Netherlands, CC BY 2.0' )
			),
		),
		array(
			'slug' => 'ferrari-enzo', 'make' => 'Ferrari', 'model' => 'Enzo', 'variant' => 'Coupé', 'year' => 2003, 'body' => 'Coupé',
			'tagline' => 'Ferrari’s Formula One-inspired hypercar, named after the company’s founder.',
			'engine' => '6.0L naturally aspirated V12 (F140)', 'power' => '660 CV', 'transmission' => '6-speed F1 automated manual', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '29.4 L/100 km (EPA)', 'seats' => '2',
			'highlights' => "Naturally aspirated 6.0-litre V12
Carbon-fibre and Nomex body and tub
Carbon-ceramic brakes
F1-style paddle-shift gearbox",
			'summary' => '<p>The Enzo brought Ferrari’s Formula One know-how to the road in a strictly limited run. Its 6.0-litre V12 made 660 CV, and the carbon-fibre body uses underbody aerodynamics and small active flaps instead of a large rear wing.</p>',
			'sort_order' => 104,
			'images' => array(
				array( '3/32/2003_Ferrari_Enzo_2.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( '8/85/Ferrari_Enzo_-_Flickr_-_Alexandre_Pr%C3%A9vot_%281%29_%28cropped%29.jpg', 'Alexandre Prévot from Nancy, France, CC BY-SA 2.0' ),
				array( '1/1d/Ferrari_Enzo_6.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( 'c/ce/Orange_Enzo_Ferrari_%287191948164%29.jpg', 'Axion23, CC BY 2.0' )
			),
		),
		array(
			'slug' => 'ferrari-f8-tributo', 'make' => 'Ferrari', 'model' => 'F8 Tributo', 'variant' => 'Coupé', 'year' => 2020, 'body' => 'Coupé',
			'tagline' => 'Ferrari’s mid-engined V8 berlinetta, named as a tribute to its most celebrated engine.',
			'engine' => '3.9L twin-turbo V8 (F154), mid-mounted', 'power' => '720 CV', 'transmission' => '7-speed F1 dual-clutch', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '12.9 L/100 km (WLTP combined)', 'seats' => '2',
			'highlights' => "720 CV twin-turbo V8 from the 488 Pista
S-Duct in the nose for front downforce
Lexan rear screen with louvres recalling the F40
Side Slip Control 6.1 with Ferrari Dynamic Enhancer",
			'summary' => '<p>The F8 Tributo replaced the 488 GTB in 2019. Its 3.9-litre twin-turbo V8 makes 720 CV, the same output as the track-focused 488 Pista, and the car is 40 kg lighter than the model it replaced.</p>',
			'sort_order' => 110,
			'images' => array(
				array( 'd/d6/Ferrari_F8_Tributo_DSC_7013.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '8/81/Ferrari_F8_Tributo%2C_GIMS_2019%2C_Le_Grand-Saconnex_%28GIMS1318%29.jpg', 'Matti Blume, CC BY-SA 4.0' ),
				array( 'e/e2/Ferrari_F8_Tributo%2C_GIMS_2019%2C_Le_Grand-Saconnex_%28GIMS1319%29.jpg', 'Matti Blume, CC BY-SA 4.0' ),
				array( 'e/e9/Ferrari_F8_Tributo_DSC_7014.jpg', 'Alexander Migl, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'ferrari-812-superfast', 'make' => 'Ferrari', 'model' => '812 Superfast', 'variant' => 'Coupé', 'year' => 2018, 'body' => 'Coupé',
			'tagline' => 'A front-engined V12 grand tourer with 800 CV and no turbochargers.',
			'engine' => '6.5L naturally aspirated V12 (F140GA), front mid-mounted', 'power' => '800 CV', 'transmission' => '7-speed F1 dual-clutch', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '14.9 L/100 km (NEDC combined)', 'seats' => '2',
			'highlights' => "800 CV naturally aspirated V12
Revs to 8,900 rpm
Virtual Short Wheelbase 2.0 rear-wheel steering
Electric power steering, a first for Ferrari",
			'summary' => '<p>The 812 Superfast replaced the F12berlinetta in 2017. Its 6.5-litre V12 makes 800 CV without turbocharging, and its name combines that output with the engine’s 12 cylinders.</p>',
			'sort_order' => 111,
			'images' => array(
				array( '2/24/Ferrari_812_Superfast_IMG_8829.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '9/9f/Ferrari_812_Superfast%2C_GIMS_2019%2C_Le_Grand-Saconnex_%28GIMS1323%29.jpg', 'Matti Blume, CC BY-SA 4.0' ),
				array( 'a/a8/Ferrari_812_Superfast_at_the_2026_Adelaide_Motorsport_Festival_%28DSCF2566%29.jpg', 'Yu Chu Chin, CC BY-SA 4.0' ),
				array( '4/42/Ferrari_812_Superfast%2C_Zurich_01.jpg', 'Ank Kumar, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'lamborghini-aventador-svj', 'make' => 'Lamborghini', 'model' => 'Aventador', 'variant' => 'SVJ coupé', 'year' => 2019, 'body' => 'Coupé',
			'tagline' => 'The most extreme Aventador, with active aerodynamics and a Nürburgring record.',
			'engine' => '6.5L naturally aspirated V12, mid-mounted', 'power' => '770 CV', 'transmission' => '7-speed ISR automated manual', 'drivetrain' => 'All-wheel drive', 'fuel' => 'Petrol', 'consumption' => '19.6 L/100 km (NEDC combined)', 'seats' => '2',
			'highlights' => "770 CV naturally aspirated V12
ALA 2.0 active aerodynamics
Scissor doors
Carbon-fibre monocoque",
			'summary' => '<p>The SVJ, short for Superveloce Jota, was the final and most focused version of the Aventador coupé. Its V12 makes 770 CV, and the ALA 2.0 system opens and closes flaps to shift downforce from side to side through corners.</p>',
			'sort_order' => 112,
			'images' => array(
				array( '1/15/Lamborghini_Aventador_SVJ_2019.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( '8/89/Lamborghini_Aventador_SVJ_13.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( 'd/dc/Lamborghini_Aventador_SVJ_2019_grey.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( 'c/c7/Lamborghini_Aventador_SVJ_%28Ank_kumar%2C_Infosys%29_03.jpg', 'Ank Kumar, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'mclaren-720s', 'make' => 'McLaren', 'model' => '720S', 'variant' => 'Coupé', 'year' => 2018, 'body' => 'Coupé',
			'tagline' => 'McLaren’s second-generation Super Series car, built around a carbon-fibre tub.',
			'engine' => '4.0L twin-turbo V8 (M840T), mid-mounted', 'power' => '720 PS', 'transmission' => '7-speed dual-clutch (SSG)', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '10.7 L/100 km (NEDC combined)', 'seats' => '2',
			'highlights' => "Monocage II carbon-fibre tub
Double-skinned dihedral doors
Proactive Chassis Control II
Folding driver display",
			'summary' => '<p>The 720S replaced the 650S in 2017. Its 4.0-litre twin-turbo V8 makes 720 PS, and the carbon-fibre Monocage II structure extends up into the roof, allowing slimmer pillars and better visibility.</p>',
			'sort_order' => 113,
			'images' => array(
				array( 'a/af/Mclaren_720S_PA280973-PSD.jpg', 'Ermell, CC BY-SA 4.0' ),
				array( '6/6c/McLaren_720S_Orange.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( 'b/b9/McLaren_720S_25.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( '9/94/McLaren_720S%2C_IAA_2017%2C_%281Y7A3406%29.jpg', 'Matti Blume, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'mclaren-artura', 'make' => 'McLaren', 'model' => 'Artura', 'variant' => 'Coupé', 'year' => 2022, 'body' => 'Coupé',
			'tagline' => 'McLaren’s first series-production plug-in hybrid, with an all-new V6.',
			'engine' => '3.0L twin-turbo V6 with axial-flux electric motor, mid-mounted', 'power' => '680 PS', 'transmission' => '8-speed dual-clutch (SSG)', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol plug-in hybrid', 'consumption' => '4.6 L/100 km (WLTP weighted combined)', 'seats' => '2',
			'highlights' => "120-degree twin-turbo V6
Axial-flux electric motor in the gearbox
McLaren Carbon Lightweight Architecture
Around 30 km of electric-only range",
			'summary' => '<p>The Artura replaced the Sports Series cars with a new kind of McLaren. A 3.0-litre twin-turbo V6 and an electric motor give a combined 680 PS, and the car can travel short distances on electric power alone.</p>',
			'sort_order' => 114,
			'images' => array(
				array( '4/4f/McLaren_Artura_IMG_0534.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '1/1a/McLaren_Artura_IMG_0527.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '9/97/McLaren_Artura_3.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( 'd/dc/2024_McLaren_Artura_6.jpg', 'Calreyn88, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'porsche-carrera-gt', 'make' => 'Porsche', 'model' => 'Carrera GT', 'variant' => 'Roadster', 'year' => 2004, 'body' => 'Roadster',
			'tagline' => 'A carbon-fibre V10 supercar with a racing engine and a manual gearbox.',
			'engine' => '5.7L naturally aspirated V10, mid-mounted', 'power' => '612 PS', 'transmission' => '6-speed manual with ceramic clutch', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '17.8 L/100 km (EU combined)', 'seats' => '2',
			'highlights' => "V10 developed for a Le Mans prototype
Carbon-fibre monocoque and subframe
Porsche Ceramic Composite Clutch
Removable roof panels",
			'summary' => '<p>The Carrera GT used a 5.7-litre V10 originally developed for a Le Mans racing programme. With 612 PS, a carbon-fibre chassis and a six-speed manual gearbox, it was one of the last analogue supercars.</p>',
			'sort_order' => 115,
			'images' => array(
				array( '9/97/Porsche_Carrera_GT_Classic-Gala_2025_DSC_0837.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '0/06/Porsche_Carrera_GT_%2888960%29.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( '2/24/Porsche_Carrera_GT_%2858140%29.jpg', 'Calreyn88, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'porsche-718-cayman-gt4-rs', 'make' => 'Porsche', 'model' => '718 Cayman', 'variant' => 'GT4 RS', 'year' => 2022, 'body' => 'Coupé',
			'tagline' => 'The mid-engined Cayman with the 911 GT3’s naturally aspirated flat-six.',
			'engine' => '4.0L naturally aspirated flat-six, mid-mounted', 'power' => '500 PS', 'transmission' => '7-speed PDK dual-clutch', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '13.0 L/100 km (WLTP combined)', 'seats' => '2',
			'highlights' => "Flat-six from the 911 GT3, revving to 9,000 rpm
Air intakes in place of the rear side windows
Carbon-fibre bonnet and front wings
Swan-neck rear wing",
			'summary' => '<p>The GT4 RS is the most extreme 718 Cayman. It uses the 4.0-litre flat-six from the 911 GT3, making 500 PS, and draws air for the engine through openings where the regular car has small rear side windows.</p>',
			'sort_order' => 116,
			'images' => array(
				array( '6/68/Porsche_718_Cayman_GT4_RS_SCD_24.jpg', 'MrWalkr, CC BY-SA 4.0' ),
				array( 'c/c7/2023_Porsche_718_Cayman_GT4_RS_SCD_24.jpg', 'MrWalkr, CC BY-SA 4.0' ),
				array( '0/00/2022_Porsche_718_Cayman_GT4_RS_SCD24.jpg', 'MrWalkr, CC BY-SA 4.0' ),
				array( '0/09/2022_Porsche_718_Cayman_GT4_RS_Weissach.jpg', 'MrWalkr, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'mercedes-amg-g63-4x4-squared', 'make' => 'Mercedes-AMG', 'model' => 'G 63', 'variant' => '4x4²', 'year' => 2022, 'body' => 'SUV',
			'tagline' => 'The G-Class raised on portal axles and given AMG’s twin-turbo V8.',
			'engine' => '4.0L twin-turbo V8 (M177)', 'power' => '585 PS', 'transmission' => '9-speed automatic (AMG Speedshift TCT 9G)', 'drivetrain' => 'Permanent AWD with portal axles', 'fuel' => 'Petrol', 'consumption' => '16.0 L/100 km (combined, factory)', 'seats' => '5',
			'highlights' => "Portal axles front and rear
Around 350 mm of ground clearance
Three locking differentials
Two-stage adjustable dampers",
			'summary' => '<p>The G 63 4x4² combines the G-Class body with portal axles, which lift the axle centrelines above the wheel hubs. The result is around 350 mm of ground clearance, paired with AMG’s 585 PS twin-turbo V8.</p>',
			'sort_order' => 117,
			'images' => array(
				array( '8/80/Mercedes-AMG_G_63_4x4%C2%B2_1X7A7343.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( 'f/fe/Mercedes-AMG_G_63_4x4%C2%B2_1X7A7348.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '1/1d/Mercedes-AMG_G_63_4x4%C2%B2_1X7A6594.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( 'a/a4/Mercedes-AMG_G_63_4x4%C2%B2_1X7A7344.jpg', 'Alexander-93, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'land-rover-defender-110-v8', 'make' => 'Land Rover', 'model' => 'Defender 110', 'variant' => 'V8 (P525), L663', 'year' => 2022, 'body' => 'SUV',
			'tagline' => 'The new-generation Defender with a supercharged V8 under the bonnet.',
			'engine' => '5.0L supercharged V8', 'power' => '525 PS', 'transmission' => '8-speed automatic', 'drivetrain' => 'Permanent AWD, two-speed transfer box', 'fuel' => 'Petrol', 'consumption' => '15.1 L/100 km (WLTP combined)', 'seats' => '5',
			'highlights' => "525 PS supercharged V8
Aluminium monocoque (D7x)
Air suspension and Terrain Response 2
Quad exhaust outlets",
			'summary' => '<p>The V8 is the fastest version of the L663 Defender. Its 5.0-litre supercharged engine makes 525 PS, and the chassis gains uprated suspension and an electronic active rear differential.</p>',
			'sort_order' => 118,
			'images' => array(
				array( 'd/de/Land_Rover_Defender_110_V8_%28L663%29_Washington_DC_Metro_Area%2C_USA.jpg', 'OWS Photography, CC BY 4.0' ),
				array( 'd/df/Land_Rover_Defender_110_V8_%28L663%29_Washington_DC_Metro_Area%2C_USA_%281%29.jpg', 'OWS Photography, CC BY 4.0' ),
				array( '3/39/Land_Rover_Defender_110_V8_%28L663%29_Washington_DC_Metro_Area%2C_USA_%282%29.jpg', 'OWS Photography, CC BY 4.0' ),
				array( 'f/fc/Land_Rover_Defender_%28L663%29_V8_IMG_6604.jpg', 'Alexander Migl, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'toyota-land-cruiser-250', 'make' => 'Toyota', 'model' => 'Land Cruiser', 'variant' => '250, 2.8 D-4D', 'year' => 2024, 'body' => 'SUV',
			'tagline' => 'The Prado successor, on the same rugged platform as the Land Cruiser 300.',
			'engine' => '2.8L turbodiesel four-cylinder (1GD-FTV)', 'power' => '204 PS', 'transmission' => '8-speed automatic', 'drivetrain' => 'Permanent 4WD, low range', 'fuel' => 'Diesel', 'consumption' => '10.6 L/100 km (WLTP combined)', 'seats' => '5 or 7',
			'highlights' => "TNGA-F body-on-frame platform
Eight-speed automatic
Electronic front stabiliser disconnect
Upright, boxy styling inspired by earlier Land Cruisers",
			'summary' => '<p>The Land Cruiser 250 replaced the long-running Prado. It moves to the TNGA-F ladder-frame platform shared with the Land Cruiser 300, and its 2.8-litre turbodiesel drives all four wheels through an eight-speed automatic.</p>',
			'sort_order' => 119,
			'images' => array(
				array( '9/9a/Toyota_Land_Cruiser_250_ZX_First_Edition.jpg', 'TTTNIS, CC0' ),
				array( 'e/e3/Toyota_Land_Cruiser_250_VX.jpg', 'TTTNIS, CC0' ),
				array( '2/26/Toyota_Land_Cruiser_250_ZX_First_Edition_rear.jpg', 'TTTNIS, CC0' ),
				array( 'e/e8/2024_Toyota_Land_Cruiser_250_VX_in_Platinum_White_Pearl_Mica%2C_front_left.jpg', 'Mr.choppers, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'bmw-m4-csl', 'make' => 'BMW', 'model' => 'M4', 'variant' => 'CSL (G82)', 'year' => 2022, 'body' => 'Coupé',
			'tagline' => 'A lighter, harder M4 built in a limited run to mark 50 years of BMW M.',
			'engine' => '3.0L twin-turbo straight-six (S58)', 'power' => '550 PS', 'transmission' => '8-speed M Steptronic automatic', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '10.1 L/100 km (WLTP combined)', 'seats' => '2',
			'highlights' => "550 PS twin-turbo straight-six
About 100 kg lighter than the M4 Competition
Rear seats replaced by storage trays
Carbon-fibre roof, bonnet and boot lid",
			'summary' => '<p>The M4 CSL is a lightweight special built for BMW M’s 50th anniversary. Its straight-six makes 550 PS, and removing the rear seats and using more carbon fibre saves around 100 kg over the M4 Competition.</p>',
			'sort_order' => 120,
			'images' => array(
				array( 'd/d7/BMW_M4_CSL_IMG_7638.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( 'c/c7/2022_BMW_M4_CSL_FOS22.jpg', 'MrWalkr, CC BY-SA 4.0' ),
				array( '3/33/BMW_M4_CSL_Romans.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( 'd/d9/2022_BMW_M4_CSL_Rear.jpg', 'MrWalkr, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'audi-r8-v10-performance', 'make' => 'Audi', 'model' => 'R8', 'variant' => 'V10 performance quattro (facelift)', 'year' => 2020, 'body' => 'Coupé',
			'tagline' => 'Audi’s naturally aspirated V10 supercar in its most powerful all-wheel-drive form.',
			'engine' => '5.2L naturally aspirated V10 (FSI), mid-mounted', 'power' => '620 PS', 'transmission' => '7-speed S tronic dual-clutch', 'drivetrain' => 'quattro all-wheel drive', 'fuel' => 'Petrol', 'consumption' => '13.3 L/100 km (WLTP combined)', 'seats' => '2',
			'highlights' => "Naturally aspirated V10 revving past 8,000 rpm
quattro all-wheel drive
Audi Space Frame in aluminium and carbon fibre
Wider front grille and flat slot after the 2019 facelift",
			'summary' => '<p>The facelifted second-generation R8 arrived in 2019. In V10 performance quattro form its 5.2-litre engine makes 620 PS and drives all four wheels through a seven-speed dual-clutch gearbox.</p>',
			'sort_order' => 121,
			'images' => array(
				array( '0/0e/2024_Audi_R8_Performance_V10.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( '1/11/Audi_R8_V10_Performance.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( 'f/fd/Audi_R8_V10_Performance_4S_FL_Java_Green_Metallic_%282%29.jpg', 'Damian B Oh, CC BY-SA 4.0' ),
				array( 'f/fa/Audi_R8_V10_Performance_4S_FL_Java_Green_Metallic_%281%29.jpg', 'Damian B Oh, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'nissan-z', 'make' => 'Nissan', 'model' => 'Z', 'variant' => 'RZ34, 6-speed manual', 'year' => 2023, 'body' => 'Coupé',
			'tagline' => 'The seventh-generation Z, with a twin-turbo V6 and a manual gearbox.',
			'engine' => '3.0L twin-turbo V6 (VR30DDTT)', 'power' => '400 hp', 'transmission' => '6-speed manual', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '10.8 L/100 km (ADR combined, manual)', 'seats' => '2',
			'highlights' => "Twin-turbo VR30DDTT V6
Six-speed manual or nine-speed automatic
Headlamp shapes recalling the 240Z
Tail lamps inspired by the 300ZX",
			'summary' => '<p>The Z, sold as the Fairlady Z in Japan, replaced the 370Z. Its 3.0-litre twin-turbo V6 makes 400 hp, and its styling borrows details from earlier Z cars.</p>',
			'sort_order' => 122,
			'images' => array(
				array( 'e/e6/2023_Nissan_Z_Performance_6MT_in_Passion_Red_TriCoat%2C_Front_Left%2C_05-17-2023.jpg', 'Elise240SX, CC BY-SA 4.0' ),
				array( '7/7c/2023_Nissan_Z_Performance_in_Seiran_Blue%2C_front_right_%28NYIAS_2022%29.jpg', 'Mr.choppers, CC BY-SA 3.0' ),
				array( '0/04/2023_Nissan_Z_%2852810173459%29.jpg', 'Greg Gjerdingen from Willmar, USA, CC BY 2.0' )
			),
		),
		array(
			'slug' => 'rolls-royce-phantom', 'make' => 'Rolls-Royce', 'model' => 'Phantom', 'variant' => 'VIII, standard wheelbase', 'year' => 2018, 'body' => 'Saloon',
			'tagline' => 'Rolls-Royce’s flagship saloon, built on its own aluminium spaceframe.',
			'engine' => '6.75L twin-turbo V12', 'power' => '563 bhp', 'transmission' => '8-speed automatic, satellite-aided', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '13.9 L/100 km (NEDC combined)', 'seats' => '5',
			'highlights' => "Aluminium Architecture of Luxury spaceframe
The Gallery glass-fronted dashboard
Rear-hinged rear coach doors
Satellite-aided gearbox",
			'summary' => '<p>The eighth-generation Phantom arrived in 2017. Its 6.75-litre twin-turbo V12 makes 563 bhp and 900 Nm from 1,700 rpm, and it was the first car on Rolls-Royce’s own aluminium spaceframe.</p>',
			'sort_order' => 123,
			'images' => array(
				array( 'b/b8/Rolls-Royce_Phantom_VIII_Series_I_IMG_9101.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '7/75/Rolls-Royce_Phantom_VIII_001.jpg', 'JustAnotherCarDesigner, CC BY-SA 4.0' ),
				array( '8/86/Rolls-Royce_Phantom_%28VIII%29_Greater_Toronto_Area%2C_Canada.jpg', 'OWS Photography, CC BY 4.0' ),
				array( 'a/a4/Rolls-Royce_Phantom_VIII_002.jpg', 'JustAnotherCarDesigner, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'aston-martin-vantage', 'make' => 'Aston Martin', 'model' => 'Vantage', 'variant' => '2024 coupé', 'year' => 2024, 'body' => 'Coupé',
			'tagline' => 'Aston Martin’s front-engined V8 sports car, reworked with 665 PS.',
			'engine' => '4.0L twin-turbo V8, front mid-mounted', 'power' => '665 PS', 'transmission' => '8-speed automatic', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '12.1 L/100 km (WLTP combined)', 'seats' => '2',
			'highlights' => "665 PS twin-turbo V8
Wider body and larger front grille
DB12-style cabin with touchscreen
Revised chassis with new dampers",
			'summary' => '<p>The 2024 Vantage is a heavily revised version of Aston Martin’s V8 sports car. Its twin-turbo V8 makes 665 PS, 155 PS more than before, and the car gains a wider body and a new interior.</p>',
			'sort_order' => 124,
			'images' => array(
				array( '1/1b/Aston_Martin_Vantage_%282024%29_IMG_0002.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '1/1c/Aston_Martin_Vantage_%282024%29_IMG_0015.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( 'd/d7/Aston_Martin_Vantage_%282024%29_IMG_9999.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '7/74/Aston_Martin_Vantage_%282024%29_IMG_0003.jpg', 'Alexander-93, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'datsun-240z', 'make' => 'Datsun', 'model' => '240Z', 'variant' => 'S30, European specification', 'year' => 1971, 'body' => 'Coupé',
			'tagline' => 'The affordable six-cylinder sports car that won the Safari Rally twice.',
			'engine' => '2.4L straight-six (L24), twin SU-type carburettors', 'power' => '130 PS', 'transmission' => '5-speed manual', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '11 L/100 km (typical, period US figure)', 'seats' => '2',
			'highlights' => "2.4-litre overhead-cam straight-six
Long bonnet and fastback hatch
Fully independent suspension
Safari Rally winner in 1971 and 1973",
			'summary' => '<p>The 240Z brought a smooth straight-six, independent suspension and handsome fastback styling to a wide audience. It also proved itself on the toughest roads in Africa, winning the Safari Rally in 1971 and 1973.</p>',
			'sort_order' => 130,
			'images' => array(
				array( '6/68/1973_Datsun_240Z_white.jpg', 'Calreyn88, CC BY 4.0' ),
				array( '5/56/Yellow_Datsun_240Z_dllu.jpg', 'Dllu, CC BY-SA 4.0' ),
				array( '9/9a/1971_Datsun_240Z_bsj25.jpg', 'Calreyn88, CC BY 4.0' ),
				array( 'c/c7/1971_Datsun_240Z_East_African_Safari_Rally.jpg', 'TTTNIS, CC0' )
			),
		),
		array(
			'slug' => 'toyota-celica-gt-four-st185', 'make' => 'Toyota', 'model' => 'Celica', 'variant' => 'GT-Four ST185 (Turbo 4x4, Europe)', 'year' => 1990, 'body' => 'Liftback coupé',
			'tagline' => 'Toyota’s turbocharged four-wheel-drive Celica, a four-time Safari Rally winner.',
			'engine' => '2.0L turbocharged four-cylinder (3S-GTE)', 'power' => '204 PS', 'transmission' => '5-speed manual', 'drivetrain' => 'Permanent four-wheel drive', 'fuel' => 'Petrol', 'consumption' => '9.2 L/100 km (combined, cars-data.com)', 'seats' => '4',
			'highlights' => "3S-GTE turbocharged four with intercooler
Permanent four-wheel drive
Homologation base for Toyota’s Group A rally car
Safari Rally winner four years running",
			'summary' => '<p>The ST185 was the second Celica GT-Four and the basis for Toyota’s Group A rally car. Its 2.0-litre turbocharged engine drives all four wheels, and in rally form it won the Safari Rally four years in a row.</p>',
			'sort_order' => 131,
			'images' => array(
				array( '3/36/1990_Toyota_Celica_GT-Four_%28ST185%29_%2851297501181%29.jpg', 'Jones028 from Hong Kong, CC BY 2.0' ),
				array( '1/1e/1990_Toyota_Celica_GT-Four_%28ST185%29_%2851298213114%29.jpg', 'Jones028 from Hong Kong, CC BY 2.0' ),
				array( 'e/ec/Toyota_Celica_GT-4_%283995522709%29.jpg', 'dave_7 from Lethbridge, Canada, CC BY 2.0' )
			),
		),
		array(
			'slug' => 'subaru-impreza-22b', 'make' => 'Subaru', 'model' => 'Impreza', 'variant' => '22B STi', 'year' => 1998, 'body' => 'Coupé',
			'tagline' => 'A wide-bodied road car built to celebrate three straight world rally titles.',
			'engine' => '2.2L turbocharged flat-four (EJ22G)', 'power' => '280 PS', 'transmission' => '5-speed manual', 'drivetrain' => 'Permanent AWD, DCCD centre diff', 'fuel' => 'Petrol', 'consumption' => '', 'seats' => '4',
			'highlights' => "Body 80 mm wider, styled after the Impreza WRC97
Enlarged 2.2-litre version of the EJ flat-four
Bilstein dampers and Eibach springs
Adjustable rear wing and 17-inch BBS wheels",
			'summary' => '<p>The 22B STi marked Subaru’s 40th anniversary and its third consecutive World Rally Championship manufacturers’ title. It combined a two-door Impreza with a wide body inspired by the WRC car and a 2.2-litre flat-four.</p>',
			'sort_order' => 132,
			'images' => array(
				array( 'e/ea/1998_Subaru_Impreza_22b_STi.jpg', 'MrWalkr, CC BY-SA 4.0' ),
				array( 'a/a2/1998_Subaru_Impreza_22B_STi_%2822532%29.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( '7/7e/1998_Subaru_Impreza_22B_STi.jpg', 'MrWalkr, CC BY-SA 4.0' ),
				array( 'a/a5/1998_Subaru_Impreza_22B_STi_%2814249%29.jpg', 'Calreyn88, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'lancia-stratos', 'make' => 'Lancia', 'model' => 'Stratos', 'variant' => 'HF Stradale', 'year' => 1974, 'body' => 'Coupé',
			'tagline' => 'The first car designed from scratch to win rallies, with a Ferrari V6 behind the seats.',
			'engine' => '2.4L V6 (Ferrari Dino), mid-mounted', 'power' => '190 CV', 'transmission' => '5-speed manual', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '16 L/100 km (average, approx.)', 'seats' => '2',
			'highlights' => "Ferrari Dino V6 mounted behind the cabin
Wedge-shaped body by Bertone
Very short 2,180 mm wheelbase
World Rally Championship titles in 1974, 1975 and 1976",
			'summary' => '<p>The Stratos was conceived purely as a rally car, with the road version built only to satisfy homologation rules. Its 2.4-litre Ferrari Dino V6 sits behind the two seats in a short, wide wedge of a body.</p>',
			'sort_order' => 133,
			'images' => array(
				array( 'f/fa/1975_Lancia_Stratos_HF_Stradale_7.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( '8/89/Lancia_Stratos_HF_Classic-Gala_2022_1X7A0375.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( 'd/d8/1975_Lancia_Stratos_HF_Stradale_3.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( '9/90/1975_Lancia_Stratos_HF_Stradale_Low.jpg', 'MrWalkr, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'range-rover-classic', 'make' => 'Land Rover', 'model' => 'Range Rover', 'variant' => 'Classic 3.5 V8, two-door', 'year' => 1970, 'body' => 'SUV',
			'tagline' => 'The original luxury off-roader, with a V8 and permanent four-wheel drive.',
			'engine' => '3.5L V8 (Rover), twin carburettors', 'power' => '135 bhp', 'transmission' => '4-speed manual with two-speed transfer box', 'drivetrain' => 'Permanent 4WD, lockable centre diff', 'fuel' => 'Petrol', 'consumption' => '19.6 L/100 km (road test, Autocar 1970)', 'seats' => '5',
			'highlights' => "Aluminium V8 derived from a Buick design
Permanent four-wheel drive
Long-travel coil springs at all four corners
Disc brakes on all wheels",
			'summary' => '<p>The Range Rover combined Land Rover off-road ability with a smooth V8, coil springs and a comfortable cabin. Launched in 1970 as a two-door, it created the market for luxurious four-wheel drives.</p>',
			'sort_order' => 134,
			'images' => array(
				array( '0/08/1973_Land_Rover_Range_Rover_3.5.jpg', 'Vauxford, CC BY-SA 4.0' ),
				array( '2/2c/Range_Rover_Classic_%281970%29_Classic-Gala_2022_1X7A0287.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '4/4d/Range_Rover_Classic_2door_001.jpg', '天然ガス, CC BY-SA 3.0' ),
				array( '0/05/Range_Rover_Classic_%281970%29_Classic-Gala_2022_1X7A0286.jpg', 'Alexander Migl, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'peugeot-504', 'make' => 'Peugeot', 'model' => '504', 'variant' => 'TI saloon', 'year' => 1973, 'body' => 'Saloon',
			'tagline' => 'The tough Pininfarina-styled saloon that conquered African roads and the Safari Rally.',
			'engine' => '2.0L four-cylinder with Kugelfischer injection', 'power' => '104 PS', 'transmission' => '4-speed manual', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '8.7 L/100 km (best case, period review)', 'seats' => '5',
			'highlights' => "Styling by Pininfarina
Independent rear suspension
Disc brakes on all four wheels
European Car of the Year 1969",
			'summary' => '<p>The 504 was Peugeot’s robust mid-size saloon, styled by Pininfarina and praised for its ride and strength. Its toughness made it a favourite across Africa, and Ove Andersson and Arne Hertz drove one to victory on the 1975 Safari Rally.</p>',
			'sort_order' => 135,
			'images' => array(
				array( '0/0a/1978_Peugeot_504_Ti_Automatic_2.0_Front.jpg', 'Vauxford, CC BY-SA 4.0' ),
				array( 'f/f0/Peugeot_504_GL_2.jpg', 'Handelsgeselschaft, CC BY-SA 4.0' ),
				array( '2/24/Peugeot_504_GL.jpg', 'Handelsgeselschaft, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'peugeot-205-t16', 'make' => 'Peugeot', 'model' => '205', 'variant' => 'Turbo 16 road car', 'year' => 1984, 'body' => 'Hatchback',
			'tagline' => 'A mid-engined, four-wheel-drive Group B special in the shape of a 205.',
			'engine' => '1.8L turbocharged four-cylinder (XU8T), mid-mounted', 'power' => '200 PS', 'transmission' => '5-speed manual', 'drivetrain' => 'Four-wheel drive', 'fuel' => 'Petrol', 'consumption' => '11.6 L/100 km (average, period figure)', 'seats' => '2',
			'highlights' => "Turbocharged engine mounted behind the seats
Four-wheel drive
Body built by Heuliez
One of 200 road cars for Group B homologation",
			'summary' => '<p>The 205 Turbo 16 looked like Peugeot’s small hatchback but shared almost nothing with it underneath. A turbocharged engine sits behind the two seats and drives all four wheels, and 200 road cars were built so the rally version could compete in Group B.</p>',
			'sort_order' => 136,
			'images' => array(
				array( '3/3b/Peugeot_205_Turbo_16_1X7A6557.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '3/3f/Peugeot_205_Turbo_16.JPG', 'Louis.attene, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'ford-sierra-rs-cosworth', 'make' => 'Ford', 'model' => 'Sierra', 'variant' => 'RS Cosworth (three-door)', 'year' => 1986, 'body' => 'Hatchback',
			'tagline' => 'The turbocharged, whale-tailed Sierra built to win touring car races.',
			'engine' => '2.0L turbocharged 16-valve four-cylinder (Cosworth YB)', 'power' => '204 PS', 'transmission' => '5-speed manual (Borg-Warner T5)', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '7.4 L/100 km (constant 56 mph, Ford catalogue)', 'seats' => '5',
			'highlights' => "Cosworth YB turbocharged 16-valve engine
Large rear wing for high-speed stability
Borg-Warner five-speed gearbox
Homologation base for the RS500",
			'summary' => '<p>The Sierra RS Cosworth was built so Ford could race the Sierra in Group A touring cars. Its Cosworth-developed 2.0-litre turbo engine makes 204 PS, and its large rear wing became one of the defining shapes of the 1980s.</p>',
			'sort_order' => 137,
			'images' => array(
				array( '8/82/1986_Ford_Sierra_RS_Cosworth_2.0_%281%29.jpg', 'Vauxford, CC BY-SA 4.0' ),
				array( 'c/c1/1986_Ford_Sierra_RS_Cosworth_6.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( 'a/ae/1986_Ford_Sierra_RS_Cosworth_7.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( '9/9f/1986_Ford_Sierra_RS_Cosworth_-_2.0_%28204PS%29_petrol_manual_-_2025-05-05%2C_front_right.jpg', 'DieselFordMondeo, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'toyota-gr-corolla', 'make' => 'Toyota', 'model' => 'GR Corolla', 'variant' => 'GTS, 6-speed manual', 'year' => 2023, 'body' => 'Hatchback',
			'tagline' => 'A rally-bred hot hatch with a three-cylinder turbo and adjustable all-wheel drive.',
			'engine' => '1.6L turbocharged three-cylinder (G16E-GTS)', 'power' => '300 PS', 'transmission' => '6-speed manual', 'drivetrain' => 'GR-Four all-wheel drive', 'fuel' => 'Petrol', 'consumption' => '8.4 L/100 km (ADR combined)', 'seats' => '5',
			'highlights' => "1.6-litre three-cylinder turbo shared with the GR Yaris
GR-Four AWD with adjustable torque split
Six-speed manual with rev-matching
Widened body with flared arches",
			'summary' => '<p>The GR Corolla takes the GR Yaris engine and all-wheel-drive system and puts them in a longer, more practical five-door hatchback. Its 1.6-litre three-cylinder turbo makes 300 PS through a six-speed manual gearbox.</p>',
			'sort_order' => 138,
			'images' => array(
				array( '1/10/Toyota_GR_Corolla_%28E210%29_Washington_DC_Metro_Area%2C_USA.jpg', 'OWS Photography, CC BY 4.0' ),
				array( '2/28/Toyota_GR_Corolla_%28E210%29_Washington_DC_Metro_Area%2C_USA_%282%29.jpg', 'OWS Photography, CC BY 4.0' ),
				array( 'b/b2/2024_Toyota_GR_Corolla.jpg', 'Chanokchon, CC BY-SA 4.0' ),
				array( '6/66/2023-2025_Toyota_GR_Corolla_RZ_rear.jpg', 'TTTNIS, CC0' )
			),
		),
		array(
			'slug' => 'mercedes-benz-190e-evo-ii', 'make' => 'Mercedes-Benz', 'model' => '190 E', 'variant' => '2.5-16 Evolution II', 'year' => 1990, 'body' => 'Saloon',
			'tagline' => 'The winged homologation 190 that carried Mercedes-Benz to the DTM title.',
			'engine' => '2.5L 16-valve four-cylinder, short-stroke', 'power' => '235 PS', 'transmission' => '5-speed manual', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '13.3 L/100 km (EEC urban cycle)', 'seats' => '5',
			'highlights' => "High-revving 16-valve four-cylinder
Adjustable rear wing and wide body kit
Hydraulic self-levelling suspension
One of 502 built",
			'summary' => '<p>The Evolution II was built to homologate Mercedes-Benz’s DTM touring car. Its 2.5-litre four revs to over 7,000 rpm and makes 235 PS, and its large adjustable wing and wide arches made it one of the most striking saloons of its time.</p>',
			'sort_order' => 139,
			'images' => array(
				array( '0/0d/1991_Mercedes-Benz_190_E_2.5-16_Evolution_II_no._494%2C_front_left.jpg', 'Mr.choppers, CC BY-SA 3.0' ),
				array( '2/20/1990_Mercedes-Benz_190_E_2.5-16_Evolution_II_LC25_Low.jpg', 'MrWalkr, CC BY-SA 4.0' ),
				array( '5/51/1990_Mercedes-Benz_190_E_2.5-16_Evolution_II_LC25.jpg', 'MrWalkr, CC BY-SA 4.0' ),
				array( 'e/e6/1991_Mercedes-Benz_190_E_2.5-16_Evolution_II_no._494%2C_rear_left.jpg', 'Mr.choppers, CC BY-SA 3.0' )
			),
		),
		array(
			'slug' => 'audi-sport-quattro', 'make' => 'Audi', 'model' => 'Sport quattro', 'variant' => 'Short-wheelbase homologation road car', 'year' => 1984, 'body' => 'Coupé',
			'tagline' => 'The short, wide Group B homologation special with a 306 PS five-cylinder.',
			'engine' => '2.1L turbocharged five-cylinder, 20 valves', 'power' => '306 PS', 'transmission' => '5-speed manual', 'drivetrain' => 'quattro permanent four-wheel drive', 'fuel' => 'Petrol', 'consumption' => '11.0 L/100 km (DIN, maker average)', 'seats' => '4',
			'highlights' => "All-aluminium 20-valve turbocharged five-cylinder
Wheelbase 320 mm shorter than the Quattro
Body panels in Kevlar composite
Built to homologate the Group B rally car",
			'summary' => '<p>The Sport quattro was Audi’s Group B homologation car. Its wheelbase is 320 mm shorter than the original Quattro’s for agility on tight stages, and its 2.1-litre 20-valve five-cylinder makes 306 PS.</p>',
			'sort_order' => 140,
			'images' => array(
				array( '9/92/Audi_Sport_Quattro%2C_EMS_23%2C_Essen_%28P1170082%29.jpg', 'MB-one, CC BY-SA 4.0' ),
				array( 'e/e6/Audi_Sport_Quattro_Classic-Days_2022_IMG_7075.jpg', 'Alexander Migl, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'mercedes-amg-gt-63', 'make' => 'Mercedes-AMG', 'model' => 'GT', 'variant' => 'GT 63 4MATIC+ Coupé (C192)', 'year' => 2024, 'body' => 'Coupé',
			'tagline' => 'The second-generation AMG GT, now with all-wheel drive and room for two more.',
			'engine' => '4.0L twin-turbo V8 (M177), hand-built', 'power' => '585 PS', 'transmission' => '9-speed AMG Speedshift MCT', 'drivetrain' => '4MATIC+ fully variable AWD', 'fuel' => 'Petrol', 'consumption' => '14.0 L/100 km (WLTP combined)', 'seats' => '2+2',
			'highlights' => "Hand-built 4.0-litre twin-turbo V8
Fully variable 4MATIC+ all-wheel drive
Active rear-axle steering
2+2 seating and a large hatchback boot",
			'summary' => '<p>The second AMG GT Coupé grew into a more usable grand tourer, adding all-wheel drive, rear-axle steering and two small rear seats. Its hand-built 4.0-litre V8 makes 585 PS and 800 Nm.</p>',
			'sort_order' => 150,
			'images' => array(
				array( '5/57/Mercedes-AMG_C192_1X7A0832.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( 'f/f6/Mercedes-AMG_GT_63_Pro_%28C192%29_IAA_2025_DSC_2097.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '9/90/Mercedes-AMG_GT_63_%28C192%29_APXGP_Edition_DSC_0692.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '7/71/Mercedes-AMG_GT_63_Pro_%28C192%29_IAA_2025_DSC_2092.jpg', 'Alexander-93, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'mercedes-amg-sl-63', 'make' => 'Mercedes-AMG', 'model' => 'SL', 'variant' => 'SL 63 4MATIC+ (R232)', 'year' => 2022, 'body' => 'Roadster',
			'tagline' => 'The first SL developed entirely by AMG, with a fabric roof and all-wheel drive.',
			'engine' => '4.0L twin-turbo V8 (M177), hand-built', 'power' => '585 PS', 'transmission' => '9-speed AMG Speedshift MCT', 'drivetrain' => '4MATIC+ fully variable AWD', 'fuel' => 'Petrol', 'consumption' => '13.1 L/100 km (WLTP combined)', 'seats' => '2+2',
			'highlights' => "First SL developed fully by Mercedes-AMG
Power-operated fabric roof
First SL with all-wheel drive
Active rear-axle steering",
			'summary' => '<p>The R232 SL was developed by AMG in Affalterbach and returned the famous roadster to a fabric roof and 2+2 seating. The SL 63 pairs a 585 PS V8 with all-wheel drive for the first time in an SL.</p>',
			'sort_order' => 151,
			'images' => array(
				array( '6/60/Mercedes-AMG_SL_63_%28R232%29_Classic-Days_2022_DSC_0078.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '6/62/Mercedes-AMG_SL_63_%28R232%29_1X7A7444.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '7/74/Mercedes-AMG_SL_63_%28R232%29_IMG_7374.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '3/37/Mercedes-AMG_SL_63_%28R232%29_IMG_1279.jpg', 'Alexander-93, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'bmw-m8-competition', 'make' => 'BMW', 'model' => 'M8', 'variant' => 'Competition Coupé (F92)', 'year' => 2020, 'body' => 'Coupé',
			'tagline' => 'BMW’s flagship M coupé, with a 625 PS V8 and switchable all-wheel drive.',
			'engine' => '4.4L twin-turbo V8 (S63)', 'power' => '625 PS', 'transmission' => '8-speed M Steptronic automatic', 'drivetrain' => 'M xDrive AWD with 2WD mode', 'fuel' => 'Petrol', 'consumption' => '11.3–11.4 L/100 km (WLTP combined)', 'seats' => '4',
			'highlights' => "625 PS twin-turbo V8
M xDrive with selectable rear-drive mode
Carbon-fibre roof
Integrated braking system with selectable pedal feel",
			'summary' => '<p>The M8 Competition sits at the top of BMW’s M coupé range. Its 4.4-litre twin-turbo V8 makes 625 PS, and M xDrive can send all of it to the rear wheels when the driver chooses.</p>',
			'sort_order' => 152,
			'images' => array(
				array( 'e/ea/BMW_M8_Competition_Coup%C3%A9_%28G15%2C_2022%29_%2853798736676%29.jpg', 'Charles from Port Chester, New York, CC BY 2.0' ),
				array( '2/2a/BMW_M8_Competition_Coup%C3%A9_%28G15%2C_2020%29_%2854091730780%29.jpg', 'Charles from Port Chester, New York, CC BY 2.0' ),
				array( '5/59/BMW_M8_Competition_Coup%C3%A9_%28G15%2C_2020%29_%2854091279941%29.jpg', 'Charles from Port Chester, New York, CC BY 2.0' ),
				array( '6/6d/BMW_M8_Competition_Coup%C3%A9_%28G15%2C_2022%29_%2853799155715%29.jpg', 'Charles from Port Chester, New York, CC BY 2.0' )
			),
		),
		array(
			'slug' => 'bmw-xm', 'make' => 'BMW', 'model' => 'XM', 'variant' => '653 PS plug-in hybrid (G09)', 'year' => 2023, 'body' => 'SUV',
			'tagline' => 'BMW M’s first standalone model since the M1, a 653 PS plug-in hybrid SUV.',
			'engine' => '4.4L twin-turbo V8 plus electric motor (plug-in hybrid)', 'power' => '653 PS (system)', 'transmission' => '8-speed M Steptronic automatic', 'drivetrain' => 'M xDrive all-wheel drive', 'fuel' => 'Petrol plug-in hybrid', 'consumption' => '1.5–1.6 L/100 km (WLTP weighted, PHEV)', 'seats' => '5',
			'highlights' => "V8 and electric motor with 653 PS combined
Up to 88 km of electric range (WLTP)
First M-only model since the 1978 M1
Built in Spartanburg, USA",
			'summary' => '<p>The XM is the first car since the M1 to be designed purely as a BMW M model. It combines a 4.4-litre twin-turbo V8 with an electric motor for 653 PS and can travel more than 80 km on electricity alone.</p>',
			'sort_order' => 153,
			'images' => array(
				array( 'a/a3/BMW_XM_%28G09%29_IMG_7778.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '2/27/BMW_XM_1X7A6874.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '1/18/BMW_XM_%28G09%29_1X7A1708.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( 'f/f1/BMW_XM_%28G09%29_1X7A1504.jpg', 'Alexander Migl, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'audi-rs-e-tron-gt', 'make' => 'Audi', 'model' => 'RS e-tron GT', 'variant' => 'quattro, first version', 'year' => 2021, 'body' => 'Saloon',
			'tagline' => 'Audi’s first electric RS model, a four-door GT built alongside the R8.',
			'engine' => 'Two electric motors (front and rear), 800-volt system', 'power' => '598 PS (646 PS overboost)', 'transmission' => '1-speed front, 2-speed rear', 'drivetrain' => 'quattro electric all-wheel drive', 'fuel' => 'Electric', 'consumption' => '20.8 kWh/100 km (WLTP combined)', 'seats' => '4',
			'highlights' => "800-volt electrical architecture
Two-speed gearbox on the rear axle
Up to 270 kW DC charging
Shares its J1 platform with the Porsche Taycan",
			'summary' => '<p>The RS e-tron GT was Audi Sport’s first fully electric RS car. Two motors give 598 PS, or 646 PS on overboost, and an 800-volt system allows very fast charging.</p>',
			'sort_order' => 154,
			'images' => array(
				array( 'c/c2/Audi_RS_e-tron_GT_1X7A1874.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( 'b/ba/Audi_RS_e-tron_GT_IMG_0703.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '0/0b/Audi_RS_e-tron_GT_1X7A1875.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '5/53/Audi_RS_e-tron_GT_IAA_2021_1X7A0128.jpg', 'Alexander Migl, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'porsche-911-gt3-touring', 'make' => 'Porsche', 'model' => '911 GT3', 'variant' => 'with Touring Package (992), manual', 'year' => 2021, 'body' => 'Coupé',
			'tagline' => 'The full 911 GT3 engine and chassis, without the fixed rear wing.',
			'engine' => '4.0L naturally aspirated flat-six', 'power' => '510 PS', 'transmission' => '6-speed manual', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '12.9 L/100 km (WLTP combined)', 'seats' => '2',
			'highlights' => "4.0-litre flat-six revving to 9,000 rpm
Six-speed manual gearbox
Automatically extending rear spoiler
Double-wishbone front suspension",
			'summary' => '<p>The GT3 with Touring Package keeps the racing-derived 4.0-litre flat-six and chassis of the 992 GT3 but drops the large fixed rear wing. It suits drivers who want GT3 pace with a quieter look.</p>',
			'sort_order' => 155,
			'images' => array(
				array( '8/85/Porsche_992_GT3_with_touring_package_1X7A6511.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '1/11/Porsche_992_GT3_with_touring_package_1X7A1549.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( 'd/d5/Porsche_992_GT3_with_touring_package_1X7A6142.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '9/98/Porsche_992_GT3_with_touring_package_1X7A1548.jpg', 'Alexander-93, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'porsche-macan-turbo-electric', 'make' => 'Porsche', 'model' => 'Macan', 'variant' => 'Turbo Electric', 'year' => 2024, 'body' => 'SUV',
			'tagline' => 'The all-electric second Macan, with up to 639 PS and 1,130 Nm.',
			'engine' => 'Two permanent-magnet electric motors, 800-volt system', 'power' => '639 PS (overboost)', 'transmission' => 'Single-speed, front and rear', 'drivetrain' => 'Electric all-wheel drive', 'fuel' => 'Electric', 'consumption' => '18.8–20.7 kWh/100 km (WLTP combined)', 'seats' => '5',
			'highlights' => "Up to 639 PS with Launch Control
800-volt architecture with 270 kW DC charging
Up to 591 km WLTP range
Built on the PPE platform",
			'summary' => '<p>The second-generation Macan went fully electric in 2024. The Turbo version makes 584 PS, rising to 639 PS with Launch Control, and its 800-volt system supports fast charging.</p>',
			'sort_order' => 156,
			'images' => array(
				array( '4/4c/Porsche_Macan_Turbo_Electric_001.jpg', 'JustAnotherCarDesigner, CC0' ),
				array( '4/49/Porsche_Macan_Turbo_Electric_002.jpg', 'JustAnotherCarDesigner, CC0' ),
				array( 'c/cf/Porsche_XAB_Macan_Turbo_Electric_Provance_%282%29.jpg', 'Damian B Oh, CC BY-SA 4.0' ),
				array( 'a/a1/Porsche_XAB_Macan_Turbo_Electric_Provance_%2821%29.jpg', 'Damian B Oh, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'lamborghini-urus-se', 'make' => 'Lamborghini', 'model' => 'Urus', 'variant' => 'SE plug-in hybrid', 'year' => 2024, 'body' => 'SUV',
			'tagline' => 'The first plug-in hybrid Urus, with 800 CV from a V8 and an electric motor.',
			'engine' => '4.0L twin-turbo V8 plus electric motor (plug-in hybrid)', 'power' => '800 CV (system)', 'transmission' => '8-speed automatic', 'drivetrain' => 'All-wheel drive', 'fuel' => 'Petrol plug-in hybrid', 'consumption' => '2.1 L/100 km (WLTP weighted, PHEV)', 'seats' => '5',
			'highlights' => "800 CV combined from V8 and electric motor
25.9 kWh battery for about 60 km electric range
Electric motor housed in the gearbox
Restyled bonnet, lights and rear",
			'summary' => '<p>The Urus SE is the plug-in hybrid update of Lamborghini’s super SUV. A twin-turbo V8 and an electric motor give 800 CV, while a 25.9 kWh battery allows about 60 km of electric driving.</p>',
			'sort_order' => 157,
			'images' => array(
				array( 'f/f1/Lamborghini_Urus_SE_DSC_8524.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '9/95/Lamborghini_Urus_SE_001.jpg', 'JustAnotherCarDesigner, CC0' ),
				array( '4/4a/Lamborghini_Urus_SE_DSC_9099.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( 'a/aa/Lamborghini_Urus_SE_2025.jpg', 'Calreyn88, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'ferrari-488-pista', 'make' => 'Ferrari', 'model' => '488', 'variant' => 'Pista', 'year' => 2018, 'body' => 'Coupé',
			'tagline' => 'The track-focused 488, with a 720 cv V8 drawn from Ferrari’s racing cars.',
			'engine' => '3.9L twin-turbo V8, mid-mounted', 'power' => '720 cv', 'transmission' => '7-speed F1 dual-clutch', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '12.8 L/100 km (WLTP combined)', 'seats' => '2',
			'highlights' => "720 cv twin-turbo V8
About 90 kg lighter than the 488 GTB
S-Duct front aerodynamics
Ferrari Dynamic Enhancer",
			'summary' => '<p>The 488 Pista is the track-focused version of the 488, developed with lessons from Ferrari’s Challenge and GTE racing cars. Its 3.9-litre twin-turbo V8 makes 720 cv, and weight fell by about 90 kg.</p>',
			'sort_order' => 158,
			'images' => array(
				array( '8/80/Ferrari_488_Pista_Genf_2018.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '5/50/Ferrari_488_Pista_MYLE_Festival_2025_DSC_9445.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( 'c/cb/Ferrari_488_Pista_Blue.jpg', 'Calreyn88, CC BY 4.0' ),
				array( '0/09/Ferrari_488_Pista_ml25.jpg', 'Calreyn88, CC BY 4.0' )
			),
		),
		array(
			'slug' => 'mclaren-gt', 'make' => 'McLaren', 'model' => 'GT', 'variant' => 'Coupé', 'year' => 2020, 'body' => 'Coupé',
			'tagline' => 'McLaren’s grand tourer, with a carbon-fibre tub and room for luggage.',
			'engine' => '4.0L twin-turbo V8 (M840TE), mid-mounted', 'power' => '620 PS', 'transmission' => '7-speed SSG dual-clutch', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '11.9 L/100 km (WLTP combined)', 'seats' => '2',
			'highlights' => "Carbon-fibre MonoCell II-T chassis
Glazed rear luggage area
620 PS twin-turbo V8
Softer suspension tuned for touring",
			'summary' => '<p>The McLaren GT applied the brand’s carbon-fibre construction to a grand tourer. It adds a luggage area over the engine and a more comfortable ride while keeping a 620 PS V8 and 326 km/h top speed.</p>',
			'sort_order' => 159,
			'images' => array(
				array( '4/4c/McLaren_GT_IMG_2448.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '7/77/McLaren_GT%2C_Klassikstadt%2C_Frankfurt_am_Main_%28P1032520%29.jpg', 'Matti Blume, CC BY-SA 4.0' ),
				array( '8/84/McLaren_GT_-_04.jpg', 'Oleg Yunakov, CC BY-SA 4.0' ),
				array( 'a/a0/McLaren_GT_IMG_2451.jpg', 'Alexander-93, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'aston-martin-dbs-superleggera', 'make' => 'Aston Martin', 'model' => 'DBS', 'variant' => 'Superleggera', 'year' => 2018, 'body' => 'Coupé',
			'tagline' => 'Aston Martin’s V12 flagship GT, with 725 PS and 900 Nm.',
			'engine' => '5.2L twin-turbo V12, front-mid-mounted', 'power' => '725 PS', 'transmission' => '8-speed automatic (ZF)', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '13.5 L/100 km (WLTP combined)', 'seats' => '2+2',
			'highlights' => "5.2-litre twin-turbo V12
Carbon-fibre body panels
Rear-mounted transaxle gearbox
Curlicue and Aeroblade aerodynamics",
			'summary' => '<p>The DBS Superleggera replaced the Vanquish as Aston Martin’s flagship GT. Its 5.2-litre twin-turbo V12 makes 725 PS and 900 Nm, delivered through a rear-mounted eight-speed gearbox.</p>',
			'sort_order' => 160,
			'images' => array(
				array( '8/85/Aston_Martin_DBS_Superleggera_1X7A0207.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '3/3e/Aston_Martin_DBS_Superleggera_Filderstadt_1Y7A4897.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '4/49/Aston_Martin_DBS_Superleggera_1X7A0362.jpg', 'Alexander Migl, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'bentley-continental-gt-speed', 'make' => 'Bentley', 'model' => 'Continental GT', 'variant' => 'Speed W12 (third generation)', 'year' => 2024, 'body' => 'Coupé',
			'tagline' => 'The fastest W12 Continental GT, built just before the engine’s retirement.',
			'engine' => '6.0L twin-turbo W12', 'power' => '659 PS', 'transmission' => '8-speed dual-clutch', 'drivetrain' => 'All-wheel drive', 'fuel' => 'Petrol', 'consumption' => '13.7 L/100 km (WLTP combined)', 'seats' => '4',
			'highlights' => "659 PS twin-turbo W12
All-wheel steering and electronic rear differential
48-volt active anti-roll system
Optional carbon-ceramic brakes",
			'summary' => '<p>The Continental GT Speed was the most dynamic version of the third-generation W12 car. It added all-wheel steering and an electronic limited-slip differential, with 659 PS and a 335 km/h top speed.</p>',
			'sort_order' => 161,
			'images' => array(
				array( 'e/e5/Bentley_Continental_GT_Speed_%283rd_gen.%29_IMG_0014.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( 'b/b8/Bentley_Continental_GT_Speed_%283rd_gen.%29_IMG_0015.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '7/7e/Bentley_Continental_GT_Speed_%283rd_gen.%29_Auto_Zuerich_2021_IMG_0172.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '1/11/2021_Bentley_Continental_GT_Speed_Auto.jpg', 'Calreyn88, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'rolls-royce-cullinan-black-badge', 'make' => 'Rolls-Royce', 'model' => 'Cullinan', 'variant' => 'Black Badge, Series II', 'year' => 2024, 'body' => 'SUV',
			'tagline' => 'The darker, more powerful Cullinan, with 600 PS from its V12.',
			'engine' => '6.75L twin-turbo V12', 'power' => '600 PS', 'transmission' => '8-speed automatic', 'drivetrain' => 'All-wheel drive, all-wheel steering', 'fuel' => 'Petrol', 'consumption' => '16.8 L/100 km (WLTP combined)', 'seats' => '5',
			'highlights' => "600 PS and 900 Nm from the 6.75-litre V12
Darkened Pantheon grille and chrome
All-wheel drive and all-wheel steering
Air suspension with camera-based road scanning",
			'summary' => '<p>Black Badge is Rolls-Royce’s darker, more driver-focused series. On the Cullinan Series II it raises the V12 to 600 PS and 900 Nm, with darkened brightwork and bolder interior finishes.</p>',
			'sort_order' => 162,
			'images' => array(
				array( '1/1b/2022_Rolls-Royce_Cullinan_Black_Badge_BS_O24.jpg', 'MrWalkr, CC BY-SA 4.0' ),
				array( '4/4c/Rolls-Royce_Cullinan_Black_Badge_Greater_Toronto_Area%2C_Canada.jpg', 'OWS Photography, CC BY 4.0' ),
				array( 'b/bb/2021_Rolls-Royce_Cullinan_Black_Badge_-_01.jpg', 'Oleg Yunakov, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'lotus-emira', 'make' => 'Lotus', 'model' => 'Emira', 'variant' => 'V6, 6-speed manual', 'year' => 2022, 'body' => 'Coupé',
			'tagline' => 'The last petrol Lotus, with a supercharged V6 and a manual gearbox.',
			'engine' => '3.5L supercharged V6 (Toyota-sourced), mid-mounted', 'power' => '405 PS', 'transmission' => '6-speed manual', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '11.3 L/100 km (WLTP combined)', 'seats' => '2',
			'highlights' => "Supercharged 3.5-litre V6
Six-speed manual with exposed gear linkage
Bonded aluminium chassis
Hydraulic power steering",
			'summary' => '<p>The Emira is Lotus’s last petrol sports car. Its mid-mounted supercharged V6 makes 405 PS, driven through a six-speed manual, and it keeps hydraulic steering for natural feel.</p>',
			'sort_order' => 163,
			'images' => array(
				array( '0/01/Lotus_Emira_IMG_8023.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '7/74/Lotus_Emira%2C_IAA_2025%2C_Munich_%2820250909-P1050690%29.jpg', 'Matti Blume, CC BY-SA 4.0' ),
				array( '7/71/2024_Lotus_Emira_6.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( '6/6d/Lotus_Emira%2C_Auto_2025%2C_Zurich_%2820251029-P1074561%29.jpg', 'Matti Blume, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'maserati-mc20', 'make' => 'Maserati', 'model' => 'MC20', 'variant' => 'Coupé', 'year' => 2021, 'body' => 'Coupé',
			'tagline' => 'Maserati’s mid-engined supercar, powered by its own Nettuno V6.',
			'engine' => '3.0L twin-turbo V6 (Nettuno), mid-mounted', 'power' => '630 CV', 'transmission' => '8-speed dual-clutch', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '11.6 L/100 km (WLTP combined)', 'seats' => '2',
			'highlights' => "Nettuno V6 with pre-chamber combustion
Carbon-fibre monocoque
Butterfly doors
Built in Modena",
			'summary' => '<p>The MC20 marked Maserati’s return to mid-engined supercars. It uses a carbon-fibre monocoque and the Nettuno V6, a 3.0-litre twin-turbo engine designed and built by Maserati.</p>',
			'sort_order' => 164,
			'images' => array(
				array( 'b/bb/Maserati_MC20_IAA_2021_1X7A0087.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '2/25/Maserati_MC20_%2853060861852-crop%29.jpg', 'Alexandre Prevot from Nancy, France, CC BY-SA 2.0' ),
				array( 'f/fb/Maserati_MC20_02.jpg', 'GZrex, CC BY-SA 4.0' ),
				array( '5/57/Maserati_MC20_002.jpg', 'Jengtingchen, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'volkswagen-golf-gti', 'make' => 'Volkswagen', 'model' => 'Golf GTI', 'variant' => 'Mk8, 7-speed DSG', 'year' => 2020, 'body' => 'Hatchback',
			'tagline' => 'The eighth-generation GTI, still front-driven and still the benchmark hot hatch.',
			'engine' => '2.0L turbocharged four-cylinder (EA888)', 'power' => '245 PS', 'transmission' => '7-speed DSG dual-clutch', 'drivetrain' => 'Front-wheel drive', 'fuel' => 'Petrol', 'consumption' => '7.4 L/100 km (WLTP combined)', 'seats' => '5',
			'highlights' => "245 PS turbocharged 2.0-litre
Electronically controlled front differential lock
Digital cockpit as standard
Tartan seat trim and red grille stripe",
			'summary' => '<p>The Mk8 Golf GTI keeps the formula that began in 1976: a practical hatchback with a punchy engine and sharper chassis. Its 2.0-litre turbo makes 245 PS and 370 Nm, sent to the front wheels through a locking differential.</p>',
			'sort_order' => 170,
			'images' => array(
				array( '6/66/Volkswagen_Golf_GTI_Mk8_Dolphin_Gray_Metallic_%283%29.jpg', 'Damian B Oh, CC BY-SA 4.0' ),
				array( '2/2a/VOLKSWAGEN_GOLF_GTI_%28Mk8_CD1%29_China.jpg', 'Dinkun Chen, CC BY-SA 4.0' ),
				array( '3/34/Volkswagen_Golf_GTI_Mk8_Dolphin_Gray_Metallic_%2810%29.jpg', 'Damian B Oh, CC BY-SA 4.0' ),
				array( 'b/be/Volkswagen_Golf_GTI_Mk8_Dolphin_Gray_Metallic_%288%29.jpg', 'Damian B Oh, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'mazda-mx-5', 'make' => 'Mazda', 'model' => 'MX-5', 'variant' => 'ND 2.0 Skyactiv-G', 'year' => 2019, 'body' => 'Roadster',
			'tagline' => 'The world’s best-selling two-seat roadster, light, simple and rear-driven.',
			'engine' => '2.0L naturally aspirated four-cylinder (Skyactiv-G)', 'power' => '184 PS', 'transmission' => '6-speed manual', 'drivetrain' => 'Rear-wheel drive', 'fuel' => 'Petrol', 'consumption' => '6.9 L/100 km (WLTP combined)', 'seats' => '2',
			'highlights' => "Kerb weight of about one tonne
184 PS 2.0-litre revving to 7,500 rpm
Short-throw six-speed manual
Manual fabric roof",
			'summary' => '<p>The fourth-generation MX-5 is the lightest of the modern line, and the 2019 update lifted the 2.0-litre engine to 184 PS with a higher rev limit. It remains a pure front-engined, rear-drive roadster with a manual gearbox.</p>',
			'sort_order' => 171,
			'images' => array(
				array( '2/23/2015_Mazda_MX-5_%28ND%29_Roadster_GT_convertible_%282018-10-30%29_01.jpg', 'EurovisionNim, CC BY-SA 4.0' ),
				array( 'b/b7/Mazda_MX-5_%28ND%29_1X7A7471.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '2/25/2015_Mazda_MX-5_ND_2.0_SKYACTIV-G_160_i-ELOOP_Rubinrot-Metallic_Vorderansicht.jpg', 'Kickaffe (Mario von Berg), CC BY-SA 4.0' ),
				array( '8/83/Mazda_MX-5_%28ND%29_1X7A2479.jpg', 'Alexander-93, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'hyundai-i20-n', 'make' => 'Hyundai', 'model' => 'i20 N', 'variant' => '1.6 T-GDi, 6-speed manual', 'year' => 2021, 'body' => 'Hatchback',
			'tagline' => 'Hyundai’s rally-inspired supermini hot hatch, with a manual gearbox only.',
			'engine' => '1.6L turbocharged four-cylinder (Smartstream T-GDi)', 'power' => '204 PS', 'transmission' => '6-speed manual', 'drivetrain' => 'Front-wheel drive', 'fuel' => 'Petrol', 'consumption' => '7.0 L/100 km (WLTP combined)', 'seats' => '5',
			'highlights' => "204 PS turbocharged 1.6-litre
N Corner Carving mechanical limited-slip differential
Rev matching and launch control
WRC-inspired roof spoiler",
			'summary' => '<p>The i20 N was Hyundai’s supermini hot hatch, styled and tuned with input from its World Rally Championship programme. A 1.6-litre turbo makes 204 PS, and it was sold only with a six-speed manual.</p>',
			'sort_order' => 172,
			'images' => array(
				array( '2/2f/Hyundai_i20_N_IMG_5400.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( 'd/db/Hyundai_i20_N_IMG_8773.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '3/33/2023_Hyundai_i20_N_T-GDi.jpg', 'Calreyn88, CC BY-SA 4.0' ),
				array( '9/92/Hyundai_i20_N_IMG_0028.jpg', 'Alexander Migl, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'honda-civic-type-r-fk8', 'make' => 'Honda', 'model' => 'Civic Type R', 'variant' => 'FK8, 6-speed manual', 'year' => 2017, 'body' => 'Hatchback',
			'tagline' => 'The winged FK8 Type R, once the fastest front-wheel-drive car around the Nürburgring.',
			'engine' => '2.0L VTEC Turbo four-cylinder (K20C1)', 'power' => '320 PS', 'transmission' => '6-speed manual', 'drivetrain' => 'Front-wheel drive', 'fuel' => 'Petrol', 'consumption' => '8.5 L/100 km (WLTP combined)', 'seats' => '4',
			'highlights' => "320 PS VTEC Turbo engine
Dual-axis strut front suspension
Three centre-exit exhaust pipes
Rev-matching six-speed manual",
			'summary' => '<p>The FK8 Civic Type R brought a new platform, multi-link rear suspension and 320 PS to Honda’s hot hatch. Its dual-axis front struts tame torque steer, and its bold aero package became the car’s signature.</p>',
			'sort_order' => 173,
			'images' => array(
				array( 'b/bf/Honda_CIVIC_TYPE_R_%28FK8%29.jpg', 'Tokumeigakarinoaoshima, CC BY-SA 4.0' ),
				array( '8/8c/Honda_Civic_Type_R_FK8_Rallye_Red_01.jpg', 'Ethan Llamas, CC BY-SA 4.0' ),
				array( '2/27/2018_Honda_Civic_Type_R_FK8_in_Championship_White%2C_rear_right%2C_08-04-2024.jpg', 'Ethan Llamas, CC BY-SA 4.0' ),
				array( '6/6e/Honda_Civic_Type_R_%28FK8%29_Washington_DC_Metro_Area%2C_USA.jpg', 'OWS Photography, CC BY 4.0' )
			),
		),
		array(
			'slug' => 'subaru-wrx-sti-gdb', 'make' => 'Subaru', 'model' => 'Impreza WRX STI', 'variant' => 'GDB ‘hawkeye’, 2.5 (European)', 'year' => 2006, 'body' => 'Saloon',
			'tagline' => 'The final, hawk-eyed version of the rally-bred GD Impreza STI.',
			'engine' => '2.5L turbocharged flat-four (EJ257)', 'power' => '280 PS', 'transmission' => '6-speed manual', 'drivetrain' => 'AWD with driver-controlled centre diff', 'fuel' => 'Petrol', 'consumption' => '10.9 L/100 km (NEDC combined)', 'seats' => '5',
			'highlights' => "Turbocharged boxer engine
Driver-controlled centre differential (DCCD)
Bonnet scoop feeding the intercooler
Gold alloy wheels and large rear wing",
			'summary' => '<p>The ‘hawkeye’ was the last facelift of the second-generation Impreza STI, named for its sharper headlamps. European cars used a 2.5-litre turbocharged boxer with 280 PS, driving all four wheels through Subaru’s DCCD system.</p>',
			'sort_order' => 174,
			'images' => array(
				array( 'f/fe/Subaru_IMPREZA_WRX_STI_%28GH-GDB%29_front.JPG', 'Tokumeigakarinoaoshima, CC0' ),
				array( '5/54/The_frontview_of_Subaru_IMPREZA_WRX_STi_%28GH-GDB%29.jpg', 'Tokumeigakarinoaoshima, CC0' ),
				array( '8/85/The_rearview_of_Subaru_IMPREZA_WRX_STi_%28GH-GDB%29.jpg', 'Tokumeigakarinoaoshima, CC0' )
			),
		),
		array(
			'slug' => 'mitsubishi-lancer-evolution-ix', 'make' => 'Mitsubishi', 'model' => 'Lancer Evolution', 'variant' => 'IX, 2.0 MIVEC (European)', 'year' => 2005, 'body' => 'Saloon',
			'tagline' => 'The last Evo built on the Lancer’s rally platform, with variable valve timing at last.',
			'engine' => '2.0L turbocharged four-cylinder (4G63) with MIVEC', 'power' => '280 PS', 'transmission' => '6-speed manual', 'drivetrain' => 'Full-time AWD with Active Centre Diff', 'fuel' => 'Petrol', 'consumption' => '10.6 L/100 km (NEDC combined)', 'seats' => '5',
			'highlights' => "4G63 engine with MIVEC variable valve timing
Active Centre Differential and Active Yaw Control
Aluminium roof and front wings
Recaro front seats",
			'summary' => '<p>The Evolution IX was the final Evo based on the CT-series Lancer and the last to use the famous 4G63 engine. MIVEC variable valve timing arrived for the first time, sharpening response across the rev range.</p>',
			'sort_order' => 175,
			'images' => array(
				array( 'b/bc/2005_Mitsubishi_Lancer_Evolution_IX_BS_O24.jpg', 'MrWalkr, CC BY-SA 4.0' ),
				array( '8/89/2005_Mitsubishi_Lancer_Evolution_IX_FQ-340.jpg', 'Calreyn88, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'mercedes-amg-a45-s', 'make' => 'Mercedes-AMG', 'model' => 'A 45 S', 'variant' => '4MATIC+ (W177)', 'year' => 2019, 'body' => 'Hatchback',
			'tagline' => 'A 421 PS hot hatch powered by the most powerful series-production four-cylinder of its day.',
			'engine' => '2.0L turbocharged four-cylinder (M139), hand-built', 'power' => '421 PS', 'transmission' => '8-speed AMG Speedshift DCT', 'drivetrain' => '4MATIC+ AWD with Drift Mode', 'fuel' => 'Petrol', 'consumption' => '8.3–8.4 L/100 km (WLTP combined)', 'seats' => '5',
			'highlights' => "421 PS from a hand-built 2.0-litre
AMG Torque Control rear axle with Drift Mode
Eight-speed dual-clutch gearbox
Twin-scroll turbocharger with roller bearings",
			'summary' => '<p>The A 45 S packs 421 PS into a compact hatchback. Its M139 engine is built by hand in Affalterbach, and the AMG Torque Control rear axle can send drive to either rear wheel, enabling a Drift Mode.</p>',
			'sort_order' => 176,
			'images' => array(
				array( '7/71/Mercedes-AMG_A_45_S_4MATIC%2B_%28W177%29_1X7A0310.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '3/36/Mercedes-AMG_A_45_S_4MATIC%2B_%28W177%29_1X7A0312.jpg', 'Alexander Migl, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'bmw-m2', 'make' => 'BMW', 'model' => 'M2', 'variant' => 'Coupé (G87), 6-speed manual', 'year' => 2023, 'body' => 'Coupé',
			'tagline' => 'BMW M’s compact rear-drive coupé, with M3 power and a manual option.',
			'engine' => '3.0L twin-turbo straight-six (S58)', 'power' => '460 PS', 'transmission' => '6-speed manual', 'drivetrain' => 'Rear-wheel drive, Active M Differential', 'fuel' => 'Petrol', 'consumption' => '10.0–10.2 L/100 km (WLTP combined)', 'seats' => '4',
			'highlights' => "460 PS S58 straight-six from the M3 and M4
Six-speed manual or eight-speed automatic
Active M Differential
Rear-wheel drive only",
			'summary' => '<p>The second M2 uses the same S58 twin-turbo straight-six as the M3 and M4, here with 460 PS. It stays rear-driven and keeps a six-speed manual, making it the most traditional M car of its generation.</p>',
			'sort_order' => 177,
			'images' => array(
				array( '2/2c/BMW_M2_%28G87%29_DSC_7397.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( 'a/af/BMW_M2_%28G87%29_DSC_7395.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( '7/73/BMW_M2_%28G87%29_IMG_8806.jpg', 'Alexander Migl, CC BY-SA 4.0' ),
				array( 'e/ed/BMW_G87_M2_1X7A6997.jpg', 'Alexander-93, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'audi-rs3', 'make' => 'Audi', 'model' => 'RS 3', 'variant' => 'Sportback (8Y)', 'year' => 2021, 'body' => 'Hatchback',
			'tagline' => 'Audi’s five-cylinder compact, now able to split torque between the rear wheels.',
			'engine' => '2.5L turbocharged five-cylinder (TFSI)', 'power' => '400 PS', 'transmission' => '7-speed S tronic dual-clutch', 'drivetrain' => 'quattro AWD with RS Torque Splitter', 'fuel' => 'Petrol', 'consumption' => '9.0–9.5 L/100 km (WLTP combined)', 'seats' => '5',
			'highlights' => "400 PS turbocharged five-cylinder
RS Torque Splitter on the rear axle
RS Torque Rear drift mode
Optional 290 km/h top speed",
			'summary' => '<p>The third-generation RS 3 keeps Audi’s 2.5-litre five-cylinder, with 400 PS and 500 Nm. It introduced the RS Torque Splitter, which can send all the rear-axle torque to one wheel.</p>',
			'sort_order' => 178,
			'images' => array(
				array( '3/34/Audi_RS_3_Sportback_%288Y%29_%E2%80%93_f_01062025.jpg', 'M 93, CC BY-SA 3.0 DE' ),
				array( 'f/fe/Audi_RS_3_Limousine_%288Y%29_%E2%80%93_f_11102025.jpg', 'M 93, CC BY-SA 3.0 DE' ),
				array( 'c/c9/Audi_RS_3_Limousine_%288Y%29_%E2%80%93_f_18052025.jpg', 'M 93, CC BY-SA 3.0 DE' ),
				array( '6/6c/Audi_RS_3_Sportback_%288Y%29_%E2%80%93_h_25042024.jpg', 'M 93, CC BY-SA 3.0 DE' )
			),
		),
		array(
			'slug' => 'ford-focus-rs', 'make' => 'Ford', 'model' => 'Focus RS', 'variant' => 'Mk3', 'year' => 2016, 'body' => 'Hatchback',
			'tagline' => 'The first all-wheel-drive Focus RS, famous for its Drift Mode.',
			'engine' => '2.3L turbocharged four-cylinder (EcoBoost)', 'power' => '350 PS', 'transmission' => '6-speed manual', 'drivetrain' => 'AWD with twin-clutch rear drive unit', 'fuel' => 'Petrol', 'consumption' => '7.7 L/100 km (NEDC combined)', 'seats' => '5',
			'highlights' => "350 PS 2.3-litre EcoBoost
All-wheel drive with torque vectoring
Drift Mode
Six-speed manual only",
			'summary' => '<p>The third Focus RS was the first to drive all four wheels. Its rear drive unit uses twin clutches to overdrive the outside rear wheel, and a Drift Mode made it a favourite with enthusiasts.</p>',
			'sort_order' => 179,
			'images' => array(
				array( '3/31/Ford_Focus_RS_Mk_III%2C_2016.jpg', 'Cjp24, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'hyundai-ioniq-5-n', 'make' => 'Hyundai', 'model' => 'Ioniq 5 N', 'variant' => '84 kWh AWD', 'year' => 2024, 'body' => 'Hatchback',
			'tagline' => 'Hyundai N’s first electric car, with up to 650 PS and simulated gearshifts.',
			'engine' => 'Two electric motors (front and rear), 800-volt system', 'power' => '650 PS (N Grin Boost)', 'transmission' => 'Single-speed reduction gear', 'drivetrain' => 'Electric all-wheel drive', 'fuel' => 'Electric', 'consumption' => '21.2 kWh/100 km (WLTP combined)', 'seats' => '5',
			'highlights' => "Up to 650 PS with N Grin Boost
N e-Shift simulated eight-speed gearbox
N Active Sound+ engine sound
84 kWh battery and 800-volt charging",
			'summary' => '<p>The Ioniq 5 N is Hyundai N’s first electric performance car. Two motors give up to 650 PS, and N e-Shift mimics the gearshifts of a dual-clutch gearbox to keep the driver engaged.</p>',
			'sort_order' => 180,
			'images' => array(
				array( '8/85/Hyundai_Ioniq_5_N_IMG_0053.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '2/26/Hyundai_Ioniq_5_N_IMG_9406.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( '3/3c/Hyundai_Ioniq_5_N_IMG_9544.jpg', 'Alexander-93, CC BY-SA 4.0' ),
				array( 'a/a8/Hyundai_Ioniq_5_N_IMG_9390.jpg', 'Alexander-93, CC BY-SA 4.0' )
			),
		),
		array(
			'slug' => 'mercedes-amg-c63-s-w205', 'make' => 'Mercedes-AMG', 'model' => 'C 63 S', 'variant' => 'Saloon (W205), pre-facelift', 'year' => 2015, 'body' => 'Saloon',
			'tagline' => 'The first turbocharged C 63, with a 4.0-litre V8 and 700 Nm.',
			'engine' => '4.0L twin-turbo V8 (M177), hand-built', 'power' => '510 PS', 'transmission' => '7-speed AMG Speedshift MCT', 'drivetrain' => 'Rear-wheel drive, electronic diff lock', 'fuel' => 'Petrol', 'consumption' => '8.2–8.4 L/100 km (NEDC combined)', 'seats' => '5',
			'highlights' => "4.0-litre twin-turbo V8 with turbos inside the vee
Electronically controlled rear differential lock
Dynamic engine mounts
Wider front wings than the standard C-Class",
			'summary' => '<p>The W205 C 63 S replaced the old naturally aspirated 6.2-litre V8 with a 4.0-litre twin-turbo unit. It makes 510 PS and 700 Nm, sent to the rear wheels through an electronically locking differential.</p>',
			'sort_order' => 181,
			'images' => array(
				array( '6/69/Mercedes-Benz_C-Class_W205_63_AMG_S_02_China_2016-04-14.jpg', 'Navigator84, CC BY-SA 4.0' ),
				array( '1/1f/Mercedes-Benz_C-Class_W205_63_AMG_S_01_China_2016-04-14.jpg', 'Navigator84, CC BY-SA 4.0' ),
				array( 'c/cf/Mercedes-Benz_C-Class_W205_63_AMG_S_03_China_2016-04-14.jpg', 'Navigator84, CC BY-SA 4.0' ),
				array( '1/1c/Mercedes-AMG_C63_S_Sedan_%28W205%29_Washington_DC_Metro_Area%2C_USA.jpg', 'OWS Photography, CC BY 4.0' )
			),
		),
		array(
			'slug' => 'toyota-land-cruiser-prado-150', 'make' => 'Toyota', 'model' => 'Land Cruiser Prado', 'variant' => '150 Series, 2.8 D-4D automatic', 'year' => 2017, 'body' => 'SUV',
			'tagline' => 'The mid-size Land Cruiser, here with Toyota’s 2.8-litre diesel.',
			'engine' => '2.8L turbo-diesel four-cylinder (1GD-FTV)', 'power' => '177 PS', 'transmission' => '6-speed automatic', 'drivetrain' => 'Full-time 4WD, Torsen centre diff', 'fuel' => 'Diesel', 'consumption' => '7.4 L/100 km (NEDC combined)', 'seats' => '7',
			'highlights' => "2.8-litre 1GD-FTV turbo-diesel
Full-time four-wheel drive with low range
Lockable Torsen centre differential
Seven seats in five-door form",
			'summary' => '<p>The 150 Series is the long-running mid-size Land Cruiser, built on a ladder frame with full-time four-wheel drive and low range. The 2.8-litre diesel, introduced in 2015, gives 177 PS and 450 Nm.</p>',
			'sort_order' => 182,
			'images' => array(
				array( '0/00/Toyota_Land_Cruiser_Prado_150.jpg', 'TTTNIS, CC0' ),
				array( '9/9e/2022_Toyota_Land_Cruiser_Prado_150_4.0_VX_V6_in_Gray_Metallic%2C_06-12-2024.jpg', 'Ethan Llamas, CC BY-SA 4.0' ),
				array( '8/8d/2009-2011_Toyota_Land_Cruiser_Prado_%28KDJ150R%29_VX_5-door_wagon_%282011-10-25%29_01.jpg', 'OSX, Public domain' ),
				array( '5/57/TLC_Prado_150.jpg', 'Yuri AMbox, CC BY-SA 3.0' )
			),
		),
		array(
			'slug' => 'toyota-land-cruiser-200', 'make' => 'Toyota', 'model' => 'Land Cruiser', 'variant' => '200 Series, V8 4.5 D-4D', 'year' => 2013, 'body' => 'SUV',
			'tagline' => 'Toyota’s flagship Land Cruiser, with a twin-turbo V8 diesel.',
			'engine' => '4.5L twin-turbo V8 diesel (1VD-FTV)', 'power' => '272 PS', 'transmission' => '6-speed automatic', 'drivetrain' => 'Full-time 4WD, Torsen centre diff', 'fuel' => 'Diesel', 'consumption' => '9.5 L/100 km (NEDC combined)', 'seats' => '7',
			'highlights' => "4.5-litre twin-turbo V8 diesel
Full-time four-wheel drive with low range
Kinetic Dynamic Suspension System
Crawl Control and Multi-terrain Select",
			'summary' => '<p>The 200 Series was the flagship Land Cruiser for 14 years. Its 4.5-litre twin-turbo V8 diesel makes 272 PS and 650 Nm, and full-time four-wheel drive with low range is standard.</p>',
			'sort_order' => 183,
			'images' => array(
				array( 'e/e5/2014_Toyota_Land_Cruiser_200_VX_V8_in_Black%2C_front_right.jpg', 'Ethan Llamas, CC BY-SA 4.0' ),
				array( '7/77/2014_Toyota_Land_Cruiser_200_4.5_VX_Limited_V8_in_Blizzard_Pearl%2C_front_right.jpg', 'Ethan Llamas, CC BY-SA 4.0' ),
				array( '9/9d/Toyota_Land_Cruiser_200_4.5_VX_V8_Black_-_front.jpg', 'Ethan Llamas, CC BY-SA 4.0' ),
				array( 'a/a8/2008_Toyota_Land_Cruiser_200_V8_%283769883566%29.jpg', 'Spanish Coches, CC BY 2.0' )
			),
		),
		array(
			'slug' => 'subaru-forester-xt', 'make' => 'Subaru', 'model' => 'Forester', 'variant' => 'XT (SJ), 2.0 turbo Lineartronic', 'year' => 2013, 'body' => 'SUV',
			'tagline' => 'The turbocharged fourth-generation Forester, quicker than many hot hatches.',
			'engine' => '2.0L turbocharged flat-four (FA20 DIT)', 'power' => '240 PS', 'transmission' => 'Lineartronic CVT', 'drivetrain' => 'Symmetrical AWD', 'fuel' => 'Petrol', 'consumption' => '8.5 L/100 km (NEDC combined)', 'seats' => '5',
			'highlights' => "240 PS direct-injection turbo boxer
Symmetrical all-wheel drive
X-Mode for low-grip surfaces
SI-Drive with eight-step manual mode",
			'summary' => '<p>The Forester XT paired a practical SUV body with the 240 PS turbocharged FA20 boxer. Symmetrical all-wheel drive and X-Mode give genuine ability on rough tracks.</p>',
			'sort_order' => 184,
			'images' => array(
				array( '1/13/2015-2018_Subaru_Forester_XT.jpg', 'TTTNIS, CC0' ),
				array( '0/02/Subaru_Forester_XT_%28SJ%29_front.JPG', 'Tokumeigakarinoaoshima, CC0' ),
				array( 'a/a8/Subaru_Forester_2.0_XT_AWD_2016.jpg', 'Captainmorlypogi1959, CC BY-SA 4.0' ),
				array( 'e/e3/Subaru_Forester_XT_SJ_Shishi_01_2022-05-20.jpg', 'JamesYoung8167, CC BY-SA 4.0' )
			),
		),
	),
	'commons' => $c,
);
