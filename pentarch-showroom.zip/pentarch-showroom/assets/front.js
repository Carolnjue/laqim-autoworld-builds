/*! Pentarch Showroom — front end */
(function () {
	'use strict';
	var d = document, w = window;
	var RM = w.matchMedia && w.matchMedia('(prefers-reduced-motion: reduce)').matches;
	function $(s, r) { return (r || d).querySelector(s); }
	function $$(s, r) { return [].slice.call((r || d).querySelectorAll(s)); }
	function on(el, ev, fn, o) { if (el) el.addEventListener(ev, fn, o || false); }
	function editing() { return d.documentElement.classList.contains('ple-on') || d.body.classList.contains('ple-on'); }

	/* ------------------------------------------------------------ reveal */
	function reveal() {
		var els = $$('.psr-reveal:not(.is-in),.lx-reveal:not(.is-in)');
		els.forEach(function (el) {
			if (el.style.getPropertyValue('--d')) return;
			var p = el.parentElement, i = 0;
			if (p) { var sib = [].filter.call(p.children, function (c) { return c.classList.contains('psr-reveal') || c.classList.contains('lx-reveal'); }); i = sib.indexOf(el); }
			el.style.setProperty('--d', Math.min(i, 6) * 0.08 + 's');
		});
		if (!('IntersectionObserver' in w) || RM) { els.forEach(function (e) { e.classList.add('is-in'); }); return; }
		var io = new IntersectionObserver(function (es) {
			es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('is-in'); io.unobserve(e.target); } });
		}, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
		els.forEach(function (e) { io.observe(e); });
	}

	/* ------------------------------------------------------------ counters */
	function counters() {
		$$('[data-lx-count]').forEach(function (el) {
			var end = parseInt(el.getAttribute('data-lx-count') || el.textContent, 10);
			if (!end || RM || !('IntersectionObserver' in w)) return;
			var io = new IntersectionObserver(function (es) {
				if (!es[0].isIntersecting) return; io.disconnect();
				var t0 = performance.now();
				(function f(t) { var k = Math.min(1, (t - t0) / 1600); el.textContent = Math.round(end * (1 - Math.pow(1 - k, 3))); if (k < 1) requestAnimationFrame(f); })(t0);
			});
			io.observe(el);
		});
	}

	/* ------------------------------------------------------------ header */
	function header() {
		var h = $('[data-lx-header]');
		if (!h) return;
		var last = w.scrollY, hidden = false;
		var main = d.getElementById('main'), first = main && main.querySelector('.psr-hero, .v-hero, .lx-pagehead, section, div');
		var dark = first && (first.matches('.psr-hero:not(.psr-hero--boxed), .v-hero') || (first.matches('.lx-pagehead') && !first.matches('.lx-pagehead--short')) || !!first.querySelector('.psr-hero:not(.psr-hero--boxed)'));
		h.classList.add('lx-solid');
		var lastVar = ''; function setVar() { var v2 = hidden ? '0px' : Math.max(0, Math.round((h.querySelector('.lx-bar') || h).getBoundingClientRect().bottom)) + 'px'; if (v2 !== lastVar) { lastVar = v2; d.documentElement.style.setProperty('--lx-head', v2); } }
		on(h, 'transitionend', function () { setVar(); });
		function onScroll() {
			var y = w.scrollY;
			h.classList.toggle('is-scrolled', y > 30);
			var open = h.classList.contains('is-open') || h.querySelector('.lx-nav__item.is-open');
			var hide = y > 400 && y > last + 4 && !open && !d.body.classList.contains('psr-canvas');
			var show = y < last - 4 || y < 200;
			if (!hidden) setVar();
			/* the top strip collapses with a CSS transition, so re-measure once it settles */
			clearTimeout(h.__vt); h.__vt = setTimeout(setVar, 420);
			if (hide && !hidden) { hidden = true; h.classList.add('is-hidden'); setVar(); }
			else if (show && hidden) { hidden = false; h.classList.remove('is-hidden'); setVar(); }
			last = y;
		}
		on(w, 'scroll', onScroll, { passive: true }); onScroll(); setVar(); on(w, 'resize', setVar);
		function setH() { if (w.scrollY < 30) d.documentElement.style.setProperty('--lx-headh', h.offsetHeight + 'px'); } setH(); on(w, 'resize', setH);

		var items = $$('.lx-nav__item', h), timer;
		function close(except) { items.forEach(function (i) { if (i !== except) { i.classList.remove('is-open'); var b = $('.lx-nav__link', i); if (b) b.setAttribute('aria-expanded', 'false'); } }); h.classList.toggle('has-mega', !!except); }
		function open(i) { close(i); i.classList.add('is-open'); var b = $('.lx-nav__link', i); if (b) b.setAttribute('aria-expanded', 'true'); h.classList.add('has-mega'); }
		var desk = w.matchMedia('(min-width: 1081px)');
		items.forEach(function (i) {
			if (!$('.lx-mega', i)) return;
			on(i, 'mouseenter', function () { if (!desk.matches || editing()) return; clearTimeout(timer); timer = setTimeout(function () { open(i); }, 90); });
			on(i, 'mouseleave', function () { if (!desk.matches || editing()) return; clearTimeout(timer); timer = setTimeout(function () { close(); }, 220); });
			/* keyboard: tabbing into a menu item opens its panel, tabbing out closes it */
			on(i, 'focusin', function () { if (!desk.matches || editing()) return; clearTimeout(timer); open(i); });
			on(i, 'focusout', function (e) { if (!desk.matches || i.contains(e.relatedTarget)) return; clearTimeout(timer); timer = setTimeout(function () { if (!i.contains(d.activeElement)) close(); }, 120); });
			var b = $('.lx-nav__link', i);
			on(b, 'click', function (e) {
				if (b.tagName === 'A' && desk.matches) return;
				e.preventDefault();
				if (i.classList.contains('is-open')) close(); else open(i);
			});
		});
		on(d, 'keydown', function (e) { if (e.key === 'Escape') { close(); h.classList.remove('is-open'); d.body.classList.remove('psr-lock'); } });
		on(d, 'click', function (e) { if (!h.contains(e.target)) close(); });

		var burger = $('[data-lx-burger]', h);
		on(burger, 'click', function () {
			var o = !h.classList.contains('is-open');
			h.classList.toggle('is-open', o); burger.setAttribute('aria-expanded', o ? 'true' : 'false');
			d.body.classList.toggle('psr-lock', o);
			if (!o) close();
		});
		$$('.lx-mega a, .lx-drawer a', h).forEach(function (a) { on(a, 'click', function () { h.classList.remove('is-open'); d.body.classList.remove('psr-lock'); close(); }); });
	}

	/* ------------------------------------------------------------ hero: poster slides, 3D turn */
	function hero(root) {
		var slides = $$('.psr-hero__slide', root), cars = $$('.pp-car', root), bgs = $$('.pp-bg', root), navs = $$('[data-go]', root), curEl = $('[data-psr-cur]', root);
		var IV = parseInt(root.getAttribute('data-interval'), 10) || 6000, cur = 0, busy = false, timer = null, paused = false, inView = true;
		root.style.setProperty('--iv', IV + 'ms');
		if (slides.length < 2) return;
		/* later slides carry data-psrc/data-psrcset so the first view only downloads one photo */
		function warm(i) { var f = cars[(i + cars.length) % cars.length]; if (!f) return; $$('[data-psrcset],[data-psrc]', f).forEach(function (el) { if (el.dataset.psrcset) { el.setAttribute('srcset', el.dataset.psrcset); el.removeAttribute('data-psrcset'); } if (el.dataset.psrc) { el.setAttribute('src', el.dataset.psrc); el.removeAttribute('data-psrc'); } }); }
		on(w, 'load', function () { setTimeout(function () { warm(1); }, 1200); });
		function text(to) {
			slides.forEach(function (s, i) { s.classList.remove('is-out'); if (i === cur && i !== to) s.classList.add('is-out'); s.classList.toggle('is-active', i === to); s.setAttribute('aria-hidden', i === to ? 'false' : 'true'); });
			navs.forEach(function (b, i) { if (i === to) { b.removeAttribute('aria-current'); void b.offsetWidth; b.setAttribute('aria-current', 'true'); } else b.removeAttribute('aria-current'); });
			if (curEl) curEl.textContent = (to + 1 < 10 ? '0' : '') + (to + 1);
		}
		function go(to, dir) {
			to = (to + slides.length) % slides.length;
			if (busy || to === cur) return;
			busy = true; stop(); dir = dir || (to > cur ? 1 : -1); warm(to); warm(to + 1);
			var a = cars[cur], b = cars[to];
			var im = $('img', b); if (im && im.loading === 'lazy') im.loading = 'eager';
			root.classList.toggle('dir-prev', dir < 0);
			a.classList.remove('is-on'); a.classList.add('is-leaving');
			b.classList.add('is-on', 'is-entering');
			if (bgs[cur]) bgs[cur].classList.remove('is-on'); if (bgs[to]) bgs[to].classList.add('is-on');
			root.classList.remove('is-sweep'); void root.offsetWidth; root.classList.add('is-sweep');
			text(to);
			setTimeout(function () { a.classList.remove('is-leaving'); b.classList.remove('is-entering'); cur = to; busy = false; start(); }, RM ? 50 : 1150);
		}
		function next() { go(cur + 1, 1); } function prev() { go(cur - 1, -1); }
		function start() { stop(); if (paused || !inView || d.hidden || editing()) return; timer = setTimeout(next, IV); }
		function stop() { clearTimeout(timer); }
		navs.forEach(function (b) { on(b, 'click', function () { var k = +b.getAttribute('data-go'); go(k, k > cur ? 1 : -1); }); });
		on($('[data-next]', root), 'click', next); on($('[data-prev]', root), 'click', prev);
		var ui = $('.psr-hero__ui', root);
		on(ui, 'mouseenter', function () { paused = true; root.classList.add('is-paused'); stop(); });
		on(ui, 'mouseleave', function () { paused = false; root.classList.remove('is-paused'); start(); });
		on(d, 'visibilitychange', function () { if (d.hidden) stop(); else start(); });
		on(d, 'keydown', function (e) { if (!inView || /INPUT|TEXTAREA|SELECT/.test((e.target || {}).tagName || '') || editing()) return; if (e.key === 'ArrowRight') next(); else if (e.key === 'ArrowLeft') prev(); });
		var sx = null, sy = 0;
		on(root, 'pointerdown', function (e) { if (e.pointerType === 'mouse') return; sx = e.clientX; sy = e.clientY; });
		on(root, 'pointerup', function (e) { if (sx === null) return; var dx = e.clientX - sx, dy = e.clientY - sy; sx = null; if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy)) { if (dx < 0) next(); else prev(); } });
		/* subtle parallax tilt of the car with the pointer */
		var stage = $('.pp-stage', root);
		on(root, 'mousemove', function (e) { if (RM) return; var r = root.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5; stage.style.setProperty('--rx', (y * -4).toFixed(2) + 'deg'); stage.style.setProperty('--ry', (x * 6).toFixed(2) + 'deg'); });
		if ('IntersectionObserver' in w) new IntersectionObserver(function (es) { inView = es[0].isIntersecting; if (inView) start(); else stop(); }, { threshold: .25 }).observe(root);
		text(0); start();
	}

	/* profile: reveal bars/radar, count-up numbers, duel chips */
	function profile(root) {
		var els = $$('.pf__num, .pf__radar, .pf__dims', root);
		var io = 'IntersectionObserver' in w ? new IntersectionObserver(function (es) { es.forEach(function (e) { if (!e.isIntersecting) return; io.unobserve(e.target); e.target.classList.add('is-in'); var b = $('b[data-count]', e.target); if (b && !RM) { var to = parseFloat(b.getAttribute('data-count')), dec = String(b.getAttribute('data-count')).indexOf('.') > -1 ? 1 : 0, t0 = performance.now(); (function f(now) { var k = Math.min(1, (now - t0) / 1400), v = to * (1 - Math.pow(1 - k, 3)); b.textContent = dec ? v.toFixed(1) : Math.round(v).toLocaleString(); if (k < 1) requestAnimationFrame(f); })(t0); } }); }, { threshold: .3 }) : null;
		els.forEach(function (el) { if (io) io.observe(el); else el.classList.add('is-in'); });
		$$('.pf__duel', root).forEach(function (d) { on(d, 'click', function (e) { e.preventDefault(); e.stopPropagation(); location.href = d.getAttribute('data-href'); }); });
	}

	/* parts: show the chosen car */
	function partsCar(root) {
		var sel = $('[data-ph-car]', root), box = $('[data-ph-img]', root); if (!sel || !box) return;
		function upd() { var c = byId(+sel.value) || index().filter(function (x) { return (x.make + ' ' + x.model + ' ' + x.year).indexOf(sel.options[sel.selectedIndex] ? sel.options[sel.selectedIndex].text : '') === 0; })[0]; if (!c) return; box.innerHTML = '<img src="' + esc(c.big || c.img) + '" alt=""><span><small>' + esc(c.make) + '</small><b>' + esc(c.model) + '</b></span>'; }
		on(sel, 'change', upd); setTimeout(upd, 300);
	}

	/* sidebar make filter (home hero) */
	function khFilter(inp) { var box = inp.closest('.kh-side'); on(inp, 'input', function () { var q = inp.value.trim().toLowerCase(); $$('.psr-marques li', box).forEach(function (li) { li.hidden = q && li.textContent.toLowerCase().indexOf(q) < 0; }); }); }

	/* ------------------------------------------------------------ shared index + storage */
	/* Car <select> options grouped by marque (A–Z), models A–Z inside each group. */
	function grp(list, f) {
		var g = {}, out = '';
		list.forEach(function (c, i) { (g[c.make] = g[c.make] || []).push([c, i]); });
		Object.keys(g).sort(function (a, b) { return a.localeCompare(b); }).forEach(function (m) {
			out += '<optgroup label="' + esc(m) + '">' + g[m].sort(function (a, b) { return String(a[0].model).localeCompare(String(b[0].model)); }).map(function (x) { var o = f(x[0], x[1]); return x[1] === 0 ? o.replace('<option ', '<option data-first ') : o; }).join('') + '</optgroup>';
		});
		/* keep the game's own default (its first car) unless an option is already marked selected */
		return / selected/.test(out) ? out.replace(' data-first', '') : out.replace('<option data-first ', '<option selected ');
	}
	var INDEX = null;
	function index() { if (INDEX) return INDEX; if (w.PSR_INDEX && w.PSR_INDEX.length) { INDEX = w.PSR_INDEX; return INDEX; } try { INDEX = JSON.parse(($('#psr-index') || {}).textContent || '[]'); } catch (e) { INDEX = []; } return INDEX; }
	function fold(x) { return String(x || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, ''); }
	/* colour words from the 3D paint so "red ferrari" or "black suv" finds the right cars */
	/* "GT-R" is also findable as "gtr", "AMG GT" as "amggt" */
	function tight(c) { return fold(c.make + ' ' + c.model).replace(/[^a-z0-9 ]+/g, ''); }
	function carHay(c) { return c._hay || (c._hay = ' ' + fold([c.make, c.model, tight(c), c.variant, c.color, colourWords(c.pc), c.body, c.year, c.tag, c.engine, c.power, c.drive, c.fuel, c.glb ? '3d model' : ''].join(' ')).replace(/[^a-z0-9.]+/g, ' ')); }
	function matches(c, q) { return fold(q).replace(/[^a-z0-9. ]+/g, ' ').split(/\s+/).filter(Boolean).every(function (wd) { return carHay(c).indexOf(' ' + wd) > -1; }); }
	function colourWords(hex) {
		var m = /^#?([0-9a-f]{6})$/i.exec(hex || ''); if (!m) return '';
		var n = parseInt(m[1], 16), r = (n >> 16) / 255, g = (n >> 8 & 255) / 255, b = (n & 255) / 255, mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, dl = mx - mn, sat = dl ? dl / (1 - Math.abs(2 * l - 1)) : 0, h = 0;
		if (dl) { h = mx === r ? ((g - b) / dl) % 6 : mx === g ? (b - r) / dl + 2 : (r - g) / dl + 4; h = (h * 60 + 360) % 360; }
		if (l < .16) return 'black'; if (sat < .18) return l > .8 ? 'white' : l > .5 ? 'silver grey gray' : 'grey gray';
		if (h < 15 || h >= 340) return l < .3 ? 'maroon burgundy red' : 'red'; if (h < 40) return l < .35 ? 'brown bronze' : 'orange'; if (h < 68) return l < .35 ? 'bronze brown' : 'yellow gold'; if (h < 170) return 'green'; if (h < 260) return 'blue'; if (h < 300) return 'purple'; return 'pink';
	}
	/* display name that tells apart cars sharing a make and model: year first, then the variant's last detail */
	var CN = null; function cname(c) { var k = c.make + ' ' + c.model; if (!CN) { CN = {}; index().forEach(function (x) { var q = x.make + ' ' + x.model; (CN[q] = CN[q] || []).push(x); }); } var g = CN[k] || []; if (g.length < 2) return k; var sameY = g.filter(function (x) { return x.year === c.year; }).length; if (c.year && sameY === 1) return k + ' (' + c.year + ')'; var v = String(c.variant || '').split(',').pop().trim(); return k + (v ? ' (' + (c.year ? c.year + ', ' : '') + v + ')' : ''); }
	function byId(id) { id = +id; return index().filter(function (c) { return c.id === id; })[0]; }
	function getList(k) { try { return JSON.parse(localStorage.getItem(k) || '[]').map(Number); } catch (e) { return []; } }
	function setList(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
	function esc(t) { var x = d.createElement('div'); x.textContent = t == null ? '' : String(t); return x.innerHTML; }
	function parseHash() { var o = {}; (location.hash || '').replace(/^#/, '').split('&').forEach(function (p) { var kv = p.split('='); if (kv[0]) o[decodeURIComponent(kv[0])] = decodeURIComponent((kv[1] || '').replace(/\+/g, ' ')); }); if (o.body) o.body = o.body.replace(/^sedans?$/i, 'Saloon').replace(/^suvs$/i, 'SUV').replace(/^coupes?$/i, 'Coupé'); return o; }
	function toast(msg) { var t = $('.psr-toast'); if (!t) { t = d.createElement('div'); t.className = 'psr-toast'; t.setAttribute('role', 'status'); d.body.appendChild(t); } t.innerHTML = msg; t.classList.add('is-on'); clearTimeout(t._t); t._t = setTimeout(function () { t.classList.remove('is-on'); }, 2600); }
	function thumb(c) { return c.th || c.img; }
	function miniCard(c) { return '<a class="psr-mini" href="' + esc(c.url) + '"><img src="' + esc(thumb(c)) + '" alt="" loading="lazy"><span><small>' + esc(c.make) + '</small><b>' + esc(c.model) + '</b><em>' + esc([c.year, c.tag].filter(Boolean).join(' · ')) + '</em></span></a>'; }

	/* ------------------------------------------------------------ collection (sidebar filters) */
	function collection(root) {
		var items = $('[data-psr-items]', root), cards = $$('.psr-card', items);
		var q = $('[data-f-q]', root), so = $('[data-f-sort]', root), ymin = $('[data-f-ymin]', root), ymax = $('[data-f-ymax]', root);
		var found = $('[data-found]', root), empty = $('[data-empty]', root), active = $('[data-f-active]', root), nBadge = $('[data-f-n]', root);
		cards.forEach(function (c, i) { c._i = i; });
		var PAGE = 24, limit = PAGE, keepLimit = false, pager = null;
		function vals(sel) { return $$(sel + ':checked', root).map(function (x) { return x.value; }); }
		function setVals(sel, list) { $$(sel, root).forEach(function (x) { x.checked = list.indexOf(x.value) > -1; }); }
		var HAY = {}; function hayOf(c) { var id = c.dataset.id; if (HAY[id]) return HAY[id]; var x = byId(+id) || {}; return (HAY[id] = ' ' + fold([c.dataset.name, c.dataset.make, c.dataset.body, c.dataset.year, x.color, colourWords(x.pc), x.engine, x.power, x.drive, x.fuel, x.variant, x.glb ? '3d model' : ''].join(' ')).replace(/[^a-z0-9.]+/g, ' ')); }
		function read() { return { status: vals('[data-f-status]'), make: vals('[data-f-make]'), body: vals('[data-f-body]'), q: q.value.trim(), ymin: +ymin.value || 0, ymax: +ymax.value || 0, sort: so.value }; }
		function write(st) {
			var p = [];
			['status', 'make', 'body'].forEach(function (k) { if (st[k].length) p.push(k + '=' + encodeURIComponent(st[k].join(','))); });
			if (st.q) p.push('q=' + encodeURIComponent(st.q)); if (st.ymin) p.push('ymin=' + st.ymin); if (st.ymax) p.push('ymax=' + st.ymax); if (st.sort) p.push('sort=' + st.sort);
			history.replaceState(null, '', p.length ? '#' + p.join('&') : location.pathname);
		}
		function fromHash() {
			var o = parseHash();
			setVals('[data-f-status]', (o.status || '').split(',').filter(Boolean));
			setVals('[data-f-make]', (o.make || '').split(',').filter(Boolean));
			setVals('[data-f-body]', (o.body || '').split(',').filter(Boolean));
			q.value = o.q || ''; ymin.value = o.ymin || ''; ymax.value = o.ymax || ''; so.value = o.sort || '';
		}
		function apply(push) {
			var st = read(), n = 0, words = fold(st.q).replace(/[^a-z0-9. ]+/g, ' ').split(/\s+/).filter(Boolean);
			cards.forEach(function (c) {
				var y = +c.dataset.year || 0;
				var ok = (!st.status.length || st.status.indexOf(c.dataset.status) > -1) && (!st.make.length || st.make.indexOf(c.dataset.make) > -1) && (!st.body.length || st.body.indexOf(c.dataset.body) > -1) &&
					(!words.length || words.every(function (wd) { return hayOf(c).indexOf(' ' + wd) > -1; })) && (!y || ((!st.ymin || y >= st.ymin) && (!st.ymax || y <= st.ymax)));
				c.hidden = !ok; if (ok) { n++; c.classList.add('is-in'); }
			});
			cards.slice().sort(function (a, b) {
				if (st.sort === 'year') return (+b.dataset.year || 0) - (+a.dataset.year || 0) || a._i - b._i;
				if (st.sort === 'name') return (a.dataset.make + a.dataset.name).localeCompare(b.dataset.make + b.dataset.name);
				if (st.sort === 'hp') return (+b.dataset.hp || 0) - (+a.dataset.hp || 0);
				return a._i - b._i;
			}).forEach(function (c) { items.appendChild(c); });
			/* paging: show PAGE cards at a time */
			if (!keepLimit) limit = PAGE;
			var shown = 0;
			$$('.psr-card', items).forEach(function (c) { if (c.hidden) return; shown++; if (shown > limit) { c.hidden = true; c.dataset.paged = '1'; } else { delete c.dataset.paged; } });
			if (!pager) { pager = d.createElement('div'); pager.className = 'psr-pager'; pager.innerHTML = '<p data-pg-txt></p><button type="button" class="lx-btn lx-btn--gold" data-pg-more>Show more</button>'; items.parentNode.insertBefore(pager, items.nextSibling); on($('[data-pg-more]', pager), 'click', function () { limit += PAGE; keepLimit = true; apply(false); keepLimit = false; }); }
			pager.hidden = n <= limit; $('[data-pg-txt]', pager).textContent = 'Showing ' + Math.min(limit, n) + ' of ' + n + ' cars';
			$('[data-pg-more]', pager).textContent = 'Show ' + Math.min(PAGE, n - limit) + ' more';
			cards.forEach(function (c) { if (!c.hidden) { c.style.animation = 'none'; void c.offsetWidth; c.style.animation = ''; } });
			found.textContent = n; if (found.nextSibling && found.nextSibling.nodeType === 3) found.nextSibling.textContent = n === 1 ? ' car' : ' cars'; empty.hidden = n > 0;
			var tags = [];
			st.status.forEach(function (v) { tags.push(['[data-f-status]', v, $('[data-f-status][value="' + v + '"]', root).parentNode.querySelector('span').textContent]); });
			st.make.forEach(function (v) { tags.push(['[data-f-make]', v, v]); });
			st.body.forEach(function (v) { tags.push(['[data-f-body]', v, v]); });
			if (st.q) tags.push(['q', '', '“' + st.q + '”']);
			if (st.ymin || st.ymax) tags.push(['y', '', (st.ymin || '…') + '–' + (st.ymax || '…')]);
			active.innerHTML = tags.map(function (t, i) { return '<button type="button" data-tag="' + i + '">' + esc(t[2]) + ' <i>×</i></button>'; }).join('');
			$$('[data-tag]', active).forEach(function (b) { on(b, 'click', function () { var t = tags[+b.getAttribute('data-tag')]; if (t[0] === 'q') q.value = ''; else if (t[0] === 'y') { ymin.value = ''; ymax.value = ''; } else $$(t[0], root).forEach(function (x) { if (x.value === t[1]) x.checked = false; }); apply(true); }); });
			nBadge.hidden = !tags.length; nBadge.textContent = tags.length;
			if (push) write(st);
		}
		$$('input[type=checkbox]', root).forEach(function (x) { on(x, 'change', function () { apply(true); }); });
		[ymin, ymax].forEach(function (x) { on(x, 'change', function () { apply(true); }); });
		on(so, 'change', function () { apply(true); });
		var qt; on(q, 'input', function () { clearTimeout(qt); qt = setTimeout(function () { apply(true); }, 160); });
		on($('[data-empty-reset]', root), 'click', function () { var r = $('[data-f-reset]', root); if (r) r.click(); });
		on($('[data-f-reset]', root), 'click', function () { $$('input[type=checkbox]', root).forEach(function (x) { x.checked = false; }); q.value = ''; ymin.value = ''; ymax.value = ''; so.value = ''; apply(true); });
		var side = $('[data-psr-side]', root);
		$$('[data-side-open]', root).forEach(function (b) { on(b, 'click', function () { root.classList.add('side-open'); d.body.classList.add('psr-lock'); }); });
		$$('[data-side-close]', root).forEach(function (b) { on(b, 'click', function () { root.classList.remove('side-open'); d.body.classList.remove('psr-lock'); }); });
		on(w, 'hashchange', function () { fromHash(); apply(false); });
		fromHash(); apply(false);
	}

	/* Section jump bar for long multi-tool pages (Play, Lab) */
	function jumpbar() {
		if (!/^\/(play|lab)\/?$/.test(location.pathname)) return;
		var secs = $$('section[id]').filter(function (s) { return $('.lx-eyebrow', s); });
		if (secs.length < 5) return;
		var bar = d.createElement('nav'); bar.className = 'psr-jump'; bar.setAttribute('aria-label', 'Jump to');
		bar.innerHTML = '<div class="psr-jump__in">' + secs.map(function (s) { return '<a href="#' + s.id + '" data-jump="' + s.id + '">' + esc($('.lx-eyebrow', s).textContent.trim()) + '</a>'; }).join('') + '</div>';
		secs[0].parentNode.insertBefore(bar, secs[0]);
		var hdr = $('.lx-header');
		function top() { var h = hdr ? hdr.getBoundingClientRect().bottom : 0; bar.style.top = Math.max(0, Math.round(h)) + 'px'; }
		top(); on(w, 'scroll', top, { passive: true }); on(w, 'resize', top);
		var links = $$('a', bar), cur = '';
		$$('a', bar).forEach(function (a) { on(a, 'click', function (e) { e.preventDefault(); var t = d.getElementById(a.getAttribute('data-jump')); if (!t) return; var off = function () { return (hdr ? hdr.getBoundingClientRect().height : 0) + bar.offsetHeight - 2; }; var go = function (sm) { w.scrollTo({ top: t.getBoundingClientRect().top + w.scrollY - off(), behavior: sm ? 'smooth' : 'auto' }); }; go(true); setTimeout(function () { if (Math.abs(t.getBoundingClientRect().top - off()) > 8) go(false); }, 900); history.replaceState(null, '', '#' + t.id); }); });
		function spy() {
			var y = bar.getBoundingClientRect().bottom + 40, id = '';
			secs.forEach(function (s) { if (s.getBoundingClientRect().top <= y) id = s.id; });
			if (id === cur) return; cur = id;
			links.forEach(function (a) { var on2 = a.getAttribute('data-jump') === id; a.classList.toggle('is-on', on2); if (on2) { var inr = bar.firstChild; inr.scrollTo({ left: a.offsetLeft - inr.clientWidth / 2 + a.clientWidth / 2, behavior: 'smooth' }); } });
		}
		spy(); on(w, 'scroll', spy, { passive: true });
	}

	/* ------------------------------------------------------------ home finder */
	function finder(f) {
		var chips = $$('[data-fd-make]', f), n = $('[data-fd-n]', f), make = '';
		var body = $('[data-fd-body]', f), ymin = $('[data-fd-ymin]', f), ymax = $('[data-fd-ymax]', f), q = $('[data-fd-q]', f);
		function st() { return { make: make, body: body.value, ymin: +ymin.value || 0, ymax: +ymax.value || 0, q: q.value.trim().toLowerCase(), status: $$('[data-fd-status]:checked', f).map(function (x) { return x.value; }) }; }
		function count() {
			var s = st(), k = index().filter(function (c) { var y = +c.year || 0; return (!s.make || c.make === s.make) && (!s.body || c.body === s.body) && (!s.status.length || s.status.indexOf(c.status) > -1) && (!y || ((!s.ymin || y >= s.ymin) && (!s.ymax || y <= s.ymax))) && (!s.q || matches(c, s.q)); }).length;
			n.textContent = k; var lb = $('[data-fd-lbl]', f); if (lb) lb.textContent = k === 1 ? 'car matches' : 'cars match'; n.parentNode.classList.remove('bump'); void n.offsetWidth; n.parentNode.classList.add('bump');
		}
		chips.forEach(function (c) { on(c, 'click', function () { make = c.getAttribute('data-fd-make'); chips.forEach(function (x) { x.classList.toggle('is-on', x === c); }); count(); }); });
		$$('select, input', f).forEach(function (x) { on(x, 'change', count); on(x, 'input', count); });
		on(f, 'submit', function (e) {
			e.preventDefault(); var s = st(), p = [];
			if (s.make) p.push('make=' + encodeURIComponent(s.make)); if (s.body) p.push('body=' + encodeURIComponent(s.body)); if (s.status.length) p.push('status=' + s.status.join(','));
			if (s.ymin) p.push('ymin=' + s.ymin); if (s.ymax) p.push('ymax=' + s.ymax); if (s.q) p.push('q=' + encodeURIComponent(q.value.trim()));
			location.href = f.getAttribute('action') + (p.length ? '#' + p.join('&') : '');
		});
		on($('[data-fd-surprise]', f), 'click', function () { var all = index(); if (all.length) location.href = all[Math.floor(Math.random() * all.length)].url; });
		count();
	}

	/* ------------------------------------------------------------ app chrome: search, sidebar, garage, compare */
	function app() {
		var srch = $('[data-lx-search-panel]'), side = $('[data-lx-side]');
		function lock(o) { d.body.classList.toggle('psr-lock', o); }
		var back = null;
		function openSearch() { if (!srch) return; back = d.activeElement; srch.classList.add('is-open'); lock(true); var i = $('input', srch); setTimeout(function () { i.focus(); }, 60); render(''); }
		function closeAll() { var was = (srch && srch.classList.contains('is-open')) || (side && side.classList.contains('is-open')); if (srch) srch.classList.remove('is-open'); if (side) side.classList.remove('is-open'); lock(false); if (was && back && back.focus && d.contains(back)) { try { back.focus({ preventScroll: true }); } catch (e) {} } back = null; }
		function render(t) {
			var out = $('[data-lx-results]', srch), needle = t.toLowerCase().trim(), list = index();
			var words = fold(needle).split(/\s+/).filter(Boolean), res = needle ? list.filter(function (c) { var hay = ' ' + fold([c.make, c.model, tight(c), c.variant, c.color, colourWords(c.pc), c.body, c.year, c.tag, c.engine, c.power, c.drive, c.fuel, c.tagline, c.hl, c.glb ? '3d model' : '', c.hp ? c.hp + 'hp' : ''].join(' ')).replace(/[^a-z0-9.]+/g, ' '); return words.every(function (wd) { return hay.indexOf(' ' + wd.replace(/[^a-z0-9.]+/g, '')) > -1; }); }) : list.slice(0, 8);
			if (needle) { var nm = function (c) { var h = ' ' + fold(c.make + ' ' + c.model + ' ' + tight(c)).replace(/[^a-z0-9.]+/g, ' '); return words.every(function (wd) { return h.indexOf(' ' + wd.replace(/[^a-z0-9.]+/g, '')) > -1; }) ? 0 : 1; }; res = res.map(function (c, k) { return [nm(c), k, c]; }).sort(function (a, b) { return a[0] - b[0] || a[1] - b[1]; }).map(function (x) { return x[2]; }); }
			$('[data-lx-results-h]', srch).textContent = needle ? res.length + (res.length === 1 ? ' car' : ' cars') : 'Start typing, or jump into these';
			out.innerHTML = res.length ? res.map(miniCard).join('') : '<p class="psr-none">No car matches “' + esc(t) + '” yet.</p>';
		}
		$$('[data-lx-search], a[href="#search"]').forEach(function (b) { on(b, 'click', function (e) { e.preventDefault(); openSearch(); }); });
		$$('a[href="#garage"]').forEach(function (b) { on(b, 'click', function (e) { e.preventDefault(); if (side) { back = b; garage(); side.classList.add('is-open'); lock(true); /* the heart opens straight onto the saved cars, not the menu */ var g = $('[data-lx-garage]'), gw = g && (g.previousElementSibling || g); setTimeout(function () { if (gw && gw.scrollIntoView) gw.scrollIntoView({ block: 'start', behavior: 'smooth' }); }, 350); } }); });
		var topBtn = $('[data-lx-top]');
		on(topBtn, 'click', function () { w.scrollTo({ top: 0, behavior: RM ? 'auto' : 'smooth' }); });
		on(w, 'scroll', function () { var h = d.documentElement, p = h.scrollTop / Math.max(1, h.scrollHeight - h.clientHeight); h.style.setProperty('--lx-progress', (p * 100).toFixed(1) + '%'); if (topBtn) topBtn.classList.toggle('is-on', h.scrollTop > 700); }, { passive: true });
		if (srch) {
			var inp = $('input', srch); on(inp, 'input', function () { render(inp.value); });
			on(inp, 'keydown', function (e) { if (e.key === 'Enter') { var a = $('.psr-mini', srch); if (a) location.href = a.href; } });
			$$('[data-lx-close]', srch).forEach(function (b) { on(b, 'click', closeAll); });
			$$('[data-lx-q]', srch).forEach(function (b) { on(b, 'click', function () { inp.value = b.getAttribute('data-lx-q'); render(inp.value); inp.focus(); }); });
		}
		$$('[data-lx-menu]').forEach(function (b) { on(b, 'click', function () { if (!side) return; back = b; garage(); side.classList.add('is-open'); lock(true); var f1 = $('button, a[href]', side); if (f1) setTimeout(function () { try { f1.focus({ preventScroll: true }); } catch (e) {} }, 60); }); });
		if (side) $$('[data-lx-close]', side).forEach(function (b) { on(b, 'click', closeAll); });
		on(d, 'keydown', function (e) { if (e.key === '/' && !/INPUT|TEXTAREA|SELECT/.test(e.target.tagName)) { e.preventDefault(); openSearch(); } if (e.key === 'Escape') closeAll();
			/* keep Tab inside an open panel */
			var pan = srch && srch.classList.contains('is-open') ? srch : side && side.classList.contains('is-open') ? side : null;
			if (pan && e.key === 'Tab') { var fs = $$('a[href], button:not([disabled]), input, select, textarea, [tabindex]:not([tabindex="-1"])', pan).filter(function (x) { return x.offsetParent !== null; }); if (fs.length) { var a = fs[0], z = fs[fs.length - 1]; if (e.shiftKey && (d.activeElement === a || !pan.contains(d.activeElement))) { e.preventDefault(); z.focus(); } else if (!e.shiftKey && (d.activeElement === z || !pan.contains(d.activeElement))) { e.preventDefault(); a.focus(); } } } });

		/* garage (saved cars) */
		function garage() {
			var favs = getList('psr_favs'), box = $('[data-lx-garage]');
			$$('[data-lx-favn]').forEach(function (x) { x.textContent = favs.length; x.hidden = !favs.length; });
			if (!box) return;
			var cars = favs.map(byId).filter(Boolean);
			box.innerHTML = cars.length ? cars.map(miniCard).join('') + (cars.length > 1 ? '<div class="gar__acts"><a class="lx-btn lx-btn--gold" href="' + esc((PSR.play || '/play/') + '#race=' + cars[0].id + ',' + cars[1].id) + '">Race my garage ⚑</a><a class="lx-btn lx-btn--dark" href="' + esc((PSR.play || '/play/') + '#cmp=' + cars[0].id + ',' + cars[1].id) + '">Spec duel ⇄</a></div>' : '') : '<p class="psr-none">Tap ♥ on any car to keep it here.</p>';
		}
		function syncButtons() {
			var favs = getList('psr_favs'), cmp = getList('psr_cmp');
			$$('[data-fav]').forEach(function (b) { var on_ = favs.indexOf(+b.getAttribute('data-fav')) > -1; b.setAttribute('aria-pressed', on_); b.classList.toggle('is-on', on_); });
			$$('[data-cmp]').forEach(function (b) { var on_ = cmp.indexOf(+b.getAttribute('data-cmp')) > -1; b.setAttribute('aria-pressed', on_); b.classList.toggle('is-on', on_); });
			tray(cmp); garage();
		}
		on(d, 'click', function (e) {
			var f = e.target.closest && e.target.closest('[data-fav]'), c = e.target.closest && e.target.closest('[data-cmp]');
			if (f) { e.preventDefault(); var id = +f.getAttribute('data-fav'), l = getList('psr_favs'), i = l.indexOf(id); if (i > -1) { l.splice(i, 1); toast('Removed from your garage'); } else { l.push(id); toast('Saved to <b>My garage</b> ♥'); f.classList.add('pop'); setTimeout(function () { f.classList.remove('pop'); }, 500); } setList('psr_favs', l); syncButtons(); }
			if (c) { e.preventDefault(); var id2 = +c.getAttribute('data-cmp'), l2 = getList('psr_cmp'), j = l2.indexOf(id2); if (j > -1) l2.splice(j, 1); else { l2.push(id2); if (l2.length > 2) l2.shift(); } setList('psr_cmp', l2); syncButtons(); }
		});
		var trayEl;
		function tray(cmp) {
			if (!index().length) return;
			if (!trayEl) { trayEl = d.createElement('div'); trayEl.className = 'psr-tray'; d.body.appendChild(trayEl);
				/* the tray would cover the duel it leads to, so tuck it away while the duel is on screen */
				var dsec = d.getElementById('duel'); if (dsec && 'IntersectionObserver' in w) new IntersectionObserver(function (es) { trayEl.classList.toggle('is-tucked', es[0].isIntersecting); }, { threshold: .15 }).observe(dsec); }
			var cars = cmp.map(byId).filter(Boolean);
			trayEl.classList.toggle('is-on', cars.length > 0);
			var slots = [0, 1].map(function (i) { var c = cars[i]; return c ? '<div class="psr-tray__car"><img src="' + esc(thumb(c)) + '" alt=""><span><small>' + esc(c.make) + '</small>' + esc(c.model) + '</span><button type="button" data-cmp="' + c.id + '" aria-label="Remove">×</button></div>' : '<div class="psr-tray__car is-empty"><span>Pick another car to compare</span></div>'; });
			var duel = ((w.PSR && PSR.play) || '/play/') + '#cmp=' + cmp.join(',');
			trayEl.innerHTML = '<p class="psr-tray__h">Compare</p>' + slots[0] + '<i class="psr-tray__vs">vs</i>' + slots[1] + (cars.length === 2 ? '<a class="psr-btn psr-btn--solid" href="' + duel + '"><span>Start the duel</span></a>' : '') + '<button type="button" class="psr-tray__x" data-tray-clear aria-label="Clear">Clear</button>';
			var x = $('[data-tray-clear]', trayEl); on(x, 'click', function () { setList('psr_cmp', []); syncButtons(); });
			if (location.pathname.replace(/\/$/, '').split('/').pop() === 'play' && cars.length === 2) { var dz = $('[data-psr-duel]'); if (dz && dz._set) dz._set(cmp); }
		}
		syncButtons();
	}

	/* ------------------------------------------------------------ reel */
	function reel(root) {
		var tr = $('.psr-reel__track', root);
		$$('[data-reel]', root).forEach(function (b) {
			on(b, 'click', function () {
				var c = $('.psr-card', tr); var step = c ? c.getBoundingClientRect().width + 24 : 320;
				tr.scrollBy({ left: step * +b.getAttribute('data-reel'), behavior: RM ? 'auto' : 'smooth' });
			});
		});
	}

	/* ------------------------------------------------------------ forms */
	function form(f) {
		var note = $('[data-note]', f), orig = note ? note.textContent : '';
		on(f, 'submit', function (e) {
			e.preventDefault();
			if (editing()) return;
			var data = {}; new FormData(f).forEach(function (v, k) { data[k] = v; });
			var bad = false;
			$$('.psr-field', f).forEach(function (l) { l.classList.remove('is-bad'); });
			if ((data.name || '').trim().length < 2) { bad = true; f.querySelector('[name=name]').parentNode.classList.add('is-bad'); }
			if ((data.phone || '').replace(/\D/g, '').length < 7) { bad = true; f.querySelector('[name=phone]').parentNode.classList.add('is-bad'); }
			if (bad) { f.classList.add('is-error'); if (note) note.textContent = 'Please add your name and a phone number we can reach.'; var fb = $('.is-bad input, .is-bad textarea', f); if (fb) fb.focus(); return; }
			f.classList.remove('is-error', 'is-done'); f.classList.add('is-sending');
			if (note) note.textContent = 'Sending…';
			fetch((w.PSR && PSR.rest ? PSR.rest : '/wp-json/psr/v1/') + 'enquiry', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data), credentials: 'same-origin' })
				.then(function (r) { return r.json().then(function (j) { if (!r.ok) throw new Error(j.message || 'Error'); return j; }); })
				.then(function (j) { f.classList.remove('is-sending'); f.classList.add('is-done'); f.reset(); if (note) note.textContent = j.message || 'Thank you.'; })
				.catch(function (er) { f.classList.remove('is-sending'); f.classList.add('is-error'); if (note) note.textContent = er.message || orig; });
		});
	}

	/* ------------------------------------------------------------ lightbox */
	function lightbox(root) {
		var data = $('[data-lb-items]', root); if (!data) return;
		var items = []; try { items = JSON.parse(data.textContent); } catch (e) { return; }
		if (!items.length) return;
		var lb = d.createElement('div'); lb.className = 'psr-lb'; lb.setAttribute('role', 'dialog'); lb.setAttribute('aria-modal', 'true'); lb.setAttribute('aria-label', 'Photographs');
		lb.innerHTML = '<div class="psr-lb__top"><span data-lb-n></span><button class="psr-lb__close" type="button" aria-label="Close"><svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="1.6" fill="none"/></svg></button></div>' +
			'<div class="psr-lb__stage"><img alt=""><button class="psr-lb__nav" data-d="-1" type="button" aria-label="Previous"><svg viewBox="0 0 24 24"><path d="M19 12H5M11 6l-6 6 6 6" fill="none" stroke="currentColor" stroke-width="1.6"/></svg></button><button class="psr-lb__nav" data-d="1" type="button" aria-label="Next"><svg viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6" fill="none" stroke="currentColor" stroke-width="1.6"/></svg></button></div>' +
			'<div><p class="psr-lb__cap" data-lb-cap></p><div class="psr-lb__strip"></div></div>';
		d.body.appendChild(lb);
		var img = $('.psr-lb__stage img', lb), strip = $('.psr-lb__strip', lb), n = $('[data-lb-n]', lb), cap = $('[data-lb-cap]', lb), i = 0, last;
		items.forEach(function (it, k) { var b = d.createElement('button'); b.type = 'button'; b.setAttribute('aria-label', 'Photo ' + (k + 1)); b.innerHTML = '<img loading="lazy" alt="" src="' + (it.t || it.src) + '">'; on(b, 'click', function () { show(k); }); strip.appendChild(b); });
		function show(k) {
			i = (k + items.length) % items.length;
			img.classList.add('is-loading');
			var im = new Image(); im.onload = function () { img.src = items[i].src; img.classList.remove('is-loading'); }; im.src = items[i].src;
			var h1 = $('h1'); img.alt = (h1 ? h1.textContent.trim() + ', ' : '') + 'photo ' + (i + 1) + ' of ' + items.length;
			n.textContent = (i + 1 < 10 ? '0' : '') + (i + 1) + ' / ' + (items.length < 10 ? '0' : '') + items.length;
			cap.textContent = items[i].c ? 'Photo: ' + items[i].c : '';
			$$('button', strip).forEach(function (b, j) { if (j === i) { b.setAttribute('aria-current', 'true'); b.scrollIntoView({ block: 'nearest', inline: 'center' }); } else b.removeAttribute('aria-current'); });
		}
		function open(k) { last = d.activeElement; lb.classList.add('is-open'); d.body.classList.add('psr-lock'); show(k); $('.psr-lb__close', lb).focus(); }
		function close() { lb.classList.remove('is-open'); d.body.classList.remove('psr-lock'); if (last) last.focus(); }
		$$('[data-lb]', root).forEach(function (b) { on(b, 'click', function () { open(+b.getAttribute('data-lb')); }); });
		on($('.psr-lb__close', lb), 'click', close);
		$$('.psr-lb__nav', lb).forEach(function (b) { on(b, 'click', function () { show(i + +b.getAttribute('data-d')); }); });
		on(d, 'keydown', function (e) { if (!lb.classList.contains('is-open')) return; if (e.key === 'Escape') close(); if (e.key === 'ArrowRight') show(i + 1); if (e.key === 'ArrowLeft') show(i - 1); if (e.key === 'Tab') { var fs = $$('button', lb).filter(function (x) { return x.offsetParent !== null; }); if (fs.length) { var a = fs[0], z = fs[fs.length - 1]; if (e.shiftKey && (d.activeElement === a || !lb.contains(d.activeElement))) { e.preventDefault(); z.focus(); } else if (!e.shiftKey && (d.activeElement === z || !lb.contains(d.activeElement))) { e.preventDefault(); a.focus(); } } } });
		var sx = null; on(lb, 'pointerdown', function (e) { sx = e.clientX; }); on(lb, 'pointerup', function (e) { if (sx === null) return; var dx = e.clientX - sx; sx = null; if (Math.abs(dx) > 50) show(i + (dx < 0 ? 1 : -1)); });
	}

	/* ------------------------------------------------------------ parallax */
	function parallax() {
		var els = $$('[data-lx-parallax]');
		if (!els.length || RM) return;
		var tick = false;
		function f() {
			tick = false;
			var vh = w.innerHeight;
			els.forEach(function (el) {
				var r = el.parentElement.getBoundingClientRect();
				if (r.bottom < 0 || r.top > vh) return;
				var p = (r.top + r.height / 2 - vh / 2) / vh;
				el.style.transform = 'translate3d(0,' + (p * -12).toFixed(2) + '%,0) scale(1.18)';
			});
		}
		on(w, 'scroll', function () { if (!tick) { tick = true; requestAnimationFrame(f); } }, { passive: true }); f();
	}

	/* ------------------------------------------------------------ guess the car */
	function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
	function store(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { return null; } }
	/* Game data: inline JSON, or a cached static file named in data-src. */
	function jsonOf(el, cb) { if (!el) return; var src = el.getAttribute('data-src'); if (src) { fetch(src).then(function (r) { return r.json(); }).then(cb).catch(function () {}); return; } var j; try { j = JSON.parse(el.textContent); } catch (e) { return; } cb(j); }
	function guess(root) { jsonOf($('[data-g-data]', root), function (j) { guessRun(root, j); }); }
	function guessRun(root, data) {
		var img = $('[data-g-img]', root), opts = $('[data-g-opts]', root), msg = $('[data-g-msg]', root), hint = $('[data-g-hint]', root);
		var elS = $('[data-g-score]', root), elK = $('[data-g-streak]', root), elB = $('[data-g-best]', root);
		var zoomBtn = $('[data-g-zoom]', root), nextBtn = $('[data-g-next]', root);
		var score = 0, streak = 0, best = parseInt(store('psr_best') || '0', 10) || 0, deck = [], cur = null, zl = 0, done = false;
		var Z = [430, 280, 170];
		elB.textContent = best;
		function name(r) { return r.make + ' ' + r.model; }
		function round() {
			if (!deck.length) deck = shuffle(data.slice());
			cur = deck.pop(); zl = 0; done = false;
			root.classList.remove('is-revealed');
			var pic = cur.pics[Math.floor(Math.random() * cur.pics.length)];
			img.style.backgroundImage = 'url("' + pic + '")';
			img.style.setProperty('--x', (30 + Math.random() * 40).toFixed(0) + '%');
			img.style.setProperty('--y', (35 + Math.random() * 30).toFixed(0) + '%');
			img.style.setProperty('--z', Z[0] + '%'); img.style.setProperty('--blur', '3px');
			hint.textContent = 'Zoomed in · worth 3 points';
			var bodyOf = function (r) { var c = byId(r.id); return c ? c.body : ''; }, cb = bodyOf(cur), others = shuffle(data.filter(function (r) { return name(r) !== name(cur); })).map(function (r) { return [(bodyOf(r) === cb ? 2 : 0) + (Math.abs((+r.year || 0) - (+cur.year || 0)) < 15 ? 1 : 0) + Math.random() * 1.5, r]; }).sort(function (a, b) { return b[0] - a[0]; }).map(function (x) { return x[1]; });
			var seen = {}, pick = [];
			others.forEach(function (r) { if (pick.length < 3 && !seen[name(r)]) { seen[name(r)] = 1; pick.push(r); } });
			var all = shuffle(pick.concat([cur]));
			opts.innerHTML = '';
			all.forEach(function (r) {
				var b = d.createElement('button'); b.type = 'button';
				b.innerHTML = '<small></small><span></span>';
				b.firstChild.textContent = r.make; b.lastChild.textContent = r.model;
				b._r = r; on(b, 'click', function () { answer(b); }); opts.appendChild(b);
			});
			msg.textContent = '';
			zoomBtn.disabled = false;
		}
		function answer(b) {
			if (done) return; done = true;
			var ok = name(b._r) === name(cur), pts = 3 - zl;
			$$('button', opts).forEach(function (x) { x.disabled = true; if (name(x._r) === name(cur)) x.classList.add('is-right'); });
			root.classList.add('is-revealed'); hint.textContent = cur.tag;
			var lost = streak; if (ok) { score += pts; streak++; if (streak > best) { best = streak; store('psr_best', String(best)); } FX.play(pts === 3 || streak % 5 === 0 ? 'streak' : 'ok'); if (pts === 3 && streak >= 3) FX.confetti(img, 70); msg.innerHTML = (pts === 3 ? '<b>Nailed it from the close-up!</b> ' : '') + 'Correct, +' + pts + '. <a href="' + cur.url + '">Explore the ' + cur.model.replace(/</g, '') + ' →</a>'; }
			else { b.classList.add('is-wrong'); streak = 0; FX.play('no'); FX.buzz(60); msg.innerHTML = 'It was the ' + name(cur).replace(/</g, '') + '. <a href="' + cur.url + '">See it →</a>' + (lost >= 3 ? ' ' + FX.shareBtn('I named ' + lost + ' cars in a row from a close-up on Laqim Autoworld. Can you beat it?') : ''); }
			elS.textContent = score; elK.textContent = streak; elB.textContent = best;
			zoomBtn.disabled = true;
		}
		on(zoomBtn, 'click', function () { if (done || zl >= Z.length - 1) return; zl++; FX.play('flip'); img.style.setProperty('--z', Z[zl] + '%'); img.style.setProperty('--blur', (zl >= Z.length - 1 ? 0 : 1.4) + 'px'); hint.textContent = 'Zoomed out · worth ' + (3 - zl) + (3 - zl === 1 ? ' point' : ' points'); if (zl >= Z.length - 1) zoomBtn.disabled = true; });
		on(nextBtn, 'click', round);
		round();
	}

	/* ------------------------------------------------------------ spec duel */
	function duel(root) { jsonOf($('[data-d-data]', root), function (j) { duelRun(root, j); }); }
	function duelRun(root, data) {
		var sides = $$('[data-d-side]', root), sels = $$('[data-d-sel]', root), rows = $('[data-d-rows]', root), verdict = $('[data-d-verdict]', root);
		var STATS = [['hp', 'Power', ' hp', 0], ['tq', 'Torque', ' Nm', 0], ['acc', '0–100 km/h', ' s', 1, 1], ['vmax', 'Top speed', ' km/h', 0], ['kg', 'Weight', ' kg', 0, 1], ['pw', 'Power-to-weight', ' hp/t', 0], ['qm', 'Quarter mile (simulated)', ' s', 1, 1], ['l', 'Engine size', ' L', 1], ['cyl', 'Cylinders', '', 0], ['seats', 'Seats', '', 0, 0, 1], ['year', 'Model year', '', 0, 0, 1]];
		var QM = {};
		function sv(R, k) {
			if (k === 'pw' || k === 'qm') { var ix0 = (R.id && byId(R.id)) || index().filter(function (c) { return c.make === R.make && c.model === R.model; })[0]; if (!ix0 || !ix0.hp || !ix0.kg) return null;
				if (k === 'pw') return Math.round(ix0.hp / ix0.kg * 1000);
				if (QM[ix0.id] == null) { var sp = carSpec(ix0); calibrate(sp); var rr = simulate(sp, CONDS.dry, DIST['400'], 1 / 120); QM[ix0.id] = +(rr[rr.length - 1][0] - .18).toFixed(1); } return QM[ix0.id]; }
			var v = R.s && R.s[k] != null ? R.s[k] : null; if (v == null) { var ix = (R.id && byId(R.id)) || index().filter(function (c) { return c.make === R.make && c.model === R.model; })[0]; v = ix && ix[k] ? ix[k] : null; } return v || v === 0 ? (v === 0 ? null : v) : null; }
		function show() { sels.forEach(function (s, i) { var r = data[+s.value]; var im = $('[data-d-img]', sides[i]); im.style.opacity = 0; setTimeout(function () { im.src = r.img; im.alt = r.make + ' ' + r.model; im.onload = function () { im.style.opacity = 1; }; }, 150); }); sides.forEach(function (x) { x.classList.remove('is-win'); }); rows.innerHTML = ''; verdict.textContent = ''; }
		function fight() {
			var A = data[+sels[0].value], B = data[+sels[1].value], wa = 0, wb = 0;
			rows.innerHTML = ''; sides.forEach(function (x) { x.classList.remove('is-win'); });
			STATS.forEach(function (st, k) {
				var a = sv(A, st[0]), b = sv(B, st[0]);
				if (a == null && b == null) return;
				var mx = Math.max(a || 0, b || 0) || 1;
				var row = d.createElement('div'); row.className = 'psr-duel__row';
				function bar(v, side, win) { return '<div class="psr-duel__bar psr-duel__bar--' + side + (win ? ' is-win' : '') + '"><i></i><b>' + (v == null ? '—' : (st[3] ? v.toFixed(1) : v) + st[2]) + '</b></div>'; }
				var lo = st[4], aw = !st[5] && a != null && (b == null || (lo ? a < b : a > b)), bw = !st[5] && b != null && (a == null || (lo ? b < a : b > a));
				if (aw) wa++; if (bw) wb++;
				row.innerHTML = bar(a, 'a', aw) + '<div class="psr-duel__label">' + st[1] + '</div>' + bar(b, 'b', bw);
				rows.appendChild(row);
				var bars = $$('.psr-duel__bar i', row);
				setTimeout(function () { bars[0].style.setProperty('--p', ((a || 0) / mx * 100) + '%'); bars[1].style.setProperty('--p', ((b || 0) / mx * 100) + '%'); FX.play('tick'); }, 120 + k * 260);
			});
			setTimeout(function () {
				if (wa === wb) verdict.innerHTML = 'A dead heat, <em>' + wa + '–' + wb + '</em>.';
				else { var w = wa > wb ? A : B; sides[wa > wb ? 0 : 1].classList.add('is-win'); verdict.innerHTML = 'The <em>' + (w.make + ' ' + w.model).replace(/</g, '') + '</em> takes it, ' + Math.max(wa, wb) + '–' + Math.min(wa, wb) + '. ' + FX.shareBtn('Spec Duel: the ' + w.make + ' ' + w.model + ' beats the ' + (wa > wb ? B : A).make + ' ' + (wa > wb ? B : A).model + ' ' + Math.max(wa, wb) + '–' + Math.min(wa, wb) + '. Pick your own match-up on Laqim Autoworld.'); FX.play('win'); }
			}, 120 + STATS.length * 260 + 600);
		}
		function rand() { var a = Math.floor(Math.random() * data.length), b; do { b = Math.floor(Math.random() * data.length); } while (data.length > 1 && (b === a || data[b].make + data[b].model === data[a].make + data[a].model)); sels[0].value = a; sels[1].value = b; show(); setTimeout(fight, 450); }
		sels.forEach(function (s) { on(s, 'change', show); });
		on($('[data-d-go]', root), 'click', fight);
		on($('[data-d-rand]', root), 'click', rand);
		var a0 = Math.floor(Math.random() * data.length), b0 = (a0 + 1 + Math.floor(Math.random() * (data.length - 1))) % data.length;
		function idx(id) { for (var i = 0; i < data.length; i++) if (data[i].id === +id) return i; return -1; }
		var hc = (parseHash().cmp || '').split(',').map(idx).filter(function (i) { return i > -1; });
		if (hc.length === 2) { a0 = hc[0]; b0 = hc[1]; setTimeout(function () { root.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, 400); }
		root._set = function (ids) { var x = ids.map(idx); if (x[0] > -1 && x[1] > -1) { sels[0].value = x[0]; sels[1].value = x[1]; show(); setTimeout(fight, 450); } };
		sels[0].value = a0; sels[1].value = b0; show();
		if ('IntersectionObserver' in w) { var io = new IntersectionObserver(function (es) { if (es[0].isIntersecting) { io.disconnect(); fight(); } }, { threshold: .35 }); io.observe(rows); } else fight();
	}

	/* ------------------------------------------------------------ 3D: shared loaders, studio environment, model viewer */
	var SCR = {};
	function loadScript(src, cb) {
		if (SCR[src]) { if (SCR[src].done) return cb(SCR[src].err); SCR[src].q.push(cb); return; }
		var rec = SCR[src] = { q: [cb] }, s = d.createElement('script'); s.src = src;
		function fin(err) { rec.done = true; rec.err = err; var q = rec.q; rec.q = []; q.forEach(function (f) { f(err); }); }
		s.onload = function () { fin(); }; s.onerror = function () { fin(new Error('load ' + src)); }; d.head.appendChild(s);
	}
	function loadThree(cb) {
		if (w.THREE) return cb();
		loadScript('https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js', cb);
	}
	var EX = 'https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/';
	function load3D(cb) {
		loadThree(function (err) {
			if (err || !w.THREE) return cb(err || new Error('three'));
			var need = [];
			if (!w.THREE.GLTFLoader) need.push(EX + 'loaders/GLTFLoader.js');
			if (!w.THREE.OrbitControls) need.push(EX + 'controls/OrbitControls.js');
			(function next() { if (!need.length) return cb(); loadScript(need.shift(), function (e) { if (e) return cb(e); next(); }); })();
		});
	}
	function studioEnv(R) {
		var T = w.THREE, pm = new T.PMREMGenerator(R), sc = new T.Scene();
		var room = new T.Mesh(new T.BoxGeometry(24, 12, 24), new T.MeshBasicMaterial({ color: new T.Color(.3, .29, .28), side: T.BackSide })); sc.add(room);
		function panel(wd, ht, x, y, z, rx, ry, k) { var p = new T.Mesh(new T.PlaneGeometry(wd, ht), new T.MeshBasicMaterial({ color: new T.Color(k, k, k * .96), side: T.DoubleSide })); p.position.set(x, y, z); p.rotation.set(rx || 0, ry || 0, 0); sc.add(p); }
		panel(14, 3, 0, 5.9, 0, Math.PI / 2, 0, 4); panel(3, 14, -6, 5.9, 0, Math.PI / 2, 0, 2); panel(3, 14, 6, 5.9, 0, Math.PI / 2, 0, 2);
		panel(10, 4, -11.9, 3, 0, 0, Math.PI / 2, 2.2); panel(10, 4, 11.9, 3, 0, 0, -Math.PI / 2, 2.2); panel(16, 3, 0, 3, -11.9, 0, 0, 1.6);
		var tex = pm.fromScene(sc, .035).texture; pm.dispose(); return tex;
	}
	function shadowTex() {
		var c = d.createElement('canvas'); c.width = c.height = 256; var x = c.getContext('2d'), g = x.createRadialGradient(128, 128, 10, 128, 128, 128);
		g.addColorStop(0, 'rgba(0,0,0,.55)'); g.addColorStop(.55, 'rgba(0,0,0,.22)'); g.addColorStop(1, 'rgba(0,0,0,0)'); x.fillStyle = g; x.fillRect(0, 0, 256, 256);
		return new w.THREE.CanvasTexture(c);
	}
	function setupRenderer(cv, alpha) {
		var T = w.THREE, R;
		try { R = new T.WebGLRenderer({ canvas: cv, antialias: true, alpha: !!alpha }); }
		catch (e) { /* graphics unavailable (old device, or the browser has switched 3D off): say so instead of a blank box */
			var box = cv.parentNode; if (box && !box.querySelector('.psr-nogl')) { var m = d.createElement('p'); m.className = 'psr-nogl'; m.textContent = '3D needs graphics this browser has switched off. Reload the page, or try another browser.'; box.appendChild(m); box.classList.add('has-nogl'); }
			throw e; }
		/* if the graphics card drops this 3D view (too many open at once), offer a one-tap restore */
		cv.addEventListener('webglcontextlost', function (ev) { ev.preventDefault(); var box = cv.parentNode; if (!box || box.querySelector('.psr-nogl')) return; var m = d.createElement('button'); m.type = 'button'; m.className = 'psr-nogl'; m.textContent = '3D view paused to save graphics memory. Tap to reload the page.'; m.onclick = function () { location.reload(); }; box.appendChild(m); box.classList.add('has-nogl'); }, false);
		R.setPixelRatio(Math.min(1.6, w.devicePixelRatio || 1)); R.outputEncoding = T.sRGBEncoding; R.toneMapping = T.ACESFilmicToneMapping; R.toneMappingExposure = .82;
		return R;
	}
	var GLB = {};
	/* Stand-in body for cars without a licensed 3D model: a sculpted coupé silhouette (nose +X, 4.7 m). */
	function genericCar(color, suv) {
		var T = w.THREE, g = new T.Group();
		var paint = new T.MeshStandardMaterial({ color: new T.Color(color || 0xc99a3a).convertSRGBToLinear(), metalness: .65, roughness: .28 });
		var glass = new T.MeshStandardMaterial({ color: 0x0b0d12, metalness: .9, roughness: .08, polygonOffset: true, polygonOffsetFactor: -1 });
		var dark = new T.MeshStandardMaterial({ color: 0x111114, roughness: .55 }), rimM = new T.MeshStandardMaterial({ color: 0xd9d4c8, metalness: 1, roughness: .25 });
		function ext(pts, depth, mat, bev) { var sh = new T.Shape(); sh.moveTo(pts[0][0], pts[0][1]); for (var i = 1; i < pts.length; i++) sh.lineTo(pts[i][0], pts[i][1]); var geo = new T.ExtrudeGeometry(sh, { depth: depth, bevelEnabled: !!bev, bevelThickness: .06, bevelSize: .06, bevelSegments: 3, steps: 1 }); geo.translate(0, 0, -depth / 2); var m = new T.Mesh(geo, mat); g.add(m); return m; }
		var WR = suv ? .44 : .36;
		if (suv) {
			ext([[-2.42, .5], [-2.46, 1.12], [-2.3, 1.22], [-2.1, 1.84], [.62, 1.86], [1.32, 1.32], [2.3, 1.18], [2.46, .96], [2.44, .5], [1.95, .46], [1.88, .82], [1.06, .82], [.98, .46], [-1.02, .46], [-1.1, .82], [-1.92, .82], [-1.99, .46]], 1.86, paint, true);
			ext([[-2.08, 1.26], [-1.98, 1.76], [.58, 1.78], [1.22, 1.32]], 1.98, glass, false);
			var rw = new T.Mesh(new T.BoxGeometry(.04, .4, 1.4), glass); rw.position.set(-2.32, 1.5, 0); rw.rotation.z = -.18; g.add(rw);
			var rack = new T.Mesh(new T.BoxGeometry(2.2, .05, 1.5), dark); rack.position.set(-.6, 1.95, 0); g.add(rack);
			var grille = new T.Mesh(new T.BoxGeometry(.06, .34, .9), rimM); grille.position.set(2.47, .88, 0); g.add(grille);
		} else {
			ext([[-2.32, .34], [-2.36, .74], [-2.05, .93], [-1.15, .99], [-.55, 1.26], [.38, 1.29], [1.08, .98], [2.05, .8], [2.38, .58], [2.34, .32], [1.85, .3], [1.78, .55], [1.12, .55], [1.05, .3], [-1.05, .3], [-1.12, .55], [-1.78, .55], [-1.85, .3]], 1.72, paint, true);
			ext([[-1.0, .99], [-.52, 1.22], [.36, 1.25], [.98, .99]], 1.9, glass, false);
		}
		[[1.45, .86], [1.45, -.86], [-1.45, .86], [-1.45, -.86]].forEach(function (q) { var wh = new T.Mesh(new T.CylinderGeometry(WR, WR, suv ? .32 : .26, 28), dark); wh.rotation.x = Math.PI / 2; wh.position.set(q[0], WR, q[1] * (suv ? 1.04 : 1)); g.add(wh); var rm = new T.Mesh(new T.CylinderGeometry(WR * .6, WR * .6, suv ? .33 : .27, 20), rimM); rm.rotation.x = Math.PI / 2; rm.position.copy(wh.position); g.add(rm); });
		var lamp = new T.MeshBasicMaterial({ color: 0xfff3d6 }), tail = new T.MeshBasicMaterial({ color: 0xc8000a });
		[.62, -.62].forEach(function (z) { var hl = new T.Mesh(new T.BoxGeometry(.08, .07, .34), lamp); hl.position.set(suv ? 2.46 : 2.36, suv ? 1.06 : .62, z * (suv ? 1.1 : 1)); g.add(hl); var tl = new T.Mesh(new T.BoxGeometry(.06, suv ? .3 : .06, .4), tail); tl.position.set(suv ? -2.47 : -2.38, suv ? 1.25 : .78, z * (suv ? 1.1 : 1)); g.add(tl); });
		g.traverse(function (o) { if (o.isMesh) { o.castShadow = true; } });
		return g;
	}
	/* body-paint helpers shared by every 3D view: pick the main body material, and repaint a model to match the photographed car */
	var BodyKit = w.PSR_BODY = (function () {
		var SKIP = /glass|window|wind|tyre|tire|wheel|rim|interior|interno|interieur|innen|cabin|seat|dash|leather|couro|light|lamp|farol|chrome|cromado|mirror|espelho|engine|motor|exhaust|brake|freio|caliper|disc|rubber|pneu|plastic|plastico|vidro|roda|grill|carpet|steer|logo|badge|plate|black|preto|dark|trim/i;
		function area(g) { var p = g.attributes.position, ix = g.index, a = 0, A = new w.THREE.Vector3(), B = new w.THREE.Vector3(), Cc = new w.THREE.Vector3(), n = ix ? ix.count : p.count; for (var i = 0; i < n; i += 3) { var i0 = ix ? ix.getX(i) : i, i1 = ix ? ix.getX(i + 1) : i + 1, i2 = ix ? ix.getX(i + 2) : i + 2; A.fromBufferAttribute(p, i0); B.fromBufferAttribute(p, i1); Cc.fromBufferAttribute(p, i2); a += B.sub(A).cross(Cc.sub(A)).length() / 2; } return a; }
		function pickPaint(m) {
		var tally = new Map();
		m.traverse(function (o) { if (!o.isMesh || Array.isArray(o.material)) return; var mt = o.material; if (SKIP.test(mt.name || '') || SKIP.test(o.name || '') || mt.transparent && mt.opacity < .9) return;
		var c = mt.color || { r: 0, g: 0, b: 0 }, lum = c.r * .3 + c.g * .59 + c.b * .11; if (lum < .015 && !mt.map) return;
		var ar = 0; try { ar = area(o.geometry) * o.getWorldScale(new w.THREE.Vector3()).x * o.getWorldScale(new w.THREE.Vector3()).x; } catch (e) {} var mx = Math.max(c.r, c.g, c.b), mn = Math.min(c.r, c.g, c.b), sat = mx ? (mx - mn) / mx : 0; tally.set(mt, (tally.get(mt) || 0) + ar * (.35 + sat * 1.6) * (lum > .05 ? 1 : .6) * (mt.map ? .7 : 1) * (/paint|pintura|peinture|vernice|lackierung|karosserie|body|colou?red|carpaint|exterior|shell|lack/i.test((mt.name || '') + ' ' + (o.name || '')) ? 4 : 1)); });
		var best = null, bv = 0; tally.forEach(function (v, k) { if (v > bv) { bv = v; best = k; } }); return best;
		}
		function byName(m, names) { var re = new RegExp('^(' + String(names).split('|').map(function (x) { return x.trim().replace(/[.*+?^${}()[\]\\]/g, '\\$&'); }).join('|') + ')$', 'i'), out = []; m.traverse(function (o) { if (!o.isMesh) return; (Array.isArray(o.material) ? o.material : [o.material]).forEach(function (mt) { if (mt && re.test(mt.name || '') && out.indexOf(mt) < 0) out.push(mt); }); }); return out; }
		function share(m, t) { var a = 0, b = 0; m.traverse(function (o) { if (!o.isMesh) return; var n = o.geometry.attributes.position.count; b += n; if (o.material === t) a += n; }); return b ? a / b : 0; }
		function tint(t, hex) { t.color = t.color || new w.THREE.Color(); t.color.set(hex).convertSRGBToLinear(); if (t.map) t.map = null; t.needsUpdate = true; }
		return { pick: function (m, names) { if (names) { var l = byName(m, names); if (l.length) return l[0]; } return pickPaint(m); }, all: function (m, names) { return names ? byName(m, names) : []; },
			paint: function (m, hex, names) { if (!hex) return; if (names) { var l = byName(m, names); if (l.length) { l.forEach(function (t) { tint(t, hex); }); return; } } var t = pickPaint(m); if (!t) return; if (t.map && share(m, t) > .25) return; /* one texture atlas for the whole car: leave it */ tint(t, hex); } };
	})();
	function loadModel(url, cb) {
		if (GLB[url] && GLB[url].scene) return cb(null, GLB[url].scene.clone(true));
		if (GLB[url]) { GLB[url].wait.push(cb); return; }
		GLB[url] = { wait: [cb] };
		new w.THREE.GLTFLoader().load(url, function (g) {
			var T = w.THREE, s = g.scene;
			s.traverse(function (o) { if (o.isMesh) { o.frustumCulled = true; if (o.material && o.material.map) o.material.map.anisotropy = 4; } });
			var box = new T.Box3().setFromObject(s), size = box.getSize(new T.Vector3()), len = Math.max(size.x, size.z), k = 4.8 / (len || 1);
			s.scale.setScalar(k); box.setFromObject(s); var c = box.getCenter(new T.Vector3());
			s.position.x -= c.x; s.position.z -= c.z; s.position.y -= box.min.y;
			var wrap = new T.Group(); wrap.add(s);
			if (size.z * k < size.x * k) wrap.rotation.y = 0; else wrap.rotation.y = Math.PI / 2; /* face sideways: length along X */
			try { var pc = index().filter(function (x) { return x.pc && x.glb && x.glb.replace(/^https?:/, '') === url.replace(/^https?:/, ''); })[0]; if (pc) BodyKit.paint(wrap, pc.pc, pc.pm); } catch (e) {}
			GLB[url].scene = wrap; var q = GLB[url].wait; GLB[url].wait = [];
			q.forEach(function (f, i) { f(null, i ? wrap.clone(true) : wrap); });
		}, function (e) { if (GLB[url] && e.total) { GLB[url].pct = Math.min(1, e.loaded / e.total); GLB[url].mb = [e.loaded / 1048576, e.total / 1048576]; } }, function (e) { var q = GLB[url].wait; delete GLB[url]; q.forEach(function (f) { f(e); }); });
	}
	function loadTag(stage, url) { var el = d.createElement('div'); el.className = 'l3d'; el.innerHTML = '<span class="sr__ring"></span><b>Loading the 3D car</b><small>0%</small>'; stage.appendChild(el); var t = setInterval(function () { var p = modelPct(url), g = GLB[url], mb = g && g.mb; $('small', el).textContent = Math.round(p * 100) + '%' + (mb && p < 1 ? ' · ' + mb[0].toFixed(1) + ' of ' + mb[1].toFixed(1) + ' MB' : ''); }, 200); return function () { clearInterval(t); el.remove(); }; }
	function modelPct(url) { var g = GLB[url]; return !g ? 0 : g.scene ? 1 : (g.pct || 0); }
	/* Stand-alone orbit viewer (car pages + showroom modal) */
	function mountViewer(el, url, onReady) {
		var T = w.THREE, cv = d.createElement('canvas'); cv.className = 'v3d__cv'; el.appendChild(cv);
		var R = setupRenderer(cv), S = new T.Scene(); S.background = new T.Color(0x0d0d10); S.fog = new T.Fog(0x0d0d10, 14, 34); S.environment = studioEnv(R);
		S.add(new T.HemisphereLight(0xffffff, 0x1a1a1e, .7)); var dl = new T.DirectionalLight(0xffffff, .95); dl.position.set(5, 9, 6); S.add(dl); var rim = new T.DirectionalLight(0xffe2b0, .55); rim.position.set(-6, 4, -7); S.add(rim);
		var fc = d.createElement('canvas'); fc.width = fc.height = 512; var fx2 = fc.getContext('2d'), fg = fx2.createRadialGradient(256, 256, 10, 256, 256, 256); fg.addColorStop(0, '#3a3832'); fg.addColorStop(.45, '#1b1b1f'); fg.addColorStop(1, '#0d0d10'); fx2.fillStyle = fg; fx2.fillRect(0, 0, 512, 512); var ft = new T.CanvasTexture(fc); ft.encoding = T.sRGBEncoding;
		var floor = new T.Mesh(new T.CircleGeometry(30, 64), new T.MeshStandardMaterial({ map: ft, roughness: .38, metalness: .2, envMapIntensity: .5 })); floor.rotation.x = -Math.PI / 2; S.add(floor);
		var ring = new T.Mesh(new T.RingGeometry(3.55, 3.62, 96), new T.MeshBasicMaterial({ color: 0xc99a3a })); ring.rotation.x = -Math.PI / 2; ring.position.y = .005; S.add(ring);
		var sh = new T.Mesh(new T.PlaneGeometry(7, 4), new T.MeshBasicMaterial({ map: shadowTex(), transparent: true, depthWrite: false })); sh.rotation.x = -Math.PI / 2; sh.position.y = .01; S.add(sh);
		var C = new T.PerspectiveCamera(32, 1, .05, 200); C.position.set(5.6, 1.7, 5.4);
		var O = new T.OrbitControls(C, cv); O.enableDamping = true; O.target.set(0, .7, 0); O.minDistance = 2.6; O.maxDistance = 14; O.maxPolarAngle = Math.PI / 2 - .04; O.autoRotate = false;
		function size() { var r = el.getBoundingClientRect(); R.setSize(r.width, r.height, false); C.aspect = r.width / Math.max(1, r.height); C.updateProjectionMatrix(); }
		size(); on(w, 'resize', size);
		var alive = true;
		(function loop() { if (!alive) return; requestAnimationFrame(loop); O.update(); R.render(S, C); })();
		loadModel(url, function (err, m) { if (err) { if (onReady) onReady(err); return; } S.add(m); if (onReady) onReady(); });
		return { size: size, dispose: function () { alive = false; R.dispose(); if (cv.parentNode) cv.parentNode.removeChild(cv); } };
	}
	function carViewer(root) {
		var url = root.getAttribute('data-psr-3d'), load = $('.v3d__load', root), go = $('[data-v3d-go]', root), started = false, msg = $('p', load), desk = w.matchMedia('(min-width: 900px)').matches;
		if (msg && go && !desk) msg.textContent = 'See it in 3D: drag to turn, pinch to zoom.';
		function start() {
			if (started) return; started = true; root.classList.add('is-loading');
			if (go) go.hidden = true;
			if (msg) { msg.textContent = 'Loading the 3D model…'; var tick = setInterval(function () { if (!msg.isConnected || modelPct(url) >= 1) return clearInterval(tick); var g = GLB[url], pc = modelPct(url); if (pc > 0) msg.textContent = 'Loading the 3D model… ' + Math.round(pc * 100) + '%' + (g && g.mb ? ' · ' + g.mb[0].toFixed(1) + ' of ' + g.mb[1].toFixed(1) + ' MB' : ''); }, 250); }
			load3D(function (err) {
				if (err) { load.innerHTML = '<p>3D view unavailable on this device.</p>'; return; }
				mountViewer(root, url, function (e) { if (e) { load.innerHTML = '<p>The 3D model could not load.</p>'; return; } root.classList.remove('is-loading'); load.classList.add('is-off'); });
			});
		}
		on(go, 'click', start);
		if (desk && 'IntersectionObserver' in w) { var io = new IntersectionObserver(function (es) { if (es[0].isIntersecting) { io.disconnect(); start(); } }, { rootMargin: '300px' }); io.observe(root); }
	}

	/* ------------------------------------------------------------ 3D showroom */
	function showroom(root) {
		var cars = index().filter(function (c) { return c.big || c.glb; }); if (!cars.length) return;
		var teaser = root.getAttribute('data-mode') === 'teaser';
		var start = function () {
			load3D(function (err) {
				var load = $('[data-sr-load]', root);
				if (err || !w.THREE) { if (load) load.innerHTML = '<p>The 3D showroom needs a newer browser.</p>'; return; }
				try { build(); } catch (e) { if (load) load.innerHTML = '<p>3D view unavailable on this device.</p>'; if (w.console) console.error(e); return; }
				if (load) load.classList.add('is-off');
			});
		};
		if ('IntersectionObserver' in w) { var io = new IntersectionObserver(function (es) { if (es[0].isIntersecting) { io.disconnect(); start(); } }, { rootMargin: '200px' }); io.observe(root); } else start();

		function build() {
			var T = w.THREE, cv = $('.sr__canvas', root), R = setupRenderer(cv);
			var S = new T.Scene(); S.background = new T.Color(0xe2ded6); S.fog = new T.Fog(0xe2ded6, 34, 110); S.environment = studioEnv(R);
			var C = new T.PerspectiveCamera(56, 1, .1, 260);
			var hemiL = new T.HemisphereLight(0xffffff, 0xa9a297, .45); S.add(hemiL);
			var dl = new T.DirectionalLight(0xffffff, .55); dl.position.set(6, 14, 8); S.add(dl);
			var gold = new T.MeshStandardMaterial({ color: 0xc99a3a, metalness: .85, roughness: .28 });
			var white = new T.MeshStandardMaterial({ color: 0xf3f1ec, metalness: 0, roughness: .3 });
			var charcoal = new T.MeshStandardMaterial({ color: 0x1c1c1f, metalness: .2, roughness: .45 });
			var SH = shadowTex(); var POOL = (function () { var c = d.createElement('canvas'); c.width = c.height = 256; var x = c.getContext('2d'), g = x.createRadialGradient(128, 128, 20, 128, 128, 128); g.addColorStop(0, 'rgba(255,236,190,.35)'); g.addColorStop(.6, 'rgba(255,220,150,.12)'); g.addColorStop(1, 'rgba(255,220,150,0)'); x.fillStyle = g; x.fillRect(0, 0, 256, 256); return new T.CanvasTexture(c); })();
			var groups = {}; cars.forEach(function (c) { (groups[c.make] = groups[c.make] || []).push(c); });
			var PRIO = { 'Rolls-Royce': 1, 'Ferrari': 2, 'Lamborghini': 3, 'Bentley': 4, 'Aston Martin': 5, 'Porsche': 6, 'Mercedes-Maybach': 7, 'Mercedes-AMG': 8, 'Land Rover': 9, 'Mercedes-Benz': 10, 'Lexus': 11, 'Toyota': 12 }; var makes = Object.keys(groups).sort(function (a, b) { return (PRIO[a] || 20) - (PRIO[b] || 20) || a.localeCompare(b); });
			var W = 28, ROW = 11, len = 0;
			makes.forEach(function (m) { len += Math.max(1, Math.ceil(groups[m].length / 2)) * ROW + 8; });
			var midZ = -len / 2 + 6, L = len + 50;
			/* floor: polished stone with subtle tile joints */
			var fc = d.createElement('canvas'); fc.width = fc.height = 512; var fx = fc.getContext('2d'); fx.fillStyle = '#b9b2a6'; fx.fillRect(0, 0, 512, 512); fx.strokeStyle = 'rgba(120,110,95,.18)'; fx.lineWidth = 3; fx.strokeRect(0, 0, 512, 512);
			var ft = new T.CanvasTexture(fc); ft.wrapS = ft.wrapT = T.RepeatWrapping; ft.repeat.set(W / 4, L / 4); ft.encoding = T.sRGBEncoding; ft.anisotropy = 8;
			var floor = new T.Mesh(new T.PlaneGeometry(W, L), new T.MeshStandardMaterial({ map: ft, roughness: .16, metalness: .05 })); floor.rotation.x = -Math.PI / 2; floor.position.z = midZ; S.add(floor);
			/* central runner in charcoal with gold edges */
			var run = new T.Mesh(new T.PlaneGeometry(4.2, L), charcoal); run.rotation.x = -Math.PI / 2; run.position.set(0, .004, midZ); S.add(run);
			[-2.15, 2.15].forEach(function (x) { var e = new T.Mesh(new T.PlaneGeometry(.08, L), new T.MeshBasicMaterial({ color: 0xc99a3a })); e.rotation.x = -Math.PI / 2; e.position.set(x, .006, midZ); S.add(e); });
			/* walls, ceiling, light panels, gold fins */
			var wallM = new T.MeshStandardMaterial({ color: 0xe6e2da, roughness: .9 });
			[-W / 2, W / 2].forEach(function (x) {
				var wl = new T.Mesh(new T.PlaneGeometry(L, 9), wallM); wl.rotation.y = x < 0 ? Math.PI / 2 : -Math.PI / 2; wl.position.set(x, 4.5, midZ); S.add(wl);
				var base = new T.Mesh(new T.BoxGeometry(.12, .35, L), charcoal); base.position.set(x + (x < 0 ? .06 : -.06), .17, midZ); S.add(base);
				for (var z = 8; z > -len - 20; z -= 5.5) { var fin = new T.Mesh(new T.BoxGeometry(.14, 9, .14), gold); fin.position.set(x + (x < 0 ? .08 : -.08), 4.5, z); S.add(fin); }
			});
			var ceilM = new T.MeshStandardMaterial({ color: 0xfbfaf8, roughness: 1 }), ceil = new T.Mesh(new T.PlaneGeometry(W, L), ceilM); ceil.rotation.x = Math.PI / 2; ceil.position.set(0, 9, midZ); S.add(ceil);
			var glow = new T.MeshBasicMaterial({ color: 0xffffff });
			/* night mode: black marble, gold joints, warm low light */
			var nc = d.createElement('canvas'); nc.width = nc.height = 512; var nx = nc.getContext('2d'); nx.fillStyle = '#141416'; nx.fillRect(0, 0, 512, 512); for (var vi = 0; vi < 40; vi++) { nx.strokeStyle = 'rgba(255,255,255,' + (Math.random() * .05) + ')'; nx.lineWidth = Math.random() * 2; nx.beginPath(); nx.moveTo(Math.random() * 512, 0); nx.bezierCurveTo(Math.random() * 512, 170, Math.random() * 512, 340, Math.random() * 512, 512); nx.stroke(); } nx.strokeStyle = 'rgba(201,154,58,.55)'; nx.lineWidth = 3; nx.strokeRect(0, 0, 512, 512);
			var nt = new T.CanvasTexture(nc); nt.wrapS = nt.wrapT = T.RepeatWrapping; nt.repeat.set(W / 4, L / 4); nt.encoding = T.sRGBEncoding; nt.anisotropy = 8;
			var moodNow = 'day', poolM = null;
			function setMood(m) {
				moodNow = m; var n = m === 'night';
				S.background.setHex(n ? 0x09090b : 0xe2ded6); S.fog.color.setHex(n ? 0x09090b : 0xe2ded6); S.fog.near = n ? 26 : 34; S.fog.far = n ? 95 : 110;
				floor.material.map = n ? nt : ft; floor.material.roughness = n ? .1 : .16; floor.material.metalness = n ? .35 : .05; floor.material.needsUpdate = true;
				wallM.color.setHex(n ? 0x121214 : 0xe6e2da); [floor.material, wallM, ceilM, charcoal].forEach(function (mt) { mt.envMapIntensity = n ? .12 : 1; }); floor.material.metalness = n ? .1 : .05; if (poolM) poolM.opacity = n ? .45 : 1; ceilM.color.setHex(n ? 0x0b0b0d : 0xfbfaf8); glow.color.setHex(n ? 0x8a7348 : 0xffffff);
				hemiL.intensity = n ? .3 : .45; hemiL.groundColor.setHex(n ? 0x1a1610 : 0xa9a297); dl.intensity = n ? .45 : .55; dl.color.setHex(n ? 0xffe2b0 : 0xffffff);
				try { localStorage.setItem('psr-sr-mood', m); } catch (e) {}
			}
			for (var cz = 6; cz > -len - 16; cz -= 7) { [-9, 0, 9].forEach(function (x) { var p = new T.Mesh(new T.PlaneGeometry(x ? 3 : 6, 2.2), glow); p.rotation.x = Math.PI / 2; p.position.set(x, 8.97, cz); S.add(p); }); }
			function textTex(t, sub, dark) {
				var c = d.createElement('canvas'); c.width = 1024; c.height = 256; var x = c.getContext('2d');
				if (dark) { x.fillStyle = '#1c1c1f'; x.fillRect(0, 0, 1024, 256); }
				var g = x.createLinearGradient(0, 0, 1024, 0); g.addColorStop(0, '#8a611a'); g.addColorStop(.45, '#d9a93f'); g.addColorStop(.52, '#f1d27a'); g.addColorStop(1, '#a8781f');
				x.fillStyle = dark ? g : '#1c1a16'; x.textAlign = 'center'; x.font = '500 118px "Cormorant Garamond", Georgia, serif'; x.fillText(t, 512, sub ? 140 : 165);
				if (sub) { x.font = '600 34px Manrope, Arial, sans-serif'; x.fillStyle = dark ? 'rgba(255,255,255,.7)' : 'rgba(60,52,40,.75)'; x.fillText(sub, 512, 212); }
				var tx = new T.CanvasTexture(c); tx.anisotropy = 4; tx.encoding = T.sRGBEncoding; return tx;
			}
			var loader = new T.TextureLoader(), picks = [], slots = [], bays = [], zc = 0;
			makes.forEach(function (m) {
				var list = groups[m], rows = Math.max(1, Math.ceil(list.length / 2)), bz = zc;
				/* floating brand sign: hangs from the ceiling on two fine cables, readable from both directions */
				var signTex = textTex(m.toUpperCase(), list.length + (list.length === 1 ? ' car' : ' cars'), true);
				var sign = new T.Group(); sign.position.set(0, 6.3, bz - 1); S.add(sign);
				var face = new T.Mesh(new T.PlaneGeometry(8, 2), new T.MeshBasicMaterial({ map: signTex })); face.position.z = .05; sign.add(face);
				var back = face.clone(); back.rotation.y = Math.PI; back.position.z = -.05; sign.add(back);
				var edge = new T.Mesh(new T.BoxGeometry(8.12, 2.12, .08), gold); sign.add(edge);
				[-3.2, 3.2].forEach(function (cx) { var cab = new T.Mesh(new T.CylinderGeometry(.012, .012, 9 - 7.36, 6), new T.MeshBasicMaterial({ color: 0x8a8378 })); cab.position.set(cx, 1.0 + (9 - 7.36) / 2, 0); sign.add(cab); });
				/* brand wall panels */
				[-W / 2 + .05, W / 2 - .05].forEach(function (x) { var wp = new T.Mesh(new T.PlaneGeometry(rows * ROW, 3.2), new T.MeshBasicMaterial({ map: textTex(m, '', true) })); wp.rotation.y = x < 0 ? Math.PI / 2 : -Math.PI / 2; wp.position.set(x, 6.4, bz - 2 - rows * ROW / 2); S.add(wp); });
				bays.push({ make: m, z: bz });
				list.forEach(function (c, i) {
					var side = i % 2 ? 1 : -1, row = Math.floor(i / 2), z = bz - 6 - row * ROW;
					var grp = new T.Group(); grp.position.set(side * 7.4, 0, z); grp.rotation.y = side < 0 ? Math.PI / 4.2 : -Math.PI / 4.2; S.add(grp);
					var pool = new T.Mesh(new T.CircleGeometry(5.2, 48), poolM || (poolM = new T.MeshBasicMaterial({ map: POOL, transparent: true, depthWrite: false, blending: T.AdditiveBlending }))); pool.rotation.x = -Math.PI / 2; pool.position.y = .012; grp.add(pool);
					var plinth = new T.Mesh(new T.CylinderGeometry(3.6, 3.75, .28, 72), white); plinth.position.y = .14; grp.add(plinth);
					var ring = new T.Mesh(new T.TorusGeometry(3.68, .035, 8, 96), gold); ring.rotation.x = Math.PI / 2; ring.position.y = .285; grp.add(ring);
					var sh = new T.Mesh(new T.PlaneGeometry(7, 3.6), new T.MeshBasicMaterial({ map: SH, transparent: true, depthWrite: false })); sh.rotation.x = -Math.PI / 2; sh.position.y = .29; grp.add(sh);
					var lab = new T.Mesh(new T.PlaneGeometry(3.6, .9), new T.MeshBasicMaterial({ map: textTex(c.model, [c.year, c.hp ? c.hp + ' hp' : ''].filter(Boolean).join(' · ')), transparent: true }));
					lab.position.set(0, .3, 3.95); lab.rotation.x = -Math.PI / 2.4; grp.add(lab);
					var tcv = d.createElement('canvas'); tcv.width = 512; tcv.height = 112; var tcx = tcv.getContext('2d'); tcx.fillStyle = 'rgba(20,20,22,.86)'; if (tcx.roundRect) { tcx.beginPath(); tcx.roundRect(4, 8, 504, 96, 48); tcx.fill(); } else tcx.fillRect(4, 8, 504, 96); tcx.fillStyle = '#f1d27a'; tcx.font = '600 44px Manrope, Arial, sans-serif'; tcx.textAlign = 'center'; tcx.fillText((c.model || '').slice(0, 20), 256, 70);
					var ttx = new T.CanvasTexture(tcv); ttx.encoding = T.sRGBEncoding; var tag = new T.Sprite(new T.SpriteMaterial({ map: ttx, transparent: true, depthWrite: false })); tag.scale.set(3.4, .74, 1); tag.position.set(0, 3.25, 0); grp.add(tag);
					grp.userData.car = c; picks.push(grp);
					var slot = { c: c, grp: grp, loaded: false, wp: new T.Vector3() }; grp.getWorldPosition(slot.wp); slots.push(slot);
					if (!c.glb) {
						/* no model yet: framed lightbox photo standing on the plinth */
						var frame = new T.Mesh(new T.BoxGeometry(6.2, 4.1, .12), charcoal); frame.position.set(0, 2.55, -.6); grp.add(frame);
						var pic = new T.Mesh(new T.PlaneGeometry(6, 3.9), new T.MeshBasicMaterial({ color: 0xdddddd })); pic.position.set(0, 2.55, -.53); grp.add(pic);
						loader.load(c.big, function (tx) { tx.encoding = T.sRGBEncoding; tx.anisotropy = 4; var ar = tx.image.width / tx.image.height, h = 3.9, wd = Math.min(6, h * ar); if (wd === 6) h = wd / ar; pic.geometry = new T.PlaneGeometry(wd, h); frame.geometry = new T.BoxGeometry(wd + .2, h + .2, .12); pic.position.y = frame.position.y = .45 + h / 2; pic.material = new T.MeshBasicMaterial({ map: tx }); });
						slot.loaded = true;
					}
				});
				zc -= rows * ROW + 8;
			});
			/* load nearby models only (keeps the hall fast) */
			var loading = 0;
			function stream() {
				if (loading > 0) return;
				var best = null, bd = 1e9;
				slots.forEach(function (s) { if (s.loaded) return; var dd = s.grp.position.distanceTo(pos); if (dd < bd) { bd = dd; best = s; } });
				if (!best || bd > 40) return;
				var s = best; s.loaded = true; loading++;
				var ph = new T.Mesh(new T.BoxGeometry(4.6, 1.3, 1.9), new T.MeshStandardMaterial({ color: 0xcfc9bf, transparent: true, opacity: .45 })); ph.position.y = .95; s.grp.add(ph);
				loadModel(s.c.glb, function (err, mdl) { loading--; if (err) { s.tries = (s.tries || 0) + 1; s.grp.remove(ph); if (s.tries < 3) s.loaded = false; if (w.console) console.warn('model retry', s.c.model); return; } s.grp.remove(ph); mdl.position.y = .28; mdl.scale.multiplyScalar(1.12); s.grp.add(mdl); });
			}
			/* brand jump chips */
			var chips = $('[data-sr-brands]', root);
			chips.innerHTML = bays.map(function (b, i) { return '<button type="button" data-bay="' + i + '">' + esc(b.make) + '</button>'; }).join('');
			var pos = new T.Vector3(0, 1.65, 14), yaw = 0, pitch = .02, target = null, keys = {};
			function glide(p, y) { target = { p: p, y: y, t: 0, p0: pos.clone(), y0: yaw }; }
			$$('[data-bay]', chips).forEach(function (b) { on(b, 'click', function () { var bay = bays[+b.getAttribute('data-bay')]; glide(new T.Vector3(0, 1.65, bay.z + 7), 0); closeCard(); }); });
			var drag = null;
			on(cv, 'pointerdown', function (e) { drag = { x: e.clientX, y: e.clientY, moved: 0 }; cv.setPointerCapture(e.pointerId); });
			on(cv, 'pointermove', function (e) {
				if (drag) { var dx = e.clientX - drag.x, dy = e.clientY - drag.y; drag.moved += Math.abs(dx) + Math.abs(dy); yaw -= dx * .004; pitch = Math.max(-.6, Math.min(.45, pitch - dy * .003)); drag.x = e.clientX; drag.y = e.clientY; target = null; }
				else hover(e);
			});
			on(cv, 'pointerup', function (e) { if (drag && drag.moved < 6) pick(e); drag = null; });
			on(cv, 'wheel', function (e) { if (teaser) return; e.preventDefault(); move(-e.deltaY * .012, 0); }, { passive: false });
			var mine = function () { return root.matches(':hover') || d.activeElement === cv || root.classList.contains('is-fs'); };
			on(d, 'keydown', function (e) { if (!mine() || /INPUT|SELECT|TEXTAREA/.test(e.target.tagName)) return; keys[e.key.toLowerCase()] = 1; if (/^arrow/.test(e.key.toLowerCase())) e.preventDefault(); });
			on(d, 'keyup', function (e) { keys[e.key.toLowerCase()] = 0; });
			$$('[data-mv]', root).forEach(function (b) { var k = b.getAttribute('data-mv'); on(b, 'pointerdown', function (e) { e.preventDefault(); keys['pad' + k] = 1; }); ['pointerup', 'pointerleave'].forEach(function (ev) { on(b, ev, function () { keys['pad' + k] = 0; }); }); });
			on($('[data-sr-fs]', root), 'click', function () { if (d.fullscreenElement) d.exitFullscreen(); else if (root.requestFullscreen) root.requestFullscreen().catch(function () {}); });
			on(d, 'fullscreenchange', function () { root.classList.toggle('is-fs', d.fullscreenElement === root); size(); });
			function move(f, s) { var dir = new T.Vector3(-Math.sin(yaw), 0, -Math.cos(yaw)), rt = new T.Vector3(Math.cos(yaw), 0, -Math.sin(yaw)); pos.addScaledVector(dir, f).addScaledVector(rt, s); pos.x = Math.max(-W / 2 + 1.5, Math.min(W / 2 - 1.5, pos.x)); pos.z = Math.max(zc - 4, Math.min(14, pos.z)); target = null; }
			var ray = new T.Raycaster(), mv = new T.Vector2(), hot = null;
			function cast(e) { var r = cv.getBoundingClientRect(); mv.x = ((e.clientX - r.left) / r.width) * 2 - 1; mv.y = -((e.clientY - r.top) / r.height) * 2 + 1; ray.setFromCamera(mv, C); var h = ray.intersectObjects(picks, true); if (!h.length || h[0].distance > 50) return null; var o = h[0].object; while (o && !o.userData.car) o = o.parent; return o; }
			function hover(e) { var o = cast(e); if (o !== hot) { hot = o; cv.style.cursor = hot ? 'pointer' : 'grab'; } }
			var card = $('[data-sr-card]', root), spin = $('[data-sr-spin]', root), modal = $('[data-sr-modal]', root), mstage = $('[data-sr-mstage]', root), viewer = null, curCar = null;
			function pick(e) {
				var g = cast(e); if (!g) return; var c = g.userData.car;
				if (teaser) { location.href = (PSR.showroom || '/showroom/'); return; }
				var dirTo = new T.Vector3(0, 0, 1).applyQuaternion(g.quaternion), wp = g.position;
				glide(new T.Vector3(wp.x + dirTo.x * 10, 1.75, wp.z + dirTo.z * 10), Math.atan2(dirTo.x, dirTo.z));
				showCard(c);
			}
			function showCard(c) {
				curCar = c; $('[data-sr-img]', card).src = c.img; $('[data-sr-make]', card).textContent = c.make; $('[data-sr-model]', card).textContent = c.model; $('[data-sr-tag]', card).textContent = c.tagline || '';
				$('[data-sr-specs]', card).innerHTML = [['Year', c.year], ['Engine', c.engine], ['Power', c.power], ['Torque', c.tq ? c.tq + ' Nm' : ''], ['0–100 km/h', c.acc ? c.acc.toFixed(1) + ' s' : ''], ['Top speed', c.vmax ? c.vmax + ' km/h' : ''], ['Weight', c.kg ? c.kg.toLocaleString() + ' kg' : ''], ['Gearbox', c.gear], ['Drive', c.drive], ['Fuel', c.fuel]].filter(function (r) { return r[1]; }).map(function (r) { return '<li><span>' + r[0] + '</span><b>' + esc(r[1]) + '</b></li>'; }).join('');
				$('[data-sr-link]', card).href = c.url; $('[data-sr-fav]', card).setAttribute('data-fav', c.id); $('[data-sr-cmp]', card).setAttribute('data-cmp', c.id);
				if (spin) spin.hidden = !c.glb; var rl = $('[data-sr-race]', card); if (rl) rl.href = (PSR.play || '/play/') + '#race=' + c.id;
				card.hidden = false; requestAnimationFrame(function () { card.classList.add('is-on'); });
			}
			function closeCard() { card.classList.remove('is-on'); setTimeout(function () { card.hidden = true; }, 350); }
			on($('[data-sr-close]', root), 'click', closeCard);
			var touring = null, tbtn = $('[data-sr-tour]', root);
			function stopTour() { if (!touring) return; clearTimeout(touring); touring = null; if (tbtn) { tbtn.textContent = '▶ Guided tour'; tbtn.setAttribute('aria-pressed', 'false'); } }
			function tourStep(i) {
				if (i >= slots.length) { stopTour(); closeCard(); glide(new T.Vector3(0, 1.65, 14), 0); return; }
				var g = slots[i].grp, dirTo = new T.Vector3(0, 0, 1).applyQuaternion(g.quaternion);
				glide(new T.Vector3(g.position.x + dirTo.x * 10, 1.75, g.position.z + dirTo.z * 10), Math.atan2(dirTo.x, dirTo.z));
				showCard(slots[i].c);
				touring = setTimeout(function () { tourStep(i + 1); }, 4200);
			}
			on(tbtn, 'click', function () { if (touring) { stopTour(); return; } tbtn.textContent = '■ Stop tour'; tbtn.setAttribute('aria-pressed', 'true'); tourStep(0); });
			on(cv, 'pointerdown', stopTour);
			var moodB = d.createElement('button'); moodB.type = 'button'; moodB.className = 'sr__mood'; var rb = $('[data-sr-reset]', root); rb.parentNode.insertBefore(moodB, rb.nextSibling);
			function moodLabel() { moodB.textContent = moodNow === 'night' ? '☀ Day hall' : '☾ Night hall'; moodB.setAttribute('aria-pressed', moodNow === 'night' ? 'true' : 'false'); }
			on(moodB, 'click', function () { setMood(moodNow === 'night' ? 'day' : 'night'); moodLabel(); });
			var savedMood = 'night'; try { savedMood = localStorage.getItem('psr-sr-mood') || 'night'; } catch (e) {} setMood(savedMood); moodLabel();
			on($('[data-sr-reset]', root), 'click', function () { closeCard(); if (!modal.hidden) { modal.hidden = true; if (viewer) { viewer.dispose(); viewer = null; } } pitch = .02; glide(new T.Vector3(0, 1.65, 14), 0); });
			on($('[data-sr-exit]', root), 'click', function (e) { if (d.fullscreenElement) { e.preventDefault(); d.exitFullscreen(); return; } try { var r = d.referrer && new URL(d.referrer); if (r && r.host === location.host && r.pathname !== location.pathname) { e.preventDefault(); history.back(); } } catch (x) {} });
			on(spin, 'click', function () { if (!curCar || !curCar.glb) return; modal.hidden = false; $('[data-sr-mcred]', root).textContent = curCar.m3d || ''; viewer = mountViewer(mstage, curCar.glb); });
			on($('[data-sr-mclose]', root), 'click', function () { modal.hidden = true; if (viewer) { viewer.dispose(); viewer = null; } });
			function size() { var r = root.getBoundingClientRect(); R.setSize(r.width, r.height, false); C.aspect = r.width / r.height; C.updateProjectionMatrix(); if (viewer) viewer.size(); }
			on(w, 'resize', size); size();
			var last = performance.now(), vis = true, tick = 0;
			if ('IntersectionObserver' in w) new IntersectionObserver(function (es) { vis = es[0].isIntersecting; }).observe(root);
			(function loop(now) {
				requestAnimationFrame(loop); if (!vis || !modal.hidden) return;
				var dt = Math.min(.05, (now - last) / 1000); last = now;
				var sp = 7 * dt;
				if (keys.w || keys.arrowup || keys.padf) move(sp, 0);
				if (keys.s || keys.arrowdown || keys.padb) move(-sp, 0);
				if (keys.a) move(0, -sp); if (keys.d) move(0, sp);
				if (keys.arrowleft || keys.padl) { yaw += 1.6 * dt; target = null; } if (keys.arrowright || keys.padr) { yaw -= 1.6 * dt; target = null; }
				if (target) { target.t = Math.min(1, target.t + dt / 1.2); var k = 1 - Math.pow(1 - target.t, 3); pos.lerpVectors(target.p0, target.p, k); var dy = target.y - target.y0; dy = Math.atan2(Math.sin(dy), Math.cos(dy)); yaw = target.y0 + dy * k; if (target.t >= 1) target = null; }
				if ((tick += dt) > .4) { tick = 0; stream(); }
				C.position.copy(pos); C.rotation.set(pitch, yaw, 0, 'YXZ');
				R.render(S, C);
			})(last);
			stream();
			/* mini-map */
			var mm = d.createElement('canvas'); mm.className = 'sr__map'; mm.width = 160; mm.height = 220; root.appendChild(mm); var mx = mm.getContext('2d');
			var zMin = zc - 4, zMax = 14;
			function mapY(z) { return 10 + (zMax - z) / (zMax - zMin) * 200; } function mapX(x) { return 80 + x / (W / 2) * 64; }
			on(mm, 'click', function (e) { var r = mm.getBoundingClientRect(), y = (e.clientY - r.top) / r.height * 220, z = zMax - (y - 10) / 200 * (zMax - zMin); glide(new T.Vector3(0, 1.65, z), 0); });
			setInterval(function () {
				mx.clearRect(0, 0, 160, 220); mx.fillStyle = 'rgba(20,20,22,.82)'; mx.fillRect(0, 0, 160, 220);
				mx.fillStyle = 'rgba(201,154,58,.25)'; mx.fillRect(mapX(-2.1), 10, mapX(2.1) - mapX(-2.1), 200);
				var near = null, nd = 1e9; bays.forEach(function (b) { var dz = Math.abs(pos.z - (b.z - 6)); if (dz < nd) { nd = dz; near = b; } mx.fillStyle = 'rgba(217,169,63,.55)'; mx.fillRect(18, mapY(b.z - 1), 10, 1.5); mx.fillRect(132, mapY(b.z - 1), 10, 1.5); });
				if (near) { mx.fillStyle = 'rgba(8,8,10,.85)'; mx.fillRect(0, 0, 160, 18); mx.fillStyle = '#f1d27a'; mx.font = '700 10px Manrope, sans-serif'; mx.textAlign = 'center'; mx.fillText(near.make.toUpperCase(), 80, 13); }
				slots.forEach(function (sl) { mx.fillStyle = sl.c.glb ? '#fff' : 'rgba(255,255,255,.4)'; mx.fillRect(mapX(sl.grp.position.x) - 3, mapY(sl.grp.position.z) - 2, 6, 4); });
				mx.save(); mx.translate(mapX(pos.x), mapY(pos.z)); mx.rotate(-yaw); mx.fillStyle = '#f1d27a'; mx.beginPath(); mx.moveTo(0, -7); mx.lineTo(5, 5); mx.lineTo(-5, 5); mx.closePath(); mx.fill(); mx.restore();
			}, 200);
		}
	}

	/* ------------------------------------------------------------ engine sound synth (user-started) */
	function engineSynth() {
		var AC = w.AudioContext || w.webkitAudioContext; if (!AC) return null;
		var ac = new AC(), out = ac.createGain(); out.gain.value = 0; out.connect(ac.destination);
		var lp = ac.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 900; lp.Q.value = 4; lp.connect(out);
		var o1 = ac.createOscillator(), o2 = ac.createOscillator(), o3 = ac.createOscillator(), g1 = ac.createGain(), g2 = ac.createGain(), g3 = ac.createGain();
		o1.type = 'sawtooth'; o2.type = 'square'; o3.type = 'triangle'; g1.gain.value = .5; g2.gain.value = .22; g3.gain.value = .3;
		o1.connect(g1).connect(lp); o2.connect(g2).connect(lp); o3.connect(g3).connect(lp);
		var lfo = ac.createOscillator(), lg = ac.createGain(); lfo.type = 'sine'; lfo.frequency.value = 12; lg.gain.value = .25; lfo.connect(lg).connect(g1.gain);
		[o1, o2, o3, lfo].forEach(function (o) { o.start(); });
		var api = {
			set: function (rpm, cyl, load) {
				var f = Math.max(18, rpm / 60 * cyl / 2), t = ac.currentTime;
				o1.frequency.setTargetAtTime(f, t, .05); o2.frequency.setTargetAtTime(f / 2, t, .05); o3.frequency.setTargetAtTime(f * 2, t, .05);
				lfo.frequency.setTargetAtTime(cyl >= 12 ? 3 : (cyl >= 8 ? rpm / 60 / 2 : 8), t, .1);
				lp.frequency.setTargetAtTime(500 + rpm / 7500 * 2600 * (load == null ? 1 : .6 + load * .6), t, .08);
			},
			on: function (v) { if (ac.state === 'suspended') ac.resume(); out.gain.setTargetAtTime(v ? .09 : 0, ac.currentTime, .08); },
			ac: ac, out: out
		};
		return api;
	}

	/* ------------------------------------------------------------ Engine simulator + turbo */
	var ENG = {
		4: { name: 'Inline-4', banks: 1, order: [0, 2, 3, 1], note: 'Four cylinders in a row fire every 180°. There are gaps between power strokes, which is why fours feel busier at idle.' },
		6: { name: 'V6', banks: 2, order: [0, 3, 1, 4, 2, 5], note: 'Six cylinders fire every 120°. Power strokes start to overlap, so it pulls more smoothly than a four.' },
		8: { name: 'V8', banks: 2, order: [0, 4, 3, 7, 5, 2, 6, 1], note: 'Eight cylinders fire every 90°: the deep, overlapping pulses behind the G 63 and Urus burble.' },
		12: { name: 'V12', banks: 2, order: [0, 6, 4, 10, 2, 8, 5, 11, 1, 7, 3, 9], note: 'Twelve cylinders fire every 60°. Power strokes always overlap, so there is never a gap: the Rolls-Royce silk.' }
	};
	/* ------------------------------------------------------------ 3D engine room */
	var E3 = {
		i4: { name: 'Inline-4', n: 4, banks: [0], per: 4, throws: [0, 180, 180, 0], fo: '1-3-4-2', iv: 180, match: /(^|[^0-9])(4[- ]?cyl|inline[- ]?4|four)/i, cars: 'Toyota RAV4, Harrier',
			say: 'Four cylinders in a row on a flat crank. One power stroke every 180° of rotation leaves small gaps between pulses, so fours sound busy and need balance shafts to stay smooth.', facts: ['Firing interval 180°', 'Cheapest and lightest layout', 'Second-order vibration needs balance shafts'] },
		v6: { name: 'V6 (60°)', n: 6, banks: [-30, 30], per: 3, throwsL: [0, 120, 240], throwsR: [60, 180, 300], fo: '1-2-3-4-5-6', iv: 120, match: /V6/i, cars: 'Land Cruiser 300, LX 600',
			say: 'Two banks of three, sixty degrees apart, on a split-pin crank so every cylinder fires exactly 120° after the last. Short enough to fit across or along the car, which is why it powers the Land Cruiser 300 and LX 600 as a twin-turbo.', facts: ['Firing interval 120°', 'Compact: two short banks', 'Split crankpins give even firing'] },
		f6: { name: 'Flat-6 (boxer)', n: 6, banks: [-90, 90], per: 3, throwsL: [0, 120, 240], throwsR: [180, 300, 60], fo: '1-6-2-4-3-5', iv: 120, match: /flat|boxer/i, cars: 'Porsche 911 Turbo S',
			say: 'Opposed pistons punch outwards like boxers, each pair cancelling the other’s shake. The engine sits low and short behind the rear axle of the 911, which is the root of its traction and its handling character.', facts: ['Firing interval 120°', 'Perfect primary and secondary balance', 'Very low centre of gravity'] },
		v8: { name: 'V8 (90° cross-plane)', n: 8, banks: [-45, 45], per: 4, throws: [0, 90, 270, 180], shared: 1, fo: '1-5-4-8-6-3-7-2', iv: 90, match: /V8/i, cars: 'G 63, Urus, Maybach GLS, DBX707, Bentayga',
			say: 'Two banks of four at ninety degrees share a cross-plane crank whose pins sit a quarter-turn apart. Uneven firing within each bank gives the classic offbeat burble; twin turbos usually sit inside the V (“hot-V”) for faster response.', facts: ['Firing interval 90°', 'Cross-plane crank: offbeat burble', 'Hot-V turbos in the G 63 and Urus'] },
		v12: { name: 'V12 (60°)', n: 12, banks: [-30, 30], per: 6, throws: [0, 240, 120, 120, 240, 0], shared: 1, fo: '1-7-5-11-3-9-6-12-2-8-4-10', iv: 60, match: /V12/i, cars: 'Cullinan, Ghost, Purosangue, Continental GT',
			say: 'Two inline-sixes married at sixty degrees. Each bank is perfectly balanced on its own, and with a power stroke every 60° there is always a cylinder pushing: the silk of a Rolls-Royce, the scream of a Ferrari.', facts: ['Firing interval 60°', 'Perfect balance, no shaking forces', 'Power strokes always overlap'] }
	};
	function e3build(T, key) {
		var L = E3[key], G = new T.Group(), crank = new T.Group(), parts = [], R = .26, ROD = .78, BORE = .5, SP = .62;
		var steel = new T.MeshStandardMaterial({ color: 0xbfc3c8, metalness: 1, roughness: .28 }), dark = new T.MeshStandardMaterial({ color: 0x3a3c40, metalness: .9, roughness: .4 });
		var gold = new T.MeshStandardMaterial({ color: 0xd9a93f, metalness: 1, roughness: .25 }), rodM = new T.MeshStandardMaterial({ color: 0x9aa0a8, metalness: 1, roughness: .35 });
		var glass = new T.MeshPhysicalMaterial({ color: 0xffffff, metalness: 0, roughness: .08, transmission: .9, transparent: true, opacity: .16, side: T.DoubleSide, depthWrite: false });
		var per = L.per, len = per * SP;
		/* crankshaft: main journal + webs + pins */
		var main = new T.Mesh(new T.CylinderGeometry(.09, .09, len + .9, 24), steel); main.rotation.z = Math.PI / 2; crank.add(main);
		var pins = [];
		for (var p = 0; p < per; p++) {
			var cx = (p - (per - 1) / 2) * SP, thr = L.shared || !L.throwsL ? L.throws[p] : null;
			var list = thr === null ? [[L.throwsL[p], -1], [L.throwsR[p], 1]] : [[thr, 0]];
			list.forEach(function (t) {
				var a = t[0] * Math.PI / 180, off = t[1] * .1, pin = new T.Mesh(new T.CylinderGeometry(.075, .075, thr === null ? .18 : .32, 20), steel);
				pin.rotation.z = Math.PI / 2; pin.position.set(cx + off, R * Math.cos(a), R * Math.sin(a)); crank.add(pin);
				[-1, 1].forEach(function (s) { var web = new T.Mesh(new T.BoxGeometry(.05, R + .22, .26), dark); web.position.set(cx + off + s * (thr === null ? .1 : .18), R * .5 * Math.cos(a), R * .5 * Math.sin(a)); web.rotation.x = a; crank.add(web);
					var cw = new T.Mesh(new T.CylinderGeometry(.2, .2, .05, 24, 1, false, 0, Math.PI), dark); cw.rotation.z = Math.PI / 2; cw.rotation.y = 0; cw.position.copy(web.position).setY(-.08 * Math.cos(a)).setZ(-.08 * Math.sin(a)); cw.rotation.x = a + Math.PI / 2; crank.add(cw); });
				pins.push({ a: t[0], x: cx + off });
			});
		}
		var fly = new T.Mesh(new T.CylinderGeometry(.55, .55, .07, 48), gold); fly.rotation.z = Math.PI / 2; fly.position.x = -(len / 2 + .5); crank.add(fly);
		var teeth = new T.Mesh(new T.TorusGeometry(.56, .025, 6, 80), steel); teeth.rotation.y = Math.PI / 2; teeth.position.x = fly.position.x; crank.add(teeth);
		var pul = new T.Mesh(new T.CylinderGeometry(.2, .2, .1, 32), dark); pul.rotation.z = Math.PI / 2; pul.position.x = len / 2 + .45; crank.add(pul);
		G.add(crank);
		/* cylinders */
		var banks = L.banks, cyl = [], idx = 0;
		banks.forEach(function (deg, b) {
			var al = deg * Math.PI / 180, dir = new T.Vector3(0, Math.cos(al), Math.sin(al));
			var head = new T.Group(); G.add(head);
			for (var p = 0; p < per; p++) {
				var pin = pins[L.shared || !L.throwsL ? p : p * 2 + b], throwDeg = pin.a, x = pin.x;
				var pist = new T.Group(), crown = new T.Mesh(new T.CylinderGeometry(BORE / 2 - .015, BORE / 2 - .015, .26, 32), steel); pist.add(crown);
				[.06, .02, -.02].forEach(function (yy) { var ring = new T.Mesh(new T.TorusGeometry(BORE / 2 - .012, .008, 6, 40), dark); ring.rotation.x = Math.PI / 2; ring.position.y = yy; pist.add(ring); });
				var rod = new T.Mesh(new T.BoxGeometry(.07, 1, .05), rodM), gas = new T.Mesh(new T.CylinderGeometry(BORE / 2 - .01, BORE / 2 - .01, 1, 32, 1, true), new T.MeshBasicMaterial({ color: 0x5aa9e6, transparent: true, opacity: .35, side: T.DoubleSide, depthWrite: false }));
				var top = R + ROD + .32, wall = new T.Mesh(new T.CylinderGeometry(BORE / 2 + .02, BORE / 2 + .02, 2 * R + .5, 32, 1, true), glass);
				var q = new T.Quaternion().setFromUnitVectors(new T.Vector3(0, 1, 0), dir);
				[pist, gas, wall].forEach(function (m) { m.quaternion.copy(q); });
				wall.position.copy(dir.clone().multiplyScalar(top - R - .25 + .12)).setX(x);
				var spark = new T.Mesh(new T.SphereGeometry(.07, 12, 12), new T.MeshBasicMaterial({ color: 0xfff1b8, transparent: true, opacity: 0 }));
				spark.position.copy(dir.clone().multiplyScalar(top + .02)).setX(x);
				var vI = new T.Mesh(new T.CylinderGeometry(.06, .06, .03, 16), new T.MeshStandardMaterial({ color: 0x5aa9e6, metalness: .6, roughness: .3 })), vE = vI.clone(); vE.material = new T.MeshStandardMaterial({ color: 0xb06a3a, metalness: .6, roughness: .3 });
				var side = new T.Vector3(1, 0, 0);
				[vI, vE].forEach(function (v, k) { v.quaternion.copy(q); var stem = new T.Mesh(new T.CylinderGeometry(.012, .012, .3, 6), steel); stem.position.y = .15; v.add(stem); v.userData.base = dir.clone().multiplyScalar(top + .05).setX(x + (k ? .12 : -.12)); v.position.copy(v.userData.base); head.add(v); });
				var cap = new T.Mesh(new T.BoxGeometry(SP * .9, .08, BORE + .1), new T.MeshStandardMaterial({ color: 0x2a2b30, metalness: .8, roughness: .35, transparent: true, opacity: .7 })); cap.quaternion.copy(q); cap.position.copy(dir.clone().multiplyScalar(top + .35)).setX(x); head.add(cap);
				var plug = new T.Mesh(new T.CylinderGeometry(.03, .03, .22, 8), gold); plug.quaternion.copy(q); plug.position.copy(dir.clone().multiplyScalar(top + .48)).setX(x); head.add(plug);
				G.add(pist); G.add(rod); G.add(gas); G.add(wall); G.add(spark);
				var tdc = ((deg - throwDeg) % 360 + 360) % 360;
				cyl.push({ x: x, dir: dir, al: al, thr: throwDeg * Math.PI / 180, pist: pist, rod: rod, gas: gas, spark: spark, vI: vI, vE: vE, top: top, tdc: tdc, b: b, p: p, num: 0 });
				idx++;
			}
			/* camshafts, running at half crank speed */
			[-.12, .12].forEach(function (o, k) { var cam = new T.Group(), shaft = new T.Mesh(new T.CylinderGeometry(.035, .035, len + .3, 10), steel); shaft.rotation.z = Math.PI / 2; cam.add(shaft);
				for (var c = 0; c < per; c++) { var lobe = new T.Mesh(new T.BoxGeometry(.05, .13, .07), k ? gold : steel); lobe.position.set((c - (per - 1) / 2) * SP + o, .045, 0); cam.add(lobe); }
				cam.position.copy(dir.clone().multiplyScalar(top + .62)); cam.position.x = 0; cam.userData.k = k; head.add(cam); head.userData.cams = (head.userData.cams || []).concat([cam]); });
			var cover = new T.Mesh(new T.BoxGeometry(len + .25, .12, BORE + .22), new T.MeshStandardMaterial({ color: 0x8a6420, metalness: 1, roughness: .3, transparent: true, opacity: .32, depthWrite: false }));
			cover.quaternion.setFromUnitVectors(new T.Vector3(0, 1, 0), dir); cover.position.copy(dir.clone().multiplyScalar(top + .78)); cover.userData.cover = 1; head.add(cover);
			head.userData.dir = dir.clone(); cyl.head = cyl.head || []; cyl.head.push(head);
		});
		/* firing: pair cylinders that share a TDC angle and put one on each crank turn */
		var seen = {};
		cyl.forEach(function (c) { var k = Math.round(c.tdc); c.fire = c.tdc + (seen[k] ? 360 : 0); seen[k] = 1; });
		cyl.slice().sort(function (a, b) { return a.fire - b.fire; }).forEach(function (c, i) { c.ord = i; });
		/* number cylinders bank by bank, front to back */
		var foA = L.fo.split('-').map(Number); cyl.forEach(function (c) { c.num = foA[c.ord]; });
		/* block: translucent sump and front cover */
		var sump = new T.Mesh(new T.BoxGeometry(len + .5, .5, 1.1), new T.MeshStandardMaterial({ color: 0x24252a, metalness: .7, roughness: .45, transparent: true, opacity: .35, depthWrite: false })); sump.position.y = -.42; sump.userData.cover = 1; G.add(sump);
		/* turbochargers + exhaust manifolds (turbo layouts), intake plenum */
		var turbos = new T.Group(), hotM = new T.MeshStandardMaterial({ color: 0x8a5a3a, metalness: .9, roughness: .35, emissive: 0x3a1000, emissiveIntensity: .4 }), coldM = new T.MeshStandardMaterial({ color: 0xc9ccd2, metalness: 1, roughness: .25 });
		function snail(pos, flip) { var tg = new T.Group(); var hs = new T.Mesh(new T.TorusGeometry(.2, .11, 12, 24), hotM); hs.rotation.y = Math.PI / 2; tg.add(hs); var cs = new T.Mesh(new T.TorusGeometry(.2, .11, 12, 24), coldM); cs.rotation.y = Math.PI / 2; cs.position.x = flip ? -.34 : .34; tg.add(cs);
			var core = new T.Mesh(new T.CylinderGeometry(.09, .09, .34, 12), gold); core.rotation.z = Math.PI / 2; core.position.x = flip ? -.17 : .17; tg.add(core); var wh = new T.Mesh(new T.CylinderGeometry(.13, .13, .04, 10), coldM); wh.rotation.z = Math.PI / 2; wh.position.x = flip ? -.34 : .34; wh.userData.spin = 1; tg.add(wh); tg.position.copy(pos); turbos.add(tg); return tg; }
		var turboKeys = { v6: 1, f6: 1, v8: 1, v12: 1 };
		if (turboKeys[key]) {
			if (key === 'f6') { [-1, 1].forEach(function (sd) { snail(new T.Vector3(-len / 2 - .55, -.25, sd * 1.25), sd < 0); }); }
			else if (key === 'v8') { [-1, 1].forEach(function (sd, i) { snail(new T.Vector3(sd * len / 4, R + ROD + .55, 0), i === 0); }); }
			else { (cyl.head || []).forEach(function (h, bi) { var dir = h.userData.dir, p = dir.clone().multiplyScalar(R + ROD + .1).add(dir.clone().cross(new T.Vector3(1, 0, 0)).normalize().multiplyScalar(bi ? -.5 : .5)); p.x = -len / 2 - .2; snail(p, true); }); }
			/* exhaust runners from every cylinder head toward its turbo */
			var pipeM = new T.MeshStandardMaterial({ color: 0x6b4a32, metalness: .85, roughness: .4 });
			cyl.forEach(function (c) { var tgt = null, best = 1e9; turbos.children.forEach(function (tb) { var dd = tb.position.distanceTo(c.dir.clone().multiplyScalar(c.top).setX(c.x)); if (dd < best) { best = dd; tgt = tb; } }); if (!tgt) return;
				var a = c.dir.clone().multiplyScalar(c.top + .1).setX(c.x), side = key === 'v8' ? c.dir.clone().multiplyScalar(-1) : new T.Vector3(0, 0, 0), b = tgt.position.clone(), mid = a.clone().add(b).multiplyScalar(.5).add(side.multiplyScalar(.15));
				var curve = new T.QuadraticBezierCurve3(a, mid, b); var tube = new T.Mesh(new T.TubeGeometry(curve, 12, .035, 6, false), pipeM); tube.userData.pipe = 1; turbos.add(tube); });
		}
		G.add(turbos); G.userData.turbos = turbos;
		if (L.banks.length === 2 && key !== 'f6') { var plen = new T.Mesh(new T.BoxGeometry(len + .1, .16, .42), new T.MeshStandardMaterial({ color: 0x1b1b1f, metalness: .6, roughness: .3 })); plen.position.y = R + ROD + (key === 'v8' ? .95 : 1.05); plen.userData.cover = 1; G.add(plen); var badge = new T.Mesh(new T.BoxGeometry(len * .5, .02, .2), gold); badge.position.y = plen.position.y + .09; badge.userData.cover = 1; G.add(badge); G.userData.plenum = [plen, badge]; }
		G.userData.sump = sump; G.userData.fly = fly;
		G.userData = { L: L, crank: crank, cyl: cyl, R: R, ROD: ROD, len: len };
		return G;
	}
	function e3pose(G, th, slowFx) {
		var u = G.userData, R = u.R, ROD = u.ROD, live = { p: 0, c: 0, i: 0, e: 0 }, firing = null;
		u.crank.rotation.x = th;
		u.cyl.forEach(function (c) {
			var beta = th + c.thr - c.al, s = R * Math.cos(beta) + Math.sqrt(ROD * ROD - Math.pow(R * Math.sin(beta), 2));
			var pinP = new w.THREE.Vector3(c.x, R * Math.cos(th + c.thr), R * Math.sin(th + c.thr)), pistP = c.dir.clone().multiplyScalar(s).setX(c.x);
			c.pist.position.copy(c.dir.clone().multiplyScalar(s + .13).setX(c.x));
			var mid = pinP.clone().add(pistP).multiplyScalar(.5); c.rod.position.copy(mid); c.rod.scale.y = pinP.distanceTo(pistP);
			c.rod.quaternion.setFromUnitVectors(new w.THREE.Vector3(0, 1, 0), pistP.clone().sub(pinP).normalize());
			var crownTop = s + .26, head = c.top, h = Math.max(.02, head - crownTop);
			c.gas.scale.y = h; c.gas.position.copy(c.dir.clone().multiplyScalar(crownTop + h / 2).setX(c.x));
			var ph = (((th * 180 / Math.PI - c.fire) % 720) + 720) % 720, st = ph < 180 ? 'p' : ph < 360 ? 'e' : ph < 540 ? 'i' : 'c'; live[st]++;
			var col = st === 'p' ? new w.THREE.Color().setHSL(.07 + ph / 180 * .03, 1, .62 - ph / 180 * .25) : st === 'e' ? new w.THREE.Color(0x77706a) : st === 'i' ? new w.THREE.Color(0x5aa9e6) : new w.THREE.Color(0x9fb4c8);
			c.gas.material.color.copy(col); c.gas.material.opacity = st === 'p' ? .85 - ph / 180 * .45 : st === 'c' ? .3 + (ph - 540) / 180 * .4 : .3;
			var sp = ph < 30 || ph > 712 ? 1 - Math.min(ph < 30 ? ph : 0, 30) / 30 : 0; c.spark.material.opacity = sp; c.spark.scale.setScalar(.6 + sp * 1.4);
			if (sp > .2) firing = c;
			var li = st === 'i' ? Math.sin((ph - 360) / 180 * Math.PI) : 0, le = st === 'e' ? Math.sin((ph - 180) / 180 * Math.PI) : 0;
			c.vI.position.copy(c.vI.userData.base.clone().sub(c.dir.clone().multiplyScalar(li * .09)));
			c.vE.position.copy(c.vE.userData.base.clone().sub(c.dir.clone().multiplyScalar(le * .09)));
			c.st = st; c.ph = ph;
		});
		(u.cyl.head || []).forEach(function (h) { (h.userData.cams || []).forEach(function (cm) { cm.rotation.x = th / 2 + (cm.userData.k ? Math.PI / 2 : 0); }); });
		if (u.turbos) u.turbos.children.forEach(function (tg) { tg.children.forEach(function (o) { if (o.userData.spin) o.rotation.x = th * 6; }); });
		return { live: live, firing: firing };
	}
	function engine3d(root) {
		var stage = $('[data-e3-stage]', root); if (!stage) return;
		var key = 'v8', rpm = 1200, slow = true, xray = false, th = 0, vis = false, started = false, snd = null, sndOn = false;
		var hud = $('[data-e3-hud]', root), fo = $('[data-e3-fo]', root), info = $('[data-e3-info]', root);
		function cars(L) { return index().filter(function (c) { return L.match.test(c.engine || '') || (key === 'f6' && /911/.test(c.model)) || (key === 'i4' && /RAV4|Harrier/.test(c.model)); }); }
		function panel() {
			var L = E3[key], list = cars(L);
			$$('[data-e3-lay]', root).forEach(function (b) { b.setAttribute('aria-pressed', b.getAttribute('data-e3-lay') === key ? 'true' : 'false'); });
			info.innerHTML = '<p class="lx-eyebrow">' + esc(L.name) + '</p><h3>' + esc({ i4: 'The everyday hero', v6: 'Compact muscle', f6: 'The boxer', v8: 'The burble', v12: 'The silk' }[key]) + '</h3><p>' + esc(L.say) + '</p>'
				+ '<ul class="e3__facts">' + L.facts.map(function (f) { return '<li>' + esc(f) + '</li>'; }).join('') + '</ul>'
				+ (E3PH[key] ? '<figure class="e3__photo"><img src="' + E3PH[key][0] + '" alt="' + esc(E3PH[key][1]) + '" loading="lazy"><figcaption><b>The real thing:</b> ' + esc(E3PH[key][1]) + '<small>Photo: ' + esc(E3PH[key][2]) + ', via Wikimedia Commons</small></figcaption></figure>' : '')
				+ '<dl class="e3__nums"><div><dt>Cylinders</dt><dd>' + L.n + '</dd></div><div><dt>Fires every</dt><dd>' + L.iv + '°</dd></div><div><dt>Firing order</dt><dd class="sm">' + L.fo + '</dd></div></dl>'
				+ (list.length ? '<p class="e3__in">In the showcase</p><div class="e3__cars">' + list.slice(0, 6).map(function (c) { return '<a href="' + esc(c.url) + '"><img src="' + esc(thumb(c)) + '" alt="" loading="lazy"><span>' + esc(c.model) + '<em>' + esc(c.engine || '') + '</em></span></a>'; }).join('') + '</div>' : '');
		}
		$$('[data-e3-lay]', root).forEach(function (b) { on(b, 'click', function () { key = b.getAttribute('data-e3-lay'); panel(); if (started) rebuild(); if (snd && sndOn) snd.set(rpm, E3[key].n); }); });
		var rr = $('[data-e3-rpm]', root); on(rr, 'input', function () { rpm = +rr.value; $('[data-e3-rpmv]', root).textContent = rpm.toLocaleString(); if (snd && sndOn) snd.set(rpm, E3[key].n); });
		on($('[data-e3-slow]', root), 'change', function (e) { slow = e.target.checked; });
		var exp = 0;
		function applyExp() { if (!eng) return; var u = eng.userData; (u.cyl.head || []).forEach(function (h) { h.position.copy(h.userData.dir).multiplyScalar(exp * 1.1); }); if (u.plenum) u.plenum.forEach(function (p) { if (p.userData.y0 == null) p.userData.y0 = p.position.y; p.position.y = p.userData.y0 + exp * 1.9; }); if (u.turbos) u.turbos.position.set(key === 'v8' ? 0 : -exp * 1.2, key === 'v8' ? exp * 1.6 : 0, 0); if (u.sump) u.sump.position.y = -.42 - exp * 1.1; }
		var ex = $('[data-e3-exp]', root); if (ex) on(ex, 'input', function () { exp = +ex.value / 100; applyExp(); });
		on($('[data-e3-xray]', root), 'change', function (e) { xray = e.target.checked; if (eng) eng.traverse(function (o) { if (o.userData && o.userData.cover) o.visible = !xray; }); });
		var sb = $('[data-e3-snd]', root);
		on(sb, 'click', function () { if (!snd) snd = engineSynth(); if (!snd) return; sndOn = !sndOn; snd.on(sndOn); snd.set(rpm, E3[key].n); sb.setAttribute('aria-pressed', sndOn); sb.textContent = sndOn ? '🔊 Sound on' : '🔈 Hear it'; });
		var hm = /engine=(i4|v6|f6|v8|v12)/.exec(location.hash); if (hm) key = hm[1];
		panel();
		var T, Rd, S, C, O, eng = null;
		function rebuild() {
			if (eng) { S.remove(eng); eng.traverse(function (o) { if (o.geometry) o.geometry.dispose(); }); }
			eng = e3build(T, key); S.add(eng); if (xray) eng.traverse(function (o) { if (o.userData && o.userData.cover) o.visible = false; }); applyExp();
			var L = E3[key]; fo.innerHTML = eng.userData.cyl.slice().sort(function (a, b) { return a.ord - b.ord; }).map(function (c) { return '<i data-n="' + c.num + '">' + c.num + '</i>'; }).join('');
			var span = Math.max(3.4, L.per * .62 + 2.2) * Math.max(1, 1.5 / (C.aspect || 1.5)); C.position.set(span * .95, span * .55, span * 1.05); O.target.set(0, .55, 0); O.update();
		}
		function start() {
			if (started) return; started = true; stage.classList.add('is-loading');
			load3D(function (err) {
				stage.classList.remove('is-loading'); if (err) { stage.classList.add('is-fail'); return; }
				T = w.THREE; var cv = d.createElement('canvas'); cv.className = 'e3__cv'; stage.insertBefore(cv, stage.firstChild);
				Rd = setupRenderer(cv, true); Rd.toneMappingExposure = 1; S = new T.Scene(); S.environment = studioEnv(Rd);
				S.add(new T.HemisphereLight(0xfff4e0, 0x202024, .6)); var dl = new T.DirectionalLight(0xffffff, 1.1); dl.position.set(4, 7, 5); S.add(dl);
				var warm = new T.PointLight(0xffb347, 0, 3); S.add(warm);
				C = new T.PerspectiveCamera(32, 1, .05, 100); O = new T.OrbitControls(C, cv); O.enableDamping = true; O.enablePan = false; O.minDistance = 2.2; O.maxDistance = 12;
				function size() { var r = stage.getBoundingClientRect(); Rd.setSize(r.width, r.height, false); C.aspect = r.width / Math.max(1, r.height); C.updateProjectionMatrix(); }
				size(); on(w, 'resize', size); rebuild();
				on($('[data-e3-reset]', root), 'click', function () { rebuild(); });
				var last = performance.now(), lastFire = null;
				(function loop(now) {
					requestAnimationFrame(loop); var dt = Math.min(.05, (now - last) / 1000); last = now; if (!vis) return;
					th += rpm / 60 * Math.PI * 2 * dt * (slow ? .02 : .2);
					var r = e3pose(eng, th % (Math.PI * 4));
					if (r.firing) { warm.position.copy(r.firing.spark.position); warm.intensity = 2.5; } else warm.intensity *= .85;
					if (r.firing && r.firing !== lastFire) { $$('i', fo).forEach(function (i) { i.classList.toggle('is-on', +i.getAttribute('data-n') === r.firing.num); }); lastFire = r.firing; }
					hud.innerHTML = '<span class="p">Power ' + r.live.p + '</span><span class="e">Exhaust ' + r.live.e + '</span><span class="i">Intake ' + r.live.i + '</span><span class="c">Compression ' + r.live.c + '</span><b>' + Math.floor((th * 180 / Math.PI) % 720) + '° of 720°</b>';
					O.update(); Rd.render(S, C);
				})(last);
			});
		}
		if ('IntersectionObserver' in w) new IntersectionObserver(function (es) { vis = es[0].isIntersecting; if (vis) start(); else if (snd && sndOn) { sndOn = false; snd.on(false); sb.setAttribute('aria-pressed', 'false'); sb.textContent = '🔈 Hear it'; } }, { rootMargin: '200px' }).observe(stage); else { vis = true; start(); }
	}
	/* ------------------------------------------------------------ Boost Lab: turbo physics you can feel */
	var BL = {
		na: { name: 'Naturally aspirated V12', car: 'like the Purosangue', tna: 716, peak: 6250, bmax: 0, tau: .01, thr: 0, e: 0, turbos: 0 },
		single: { name: 'Single big turbo', car: 'old-school tuner style', tna: 430, peak: 4500, bmax: 1.25, tau: 1.35, thr: 3200, e: 0, turbos: 1 },
		twin: { name: 'Twin-turbo V8 (hot-V)', car: 'like the Urus and G 63', tna: 430, peak: 4800, bmax: 1.0, tau: .55, thr: 1900, e: 0, turbos: 2 },
		hybrid: { name: 'Twin-turbo + 48V boost', car: 'like the 2024 G 63', tna: 430, peak: 4800, bmax: 1.0, tau: .55, thr: 1900, e: 250, turbos: 2 },
		eturbo: { name: 'Electric turbo', car: 'Formula 1 technology', tna: 430, peak: 4800, bmax: 1.05, tau: .14, thr: 900, e: 0, turbos: 1, et: 1 }
	};
	function boostLab(root) {
		var cv = $('[data-bl-cv]', root); if (!cv) return;
		var x = cv.getContext('2d'), key = 'twin', S = null, vis = false, hold = false, best = {}, snd = null, sndOn = false;
		var RAT = [4.71, 3.14, 2.11, 1.67, 1.29, 1.0, .84, .67], FIN = 3.2, RW = .37, M = 2250;
		function reset() { S = { t: 0, v: 0, g: 0, rpm: 900, b: -.55, sh: 0, shaft: 0, ang: 0, ang2: 0, hist: [], t100: 0, tboost: 0, bov: 0, parts: [], running: false, done: false }; }
		reset();
		function setKey(k) { key = k; reset(); $$('[data-bl-k]', root).forEach(function (b) { b.setAttribute('aria-pressed', b.getAttribute('data-bl-k') === k ? 'true' : 'false'); }); $('[data-bl-desc]', root).textContent = BL[k].name + ', ' + BL[k].car + '.'; msg('Hold the pedal to launch from a standstill. Let go any time.'); }
		function msg(t) { $('[data-bl-msg]', root).innerHTML = t; }
		$$('[data-bl-k]', root).forEach(function (b) { on(b, 'click', function () { setKey(b.getAttribute('data-bl-k')); }); });
		var ped = $('[data-bl-pedal]', root);
		function down(e) { if (e) e.preventDefault(); if (S.done) reset(); hold = true; S.running = true; ped.classList.add('is-on'); if (sndOn && snd) snd.on(true); }
		function up() { if (!hold) return; hold = false; ped.classList.remove('is-on'); }
		on(ped, 'pointerdown', down); ['pointerup', 'pointerleave', 'pointercancel'].forEach(function (ev) { on(ped, ev, up); });
		on(ped, 'keydown', function (e) { if (e.key === ' ' || e.key === 'Enter') down(e); }); on(ped, 'keyup', up);
		on($('[data-bl-reset]', root), 'click', function () { reset(); msg('Reset. Hold the pedal to launch.'); });
		var sb = $('[data-bl-snd]', root);
		on(sb, 'click', function () { if (!snd) snd = engineSynth(); if (!snd) return; sndOn = !sndOn; snd.on(sndOn); sb.setAttribute('aria-pressed', sndOn); sb.textContent = sndOn ? '🔊 Sound on' : '🔈 Sound'; });
		setKey('twin');
		function tq(rpm) { var L = BL[key], r = rpm / L.peak; return L.tna * Math.max(.45, Math.min(1, .55 + .9 * r - .45 * r * r)) * (rpm > 6900 ? .7 : 1); }
		function step(dt) {
			var L = BL[key], thr = hold ? 1 : 0;
			/* boost target rises once exhaust energy is there */
			var energy = Math.max(0, Math.min(1, (S.rpm - L.thr + 900) / 1400)) * thr, tgt = L.bmax ? (thr ? L.bmax * (L.et ? 1 : energy) : -.55) : (thr ? 0 : -.55);
			var tau = tgt > S.b ? L.tau * (1.25 - energy * .5) : .18; S.b += (tgt - S.b) * Math.min(1, dt / Math.max(.02, tau));
			if (!thr && S.b > .35 && L.bmax && !S.bov) { S.bov = .6; for (var i = 0; i < 40; i++) S.parts.push({ k: 'bov', x: 0, y: 0, vx: Math.random() * 2 - 1, vy: -Math.random() * 2, l: 1 }); }
			S.bov = Math.max(0, S.bov - dt);
			S.shaft = L.bmax ? Math.max(0, (S.b + .55) / (L.bmax + .55)) * 190000 : 0;
			var eTq = L.e && thr ? L.e * Math.max(0, 1 - Math.max(0, S.b) / L.bmax) : 0;
			var engT = thr ? tq(S.rpm) * (1 + Math.max(0, S.b) * (L.bmax ? .95 : 0)) + eTq : 0;
			if (S.sh > 0) { S.sh -= dt; engT = 0; }
			if (S.running && !S.done) {
				var ratio = RAT[S.g] * FIN, F = engT * ratio * .9 / RW, drag = .5 * 1.1 * .95 * S.v * S.v + .015 * M * 9.81;
				var a = Math.min((F - drag) / M, 1.05 * 9.81); if (!thr) a = -drag / M - (S.v > .3 ? .4 : 0);
				S.v = Math.max(0, S.v + a * dt); S.t += dt;
				var wheelRpm = S.v / (2 * Math.PI * RW) * 60, rr = wheelRpm * ratio;
				S.rpm = Math.max(thr ? 1600 + Math.max(0, 2600 - S.t * 3000) * 0 : 900, rr < 1200 && thr ? Math.max(rr, 2600 - (L.e ? 400 : 0)) : rr);
				if (S.rpm > 6800 && S.g < RAT.length - 1) { S.g++; S.sh = .14; }
				if (!S.t100 && S.v >= 27.78) { S.t100 = S.t; best[key] = Math.min(best[key] || 99, S.t); table(); msg('<b>0–100 km/h in ' + S.t.toFixed(2) + ' s.</b> ' + (L.bmax ? 'Full boost arrived after ' + (S.tboost || S.t).toFixed(2) + ' s.' : 'No turbo, no lag: torque was there the moment you pressed.')); }
				if (!S.tboost && L.bmax && S.b >= L.bmax * .92) S.tboost = S.t;
				if (S.v * 3.6 > 250 || (!thr && S.v < .2)) { S.done = true; S.running = false; }
				S.hist.push({ b: S.b, t: engT, v: S.v }); if (S.hist.length > 600) S.hist.shift();
			} else if (!S.running) { S.rpm += ((thr ? 3000 : 900) - S.rpm) * Math.min(1, dt * 3); }
			if (snd && sndOn) snd.set(S.rpm, 8, thr ? 1 : .25);
			S.ang += S.shaft / 60 * dt * .012; S.ang2 = S.ang;
			/* flow particles */
			var flow = (S.rpm / 7000) * (thr ? 1 : .25);
			if (L.bmax && Math.random() < flow * 1.6) S.parts.push({ k: 'ex', u: 0, l: 1, j: Math.random() });
			if (L.bmax && Math.random() < (Math.max(0, S.b + .55) / (L.bmax + .55)) * 1.8) S.parts.push({ k: 'air', u: 0, l: 1, j: Math.random() });
			S.parts.forEach(function (p) { if (p.k === 'bov') { p.x += p.vx * dt * 60; p.y += p.vy * dt * 60; p.l -= dt * 1.4; } else { p.u += dt * (.4 + flow * 1.2); if (p.u > 1) p.l = 0; } });
			S.parts = S.parts.filter(function (p) { return p.l > 0; }).slice(-260);
		}
		function table() {
			$('[data-bl-table]', root).innerHTML = Object.keys(BL).map(function (k) { var b = best[k]; return '<li class="' + (k === key ? 'is-cur' : '') + '"><span>' + esc(BL[k].name) + '</span><b>' + (b ? b.toFixed(2) + ' s' : '–') + '</b></li>'; }).join('');
		}
		table();
		/* ---------- drawing ---------- */
		function wheel(cx, cy, r, ang, blades, col, splitter) {
			x.save(); x.translate(cx, cy); x.rotate(ang);
			var g = x.createRadialGradient(0, 0, r * .1, 0, 0, r); g.addColorStop(0, '#f7f3ea'); g.addColorStop(1, col); x.fillStyle = 'rgba(0,0,0,.35)'; x.beginPath(); x.arc(0, 0, r, 0, 7); x.fill();
			for (var i = 0; i < blades * (splitter ? 2 : 1); i++) {
				var a = i / (blades * (splitter ? 2 : 1)) * Math.PI * 2, short = splitter && i % 2; x.save(); x.rotate(a);
				x.beginPath(); x.moveTo(r * (short ? .5 : .2), 0); x.quadraticCurveTo(r * .7, r * .18, r * .98, r * .32); x.lineTo(r * .98, r * .4); x.quadraticCurveTo(r * .62, r * .26, r * (short ? .5 : .2), r * .08); x.closePath(); x.fillStyle = g; x.fill(); x.restore();
			}
			x.fillStyle = '#2a2a2e'; x.beginPath(); x.arc(0, 0, r * .18, 0, 7); x.fill(); x.fillStyle = '#d9a93f'; x.beginPath(); x.arc(0, 0, r * .07, 0, 7); x.fill();
			x.restore();
		}
		function snail(cx, cy, r, hot, flip) {
			x.save(); x.translate(cx, cy); if (flip) x.scale(-1, 1);
			x.beginPath(); for (var a = 0; a <= Math.PI * 2.05; a += .05) { var rr = r * (1.15 + a / (Math.PI * 2) * .55); x.lineTo(Math.cos(a) * rr, Math.sin(a) * rr); }
			x.closePath();
			var g = x.createRadialGradient(0, 0, r, 0, 0, r * 1.8); g.addColorStop(0, hot > 0 ? 'rgba(255,' + Math.round(140 - hot * 60) + ',40,' + (.25 + hot * .5) + ')' : '#2b3440'); g.addColorStop(1, '#1a1a1d');
			x.fillStyle = g; x.fill(); x.strokeStyle = 'rgba(241,210,122,.45)'; x.lineWidth = 1.5; x.stroke();
			x.restore();
		}
		function dial(cx, cy, r, v, min, max, label, unit, red, fmt) {
			x.save(); x.translate(cx, cy);
			var g = x.createRadialGradient(0, -r * .3, r * .1, 0, 0, r); g.addColorStop(0, '#22201c'); g.addColorStop(1, '#0b0b0d'); x.fillStyle = g; x.beginPath(); x.arc(0, 0, r, 0, 7); x.fill();
			x.lineWidth = 2; x.strokeStyle = '#c99a3a'; x.beginPath(); x.arc(0, 0, r, 0, 7); x.stroke();
			var a0 = Math.PI * .75, a1 = Math.PI * 2.25;
			for (var i = 0; i <= 40; i++) { var k = i / 40, a = a0 + (a1 - a0) * k, big = i % 5 === 0, rv = min + (max - min) * k; x.strokeStyle = red !== null && rv >= red ? '#ff4d4d' : big ? '#f1d27a' : 'rgba(255,255,255,.35)'; x.lineWidth = big ? 2 : 1; x.beginPath(); x.moveTo(Math.cos(a) * r * (big ? .78 : .84), Math.sin(a) * r * (big ? .78 : .84)); x.lineTo(Math.cos(a) * r * .92, Math.sin(a) * r * .92); x.stroke();
				if (big && i % 10 === 0) { x.fillStyle = 'rgba(255,255,255,.7)'; x.font = '600 ' + Math.round(r * .13) + 'px Manrope, sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(fmt ? fmt(rv) : Math.round(rv), Math.cos(a) * r * .62, Math.sin(a) * r * .62); } }
			var k2 = Math.max(0, Math.min(1, (v - min) / (max - min))), an = a0 + (a1 - a0) * k2;
			x.shadowColor = 'rgba(255,90,40,.7)'; x.shadowBlur = 10; x.strokeStyle = '#ff5a28'; x.lineWidth = 3; x.beginPath(); x.moveTo(-Math.cos(an) * r * .12, -Math.sin(an) * r * .12); x.lineTo(Math.cos(an) * r * .86, Math.sin(an) * r * .86); x.stroke(); x.shadowBlur = 0;
			x.fillStyle = '#d9a93f'; x.beginPath(); x.arc(0, 0, r * .08, 0, 7); x.fill();
			x.fillStyle = '#fff'; x.font = '500 ' + Math.round(r * .3) + 'px "Cormorant Garamond", serif'; x.textAlign = 'center'; x.textBaseline = 'alphabetic'; x.fillText(fmt ? fmt(v) : Math.round(v), 0, r * .55);
			x.fillStyle = '#f1d27a'; x.font = '800 ' + Math.round(r * .1) + 'px Manrope, sans-serif'; x.fillText(label + (unit ? ' · ' + unit : ''), 0, r * .74);
			x.restore();
		}
		function draw() {
			var Wc = cv.clientWidth, Hc = cv.clientHeight, k = Math.min(2, w.devicePixelRatio || 1);
			if (cv.width !== Math.round(Wc * k)) { cv.width = Math.round(Wc * k); cv.height = Math.round(Hc * k); }
			x.setTransform(k, 0, 0, k, 0, 0); x.clearRect(0, 0, Wc, Hc);
			var L = BL[key], narrow = Wc < 640, tw = narrow ? Wc : Wc * .56, th = narrow ? Hc * .5 : Hc * .72;
			/* turbo cutaway */
			var r = Math.min(tw / 7.8, th / 5.6), cyT = th * .52, cxT = tw * .3, cxC = tw * .7, hot = Math.max(0, Math.min(1, S.rpm / 7000 * (hold ? 1 : .4)));
			x.fillStyle = 'rgba(241,210,122,.7)'; x.font = '800 10px Manrope, sans-serif'; x.textAlign = 'center';
			if (L.bmax) {
				var pw = r * .42;
				function pipe(x0, y0, x1, y1, c1, c2) { var g = x.createLinearGradient(x0, y0, x1, y1); g.addColorStop(0, c1); g.addColorStop(1, c2); x.strokeStyle = g; x.lineWidth = pw; x.lineCap = 'round'; x.beginPath(); x.moveTo(x0, y0); x.lineTo(x1, y1); x.stroke(); x.lineWidth = 1; x.strokeStyle = 'rgba(241,210,122,.35)'; }
				function tag(t, px, py, al) { x.font = '800 9.5px Manrope, sans-serif'; x.textAlign = al || 'center'; x.fillStyle = 'rgba(255,255,255,.78)'; x.fillText(t, px, py); }
				pipe(cxT - r * .9, cyT + r * 2.4, cxT - r * .9, cyT + r * 1.1, 'rgba(120,40,10,.6)', 'rgba(255,' + Math.round(150 - hot * 70) + ',40,' + (.35 + hot * .55) + ')');
				pipe(cxT - r * .2, cyT, cxT - r * 2.3, cyT, 'rgba(90,80,70,.8)', 'rgba(60,60,64,.2)');
				pipe(cxC + r * .2, cyT, cxC + r * 2.3, cyT, 'rgba(90,160,230,.55)', 'rgba(60,80,110,.15)');
				pipe(cxC + r * .9, cyT - r * 1.1, cxC + r * .9, cyT - r * 2.45, 'rgba(120,190,255,' + (.3 + Math.max(0, S.b) * .45) + ')', 'rgba(60,110,170,.25)');
				tag('FROM EXHAUST MANIFOLD', cxT - r * .9, cyT + r * 2.65); tag('EXHAUST', cxT - r * 2.25, cyT + pw * 1.25, 'left'); tag('OUT', cxT - r * 2.25, cyT + pw * 1.25 + 11, 'left'); tag('FRESH', cxC + r * 2.25, cyT + pw * 1.25, 'right'); tag('AIR IN', cxC + r * 2.25, cyT + pw * 1.25 + 11, 'right'); tag('TO INTERCOOLER → ENGINE', cxC + r * .9, cyT - r * 2.6);
				snail(cxT, cyT, r, hot, false); snail(cxC, cyT, r, 0, true);
				x.fillStyle = '#3a3b40'; x.fillRect(cxT, cyT - r * .14, cxC - cxT, r * .28); x.fillStyle = 'rgba(217,169,63,.8)'; x.fillRect(cxT + (cxC - cxT) * .4, cyT - r * .22, (cxC - cxT) * .2, r * .44);
				wheel(cxT, cyT, r * .95, S.ang, 11, '#ff9a3c', false); wheel(cxC, cyT, r * .95, -S.ang2, 7, '#9fc6e8', true);
				if (L.et) { x.strokeStyle = '#7fb4ff'; x.lineWidth = 2; x.setLineDash([4, 4]); x.strokeRect(cxT + (cxC - cxT) * .38, cyT - r * .32, (cxC - cxT) * .24, r * .64); x.setLineDash([]); x.fillStyle = '#7fb4ff'; x.fillText('E-MOTOR', (cxT + cxC) / 2, cyT - r * .42); }
				x.fillStyle = 'rgba(255,255,255,.8)'; x.font = '800 10px Manrope, sans-serif'; x.fillText('TURBINE · EXHAUST SIDE', cxT + r * .4, cyT + r * 2.05); x.fillText('COMPRESSOR · INTAKE SIDE', cxC, cyT + r * 2.05);
				x.font = '500 ' + Math.round(r * .42) + 'px "Cormorant Garamond", serif'; x.fillStyle = '#fff'; x.fillText(Math.round(S.shaft / 1000) + 'k rpm', (cxT + cxC) / 2, cyT - r * 1.45);
				x.font = '800 9px Manrope, sans-serif'; x.fillStyle = 'rgba(241,210,122,.85)'; x.fillText('TURBO SHAFT SPEED', (cxT + cxC) / 2, cyT - r * 1.25);
				/* particles */
				S.parts.forEach(function (p) {
					var px, py;
					if (p.k === 'ex') { var a = Math.PI * 2.05 * (1 - p.u), rr = r * (1.15 + (1 - p.u) * .55) * (.92 + p.j * .12); px = cxT + Math.cos(a) * rr * (p.u > .85 ? (1 - (p.u - .85) * 4) : 1); py = cyT + Math.sin(a) * rr; x.fillStyle = 'rgba(255,' + Math.round(150 + p.j * 60) + ',60,' + (.9 - p.u * .5) + ')'; }
					else if (p.k === 'air') { var a2 = Math.PI * 2.05 * p.u, rr2 = r * (1.15 + p.u * .55) * (.92 + p.j * .12); px = cxC - Math.cos(a2) * rr2; py = cyT + Math.sin(a2) * rr2; x.fillStyle = 'rgba(140,200,255,' + (.5 + p.u * .45) + ')'; }
					else { px = cxC + r * 1.5 + p.x; py = cyT - r * 1.3 + p.y; x.fillStyle = 'rgba(255,255,255,' + p.l * .7 + ')'; }
					x.beginPath(); x.arc(px, py, p.k === 'bov' ? 3 : 2.2, 0, 7); x.fill();
				});
				if (S.bov > 0) { x.fillStyle = 'rgba(255,255,255,' + Math.min(1, S.bov * 2) + ')'; x.font = '800 12px Manrope, sans-serif'; x.fillText('PSSHH · blow-off valve', cxC + r * 1.5, cyT - r * 1.75); }
			} else {
				x.fillStyle = 'rgba(255,255,255,.85)'; x.font = '500 ' + Math.round(r * .55) + 'px "Cormorant Garamond", serif'; x.fillText('No turbo here', tw / 2, cyT - 6);
				x.font = '400 13px Manrope, sans-serif'; x.fillStyle = 'rgba(255,255,255,.62)'; x.fillText('The V12 breathes on its own: instant response, but it', tw / 2, cyT + 22); x.fillText('needs 6.5 litres and 9,000 rpm to make its power.', tw / 2, cyT + 40);
			}
			/* dials */
			var dx = narrow ? 0 : tw, dw = narrow ? Wc : Wc - tw, dy = narrow ? th : 0, dh = narrow ? Hc * .26 : th, dr = Math.min(dw / 7.1, dh / 2.6);
			dial(dx + dw * .2, dy + dh * .5, dr, S.rpm / 1000, 0, 8, 'RPM', 'x1000', 6.8, function (v) { return v.toFixed(v < 10 && v % 1 ? 1 : 0); });
			dial(dx + dw * .5, dy + dh * .5, dr * 1.18, S.v * 3.6, 0, 280, 'KM/H', '', null);
			dial(dx + dw * .8, dy + dh * .5, dr, S.b, -1, 1.5, 'BOOST', 'bar', null, function (v) { return v.toFixed(1); });
			x.fillStyle = 'rgba(255,255,255,.75)'; x.font = '700 11px Manrope, sans-serif'; x.textAlign = 'center'; x.fillText('GEAR ' + (S.g + 1) + (S.sh > 0 ? ' · SHIFT' : '') + '   ·   ' + S.t.toFixed(2) + ' s', dx + dw * .5, dy + dh * .5 + dr * 1.42);
			/* trace */
			var gy = narrow ? Hc * .78 : th + 10, gh = Hc - gy - 12, gx0 = 14, gw = Wc - 28;
			x.strokeStyle = 'rgba(255,255,255,.08)'; x.lineWidth = 1; x.strokeRect(gx0, gy, gw, gh);
			[['b', '#f1d27a', -1, 1.5, 'boost'], ['t', '#ff7a45', 0, 1500, 'engine torque'], ['v', '#7fb4ff', 0, 70, 'speed']].forEach(function (s, si) {
				x.strokeStyle = s[1]; x.lineWidth = 2; x.beginPath();
				S.hist.forEach(function (h, i) { var px = gx0 + i / 600 * gw, py = gy + gh - (h[s[0]] - s[2]) / (s[3] - s[2]) * gh; if (i) x.lineTo(px, py); else x.moveTo(px, py); }); x.stroke();
				x.fillStyle = s[1]; x.font = '700 10px Manrope, sans-serif'; x.textAlign = 'left'; x.fillText('— ' + s[4], gx0 + 8 + si * 110, gy + 14);
			});
		}
		var last = performance.now();
		(function loop(now) { requestAnimationFrame(loop); var dt = Math.min(.04, (now - last) / 1000); last = now; if (!vis) return; step(dt); draw(); })(last);
		if ('IntersectionObserver' in w) new IntersectionObserver(function (es) { vis = es[0].isIntersecting; if (!vis && snd && sndOn) { sndOn = false; snd.on(false); sb.setAttribute('aria-pressed', 'false'); sb.textContent = '🔈 Sound'; } }).observe(root); else vis = true;
	}
	function engine(root) {
		var snd = null, sndOn = false;
		engine3d(root);
		var bl = $('[data-psr-boost]', root); if (bl) boostLab(bl);
		var eqEl = $('[data-eq]', root); if (eqEl) earTest(eqEl);
	}

	/* ------------------------------------------------------------ Race simulator */
	var FLIP = { 13: 1, 14: 1, 15: 1 }; /* models whose nose points the other way */
	function isFlip(c) { return !!(c && (FLIP[c.id] || c.fl)); }
	var CONDS = {
		dry: { name: 'Dry tarmac', mu: 1.0, crr: .013, rho: 1.2, pw: 1, road: 0x2b2b2e, ground: 0x587a3a, sky: [0x5f9fe0, 0xd6e8f5], fx: '' },
		wet: { name: 'Wet tarmac', mu: .68, crr: .016, rho: 1.2, pw: 1, road: 0x1d1f23, ground: 0x4c5a3c, sky: [0x5d6670, 0xa6adb3], fx: 'rain' },
		gravel: { name: 'Gravel', mu: .55, crr: .045, rho: 1.2, pw: 1, road: 0x8a7458, ground: 0x9a8a62, sky: [0xb8cfe0, 0xf3e8d2], fx: 'dust' },
		snow: { name: 'Snow', mu: .3, crr: .03, rho: 1.25, pw: 1, road: 0xd9dee3, ground: 0xf1f4f6, sky: [0xc6d0d8, 0xf4f6f8], fx: 'snow' },
		nairobi: { name: 'Nairobi altitude', mu: 1.0, crr: .013, rho: 1.0, pw: .82, turbo: .96, road: 0x2b2b2e, ground: 0x8a7a45, sky: [0x4d95e0, 0xf0e6cf], fx: '' },
		night: { name: 'Night', mu: .98, crr: .013, rho: 1.22, pw: 1.01, road: 0x1b1b1e, ground: 0x1d2414, sky: [0x05070d, 0x1b2236], fx: 'night' },
		hot: { name: 'Hot day 40°C', mu: .97, crr: .014, rho: 1.11, pw: .93, turbo: .95, road: 0x333336, ground: 0xb59a62, sky: [0xa6cfee, 0xfff2d6], fx: 'haze' }
	};
	var DIST = { '100': { name: '0–100 km/h', m: 0, v: 100 / 3.6 }, '400': { name: 'Quarter mile (402 m)', m: 402 }, '1000': { name: '1 km sprint', m: 1000 }, '80': { name: 'Overtake 80–120 km/h', m: 0, v: 120 / 3.6, v0: 80 / 3.6 } };
	function carSpec(c) {
		var hp = c.hp || 200, kg = c.kg || ({ SUV: 2300, Sedan: 1950, Coupe: 1800 })[c.body] || 2100;
		var drive = /all|4wd|awd|4matic|four/i.test(c.drive || '') ? 'awd' : (/front/i.test(c.drive || '') ? 'fwd' : 'rwd');
		if (/911|purosangue|urus|dbx|continental|bentayga|cullinan|ghost/i.test(c.model) && drive === 'rwd') drive = 'awd';
		var turbo = /turbo|biturbo|twin/i.test(c.engine || '');
		var cda = c.body === 'SUV' ? 1.05 : (c.body === 'Sedan' ? .66 : .62);
		var vmax = (c.vmax || (c.body === 'SUV' ? 210 : 250)) / 3.6;
		return { c: c, hp: hp, kg: kg + 90, drive: drive, turbo: turbo, cda: cda, vmax: vmax, tq: c.tq || hp * 1.6, acc: c.acc || 0, k: 1, dsg: /dual|pdk|dct|tct|wet-clutch/i.test(c.gear || '') };
	}
	function simulate(sp, cond, dist, dt) {
		var g = 9.81, m = sp.kg, v = dist.v0 || 0, x = 0, t = 0, out = [], pw = sp.turbo ? (cond.turbo || cond.pw) : cond.pw;
		var P = sp.hp * 745.7 * pw * sp.k, frac = sp.drive === 'awd' ? 1 : (sp.drive === 'fwd' ? .58 : .55);
		var Ftr = cond.mu * 1.12 * g * m * frac, Flow = sp.tq * 13.5 / .36 * pw * sp.k, shifts = [55, 95, 135, 175, 215, 255].map(function (s) { return s / 3.6; }), si = 0, shiftT = 0;
		var react = dist.v0 ? 0 : .18;
		while (t < 60) {
			t += dt;
			if (t < react) { out.push([t, 0, 0]); continue; }
			var F = Math.min(P / Math.max(v, 1.5), Flow, Ftr);
			if (shiftT > 0) { shiftT -= dt; F *= .15; }
			while (si < shifts.length && v > shifts[si] && dist.v0 && t < .05) si++;
			if (si < shifts.length && v > shifts[si]) { shiftT = sp.dsg ? .06 : .16; si++; }
			if (v >= sp.vmax) F = Math.min(F, .5 * cond.rho * sp.cda * v * v + cond.crr * m * g);
			var a = (F - .5 * cond.rho * sp.cda * v * v - cond.crr * m * g) / m;
			v = Math.max(0, v + a * dt); x += v * dt; out.push([t, x, v, (F >= Ftr * .999 && shiftT <= 0) ? 1 : 0]);
			if (dist.v && v >= dist.v) break;
			if (dist.m && x >= dist.m) break;
		}
		return out;
	}
	function calibrate(sp) {
		if (!sp.acc) return;
		for (var it = 0; it < 6; it++) { var r = simulate(sp, CONDS.dry, DIST['100'], .01), tt = r[r.length - 1][0] - .18; sp.k *= Math.pow(tt / sp.acc, 1.15); }
	}
	function race(root) {
		var cars = index().filter(function (c) { return c.hp; });
		if (cars.length < 2) return;
		var selA = $('[data-race-a]', root), selB = $('[data-race-b]', root), cond = 'dry', dist = '400';
		var opts = grp(cars, function (c) { return '<option value="' + c.id + '">' + esc(cname(c)) + ' · ' + c.hp + ' hp</option>'; });
		selA.innerHTML = opts; selB.innerHTML = opts;
		var h = parseHash ? parseHash() : {}; var pre = (h.race || '').split(',');
		selA.value = pre[0] || (cars.find(function (c) { return /urus/i.test(c.model); }) || cars[0]).id;
		selB.value = pre[1] || (cars.find(function (c) { return /g 63/i.test(c.model); }) || cars[1]).id;
		function cardFor(sel, el) { var c = byId(+sel.value); if (!c) return; el.innerHTML = '<img src="' + esc(c.img) + '" alt=""><span><small>' + esc(c.make) + '</small><b>' + esc(c.model) + '</b><em>' + [c.hp + ' hp', c.tq ? c.tq + ' Nm' : '', c.kg ? c.kg + ' kg' : '', c.acc ? '0–100 ' + c.acc + ' s' : ''].filter(Boolean).join(' · ') + '</em></span>' + (c.glb ? '<i>3D</i>' : ''); }
		var ca = $('[data-race-ca]', root), cb = $('[data-race-cb]', root);
		on(selA, 'change', function () { cardFor(selA, ca); }); on(selB, 'change', function () { cardFor(selB, cb); });
		cardFor(selA, ca); cardFor(selB, cb);
		$$('[data-cond]', root).forEach(function (b) { on(b, 'click', function () { cond = b.getAttribute('data-cond'); $$('[data-cond]', root).forEach(function (x) { x.setAttribute('aria-pressed', x === b ? 'true' : 'false'); }); if (scene) scene.setCond(CONDS[cond]); }); });
		$$('[data-dist]', root).forEach(function (b) { on(b, 'click', function () { dist = b.getAttribute('data-dist'); $$('[data-dist]', root).forEach(function (x) { x.setAttribute('aria-pressed', x === b ? 'true' : 'false'); }); }); });
		on($('[data-race-swap]', root), 'click', function () { var t = selA.value; selA.value = selB.value; selB.value = t; cardFor(selA, ca); cardFor(selB, cb); if (typeof callLabels === 'function') callLabels(); });
		on($('[data-race-rand]', root), 'click', function () { var a = cars[Math.floor(Math.random() * cars.length)], b; do { b = cars[Math.floor(Math.random() * cars.length)]; } while (b === a); selA.value = a.id; selB.value = b.id; cardFor(selA, ca); cardFor(selB, cb); callLabels(); });
		var stage = $('[data-race-stage]', root), hud = $('[data-race-hud]', root), res = $('[data-race-res]', root), go = $('[data-race-go]', root), scene = null, running = false;
		/* call the winner before the lights */
		var call = '', callBar = d.createElement('div'); callBar.className = 'rc__call'; callBar.innerHTML = '<span>Your call</span><button type="button" data-call="a" aria-pressed="false"></button><button type="button" data-call="b" aria-pressed="false"></button><em data-call-rec></em>'; go.parentNode.insertBefore(callBar, go);
		function calls() { try { return JSON.parse(localStorage.getItem('psr-race-calls') || '{"r":0,"n":0}'); } catch (e) { return { r: 0, n: 0 }; } }
		function callLabels() { var A = byId(+selA.value), B = byId(+selB.value); $('[data-call="a"]', callBar).textContent = A ? A.model : 'Lane 1'; $('[data-call="b"]', callBar).textContent = B ? B.model : 'Lane 2'; var k = calls(); $('[data-call-rec]', callBar).textContent = k.n ? k.r + ' of ' + k.n + ' called right' : 'optional'; call = ''; $$('[data-call]', callBar).forEach(function (x) { x.setAttribute('aria-pressed', 'false'); }); }
		$$('[data-call]', callBar).forEach(function (b) { on(b, 'click', function () { call = call === b.getAttribute('data-call') ? '' : b.getAttribute('data-call'); $$('[data-call]', callBar).forEach(function (x) { x.setAttribute('aria-pressed', x.getAttribute('data-call') === call ? 'true' : 'false'); }); FX.play('tick'); }); });
		on(selA, 'change', callLabels); on(selB, 'change', callLabels); callLabels();
		var curCam = 'chase', camBar = d.createElement('div'); camBar.className = 'rc__cams'; camBar.innerHTML = '<button type="button" data-cam="chase" aria-pressed="true">Chase</button><button type="button" data-cam="side" aria-pressed="false">Trackside</button><button type="button" data-cam="heli" aria-pressed="false">Helicopter</button><button type="button" data-cam="nose" aria-pressed="false">Head-on</button>'; stage.appendChild(camBar);
		$$('[data-cam]', camBar).forEach(function (b) { on(b, 'click', function () { $$('[data-cam]', camBar).forEach(function (x) { x.setAttribute('aria-pressed', x === b ? 'true' : 'false'); }); curCam = b.getAttribute('data-cam'); if (scene) scene.cam(curCam); }); });
		function ensureScene(cb) { if (scene) return cb(); stage.classList.add('is-loading'); load3D(function (err) { stage.classList.remove('is-loading'); if (err) { stage.innerHTML = '<p class="rc__err">3D needs a newer browser. Results still work below.</p>'; return cb(); } scene = buildScene(stage); scene.setCond(CONDS[cond]); scene.cam(curCam); cb(); }); }
		if ('IntersectionObserver' in w) { var io = new IntersectionObserver(function (es) { if (es[0].isIntersecting) { io.disconnect(); ensureScene(function () { /* fetch both lanes' cars in the background so the lights come on without a wait */ if (navigator.connection && navigator.connection.saveData) return; [selA, selB].forEach(function (sl) { var c0 = byId(+sl.value); if (c0 && c0.glb) loadModel(c0.glb, function () {}); }); }); } }, { rootMargin: '200px' }); io.observe(stage); }
		on(go, 'click', function () {
			if (running) return; var A = byId(+selA.value), B = byId(+selB.value); if (!A || !B) return;
			running = true; go.disabled = true; res.hidden = true; root.__call = call;
			/* bring the track into view when the lights start, if the button sits above it */ try { var sr = stage.getBoundingClientRect(), vh = w.innerHeight; if (sr.top < 60 || sr.bottom > vh) w.scrollBy({ top: sr.top - Math.max(165, (vh - sr.height) / 2), behavior: 'smooth' }); } catch (e) {}
			var mb = $('[data-race-mute]', root); if (mb && mb.getAttribute('aria-pressed') !== 'true') { if (!root.__syn) root.__syn = engineSynth(); if (root.__syn) root.__syn.ac.resume(); }
			var sa = carSpec(A), sb = carSpec(B); calibrate(sa); calibrate(sb);
			var C = CONDS[cond], D = DIST[dist];
			var ra = simulate(sa, C, D, 1 / 60), rb = simulate(sb, C, D, 1 / 60);
			ensureScene(function () {
				var ld = d.createElement('div'); ld.className = 'rc__loading'; ld.innerHTML = '<span class="sr__ring"></span><b>Bringing the cars to the line…</b><i><em></em></i><small></small>'; stage.appendChild(ld);
				var lt = setInterval(function () { var p = ((A.glb ? modelPct(A.glb) : 1) + (B.glb ? modelPct(B.glb) : 1)) / 2; $('em', ld).style.width = Math.round(p * 100) + '%'; $('small', ld).textContent = Math.round(p * 100) + '% · first load can take a few seconds on mobile data'; if (p >= 1) { clearInterval(lt); ld.remove(); } }, 150);
				if (scene) scene.load(A, B, function () { clearInterval(lt); ld.remove(); countdown(function () { play(ra, rb, A, B, sa, sb, C, D); }); }, D); else { show(ra, rb, A, B, sa, sb, C, D); }
			});
		});
		function countdown(cb) {
			var L = $('[data-race-lights]', root); L.hidden = false; var dots = $$('i', L); dots.forEach(function (d) { d.className = ''; });
			var n = 0; var t = setInterval(function () { if (n < 3) { dots[n].className = 'r'; n++; FX.play('beep'); } else { clearInterval(t); FX.play('go'); dots.forEach(function (d) { d.className = 'g'; }); setTimeout(function () { L.hidden = true; }, 600); cb(); } }, 650);
		}
		function play(ra, rb, A, B, sa, sb, C, D) {
			var T = Math.max(ra[ra.length - 1][0], rb[rb.length - 1][0]) + .8, t0 = performance.now(), slow = D.v ? 1 : 1;
			var spA = $('[data-hud-a]', hud), spB = $('[data-hud-b]', hud), clk = $('[data-hud-t]', hud);
			$('[data-hud-na]', hud).textContent = A.model; $('[data-hud-nb]', hud).textContent = B.model; hud.hidden = false;
			var mute = $('[data-race-mute]', root), syn = (mute && mute.getAttribute('aria-pressed') !== 'true') ? (root.__syn || (root.__syn = engineSynth())) : null, cylA = /v12|w12/i.test(A.engine || '') ? 12 : (/v8/i.test(A.engine || '') ? 8 : 6);
			if (syn) syn.on(true);
			function at(r, t) { var i = Math.min(r.length - 1, Math.max(0, Math.round(t * 60))); return r[i]; }
			function gforce(r, t) { var i = Math.round(t * 60); if (i >= r.length) return 0; var j = Math.max(0, i - 6); if (i <= j) return 0; return (r[i][2] - r[j][2]) / ((i - j) / 60) / 9.81; }
			function gearOf(v) { var k = v * 3.6, g = 1; [55, 95, 135, 175, 215, 255].forEach(function (s) { if (k > s) g++; }); return g; }
			var teA = $('[data-hud-ga]', hud), teB = $('[data-hud-gb]', hud);
			(function f(now) {
				var t = (now - t0) / 1000 * slow; var a = at(ra, t), b = at(rb, t);
				if (scene) scene.frame(a[1], b[1], a[2], b[2]);
				spA.textContent = Math.round(a[2] * 3.6); spB.textContent = Math.round(b[2] * 3.6); clk.textContent = Math.min(t, T).toFixed(2) + ' s';
				var ga = gforce(ra, t), gb = gforce(rb, t); if (teA) teA.textContent = 'Gear ' + gearOf(a[2]) + ' · ' + Math.max(0, ga).toFixed(2) + ' g' + (a[3] && t < 2.5 ? ' · wheelspin' : ''); if (teB) teB.textContent = 'Gear ' + gearOf(b[2]) + ' · ' + Math.max(0, gb).toFixed(2) + ' g' + (b[3] && t < 2.5 ? ' · wheelspin' : '');
				if (scene && scene.dyn) scene.dyn(ga, gb, t < 2.5 ? a[3] : 0, t < 2.5 ? b[3] : 0);
				if (syn) { var gearV = [0, 55, 95, 135, 175, 215, 255], kmh = a[2] * 3.6, gi = 1; while (gi < gearV.length - 1 && kmh > gearV[gi]) gi++; var lo = gearV[gi - 1], hi = gearV[gi], rp = 2200 + (kmh - lo) / Math.max(1, hi - lo) * 4600; syn.set(t < .2 ? 1200 : rp, cylA, 1); }
				if (t < T) requestAnimationFrame(f); else { if (syn) syn.on(false); show(ra, rb, A, B, sa, sb, C, D); }
			})(t0);
		}
		function show(ra, rb, A, B, sa, sb, C, D) {
			running = false; go.disabled = false; callLabels();
			var ta = ra[ra.length - 1][0] - .18, tb = rb[rb.length - 1][0] - .18, wA = ta <= tb, gap = Math.abs(ta - tb);
			var W = wA ? A : B;
			var trapA = Math.round(ra[ra.length - 1][2] * 3.6), trapB = Math.round(rb[rb.length - 1][2] * 3.6);
			var callTxt = '', myCall = root.__call || ''; root.__call = ''; if (myCall) { var right = (myCall === 'a') === (W === A), k = calls(); k.n++; if (right) k.r++; try { localStorage.setItem('psr-race-calls', JSON.stringify(k)); } catch (e) {} var rec0 = $('[data-call-rec]', root); if (rec0) rec0.textContent = k.r + ' of ' + k.n + ' called right'; callTxt = right ? ' · <b class="rc__called">You called it.</b>' : ' · <b class="rc__miss">Your call missed.</b>'; if (right) { FX.play('win'); FX.confetti(res, 120); } else FX.play('lose'); } else FX.play('win');
			res.innerHTML = '<div class="rc__win"><small>' + esc(C.name) + ' · ' + esc(D.name) + '</small><h3>' + esc(W.make + ' ' + W.model) + ' <em>wins</em></h3><p>by ' + gap.toFixed(2) + ' s' + (gap < .1 ? ': a photo finish' : '') + callTxt + '</p></div>'
				+ '<div class="rc__rows">' + [[A, ta, trapA, sa], [B, tb, trapB, sb]].map(function (r) { return '<div class="rc__row' + ((r[0] === W) ? ' is-win' : '') + '"><b>' + esc(r[0].model) + '</b><span>' + r[1].toFixed(2) + ' s</span><span>' + (D.v ? '' : r[2] + ' km/h at the line') + '</span><span>' + r[3].drive.toUpperCase() + ' · ' + r[3].hp + ' hp · ' + r[3].kg + ' kg</span></div>'; }).join('') + '</div>'
				+ '<canvas class="rc__chart" width="900" height="260"></canvas><p class="rc__why">' + esc(why(sa, sb, C, wA)) + '</p><div class="rc__acts"><button type="button" class="lx-btn lx-btn--gold" data-race-again>Race again</button><a class="lx-btn lx-btn--dark" href="' + esc(W.url) + '">See the ' + esc(W.model) + '</a>' + FX.shareBtn('Race result: the ' + W.make + ' ' + W.model + ' won by ' + gap.toFixed(2) + ' s (' + C.name + ', ' + D.name + '). Race any two cars on Laqim Autoworld.') + '</div>';
			res.hidden = false; var rcv = $('.rc__chart', res); if (res.clientWidth < 600) { rcv.width = 480; rcv.height = 300; } chart(rcv, ra, rb, A, B);
			on($('[data-race-again]', res), 'click', function () { go.click(); });
			if (!scene) res.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
		}
		function why(sa, sb, C, wA) {
			var w2 = wA ? sa : sb, l = wA ? sb : sa;
			if (C.mu < .7 && w2.drive === 'awd' && l.drive !== 'awd') return 'All-wheel drive made the difference: on low grip, only so much power can reach the road through two wheels.';
			if (w2.hp / w2.kg > l.hp / l.kg * 1.15) return 'Power-to-weight decided it: ' + Math.round(w2.hp / w2.kg * 1000) + ' hp per tonne against ' + Math.round(l.hp / l.kg * 1000) + '.';
			if (C.pw < 1) return 'Thin or hot air robs engines of power. Turbocharged engines lose less, because the turbo packs in extra air.';
			return 'Close on paper: traction, gearbox speed and aerodynamic drag separated them.';
		}
		/* knockout tournament: 8 cars, same conditions */
		var tb = $('[data-race-tour]', root), tout = $('[data-tour-out]', root);
		on(tb, 'click', function () {
			var pool = cars.slice().sort(function () { return Math.random() - .5; }).filter(function (c, i, a) { return a.findIndex(function (o) { return o.model === c.model; }) === i; }).slice(0, 8);
			var C = CONDS[cond], D = DIST[dist], rounds = [], cur = pool.map(function (c) { var sp = carSpec(c); calibrate(sp); return { c: c, sp: sp }; });
			while (cur.length > 1) {
				var nx = [], heats = [];
				for (var i = 0; i < cur.length; i += 2) { var a = cur[i], b = cur[i + 1]; var ta = simulate(a.sp, C, D, 1 / 120), tbb = simulate(b.sp, C, D, 1 / 120); var tA = ta[ta.length - 1][0] - .18, tB = tbb[tbb.length - 1][0] - .18; var win = tA <= tB ? a : b; heats.push({ a: a, b: b, tA: tA, tB: tB, w: win }); nx.push(win); }
				rounds.push(heats); cur = nx;
			}
			var names = ['Quarter-finals', 'Semi-finals', 'Final'];
			tout.innerHTML = '<div class="tour__head"><small>' + esc(C.name) + ' · ' + esc(D.name) + '</small><h3>Champion: <em>' + esc(cur[0].c.make + ' ' + cur[0].c.model) + '</em></h3></div><div class="tour__bracket">' + rounds.map(function (r, ri) { return '<div class="tour__col"><p>' + names[ri + (3 - rounds.length)] + '</p>' + r.map(function (h, hi) { return '<div class="tour__heat" style="animation-delay:' + (ri * .5 + hi * .12) + 's">' + [[h.a, h.tA], [h.b, h.tB]].map(function (x) { return '<div class="tour__car' + (x[0] === h.w ? ' is-w' : '') + '"><img src="' + esc(x[0].c.img) + '" alt=""><b>' + esc(x[0].c.model) + '</b><span>' + x[1].toFixed(2) + ' s</span></div>'; }).join('') + '</div>'; }).join('') + '</div>'; }).join('') + '<div class="tour__col tour__champ"><p>Champion</p><div class="tour__trophy"><img src="' + esc(cur[0].c.img) + '" alt=""><b>🏆 ' + esc(cur[0].c.model) + '</b><a href="#race" data-race-preset="' + cur[0].c.id + '">Race it yourself</a></div></div></div>';
			tout.hidden = false; tout.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
			var pr = $('[data-race-preset]', tout); on(pr, 'click', function (e) { e.preventDefault(); selA.value = pr.getAttribute('data-race-preset'); cardFor(selA, ca); root.scrollIntoView({ behavior: 'smooth' }); });
		});
		function chart(cv, ra, rb, A, B) {
			var x = cv.getContext('2d'), W = cv.width, H = cv.height, T = Math.max(ra[ra.length - 1][0], rb[rb.length - 1][0]), V = Math.max.apply(null, ra.concat(rb).map(function (p) { return p[2]; })) * 3.6;
			x.clearRect(0, 0, W, H); x.strokeStyle = 'rgba(255,255,255,.1)'; x.fillStyle = 'rgba(255,255,255,.55)'; x.font = W < 600 ? '600 15px Manrope' : '600 12px Manrope'; 
			for (var i = 0; i <= 4; i++) { var y = H - 30 - (H - 50) * i / 4; x.beginPath(); x.moveTo(44, y); x.lineTo(W - 10, y); x.stroke(); x.fillText(Math.round(V * i / 4), 6, y + 4); }
			x.fillText('km/h', 6, 14); x.fillText('time (s) →', W - 80, H - 8);
			[[ra, '#f1d27a', A], [rb, '#7fb4ff', B]].forEach(function (s) { x.strokeStyle = s[1]; x.lineWidth = 3; x.beginPath(); s[0].forEach(function (p, i) { var px = 44 + (W - 54) * p[0] / T, py = H - 30 - (H - 50) * p[2] * 3.6 / V; if (i) x.lineTo(px, py); else x.moveTo(px, py); }); x.stroke(); });
			x.fillStyle = '#f1d27a'; x.fillText('■ ' + A.model, 60, 22); x.fillStyle = '#7fb4ff'; x.fillText('■ ' + B.model, W < 600 ? 60 : 260, W < 600 ? 42 : 22);
		}
	}
	function buildScene(stage) {
		var T = w.THREE, cv = d.createElement('canvas'); cv.className = 'rc__cv'; stage.appendChild(cv);
		var R = setupRenderer(cv), S = new T.Scene(), env = studioEnv(R); S.environment = env;
		var C = new T.PerspectiveCamera(55, 1, .1, 3000);
		var hemi = new T.HemisphereLight(0xffffff, 0x445533, .6); S.add(hemi); var sun = new T.DirectionalLight(0xffffff, 1.1); sun.position.set(-40, 80, 30); S.add(sun);
		var L = 1400;
		function tex(fn, rx, ry) { var c = d.createElement('canvas'); c.width = c.height = 256; fn(c.getContext('2d')); var t = new T.CanvasTexture(c); t.wrapS = t.wrapT = T.RepeatWrapping; t.repeat.set(rx, ry); t.anisotropy = 8; t.encoding = T.sRGBEncoding; return t; }
		var roadTex = tex(function (x) { x.fillStyle = '#777'; x.fillRect(0, 0, 256, 256); for (var i = 0; i < 1400; i++) { x.fillStyle = 'rgba(' + (Math.random() > .5 ? '255,255,255' : '0,0,0') + ',' + (Math.random() * .08) + ')'; x.fillRect(Math.random() * 256, Math.random() * 256, 2, 2); } x.fillStyle = '#fff'; x.fillRect(124, 0, 8, 120); x.fillRect(0, 0, 6, 256); x.fillRect(250, 0, 6, 256); }, 1, L / 12);
		var roadM = new T.MeshStandardMaterial({ map: roadTex, color: 0x2b2b2e, roughness: .8, metalness: 0 });
		var road = new T.Mesh(new T.PlaneGeometry(12, L), roadM); road.rotation.x = -Math.PI / 2; road.position.z = -L / 2 + 40; S.add(road);
		var groundM = new T.MeshStandardMaterial({ color: 0x6f7a4f, roughness: 1, envMapIntensity: .22 }); roadM.envMapIntensity = .45;
		var ground = new T.Mesh(new T.PlaneGeometry(800, L + 400), groundM); ground.rotation.x = -Math.PI / 2; ground.position.set(0, -.02, -L / 2 + 40); S.add(ground);
		/* start + finish gantries, barriers, poles */
		var gold = new T.MeshStandardMaterial({ color: 0xc99a3a, metalness: .8, roughness: .3 }), white = new T.MeshStandardMaterial({ color: 0xf2f2f2, roughness: .5 }), dark = new T.MeshStandardMaterial({ color: 0x18181b, roughness: .6 });
		function gantry(z, label) { var g = new T.Group(); [-7, 7].forEach(function (x) { var p = new T.Mesh(new T.BoxGeometry(.4, 7, .4), dark); p.position.set(x, 3.5, 0); g.add(p); }); var b = new T.Mesh(new T.BoxGeometry(14.4, 1.4, .3), dark); b.position.y = 7; g.add(b); var c = d.createElement('canvas'); c.width = 1024; c.height = 100; var x = c.getContext('2d'); x.fillStyle = '#18181b'; x.fillRect(0, 0, 1024, 100); x.fillStyle = '#e6c46a'; x.font = '700 64px Manrope, sans-serif'; x.textAlign = 'center'; x.fillText(label, 512, 72); var t = new T.CanvasTexture(c); t.encoding = T.sRGBEncoding; var s = new T.Mesh(new T.PlaneGeometry(14, 1.35), new T.MeshBasicMaterial({ map: t })); s.position.set(0, 7, .16); g.add(s); g.position.z = z; S.add(g); return g; }
		gantry(0, 'LAQIM PROVING GROUND · START');
		var finish = gantry(-402, 'FINISH');
		var check = new T.Mesh(new T.PlaneGeometry(12, 1.2), new T.MeshBasicMaterial({ map: tex(function (x) { for (var i = 0; i < 8; i++) for (var j = 0; j < 8; j++) { x.fillStyle = (i + j) % 2 ? '#111' : '#fff'; x.fillRect(i * 32, j * 32, 32, 32); } }, 6, 1) }));
		check.rotation.x = -Math.PI / 2; check.position.set(0, .01, -402); S.add(check);
		for (var z = 20; z > -L + 60; z -= 4) { [-7.4, 7.4].forEach(function (x) { var bar = new T.Mesh(new T.BoxGeometry(.25, .7, 4), (Math.floor(z / 4) % 2) ? white : new T.MeshStandardMaterial({ color: 0xb8862b, roughness: .5 })); bar.position.set(x, .35, z); S.add(bar); }); }
		for (var z2 = 0; z2 > -L + 60; z2 -= 40) { [-10, 10].forEach(function (x) { var p = new T.Mesh(new T.CylinderGeometry(.12, .16, 9, 8), dark); p.position.set(x, 4.5, z2); S.add(p); var lmp = new T.Mesh(new T.BoxGeometry(1.4, .2, .5), new T.MeshBasicMaterial({ color: 0xfff6dd })); lmp.position.set(x > 0 ? x - .6 : x + .6, 9, z2); S.add(lmp); }); }
		/* grandstands, flags and boards */
		var standM = new T.MeshStandardMaterial({ color: 0x2a2a2e, roughness: .8, envMapIntensity: .4 }), crowdCols = [0xc99a3a, 0xf2f2f2, 0x1d4ed8, 0xb91c1c, 0x16a34a, 0x111111];
		[[-16, -30], [16, -30], [-16, -380], [16, -380], [-16, -980], [16, -980]].forEach(function (p) {
			var g = new T.Group(); g.position.set(p[0], 0, p[1]); S.add(g);
			var crowd = new T.InstancedMesh(new T.BoxGeometry(.5, .8, .5), new T.MeshStandardMaterial({ roughness: .7 }), 130), mtx = new T.Matrix4(), col = new T.Color(), ci = 0;
			for (var r = 0; r < 5; r++) { var step = new T.Mesh(new T.BoxGeometry(5, .6, 60), standM); step.position.set((p[0] > 0 ? 1 : -1) * r * 1.2, .3 + r * .6, 0); g.add(step);
				for (var c = 0; c < 26; c++) { mtx.makeTranslation((p[0] > 0 ? 1 : -1) * r * 1.2, 1 + r * .6, -28 + c * 2.2 + (r % 2)); crowd.setMatrixAt(ci, mtx); crowd.setColorAt(ci, col.setHex(crowdCols[(c * 7 + r * 3) % crowdCols.length])); ci++; } }
			g.add(crowd);
			var roof = new T.Mesh(new T.BoxGeometry(8, .2, 62), new T.MeshStandardMaterial({ color: 0xc99a3a, metalness: .6, roughness: .35 })); roof.position.set((p[0] > 0 ? 1 : -1) * 2.4, 5.6, 0); g.add(roof);
		});
		var bc = d.createElement('canvas'); bc.width = 512; bc.height = 96; var bx = bc.getContext('2d'); bx.fillStyle = '#111'; bx.fillRect(0, 0, 512, 96); bx.fillStyle = '#e6c46a'; bx.font = '700 58px Manrope, sans-serif'; bx.textAlign = 'center'; bx.fillText('LAQIM AUTOWORLD', 256, 68); var bt = new T.CanvasTexture(bc); bt.encoding = T.sRGBEncoding;
		for (var bz2 = -20; bz2 > -L + 60; bz2 -= 60) { [-8.2, 8.2].forEach(function (x) { var bd = new T.Mesh(new T.PlaneGeometry(8, 1.5), new T.MeshBasicMaterial({ map: bt })); bd.position.set(x, 1.1, bz2); bd.rotation.y = x < 0 ? Math.PI / 2 : -Math.PI / 2; S.add(bd); }); }
		for (var fz2 = -10; fz2 > -L + 60; fz2 -= 25) { [-9.5, 9.5].forEach(function (x, ii) { var pole = new T.Mesh(new T.CylinderGeometry(.04, .04, 4, 6), dark); pole.position.set(x, 2, fz2); S.add(pole); var flag = new T.Mesh(new T.PlaneGeometry(1.2, .7), new T.MeshBasicMaterial({ color: (Math.round(fz2 / 25) + ii) % 2 ? 0xc99a3a : 0x111111, side: T.DoubleSide })); flag.position.set(x + (x < 0 ? .6 : -.6), 3.6, fz2); S.add(flag); }); }
		/* distant hills */
		var hillM = new T.MeshStandardMaterial({ color: 0x55653f, roughness: 1, flatShading: true, envMapIntensity: .2 });
		for (var k = 0; k < 40; k++) { var hill = new T.Mesh(new T.ConeGeometry(30 + Math.random() * 60, 20 + Math.random() * 50, 7), hillM); var side = k % 2 ? 1 : -1; hill.position.set(side * (90 + Math.random() * 200), 0, -Math.random() * L); S.add(hill); }
		/* sky dome */
		var skyU = { top: { value: new T.Color(0x9cc7ef) }, bot: { value: new T.Color(0xeef4f8) } };
		var sky = new T.Mesh(new T.SphereGeometry(1500, 24, 12), new T.ShaderMaterial({ side: T.BackSide, depthWrite: false, uniforms: skyU, vertexShader: 'varying float h;void main(){h=normalize(position).y;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}', fragmentShader: 'uniform vec3 top;uniform vec3 bot;varying float h;void main(){gl_FragColor=vec4(mix(bot,top,clamp(h*2.,0.,1.)),1.);}' }));
		S.add(sky);
		/* particles for weather */
		var PN = 2500, pg = new T.BufferGeometry(), pp = new Float32Array(PN * 3); for (var i = 0; i < PN; i++) { pp[i * 3] = (Math.random() - .5) * 60; pp[i * 3 + 1] = Math.random() * 25; pp[i * 3 + 2] = (Math.random() - .5) * 120; }
		pg.setAttribute('position', new T.BufferAttribute(pp, 3));
		var pm = new T.PointsMaterial({ color: 0xffffff, size: .12, transparent: true, opacity: .7, depthWrite: false }), parts = new T.Points(pg, pm); parts.visible = false; S.add(parts);
		var sg = new T.BufferGeometry(), spp = new Float32Array(1500 * 3); for (var si2 = 0; si2 < 1500; si2++) { var th = Math.random() * Math.PI * 2, ph = Math.random() * Math.PI * .45, rr = 1300; spp[si2 * 3] = Math.cos(th) * Math.cos(ph) * rr; spp[si2 * 3 + 1] = Math.sin(ph) * rr + 40; spp[si2 * 3 + 2] = Math.sin(th) * Math.cos(ph) * rr; }
		sg.setAttribute('position', new T.BufferAttribute(spp, 3)); var stars = new T.Points(sg, new T.PointsMaterial({ color: 0xffffff, size: 2.2, sizeAttenuation: false, fog: false })); stars.visible = false; S.add(stars);
		var fx = '', cars = [null, null], lanes = [-3, 3];
		var shadowT = shadowTex(), isNight = false;
		var glowT = (function () { var c = d.createElement('canvas'); c.width = c.height = 64; var x = c.getContext('2d'), g = x.createRadialGradient(32, 32, 1, 32, 32, 31); g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(.25, 'rgba(255,255,255,.55)'); g.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = g; x.fillRect(0, 0, 64, 64); return new T.CanvasTexture(c); })();
		var beamT = (function () { var c = d.createElement('canvas'); c.width = 64; c.height = 256; var x = c.getContext('2d'), g = x.createLinearGradient(0, 256, 0, 0); g.addColorStop(0, 'rgba(255,255,255,.7)'); g.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = g; x.beginPath(); x.moveTo(22, 256); x.lineTo(42, 256); x.lineTo(64, 0); x.lineTo(0, 0); x.closePath(); x.fill(); return new T.CanvasTexture(c); })();
		function fallbackCar(color) { return genericCar(color); }
		function place(slot, c, done) {
			var holder = new T.Group(); holder.position.set(lanes[slot], 0, 0); S.add(holder);
			var sh = new T.Mesh(new T.PlaneGeometry(2.6, 5.4), new T.MeshBasicMaterial({ map: shadowT, transparent: true, depthWrite: false })); sh.rotation.x = -Math.PI / 2; sh.position.y = .02; holder.add(sh);
			if (cars[slot]) S.remove(cars[slot]); cars[slot] = holder;
			var tc = d.createElement('canvas'); tc.width = 512; tc.height = 128; var tx = tc.getContext('2d'); tx.fillStyle = slot ? 'rgba(20,40,70,.85)' : 'rgba(40,30,10,.85)'; if (tx.roundRect) { tx.beginPath(); tx.roundRect(8, 18, 496, 92, 46); tx.fill(); } else tx.fillRect(8, 18, 496, 92); tx.fillStyle = slot ? '#7fb4ff' : '#f1d27a'; tx.font = '700 48px Manrope, sans-serif'; tx.textAlign = 'center'; tx.fillText((c.model || '').slice(0, 18), 256, 82);
			var lamps = new T.Group(); lamps.visible = isNight; holder.add(lamps);
			[[-.72, .85, 2.25, 0xff2a1a, .55], [.72, .85, 2.25, 0xff2a1a, .55], [-.75, .75, -2.3, 0xfff3d6, .9], [.75, .75, -2.3, 0xfff3d6, .9]].forEach(function (q) { var sp3 = new T.Sprite(new T.SpriteMaterial({ map: glowT, color: q[3], transparent: true, depthWrite: false, blending: T.AdditiveBlending })); sp3.scale.setScalar(q[4]); sp3.position.set(q[0], q[1], q[2]); lamps.add(sp3); });
			var beam = new T.Mesh(new T.PlaneGeometry(3.2, 14), new T.MeshBasicMaterial({ map: beamT, color: 0xfff1cc, transparent: true, depthWrite: false, blending: T.AdditiveBlending, opacity: .55 })); beam.rotation.x = -Math.PI / 2; beam.position.set(0, .03, -9.4); lamps.add(beam); holder.userData.lamps = lamps;
			var tt = new T.CanvasTexture(tc); tt.encoding = T.sRGBEncoding; var tag = new T.Sprite(new T.SpriteMaterial({ map: tt, depthTest: false, transparent: true })); tag.scale.set(3.2, .8, 1); tag.position.set(0, 3.1, 0); holder.add(tag);
			function orient(m) { m.rotation.y = isFlip(c) ? -Math.PI / 2 : Math.PI / 2; var pw = new T.Group(); pw.add(m); holder.add(pw); holder.userData.pitch = pw; holder.userData.p = 0; done(); }
			if (c.glb) loadModel(c.glb, function (err, m) { if (err) return orient(fallbackCar(slot ? 0x7fb4ff : 0xc99a3a)); var wrap = new T.Group(); wrap.add(m); orient(wrap); }); else orient(fallbackCar(slot ? 0x7fb4ff : 0xc99a3a));
		}
		/* tyre smoke */
		var smT = (function () { var c = d.createElement('canvas'); c.width = c.height = 64; var x = c.getContext('2d'), gr = x.createRadialGradient(32, 32, 2, 32, 32, 31); gr.addColorStop(0, 'rgba(235,235,235,.55)'); gr.addColorStop(1, 'rgba(235,235,235,0)'); x.fillStyle = gr; x.fillRect(0, 0, 64, 64); return new T.CanvasTexture(c); })(), puffs = [];
		for (var pi = 0; pi < 70; pi++) { var sp2 = new T.Sprite(new T.SpriteMaterial({ map: smT, transparent: true, depthWrite: false, opacity: 0 })); sp2.visible = false; S.add(sp2); puffs.push({ s: sp2, life: 0 }); }
		var pIdx = 0, lastL = 0; function puff(slot) { var h = cars[slot]; if (!h) return; var p = puffs[pIdx++ % puffs.length]; p.life = 1; p.s.visible = true; p.s.position.set(h.position.x + (Math.random() > .5 ? .8 : -.8), .35, h.position.z + 2 + Math.random() * .4); p.s.scale.setScalar(.6); }
		function stepPuffs(dt) { puffs.forEach(function (p) { if (p.life <= 0) return; p.life -= dt * .9; p.s.material.opacity = Math.max(0, p.life) * .55; p.s.scale.setScalar(.6 + (1 - p.life) * 3.2); p.s.position.y += dt * .5; p.s.position.z += dt * 1.2; if (p.life <= 0) p.s.visible = false; }); }
		function size() { var r = stage.getBoundingClientRect(); R.setSize(r.width, r.height, false); C.aspect = r.width / Math.max(1, r.height); C.updateProjectionMatrix(); }
		on(w, 'resize', size); size();
		var camMode = 'chase', za = 0, zb = 0, va = 0, vb = 0, camZ = 12, idle = true, lastF = performance.now(), tags = [];
		function render() { R.render(S, C); }
		(function loop() {
			requestAnimationFrame(loop);
			if (idle) { var t = performance.now() / 1000; C.position.set(Math.sin(t * .15) * 9, 3.2, 10 + Math.cos(t * .15) * 3); C.lookAt(0, 1, -8); }
			var nowL = performance.now(), dtl = lastL ? Math.min(.1, (nowL - lastL) / 1000) : 0; lastL = nowL; stepPuffs(dtl);
			if (fx && parts.visible) { var p = pg.attributes.position.array, sp = fx === 'snow' ? .03 : (fx === 'rain' ? .6 : .02); for (var i = 0; i < PN; i++) { p[i * 3 + 1] -= sp; if (fx === 'dust') { p[i * 3 + 1] += .025; p[i * 3] += (Math.random() - .5) * .05; } if (p[i * 3 + 1] < 0) p[i * 3 + 1] = fx === 'dust' ? 0 : 25; if (p[i * 3 + 1] > 6 && fx === 'dust') p[i * 3 + 1] = 0; } pg.attributes.position.needsUpdate = true; parts.position.z = -Math.max(za, zb) + (fx === 'dust' ? 8 : -20); }
			render();
		})();
		return {
			setCond: function (c) {
				roadM.color.setHex(c.road); roadM.roughness = c.fx === 'rain' ? .18 : .8; roadM.metalness = c.fx === 'rain' ? .35 : 0; groundM.color.setHex(c.ground).convertSRGBToLinear(); hillM.color.setHex(c.fx === 'snow' ? 0xdfe5ea : c.fx === 'night' ? 0x141a10 : 0x4a5a36).convertSRGBToLinear();
				skyU.top.value.setHex(c.sky[0]); skyU.bot.value.setHex(c.sky[1]); S.fog = new T.Fog(c.sky[1], c.fx === 'snow' || c.fx === 'rain' ? 70 : 420, c.fx === 'snow' ? 380 : (c.fx === 'rain' ? 520 : 1700));
				S.environment = c.fx === 'night' ? null : env; stars.visible = c.fx === 'night'; isNight = c.fx === 'night'; cars.forEach(function (h) { if (h && h.userData.lamps) h.userData.lamps.visible = isNight; });
				fx = c.fx === 'night' ? '' : c.fx; parts.visible = !!fx && fx !== 'haze'; pm.size = fx === 'rain' ? .06 : (fx === 'dust' ? .25 : .14); pm.color.setHex(fx === 'dust' ? 0xc9b48a : 0xffffff); pm.opacity = fx === 'rain' ? .5 : .75;
				sun.intensity = fx === 'night' ? .08 : (fx === 'rain' || fx === 'snow' ? .5 : 1.1); hemi.intensity = fx === 'night' ? .18 : .6; R.toneMappingExposure = fx === 'night' ? 1.25 : .82;
			},
			load: function (A, B, cb, D) { var n = 0; za = zb = 0; idle = false; var fz = D && D.m ? D.m : 402; finish.position.z = -fz; check.position.z = -fz; finish.visible = check.visible = !!(D && D.m); place(0, A, f); place(1, B, f); function f() { if (++n === 2) { cars[0].position.z = 0; cars[1].position.z = 0; C.position.set(0, 3.4, 11); C.lookAt(0, 1, -6); cb(); } } },
			frame: function (xa, xb, a, b) {
				za = xa; zb = xb; if (cars[0]) cars[0].position.z = -xa; if (cars[1]) cars[1].position.z = -xb;
				var lead = Math.max(xa, xb), mid = (xa + xb) / 2, gap = Math.abs(xa - xb);
				var now = performance.now(), dt = Math.min(.25, (now - lastF) / 1000), k = 1 - Math.exp(-dt * 7); lastF = now;
				if (camMode === 'side') { var post = Math.floor((mid + 30) / 90) * 90 + 30; C.position.set(-11, 1.6, -post); C.lookAt(0, .8, -mid); C.fov = 38; C.updateProjectionMatrix(); return; }
				if (camMode === 'heli') { C.position.z += (-mid + 16 - C.position.z) * k; C.position.y += (26 - C.position.y) * k; C.position.x += (8 - C.position.x) * k; C.lookAt(0, 0, -mid - 6); C.fov = 50; C.updateProjectionMatrix(); return; }
				if (camMode === 'nose') { var lz = Math.max(xa, xb); C.position.z += (-lz - 9 - Math.min(10, gap * .3) - C.position.z) * Math.min(1, k * 3); C.position.y += (.7 - C.position.y) * k; C.position.x += (0 - C.position.x) * k; C.lookAt(0, .9, -mid); C.fov = 48; C.updateProjectionMatrix(); return; }
				var tz = -mid + 9 + Math.min(14, gap * .35), ty = 2.6 + Math.min(5, gap * .08);
				C.position.z += (tz - C.position.z) * k; C.position.y += (ty - C.position.y) * k; C.position.x += (Math.sin(lead * .01) * 2.5 - C.position.x) * k * .4;
				C.lookAt(0, 1, -lead - 18);
				C.fov = 55 + Math.min(14, Math.max(a, b) * .18); C.updateProjectionMatrix();
			},
			cam: function (m) { camMode = m; },
			dyn: function (ga, gb, sa, sb) {
				[[0, ga, sa], [1, gb, sb]].forEach(function (r) { var h = cars[r[0]]; if (!h || !h.userData.pitch) return; var tgt = Math.max(-.03, Math.min(.045, r[1] * .032)); h.userData.p += (tgt - h.userData.p) * .12; h.userData.pitch.rotation.x = h.userData.p; if (r[2] && Math.random() < .7) puff(r[0]); });
			},
			end: function () { idle = true; }
		};
	}

	/* ------------------------------------------------------------ 3D silhouette game */
	function silhouette(root) {
		var pool = index().filter(function (c) { return c.glb; }); if (pool.length < 4) { root.hidden = true; return; }
		var stage = $('[data-sil-stage]', root), opts = $('[data-sil-opts]', root), msg = $('[data-sil-msg]', root), nxt = $('[data-sil-next]', root);
		var streak = 0, best = +(getStore('psr_sil_best') || 0), cur = null, view = null, T, R, S, C, holder, black, started = false, busy = false;
		$('[data-sil-best]', root).textContent = best;
		function getStore(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
		function setStore(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
		function init() {
			T = w.THREE; var cv = d.createElement('canvas'); cv.className = 'sil__cv'; stage.appendChild(cv);
			R = setupRenderer(cv, true); S = new T.Scene(); S.environment = studioEnv(R); S.background = null; R.setClearColor(0x000000, 0);
			C = new T.PerspectiveCamera(30, 1, .1, 100); C.position.set(0, 1.9, 8.6); C.lookAt(0, .75, 0);
			S.add(new T.HemisphereLight(0xffffff, 0x333333, .8)); var dl = new T.DirectionalLight(0xffffff, .9); dl.position.set(4, 8, 6); S.add(dl);
			holder = new T.Group(); S.add(holder); black = new T.MeshBasicMaterial({ color: 0x050505 });
			function size() { var r = stage.getBoundingClientRect(); R.setSize(r.width, r.height, false); C.aspect = r.width / Math.max(1, r.height); C.updateProjectionMatrix(); }
			on(w, 'resize', size); size();
			var drag = null; on(cv, 'pointerdown', function (e) { drag = e.clientX; }); on(w, 'pointerup', function () { drag = null; }); on(cv, 'pointermove', function (e) { if (drag !== null) { holder.rotation.y += (e.clientX - drag) * .01; drag = e.clientX; } });
			(function loop() { requestAnimationFrame(loop); if (drag === null) holder.rotation.y += .006; R.render(S, C); })();
		}
		function round() {
			if (busy) return; busy = true; nxt.hidden = true; msg.textContent = 'Loading a mystery car…'; opts.innerHTML = '';
			cur = pool[Math.floor(Math.random() * pool.length)];
			var pt = setInterval(function () { var p = modelPct(cur.glb); msg.textContent = p > 0 && p < 1 ? 'Loading a mystery car… ' + Math.round(p * 100) + '%' : 'Loading a mystery car…'; }, 200);
			loadModel(cur.glb, function (err, m) {
				clearInterval(pt); busy = false; if (err) { msg.textContent = 'That one would not load. Try the next.'; nxt.hidden = false; return; }
				while (holder.children.length) holder.remove(holder.children[0]);
				m.traverse(function (o) { if (o.isMesh) { o.userData.mat = o.userData.mat || o.material; o.material = black; } }); holder.add(m); holder.rotation.y = Math.random() * 6;
				var names = [cur], sim = function (c) { return (c.body === cur.body ? 2 : 0) + (Math.abs((+c.year || 0) - (+cur.year || 0)) < 15 ? 1 : 0) + Math.random() * 1.5; }; var others = index().filter(function (c) { return c.model !== cur.model; }).map(function (c) { return [sim(c), c]; }).sort(function (a, b) { return b[0] - a[0]; }).map(function (x) { return x[1]; });
				others.forEach(function (o) { if (names.length < 4 && !names.some(function (n) { return n.model === o.model; })) names.push(o); });
				names.sort(function () { return Math.random() - .5; });
				opts.innerHTML = names.map(function (c) { return '<button type="button" data-g="' + c.id + '">' + esc(cname(c)) + '</button>'; }).join('');
				msg.textContent = 'Which car is this shadow? Drag to turn it.';
				$$('[data-g]', opts).forEach(function (b) { on(b, 'click', function () { answer(b, m); }); });
			});
		}
		function answer(b, m) {
			if (opts.classList.contains('is-done')) return; opts.classList.add('is-done');
			var ok = byId(+b.getAttribute('data-g')).model === cur.model;
			$$('[data-g]', opts).forEach(function (x) { if (byId(+x.getAttribute('data-g')).model === cur.model) x.classList.add('is-ok'); });
			if (!ok) b.classList.add('is-no');
			m.traverse(function (o) { if (o.isMesh && o.userData.mat) o.material = o.userData.mat; });
			var lost = streak; streak = ok ? streak + 1 : 0; if (streak > best) { best = streak; setStore('psr_sil_best', best); }
			stage.classList.remove('is-reveal'); void stage.offsetWidth; stage.classList.add('is-reveal'); if (ok) { FX.play(streak % 5 === 0 ? 'streak' : 'ok'); if (streak % 5 === 0) FX.confetti(stage, 90); } else { FX.play('no'); FX.buzz(60); }
			$('[data-sil-streak]', root).textContent = streak; $('[data-sil-best]', root).textContent = best;
			msg.innerHTML = (ok ? '<b>Correct.</b> ' : '<b>Not quite.</b> ') + 'It\'s the ' + esc(cur.make + ' ' + cur.model) + '. <a href="' + esc(cur.url) + '">See it →</a>' + (!ok && lost >= 3 ? ' ' + FX.shareBtn('I named ' + lost + ' cars in a row from their 3D shadow on Laqim Autoworld. Your turn!') : '');
			nxt.hidden = false;
		}
		on(nxt, 'click', function () { opts.classList.remove('is-done'); round(); });
		on($('[data-sil-start]', root), 'click', function () {
			if (started) return; started = true; $('[data-sil-start]', root).hidden = true;
			load3D(function (err) { if (err) { msg.textContent = '3D needs a newer browser.'; return; } init(); round(); });
		});
	}
	/* ------------------------------------------------------------ Top Trumps */
	function trumps(root) {
		var cars = index().filter(function (c) { return c.hp; }); if (cars.length < 6) return;
		var STATS = [['hp', 'Power', 'hp', 1], ['tq', 'Torque', 'Nm', 1], ['acc', '0–100', 's', -1], ['vmax', 'Top speed', 'km/h', 1], ['kg', 'Weight', 'kg', -1], ['pres', 'Presence', '/10', 1]];
		function val(c, k) { if (k === 'pres') return (c.score && c.score[4]) || 0; return c[k] || 0; }
		var you = $('[data-tt-you]', root), cpu = $('[data-tt-cpu]', root), msg = $('[data-tt-msg]', root), sc = $('[data-tt-score]', root), btn = $('[data-tt-next]', root);
		var deckY = [], deckC = [], rnd = 0, ps = 0, cs = 0, cy = null, cc = null, lock = false, houseTurn = false;
		function pct(c, s) { var v = val(c, s[0]); if (!v) return -1; var l = cars.map(function (x) { return val(x, s[0]); }).filter(Boolean), n = l.filter(function (x) { return s[3] > 0 ? x < v : x > v; }).length; return n / l.length; }
		function card(c, hide) {
			return '<div class="tt__inner' + (hide ? '' : ' is-up') + '"><div class="tt__back"><span>L</span><b>LAQIM</b><small>Top Trumps</small></div><div class="tt__front"><div class="tt__img"><img src="' + esc(c.img) + '" alt=""></div><div class="tt__nm"><small>' + esc(c.make) + '</small><b>' + esc(c.model) + '</b></div><ul>' + STATS.map(function (s) { var v = val(c, s[0]); return '<li data-st="' + s[0] + '"' + (v ? '' : ' class="is-na"') + '><span>' + s[1] + '</span><b>' + (v ? (s[0] === 'acc' ? v.toFixed(1) : v.toLocaleString()) + ' <em>' + s[2] + '</em>' : '–') + '</b></li>'; }).join('') + '</ul></div></div>';
		}
		function deal() {
			var sh = cars.slice().sort(function () { return Math.random() - .5; });
			deckY = sh.filter(function (_, i) { return i % 2 === 0; }); deckC = sh.filter(function (_, i) { return i % 2 === 1; });
			rnd = 0; ps = 0; cs = 0; houseTurn = false; next();
		}
		function next() {
			lock = false; rnd++;
			if (rnd > 10 || !deckY.length || !deckC.length) { msg.innerHTML = (ps > cs ? '<b>You win the match ' + ps + '–' + cs + '.</b> A true car person.' : (ps === cs ? '<b>A draw, ' + ps + '–' + cs + '.</b>' : '<b>The house wins ' + cs + '–' + ps + '.</b> Rematch?')) + (ps > cs ? ' ' + FX.shareBtn('I beat the house ' + ps + '–' + cs + ' at Laqim Top Trumps. Think you can do better?') : ''); if (ps > cs) { FX.play('win'); FX.confetti(root); } else if (cs > ps) FX.play('lose'); btn.textContent = 'New match'; btn.onclick = deal; return; }
			cy = deckY.shift(); cc = deckC.shift();
			you.innerHTML = card(cy, false); cpu.innerHTML = card(cc, true);
			sc.innerHTML = '<span>Round ' + rnd + ' of 10</span><b>You ' + ps + ' – ' + cs + ' House</b>';
			btn.hidden = true; FX.play('flip');
			if (houseTurn) { msg.innerHTML = '<b>The House won the last round, so it picks.</b> Thinking…'; lock = true; setTimeout(function () { var bestS = STATS.reduce(function (a, s) { return pct(cc, s) > pct(cc, a) ? s : a; }); lock = false; play(bestS[0], true); }, 1300); return; }
			msg.textContent = 'Your turn: pick your strongest stat.';
			$$('[data-st]', you).forEach(function (li) { if (li.classList.contains('is-na')) return; on(li, 'click', function () { play(li.getAttribute('data-st')); }); });
		}
		function play(k, house) {
			if (lock) return; lock = true; FX.play('flip'); var s = STATS.filter(function (x) { return x[0] === k; })[0];
			var a = val(cy, k), b = val(cc, k);
			$('.tt__inner', cpu).classList.add('is-up');
			$$('[data-st="' + k + '"]', root).forEach(function (li) { li.classList.add('is-pick'); });
			setTimeout(function () {
				var res = !b ? 1 : (a === b ? 0 : ((a > b) === (s[3] > 0) ? 1 : -1));
				if (res > 0) { ps++; houseTurn = false; FX.play('ok'); } else if (res < 0) { cs++; houseTurn = true; FX.play('no'); FX.buzz(40); }
				msg.innerHTML = (house ? 'The House played ' + s[1].toLowerCase() + '. ' : '') + (res > 0 ? '<b>You take it.</b> ' + esc(cy.model) + ' beats ' + esc(cc.model) + ' on ' + s[1].toLowerCase() + '.' : (res < 0 ? '<b>House wins.</b> ' + esc(cc.model) + ' has the better ' + s[1].toLowerCase() + '.' : '<b>A tie.</b>'));
				(res > 0 ? you : (res < 0 ? cpu : null)) && (res > 0 ? you : cpu).classList.add('is-win');
				setTimeout(function () { you.classList.remove('is-win'); cpu.classList.remove('is-win'); }, 1600);
				sc.innerHTML = '<span>Round ' + rnd + ' of 10</span><b>You ' + ps + ' – ' + cs + ' House</b>';
				btn.hidden = false; btn.textContent = rnd >= 10 ? 'Final score' : 'Next round'; btn.onclick = next;
			}, 700);
		}
		on($('[data-tt-deal]', root), 'click', function (e) { e.target.hidden = true; deal(); });
	}

	/* ------------------------------------------------------------ Stopping distance */
	function brake(root) {
		var cars = index().filter(function (c) { return c.kg || c.hp; }); if (!cars.length) return;
		var sel = $('[data-bk-car]', root), sp = $('[data-bk-speed]', root), cv = $('[data-bk-cv]', root), x = cv.getContext('2d');
		sel.innerHTML = grp(cars, function (c) { return '<option value="' + c.id + '">' + esc(cname(c)) + '</option>'; });
		var surf = 'dry', alert = .9, anim = null;
		var MU = { dry: .9, wet: .55, gravel: .45, snow: .2 };
		$$('[data-bk-s]', root).forEach(function (b) { on(b, 'click', function () { surf = b.getAttribute('data-bk-s'); $$('[data-bk-s]', root).forEach(function (o) { o.setAttribute('aria-pressed', o === b ? 'true' : 'false'); }); calc(true); }); });
		$$('[data-bk-r]', root).forEach(function (b) { on(b, 'click', function () { alert = +b.getAttribute('data-bk-r'); $$('[data-bk-r]', root).forEach(function (o) { o.setAttribute('aria-pressed', o === b ? 'true' : 'false'); }); calc(true); }); });
		on(sel, 'change', function () { calc(true); }); on(sp, 'input', function () { calc(false); }); on($('[data-bk-go]', root), 'click', function () { calc(true); });
		function size() { var r = cv.getBoundingClientRect(), k = Math.min(2, w.devicePixelRatio || 1); cv.width = r.width * k; cv.height = r.height * k; x.setTransform(k, 0, 0, k, 0, 0); }
		size(); on(w, 'resize', function () { size(); calc(false); });
		var bsc = null, bhost = cv.parentNode;
		if ('IntersectionObserver' in w) { var bio = new IntersectionObserver(function (es) { if (!es[0].isIntersecting) return; bio.disconnect(); load3D(function (err) { if (err) return; var box = d.createElement('div'); box.className = 'bk__3d'; bhost.insertBefore(box, cv); bsc = lcScene(box); bsc.lead(.55, 2.5); bhost.classList.add('has-3d'); calc(false); }); }, { rootMargin: '200px' }); bio.observe(cv); }
		function calc(play) {
			var c = byId(+sel.value), v = +sp.value / 3.6, mu = MU[surf];
			var brakesK = /911|urus|dbx|purosangue|continental/i.test(c.model) ? 1.08 : (c.kg > 2400 ? .95 : 1);
			var react = v * alert, br = v * v / (2 * mu * 9.81 * brakesK), tot = react + br;
			$('[data-bk-sv]', root).textContent = sp.value;
			$('[data-bk-react]', root).textContent = react.toFixed(1) + ' m'; $('[data-bk-brake]', root).textContent = br.toFixed(1) + ' m'; $('[data-bk-tot]', root).textContent = tot.toFixed(1) + ' m';
			var zebra = 60, ok = tot < zebra;
			$('[data-bk-verdict]', root).innerHTML = ok ? '<b>Stops in time.</b> ' + (zebra - tot).toFixed(1) + ' m to spare before the crossing.' : '<b>Too late.</b> It is still moving at the crossing ' + zebra + ' m away. That is why speed limits near schools are low.';
			$('[data-bk-verdict]', root).className = 'bk__verdict ' + (ok ? 'is-ok' : 'is-no');
			var t0 = performance.now(), tr = alert, tb = v / (mu * 9.81 * brakesK), T = tr + tb;
			cancelAnimationFrame(anim);
			function draw(t) {
				var W = cv.clientWidth, H = cv.clientHeight, scale = (W - 60) / Math.max(90, tot + 15);
				x.clearRect(0, 0, W, H);
				x.fillStyle = surf === 'snow' ? '#e7ecf0' : (surf === 'gravel' ? '#8a7458' : (surf === 'wet' ? '#22262b' : '#2c2c30')); x.fillRect(0, H * .3, W, H * .5);
				x.strokeStyle = 'rgba(255,255,255,.6)'; x.setLineDash([24, 18]); x.lineWidth = 3; x.beginPath(); x.moveTo(0, H * .55); x.lineTo(W, H * .55); x.stroke(); x.setLineDash([]);
				var zx = 30 + zebra * scale; for (var i = 0; i < 6; i++) { x.fillStyle = i % 2 ? '#2c2c30' : '#f2f2f2'; x.fillRect(zx, H * .3 + i * H * .5 / 6, 26, H * .5 / 6); }
				x.fillStyle = '#5aa9e6'; x.fillRect(30, H * .78, react * scale, 10); x.fillStyle = '#f2a33a'; x.fillRect(30 + react * scale, H * .78, br * scale, 10);
				x.fillStyle = 'rgba(255,255,255,.75)'; x.font = '600 12px Manrope, sans-serif'; x.fillText('thinking ' + react.toFixed(0) + ' m', 30, H * .82 + 28); x.fillText('braking ' + br.toFixed(0) + ' m', Math.max(30 + react * scale + 6, 130), react * scale < 110 ? H * .82 + 44 : H * .82 + 28);
				var pos;
				if (t < tr) pos = v * t; else { var tt = Math.min(t - tr, tb); pos = react + v * tt - .5 * mu * 9.81 * brakesK * tt * tt; }
				var cx = 30 + pos * scale, cy = H * .55 - 16;
				x.fillStyle = '#c99a3a'; x.fillRect(cx - 38, cy - 6, 44, 22); x.fillStyle = '#111'; x.fillRect(cx - 28, cy - 16, 26, 12);
				x.fillStyle = '#000'; x.beginPath(); x.arc(cx - 28, cy + 17, 6, 0, 7); x.arc(cx - 2, cy + 17, 6, 0, 7); x.fill();
				if (t > tr && t < T) { x.fillStyle = '#ff3b30'; x.fillRect(cx - 40, cy, 3, 8); }
				x.fillStyle = '#fff'; x.font = '700 13px Manrope, sans-serif'; x.fillText(Math.max(0, Math.round((t < tr ? v : Math.max(0, v - mu * 9.81 * brakesK * (t - tr))) * 3.6)) + ' km/h', Math.max(10, cx - 60), cy - 26);
			}
			if (bsc) {
				if (bsc.__car !== c.id) { bsc.setCar(c); bsc.__car = c.id; }
				bsc.road({ dry: 0x18181b, wet: 0x141518, gravel: 0x6f5e47, snow: 0xdfe4e8 }[surf]); bsc.clearMarks(); var NO = 2.4; bsc.zebra(zebra + NO); bsc.strip(NO, NO + react, 0x5aa9e6, 3.6); bsc.strip(NO + react, NO + tot, 0xf2a33a, 3.6);
				var posAt = function (t) { if (t < tr) return v * t; var tt = Math.min(t - tr, tb); return react + v * tt - .5 * mu * 9.81 * brakesK * tt * tt; };
				var vAt = function (t) { return t < tr ? v : Math.max(0, v - mu * 9.81 * brakesK * (t - tr)); };
				if (!play || RM) { bsc.set(posAt(T), 0, 0, 0); draw(T); return; }
				bsc.set(0, v, 0, 0);
				(function f2(now) { var t = Math.min((now - t0) / 1000 * .8, T); bsc.set(posAt(t), vAt(t), t < tr ? 0 : (t < T ? -mu * brakesK : 0), 0); draw(t); if ((now - t0) / 1000 * .8 < T + .4) anim = requestAnimationFrame(f2); })(t0);
				return;
			}
			if (!play || RM) { draw(T); return; }
			(function f(now) { var t = (now - t0) / 1000 * .8; draw(Math.min(t, T)); if (t < T + .2) anim = requestAnimationFrame(f); })(t0);
		}
		calc(false);
	}
	/* ------------------------------------------------------------ Great 0-100 drag */
	function dragAll(root) {
		var cars = index().filter(function (c) { return c.acc; }).sort(function (a, b) { return a.acc - b.acc; });
		var seen = {}; cars = cars.filter(function (c) { var k = c.make + c.model; if (seen[k]) return false; seen[k] = 1; return true; });
		var lanes = $('[data-da-lanes]', root), btn = $('[data-da-go]', root), clk = $('[data-da-t]', root);
		lanes.innerHTML = cars.map(function (c) { return '<div class="da__lane" data-acc="' + c.acc + '"><span class="da__nm"><b>' + esc(c.model) + '</b><small>' + esc(c.make) + '</small></span><div class="da__track"><span class="da__car"><img src="' + esc(c.img) + '" alt=""></span><em class="da__time">' + c.acc.toFixed(1) + ' s</em></div></div>'; }).join('');
		var running = false;
		on(btn, 'click', function () {
			if (running) return; running = true; btn.disabled = true;
			var ls = $$('.da__lane', lanes); ls.forEach(function (l) { l.classList.remove('is-done'); $('.da__car', l).style.left = '0%'; });
			var t0 = performance.now(), T = cars[cars.length - 1].acc + .3, place = 0;
			(function f(now) {
				var t = (now - t0) / 1000; clk.textContent = Math.min(t, T).toFixed(2) + ' s';
				ls.forEach(function (l) { var a = +l.getAttribute('data-acc'), k = Math.min(1, Math.pow(t / a, 1.6)); var cw = $('.da__car', l).offsetWidth; $('.da__car', l).style.left = 'calc(' + (k * 100) + '% - ' + (k * cw) + 'px)'; if (k >= 1 && !l.classList.contains('is-done')) { l.classList.add('is-done'); place++; l.setAttribute('data-place', place); } });
				if (t < T) requestAnimationFrame(f); else { running = false; btn.disabled = false; btn.textContent = 'Run it again'; }
			})(t0);
		});
	}

	/* ------------------------------------------------------------ Tech Lab */
	var FIG = {
		v8: function (n) { var p = ''; for (var i = 0; i < n; i++) { var L = i < n / 2, k = i % (n / 2), x = L ? 70 + k * 26 : 70 + k * 26, y = L ? 70 : 150, rot = L ? -25 : 25; p += '<g transform="translate(' + (x + (L ? 0 : 10)) + ' ' + y + ') rotate(' + rot + ')"><rect x="-10" y="-34" width="20" height="40" rx="3" class="f-cyl"/><rect x="-8" y="-30" width="16" height="12" rx="2" class="f-pis" style="animation-delay:-' + (i * .11).toFixed(2) + 's"/></g>'; } return '<svg viewBox="0 0 360 230">' + p + '<rect x="60" y="102" width="' + (n / 2 * 26 + 20) + '" height="18" rx="9" class="f-crank"/><g class="f-turbo" transform="translate(300 60)"><circle r="26" class="f-ring"/><g class="f-spin"><path d="M0-20L4-4 20 0 4 4 0 20-4 4-20 0-4-4Z" class="f-gold"/></g></g><g class="f-turbo" transform="translate(300 170)"><circle r="26" class="f-ring"/><g class="f-spin"><path d="M0-20L4-4 20 0 4 4 0 20-4 4-20 0-4-4Z" class="f-gold"/></g></g><path d="M300 90 V140" class="f-flow"/><text x="300" y="222" class="f-t">turbochargers</text></svg>'; },
		air: function () { return '<svg viewBox="0 0 360 230"><g class="f-body"><path d="M40 70 Q60 40 120 38 L240 38 Q300 40 320 70 L320 96 L40 96Z" class="f-ring"/></g><g transform="translate(110 120)"><rect x="-22" y="-16" width="44" height="34" rx="16" class="f-bag"/></g><g transform="translate(250 120)"><rect x="-22" y="-16" width="44" height="34" rx="16" class="f-bag"/></g><circle cx="110" cy="185" r="30" class="f-ring"/><circle cx="250" cy="185" r="30" class="f-ring"/><text x="180" y="226" class="f-t">air springs raise and lower the body</text></svg>'; },
		awd: function () { return '<svg viewBox="0 0 360 230"><rect x="120" y="20" width="120" height="190" rx="30" class="f-ring"/><rect x="88" y="40" width="22" height="46" rx="6" class="f-gold"/><rect x="250" y="40" width="22" height="46" rx="6" class="f-gold"/><rect x="88" y="146" width="22" height="46" rx="6" class="f-gold"/><rect x="250" y="146" width="22" height="46" rx="6" class="f-gold"/><circle cx="180" cy="115" r="16" class="f-ring"/><path d="M180 99V63H110M180 63H250M180 131V169H110M180 169H250" class="f-flow"/><text x="180" y="226" class="f-t">torque split front and rear</text></svg>'; },
		turbo: function () { return '<svg viewBox="0 0 360 230"><rect x="20" y="80" width="90" height="70" rx="10" class="f-ring"/><text x="65" y="120" class="f-t">engine</text><circle cx="180" cy="115" r="36" class="f-ring"/><g class="f-spin" transform="translate(180 115)"><path d="M0-26L6-6 26 0 6 6 0 26-6 6-26 0-6-6Z" class="f-gold"/></g><text x="180" y="175" class="f-t">48V motor</text><rect x="250" y="90" width="90" height="50" rx="8" class="f-ring"/><text x="295" y="120" class="f-t">battery</text><path d="M110 115H144M216 115H250" class="f-flow"/></svg>'; },
		brakes: function () { return '<svg viewBox="0 0 360 230"><g transform="translate(170 115)"><g class="f-spin f-slow"><circle r="86" class="f-disc"/><circle r="30" class="f-ring"/>' + Array.apply(null, Array(12)).map(function (_, i) { return '<circle cx="' + (60 * Math.cos(i * .5236)).toFixed(1) + '" cy="' + (60 * Math.sin(i * .5236)).toFixed(1) + '" r="4" class="f-hole"/>'; }).join('') + '</g><path d="M56-70 Q100-40 100 0 Q100 40 56 70 L70 80 Q118 40 118 0 Q118-40 70-80Z" class="f-caliper"/></g><text x="180" y="226" class="f-t">carbon-ceramic disc and caliper</text></svg>'; }
	};
	var E3PH = { i4: ['/wp-content/uploads/2026/11/laqim-engine-i4-1024x768.jpg', 'Toyota Dynamic Force inline-four, the family that powers the RAV4', 'Alexander Migl, CC BY-SA 4.0'], v6: ['/wp-content/uploads/2026/11/laqim-engine-v6-1024x576.png', 'Toyota V35A twin-turbo V6 in a Land Cruiser 300', 'Autosdeprimera, CC BY 3.0'], f6: ['/wp-content/uploads/2026/11/laqim-engine-f6-1024x613.jpg', 'Porsche 911 flat-six (1971 911 ST), the ancestor of today’s 911 Turbo engine', 'Prova MO, CC BY-SA 4.0'], v8: ['/wp-content/uploads/2026/11/laqim-tech-v8-1024x576.jpg', 'Lamborghini Urus 4.0-litre twin-turbo V8', 'Y.Leclercq, CC BY-SA 4.0'], v12: ['/wp-content/uploads/2026/11/laqim-tech-v12-1024x681.jpg', 'Ferrari F140 V12, the family behind the Purosangue’s engine', 'Mr.choppers, CC BY-SA 3.0'] };
	var TLPH = { v8: ['/wp-content/uploads/2026/11/laqim-tech-v8-1024x576.jpg', 'Lamborghini Urus 4.0-litre twin-turbo V8', 'Y.Leclercq', 'CC BY-SA 4.0'], v12: ['/wp-content/uploads/2026/11/laqim-tech-v12-1024x681.jpg', 'Ferrari F140 V12', 'Mr.choppers', 'CC BY-SA 3.0'], brakes: ['/wp-content/uploads/2026/11/laqim-tech-brakes-1024x682.jpg', 'Mercedes-AMG carbon-ceramic brake', 'Cheeni', 'CC BY-SA 3.0'], awd: ['/wp-content/uploads/2026/11/laqim-tech-awd-1024x649.jpg', 'Mercedes-Benz 4MATIC transfer gearbox', 'LSDSL', 'CC BY-SA 2.0 DE'], air: ['/wp-content/uploads/2026/11/laqim-tech-air-1024x683.jpg', 'Citroën DS, the car that made self-levelling suspension famous', 'Greg Gjerdingen', 'CC BY 2.0'] };
	function tech(root) {
		var data; try { data = JSON.parse($('[data-tl-data]', root).textContent); } catch (e) { return; }
		var fig = $('[data-tl-fig]', root), h = $('[data-tl-h]', root), p = $('[data-tl-p]', root), carsEl = $('[data-tl-cars]', root);
		var test = { v8: function (c) { return /V8/i.test(c.engine) && /turbo|biturbo/i.test(c.engine); }, v12: function (c) { return /V12/i.test(c.engine); }, turbo: function (c) { return /hybrid|MHEV|EQ Boost/i.test(c.engine + ' ' + c.fuel); }, air: function (c) { return /air/i.test(c.hl); }, awd: function (c) { return /AWD|4WD|4MATIC|all-wheel/i.test(c.drive); }, brakes: function (c) { return /ceramic/i.test(c.hl); } };
		function show(k) {
			var t = data[k]; if (!t) return;
			$$('[data-tl]', root).forEach(function (b) { b.classList.toggle('is-on', b.getAttribute('data-tl') === k); });
			fig.classList.remove('is-in'); void fig.offsetWidth;
			var svg = k === 'v8' ? FIG.v8(8) : k === 'v12' ? FIG.v8(12) : FIG[k](), ph = TLPH[k];
			fig.innerHTML = ph ? '<figure class="tl__photo"><img src="' + ph[0] + '" alt="' + esc(ph[1]) + '" loading="lazy"><div class="tl__inset">' + svg + '</div><figcaption>' + esc(ph[1]) + ' · Photo: ' + esc(ph[2]) + ', ' + esc(ph[3]) + ', via Wikimedia Commons</figcaption></figure>' : svg;
			var e3l = $('[data-tl-3d]', root); if (!e3l) { e3l = d.createElement('a'); e3l.className = 'lx-btn lx-btn--gold tl__3d'; e3l.setAttribute('data-tl-3d', ''); p.parentNode.insertBefore(e3l, p.nextSibling); }
			e3l.hidden = !(k === 'v8' || k === 'v12'); e3l.href = '/lab/#engine=' + k; e3l.textContent = k === 'v12' ? 'Watch a V12 run in 3D' : 'Watch a V8 run in 3D';
			fig.classList.add('is-in');
			h.textContent = t[0]; p.textContent = t[1];
			var list = index().filter(test[k] || function () { return false; });
			carsEl.innerHTML = list.length ? list.slice(0, 8).map(function (c) { return '<a href="' + esc(c.url) + '"><img src="' + esc(thumb(c)) + '" alt="">' + esc(cname(c)) + '</a>'; }).join('') : '<em>None in the showcase yet.</em>';
		}
		$$('[data-tl]', root).forEach(function (b) { on(b, 'click', function () { show(b.getAttribute('data-tl')); }); });
		show('v8');
		/* 3D car under the hotspots */
		var host = index().filter(function (c) { return c.glb && /urus/i.test(c.model); })[0] || index().filter(function (c) { return c.glb && c.body === 'SUV'; })[0];
		var box = $('.tl__car', root); if (!host || !box) return;
		var ANCH = { v8: [1.55, 1.0, .25], v12: [1.25, 1.05, -.35], turbo: [.45, .62, 0], air: [-1.55, .55, .95], awd: [0, .32, 0], brakes: [1.48, .4, .98] };
		function go3d() {
			load3D(function (err) {
				if (err) return; var T = w.THREE, cv = d.createElement('canvas'); cv.className = 'tl__cv'; box.insertBefore(cv, box.firstChild); box.classList.add('is-3d');
				var R = setupRenderer(cv, true), S = new T.Scene(); S.environment = studioEnv(R); R.setClearColor(0, 0);
				S.add(new T.HemisphereLight(0xffffff, 0x333333, .7)); var dl = new T.DirectionalLight(0xffffff, .9); dl.position.set(4, 8, 6); S.add(dl);
				var C = new T.PerspectiveCamera(30, 1, .1, 100); C.position.set(4.5, 2.2, 5.3);
				var O = new T.OrbitControls(C, cv); O.enableDamping = true; O.enableZoom = false; O.enablePan = false; O.target.set(0, .7, 0); O.minPolarAngle = .5; O.maxPolarAngle = 1.45;
				var sh = new T.Mesh(new T.PlaneGeometry(6.5, 3.4), new T.MeshBasicMaterial({ map: shadowTex(), transparent: true, depthWrite: false })); sh.rotation.x = -Math.PI / 2; S.add(sh);
				var car = null; loadModel(host.glb, function (e, m) { if (e) return; car = m.clone(true); car.traverse(function (o) { if (o.isMesh && o.material) { o.material = o.material.clone(); o.material.transparent = true; o.material.opacity = .55; o.material.depthWrite = false; } }); S.add(car); });
				function size() { var r = box.getBoundingClientRect(); R.setSize(r.width, r.height, false); C.aspect = r.width / Math.max(1, r.height); C.updateProjectionMatrix(); var k = Math.max(1, 1.55 / C.aspect); C.position.sub(O.target).setLength(7.25 * k).add(O.target); }
				size(); on(w, 'resize', size);
				var dots = $$('.tl__dot', box), v = new T.Vector3();
				(function loop() { requestAnimationFrame(loop); O.update(); R.render(S, C); var r = box.getBoundingClientRect(); dots.forEach(function (b) { var a = ANCH[b.getAttribute('data-tl')]; if (!a) return; v.set(a[0], a[1], a[2]).project(C); b.style.left = ((v.x + 1) / 2 * 100) + '%'; b.style.top = ((1 - v.y) / 2 * 100) + '%'; }); })();
			});
		}
		if ('IntersectionObserver' in w) { var io = new IntersectionObserver(function (es) { if (es[0].isIntersecting) { io.disconnect(); go3d(); } }, { rootMargin: '200px' }); io.observe(box); }
	}

	/* ------------------------------------------------------------ launch control */
	function lcScene(strip) {
		var T = w.THREE, cv = d.createElement('canvas'); cv.className = 'lc__cv'; strip.insertBefore(cv, strip.firstChild); strip.classList.add('is-3d');
		var R = setupRenderer(cv), S = new T.Scene(); S.background = new T.Color(0x0b0b0e); S.fog = new T.Fog(0x0b0b0e, 26, 70); S.environment = studioEnv(R);
		S.add(new T.HemisphereLight(0xffffff, 0x1c1c20, .65)); var dl = new T.DirectionalLight(0xffffff, 1); dl.position.set(4, 9, 7); S.add(dl); var rim = new T.DirectionalLight(0xffd9a0, .5); rim.position.set(-5, 3, -6); S.add(rim);
		var C = new T.PerspectiveCamera(30, 2, .1, 200); function lin(h) { return new T.Color(h).convertSRGBToLinear(); }
		var road = new T.Mesh(new T.PlaneGeometry(400, 9), new T.MeshStandardMaterial({ color: lin(0x18181b), roughness: .9, envMapIntensity: .1 })); road.rotation.x = -Math.PI / 2; S.add(road);
		var verge = new T.Mesh(new T.PlaneGeometry(400, 60), new T.MeshStandardMaterial({ color: lin(0x0f120d), roughness: 1, envMapIntensity: .1 })); verge.rotation.x = -Math.PI / 2; verge.position.set(0, -.01, -30); S.add(verge);
		function inst(geo, mat, n) { var m = new T.InstancedMesh(geo, mat, n); S.add(m); return m; }
		var M4 = new T.Matrix4(), col = new T.Color();
		var dash = inst(new T.BoxGeometry(3, .01, .16), new T.MeshBasicMaterial({ color: 0xe8e8e8 }), 24), DS = 6;
		var kerb = inst(new T.BoxGeometry(1, .12, .5), new T.MeshStandardMaterial({ roughness: .6 }), 70), KS = 1;
		for (var i = 0; i < 70; i++) kerb.setColorAt(i, col.setHex(i % 2 ? 0xf2f2f2 : 0xc99a3a).convertSRGBToLinear());
		var pole = inst(new T.CylinderGeometry(.07, .09, 5, 8), new T.MeshStandardMaterial({ color: lin(0x2a2a2e), metalness: .6, roughness: .4 }), 14), PS = 9;
		var lamp = inst(new T.BoxGeometry(.9, .14, .35), new T.MeshBasicMaterial({ color: 0xffe7b0 }), 14);
		var board = inst(new T.BoxGeometry(2.6, .8, .08), new T.MeshStandardMaterial({ color: lin(0x16161a), roughness: .5 }), 5), BS = 26;
		var stripe = inst(new T.BoxGeometry(2.6, .1, .09), new T.MeshBasicMaterial({ color: 0xc99a3a }), 5);
		var shT = shadowTex(), holder = new T.Group(); S.add(holder);
		var sh = new T.Mesh(new T.PlaneGeometry(5.6, 2.8), new T.MeshBasicMaterial({ map: shT, transparent: true, depthWrite: false })); sh.rotation.x = -Math.PI / 2; sh.position.y = .02; holder.add(sh);
		var pitch = new T.Group(); holder.add(pitch); var model = null, curUrl = '';
		var smT = (function () { var c = d.createElement('canvas'); c.width = c.height = 64; var x = c.getContext('2d'), g = x.createRadialGradient(32, 32, 2, 32, 32, 31); g.addColorStop(0, 'rgba(225,225,225,.5)'); g.addColorStop(1, 'rgba(225,225,225,0)'); x.fillStyle = g; x.fillRect(0, 0, 64, 64); return new T.CanvasTexture(c); })(), puffs = [];
		for (var p = 0; p < 40; p++) { var sp = new T.Sprite(new T.SpriteMaterial({ map: smT, transparent: true, depthWrite: false })); sp.visible = false; S.add(sp); puffs.push({ s: sp, l: 0 }); }
		var X = 0, V = 0, G = 0, slip = 0, pIdx = 0, pp = 0, last = 0, lead = 0, camD = 1, extras = [], whiteM = new T.MeshBasicMaterial({ color: 0xf2f2f2 });
		function addAt(m, xw) { S.add(m); extras.push({ m: m, xw: xw }); }
		function lay(m, n, spacing, y, z, extra) { for (var i = 0; i < n; i++) { var x = ((i * spacing - X) % (n * spacing) + n * spacing) % (n * spacing) - n * spacing * .4; M4.makeTranslation(x + (extra || 0), y, z); m.setMatrixAt(i, M4); } m.instanceMatrix.needsUpdate = true; }
		function size() { var r = strip.getBoundingClientRect(); R.setSize(r.width, r.height, false); C.aspect = r.width / Math.max(1, r.height); C.updateProjectionMatrix(); }
		size(); on(w, 'resize', size);
		var vis = true; if ('IntersectionObserver' in w) new IntersectionObserver(function (es) { vis = es[0].isIntersecting; }).observe(strip);
		(function loop(now) {
			requestAnimationFrame(loop); if (!vis) return; var dt = last ? Math.min(.1, (now - last) / 1000) : 0; last = now;
			extras.forEach(function (e) { e.m.position.x = e.xw - X; });
			lay(dash, 24, DS, .01, 0); lay(kerb, 70, KS, .06, 4.7); lay(pole, 14, PS, 2.5, -5.2); lay(lamp, 14, PS, 5, -4.85); lay(board, 5, BS, 1.1, -4.2, 3); lay(stripe, 5, BS, 1.55, -4.15, 3);
			var tp = Math.max(-.035, Math.min(.05, G * .035)); pp += (tp - pp) * Math.min(1, dt * 8); pitch.rotation.z = pp;
			holder.position.x += (Math.min(1.4, G * .9) - holder.position.x) * Math.min(1, dt * 3);
			if (slip && Math.random() < .8) { var q = puffs[pIdx++ % puffs.length]; q.l = 1; q.s.visible = true; q.s.position.set(holder.position.x - 1.5, .35, .5 + Math.random() * .6); q.s.scale.setScalar(.5); }
			puffs.forEach(function (q) { if (q.l <= 0) return; q.l -= dt * 1.1; q.s.material.opacity = Math.max(0, q.l) * .6; q.s.scale.setScalar(.5 + (1 - q.l) * 3); q.s.position.x -= dt * (V * .9 + .6); q.s.position.y += dt * .4; if (q.l <= 0) q.s.visible = false; });
			var k = Math.max(1, 1.9 / C.aspect); var lx = lead * 7.4 * k * camD * .268 * C.aspect; C.position.set(holder.position.x * .35 + .4 + lx, 1.35 + (camD - 1) * 1.6, 7.4 * k * camD); C.lookAt(holder.position.x * .35 + .4 + lx, .65, 0);
			R.render(S, C);
		})(0);
		return {
			setCar: function (c) {
				if (!c.glb) { if (curUrl === 'box') return; curUrl = 'box'; if (model) pitch.remove(model); var g0 = genericCar(0xc99a3a); pitch.add(g0); model = g0; return; }
				if (c.glb === curUrl) return; curUrl = c.glb; if (model) { pitch.remove(model); model = null; }
				var stop = loadTag(strip, c.glb); loadModel(c.glb, function (err, m) { stop(); if (err || curUrl !== c.glb) return; var g = new T.Group(); g.add(m); g.rotation.y = isFlip(c) ? Math.PI : 0; pitch.add(g); model = g; });
			},
			has: function () { return !!model; },
			set: function (x, v, g, s) { X = x; V = v; G = g; slip = s; },
			reset: function () { X = 0; V = 0; G = 0; slip = 0; },
			clearMarks: function () { extras.forEach(function (e) { S.remove(e.m); }); extras = []; },
			zebra: function (xw) { var g = new T.Group(); for (var i = 0; i < 7; i++) { var b = new T.Mesh(new T.BoxGeometry(3, .012, .55), whiteM); b.position.set(1.5, .012, -3.6 + i * 1.2); g.add(b); } var sign = new T.Mesh(new T.CylinderGeometry(.06, .06, 2.6, 8), new T.MeshStandardMaterial({ color: 0x2a2a2e })); sign.position.set(-.4, 1.3, -4.6); g.add(sign); var lt = new T.Mesh(new T.SphereGeometry(.22, 16, 12), new T.MeshBasicMaterial({ color: 0xffb020 })); lt.position.set(-.4, 2.7, -4.6); g.add(lt); addAt(g, xw); },
			strip: function (x0, x1, hex, z) { var g = new T.Group(), m = new T.Mesh(new T.BoxGeometry(Math.max(.01, x1 - x0), .015, .8), new T.MeshBasicMaterial({ color: hex })); m.position.set((x1 - x0) / 2, .014, z); g.add(m); addAt(g, x0); },
			road: function (hex) { road.material.color.copy(lin(hex)); road.material.roughness = hex === 0x141518 ? .2 : .85; },
			lead: function (v, dd) { lead = v; camD = dd || 1; }
		};
	}
	function launch(root) {
		var sel = $('[data-lc-car]', root), pad = $('[data-lc-pad]', root), say = $('[data-lc-say]', root), sub = $('[data-lc-sub]', root), msg = $('[data-lc-msg]', root);
		var lights = $$('[data-lc-lights] i', root), bar = $('[data-lc-bar]', root), kmh = $('[data-lc-kmh]', root), img = $('[data-lc-car-img]', root);
		var cars = index().filter(function (c) { return c.acc; }).sort(function (a, b) { return a.acc - b.acc; });
		if (!cars.length) { root.hidden = true; return; }
		sel.innerHTML = grp(cars, function (c) { return '<option value="' + c.id + '">' + esc(cname(c)) + ' · ' + c.acc + ' s</option>'; });
		var g3 = cars.filter(function (c) { return c.glb; })[0]; if (g3) sel.value = g3.id;
		var lh = parseHash().launch; if (lh && byId(+lh) && byId(+lh).acc) sel.value = lh;
		var st = 'idle', tOut = 0, timers = [], snd = null, BK = 'psr-lc-best', lsc = null, strip = img.parentNode;
		if ('IntersectionObserver' in w) { var lio = new IntersectionObserver(function (es) { if (!es[0].isIntersecting) return; lio.disconnect(); load3D(function (err) { if (err) return; lsc = lcScene(strip); lsc.setCar(car()); }); }, { rootMargin: '200px' }); lio.observe(strip); }
		function best() { try { return JSON.parse(localStorage.getItem(mode === 'man' ? 'psr-lc-man' : BK) || '{}'); } catch (e) { return {}; } }
		function car() { return byId(sel.value) || cars[0]; }
		var mode = 'auto', modes = d.createElement('div'); modes.className = 'lc__modes'; modes.innerHTML = '<button type="button" data-lc-mode="auto" aria-pressed="true"><b>Lights to 100</b><span>Reaction test, the car does the rest</span></button><button type="button" data-lc-mode="man" aria-pressed="false"><b>Quarter mile, you shift</b><span>Tap or Space to change up in the green</span></button>';
		pad.parentNode.insertBefore(modes, pad);
		$$('[data-lc-mode]', modes).forEach(function (b) { on(b, 'click', function () { if (st === 'run' || st === 'arming' || st === 'go') return; mode = b.getAttribute('data-lc-mode'); $$('[data-lc-mode]', modes).forEach(function (x) { x.setAttribute('aria-pressed', x === b ? 'true' : 'false'); }); root.classList.toggle('is-man', mode === 'man'); reset(); showCar(); msg.textContent = mode === 'man' ? 'Seven gears, one tachometer. Change up in the green band: too early bogs the engine, too late hits the limiter. Your time is measured against a perfect-shift run of the same car.' : 'Formula 1 drivers react in about 0.2 seconds. Jump the lights and the run does not count.'; }); });
		if (lh) setTimeout(function () { var mb2 = $('[data-lc-mode="man"]', modes); if (mb2) mb2.click(); }, 0);
		var tach = d.createElement('canvas'); tach.className = 'lc__tach'; tach.width = 300; tach.height = 300; strip.appendChild(tach); var tx = tach.getContext('2d'), flash = d.createElement('b'); flash.className = 'lc__flash'; strip.appendChild(flash);
		function drawTach(x, gear, kmhV, lim) {
			var c2 = tx, W = 300, cx = 150, cy = 160, r = 118, a0 = Math.PI * .75, a1 = Math.PI * 2.25; c2.clearRect(0, 0, W, W);
			c2.fillStyle = 'rgba(8,8,10,.82)'; c2.beginPath(); c2.arc(cx, cy, 140, 0, Math.PI * 2); c2.fill();
			c2.lineWidth = 14; c2.strokeStyle = 'rgba(255,255,255,.1)'; c2.beginPath(); c2.arc(cx, cy, r, a0, a1); c2.stroke();
			c2.strokeStyle = '#3ddc6a'; c2.beginPath(); c2.arc(cx, cy, r, a0 + (a1 - a0) * .86, a0 + (a1 - a0) * .98); c2.stroke();
			c2.strokeStyle = '#ff4d4d'; c2.beginPath(); c2.arc(cx, cy, r, a0 + (a1 - a0) * .98, a1); c2.stroke();
			c2.strokeStyle = '#d9a93f'; c2.lineWidth = 14; c2.beginPath(); c2.arc(cx, cy, r, a0, a0 + (a1 - a0) * Math.min(1, x)); c2.stroke();
			var an = a0 + (a1 - a0) * Math.min(1.02, x); c2.strokeStyle = lim ? '#ff4d4d' : '#fff'; c2.lineWidth = 4; c2.beginPath(); c2.moveTo(cx, cy); c2.lineTo(cx + Math.cos(an) * (r - 4), cy + Math.sin(an) * (r - 4)); c2.stroke();
			c2.fillStyle = '#f1d27a'; c2.font = '600 74px "Cormorant Garamond", Georgia, serif'; c2.textAlign = 'center'; c2.fillText(gear, cx, cy + 26);
			c2.fillStyle = 'rgba(255,255,255,.8)'; c2.font = '700 22px Manrope, sans-serif'; c2.fillText(Math.round(kmhV) + ' km/h', cx, cy + 70);
		}
		function flashMsg(t, cls) { flash.textContent = t; flash.className = 'lc__flash is-on ' + (cls || ''); clearTimeout(flash.__t); flash.__t = setTimeout(function () { flash.className = 'lc__flash'; }, 700); }
		/* manual-shift quarter mile */
		function manModel(c) {
			var sp = carSpec(c); calibrate(sp);
			var m = sp.kg, P = sp.hp * 745.7 * sp.k, Ftr = 1.12 * 9.81 * m * (sp.drive === 'awd' ? 1 : sp.drive === 'fwd' ? .58 : .55), Flow = sp.tq * 13.5 / .36 * sp.k;
			var VG = [58, 98, 138, 178, 218, 262, 320].map(function (k) { return k / 3.6; }), red = (c.cyl || 8) >= 12 ? 8500 : (c.cyl || 8) >= 8 ? 7000 : 6500;
			function pf(x) { return x >= 1 ? 0 : Math.max(.32, 1 - Math.pow((x - .92) / .7, 2)); }
			function make() { return { t: 0, x: 0, v: 0, g: 0, sh: 0, lim: 0, a: 0 }; }
			function rpmx(S) { return Math.max(S.g === 0 ? .55 : .2, S.v / VG[S.g]); }
			function step(S, dt) {
				var x = rpmx(S), F; S.lim = x >= 1 ? 1 : 0;
				if (S.sh > 0) { S.sh -= dt; F = 0; } else F = S.lim ? 0 : Math.min(P * pf(x) / Math.max(S.v, 1.5), Flow * pf(x) * 1.15, Ftr);
				var a = (F - .5 * 1.2 * sp.cda * S.v * S.v - .013 * m * 9.81) / m; S.a = a; S.v = Math.max(0, S.v + a * dt); S.x += S.v * dt; S.t += dt; return x;
			}
			function shift(S) { if (S.g >= VG.length - 1 || S.sh > 0) return false; S.g++; S.sh = sp.dsg ? .08 : .2; return true; }
			var ref = make(); while (ref.x < 402 && ref.t < 60) { var xr = step(ref, 1 / 240); if (xr >= .955) shift(ref); }
			return { make: make, step: step, shift: shift, rpmx: rpmx, red: red, ref: ref.t, sp: sp };
		}
		function manualRun(c, rt) {
			var M = manModel(c), S = M.make(), last = performance.now(), log = [];
			root.__shift = function () { var x = M.rpmx(S); if (!M.shift(S)) return; var q = S.lim ? ['Limiter', 'late'] : x >= .86 ? ['Perfect', 'ok'] : x >= .78 ? ['Good', 'mid'] : ['Early', 'late']; log.push(q[0]); flashMsg(q[0] + ' · ' + (S.g + 1), q[1]); FX.play(q[0] === 'Perfect' ? 'ok' : 'tick'); };
			sub.textContent = 'Tap or press Space to change up. Watch the tachometer.'; say.textContent = 'Shift!';
			(function f(now) {
				var dt = Math.min(.05, (now - last) / 1000); last = now; var n = 4, x = 0; for (var i = 0; i < n; i++) x = M.step(S, dt / n);
				if (lsc && lsc.has()) { lsc.set(S.x, S.v, S.a / 9.81, S.t < 1.2 && S.a > 9 ? 1 : 0); img.style.opacity = 0; }
				bar.style.transform = 'scaleX(' + Math.min(1, S.x / 402) + ')'; drawTach(S.lim ? 1 + Math.random() * .02 : x, S.g + 1, S.v * 3.6, S.lim); kmh.textContent = Math.round(S.x) + ' m · ' + Math.round(S.v * 3.6) + ' km/h';
				rev(Math.min(1, x) * M.red, S.sh > 0 ? .2 : 1);
				if (S.x < 402 && S.t < 40) return requestAnimationFrame(f);
				root.__shift = null; quiet(); st = 'done'; root.__doneAt = performance.now(); if (lsc) lsc.set(S.x, 0, 0, 0);
				var tot = rt + S.t, diff = S.t - M.ref, b = best(), pb = rt < 2 && (!b[c.id] || tot < b[c.id]); if (pb) { b[c.id] = tot; try { localStorage.setItem('psr-lc-man', JSON.stringify(b)); } catch (e) {} }
				$('[data-lc-tot]', root).textContent = tot.toFixed(3) + ' s'; $('[data-lc-best]', root).textContent = b[c.id] ? b[c.id].toFixed(3) + ' s' : '–';
				var per = log.filter(function (q) { return q === 'Perfect'; }).length;
				say.textContent = tot.toFixed(3) + ' s'; sub.textContent = 'Lights out to the quarter-mile line at ' + Math.round(S.v * 3.6) + ' km/h. Tap to go again.';
				msg.innerHTML = '<b>' + (diff < .05 ? 'Faultless shifting.' : diff < .25 ? 'Quick hands.' : diff < .6 ? 'Decent run, some time left on the table.' : 'The gearbox won that one.') + '</b> Reaction ' + rt.toFixed(3) + ' s + run ' + S.t.toFixed(2) + ' s. A perfect-shift run of the ' + esc(c.model) + ' does ' + M.ref.toFixed(2) + ' s, so you were ' + (diff <= 0 ? 'right on it' : '+' + diff.toFixed(2) + ' s') + '. ' + per + ' of ' + log.length + ' shifts in the green.' + (pb ? ' <b class="lc__pb">New personal best.</b>' : '') + ' ' + FX.shareBtn('Quarter mile in ' + tot.toFixed(3) + ' s shifting the ' + c.make + ' ' + c.model + ' myself on Laqim Autoworld. Can you shift faster?');
				if (pb || diff < .05) { FX.play('win'); FX.confetti(strip, 110); } else FX.play('ok');
			})(last);
		}
		function showCar() { var c = car(); img.style.backgroundImage = c.img ? 'url("' + c.img + '")' : ''; if (lsc) lsc.setCar(c); $('[data-lc-acc]', root).textContent = c.acc.toFixed(1) + ' s'; var b = best()[c.id]; $('[data-lc-best]', root).textContent = b ? b.toFixed(3) + ' s' : '–'; }
		function clear() { timers.forEach(clearTimeout); timers = []; }
		function setL(n, cls) { lights.forEach(function (l, i) { l.className = i < n ? cls : ''; }); }
		function rev(rpm, load) { try { if (!snd) snd = engineSynth(); if (snd) { snd.on(true); snd.set(rpm, car().cyl || 8, load); } } catch (e) {} }
		function quiet() { try { if (snd) snd.on(false); } catch (e) {} }
		function reset(text, subText) { clear(); st = 'idle'; setL(0, ''); root.classList.remove('is-armed', 'is-go', 'is-jump'); say.textContent = text || 'Tap to arm the lights'; sub.textContent = subText || 'Then tap again the instant they go out. Space bar works too.'; }
		function arm() {
			clear(); st = 'arming'; root.classList.add('is-armed'); root.classList.remove('is-go', 'is-jump'); say.textContent = 'Wait for it…'; sub.textContent = 'Do not tap until every light is off.';
			bar.style.transform = 'scaleX(0)'; kmh.textContent = mode === 'man' ? '0 m · 0 km/h' : '0 km/h'; img.style.transform = 'translateX(0)'; if (lsc) lsc.reset(); if (mode === 'man') drawTach(.12, 1, 0, 0);
			$('[data-lc-rt]', root).textContent = '–'; $('[data-lc-tot]', root).textContent = '–';
			lights.forEach(function (l, i) { timers.push(setTimeout(function () { setL(i + 1, 'is-on'); rev(1800 + i * 500, .3); FX.play('beep'); }, 900 * (i + 1))); });
			timers.push(setTimeout(function () { setL(0, ''); st = 'go'; tOut = performance.now(); root.classList.remove('is-armed'); root.classList.add('is-go'); say.textContent = 'GO!'; rev(6500, 1); FX.play('go'); }, 900 * 5 + 400 + Math.random() * 2200));
		}
		function hit() {
			if (st === 'done' && performance.now() - (root.__doneAt || 0) < 1200) return; /* a late shift tap at the line must not re-arm the lights */
			if (st === 'idle' || st === 'done') return arm();
			if (st === 'arming') { clear(); st = 'done'; root.__doneAt = performance.now(); setL(5, 'is-jump'); root.classList.add('is-jump'); quiet(); FX.play('lose'); FX.buzz([80, 60, 80]); say.textContent = 'Jump start'; sub.textContent = 'You moved before the lights went out. Tap to try again.'; msg.textContent = 'Stewards would hand you a penalty for that one.'; return; }
			if (st === 'run' && root.__shift) return root.__shift();
			if (st !== 'go') return;
			var rt = (performance.now() - tOut) / 1000, c = car(), tot = rt + c.acc;
			if (rt < .1) { clear(); st = 'done'; root.__doneAt = performance.now(); setL(5, 'is-jump'); root.classList.remove('is-go'); root.classList.add('is-jump'); quiet(); FX.play('lose'); FX.buzz([80, 60, 80]); say.textContent = 'Jump start'; sub.textContent = 'Under 0.100 s is anticipation, not reaction. Tap to try again.'; msg.textContent = 'Race starts treat anything quicker than a tenth of a second as a false start: no human reacts that fast.'; return; }
			st = 'run'; root.classList.remove('is-go');
			if (mode === 'man') { $('[data-lc-rt]', root).textContent = rt.toFixed(3) + ' s'; return manualRun(c, rt); }
			$('[data-lc-rt]', root).textContent = rt.toFixed(3) + ' s'; say.textContent = rt.toFixed(3) + ' s'; sub.textContent = 'Launching the ' + c.make + ' ' + c.model + '…';
			var t0 = performance.now(), dur = c.acc * 1000;
			var sp = carSpec(c); calibrate(sp); var prof = simulate(sp, CONDS.dry, DIST['100'], 1 / 60).filter(function (r) { return r[0] >= .18; }), pT = prof.length ? prof[prof.length - 1][0] - .18 : c.acc, sc = c.acc / Math.max(.5, pT);
			(function step() { var el = (performance.now() - t0) / 1000, k = Math.min(1, el * 1000 / dur), i = Math.min(prof.length - 1, Math.max(0, Math.round(el / sc * 60))), r = prof[i] || [0, 0, 0, 0], j = Math.max(0, i - 6), g = prof.length ? (r[2] - prof[j][2]) / Math.max(1 / 60, (i - j) / 60) / 9.81 : 0, v = prof.length ? Math.min(100, r[2] * 3.6) : 100 * Math.pow(k, .78);
				bar.style.transform = 'scaleX(' + k + ')'; if (lsc && lsc.has()) { lsc.set(r[1], r[2], g, r[3] && el < 1.6 ? 1 : 0); img.style.opacity = 0; } else img.style.transform = 'translateX(' + Math.round(k * (img.parentNode.clientWidth - img.offsetWidth)) + 'px)';
				var gear = 1; [55, 95].forEach(function (s2) { if (v > s2) gear++; }); kmh.textContent = Math.round(k >= 1 ? 100 : v) + ' km/h · gear ' + gear + ' · ' + Math.max(0, g).toFixed(2) + ' g'; rev(2500 + 4500 * ((v % 55) / 55), 1); if (k < 1) requestAnimationFrame(step); else { if (lsc) lsc.set(r[1], 0, 0, 0); finish(); } })();
			function finish() {
				quiet(); st = 'done'; root.__doneAt = performance.now(); $('[data-lc-tot]', root).textContent = tot.toFixed(3) + ' s';
				var b = best(), pb = rt < 2 && (!b[c.id] || tot < b[c.id]); if (pb) { b[c.id] = tot; try { localStorage.setItem(BK, JSON.stringify(b)); } catch (e) {} }
				$('[data-lc-best]', root).textContent = b[c.id] ? b[c.id].toFixed(3) + ' s' : '–';
				var grade = rt < .2 ? 'F1 reflexes.' : rt < .27 ? 'Sharp. Racing-driver territory.' : rt < .4 ? 'Solid road-driver reactions.' : 'A bit sleepy at the lights.';
				say.textContent = tot.toFixed(3) + ' s'; sub.textContent = 'Lights out to 100 km/h. Tap to go again.';
				msg.innerHTML = '<b>' + grade + '</b> Your ' + rt.toFixed(3) + ' s reaction plus the ' + esc(c.model) + '’s ' + c.acc.toFixed(1) + ' s sprint.' + (pb ? ' <b class="lc__pb">New personal best.</b>' : '') + ' ' + FX.shareBtn('Lights out to 100 km/h in ' + tot.toFixed(3) + ' s (' + rt.toFixed(3) + ' s reaction) in the ' + c.make + ' ' + c.model + ' on Laqim Autoworld. Beat my launch!');
				if (pb || rt < .2) { FX.play('win'); FX.confetti(strip, 110); } else FX.play('ok');
			}
		}
		on(pad, 'click', hit);
		on(d, 'keydown', function (e) { if (e.code !== 'Space' || !root.getBoundingClientRect || root.getBoundingClientRect().top > w.innerHeight || root.getBoundingClientRect().bottom < 0) return; if (/INPUT|SELECT|TEXTAREA|BUTTON/.test((e.target || {}).tagName || '')) return; e.preventDefault(); hit(); });
		on(sel, 'change', function () { reset(); showCar(); });
		showCar();
	}

	/* ------------------------------------------------------------ higher or lower */
	function hilo(root) {
		var STATS = [['hp', 'power', ' hp'], ['tq', 'torque', ' Nm'], ['vmax', 'top speed', ' km/h'], ['kg', 'weight', ' kg'], ['acc', '0–100 time', ' s'], ['pw', 'power-to-weight', ' hp/t'], ['len', 'length', ' mm']];
		index().forEach(function (c) { if (c.hp && c.kg) c.pw = Math.round(c.hp / c.kg * 1000); if (c.dim && c.dim[0]) c.len = c.dim[0]; });
		var cars = index().filter(function (c) { return c.hp && c.img; });
		if (cars.length < 3) { root.hidden = true; return; }
		var A, B, S, streak = 0, best = 0, busy = false, BK = 'psr-hl-best';
		try { best = +localStorage.getItem(BK) || 0; } catch (e) {}
		$('[data-hl-best]', root).textContent = best;
		function pick(not) { var p; do { p = cars[Math.floor(Math.random() * cars.length)]; } while (not.indexOf(p) > -1 || (not.length && p.model === not[0].model)); return p; }
		function val(c) { return +c[S[0]] || 0; }
		function fmt(c) { var v = val(c); return (S[0] === 'acc' ? v.toFixed(1) : Math.round(v).toLocaleString()) + S[2]; }
		function card(c, hide) { return '<img src="' + esc(c.img) + '" alt=""><span><small>' + esc(c.make) + '</small><b>' + esc(c.model) + '</b><em data-hl-v>' + (hide ? '?' : fmt(c)) + '</em><i>' + esc(S[1]) + '</i></span>'; }
		function round(keepA) {
			busy = false; S = STATS[Math.floor(Math.random() * STATS.length)];
			A = keepA || pick([]); var tries = 0;
			do { B = pick([A]); tries++; } while ((!val(A) || !val(B) || val(A) === val(B)) && tries < 40);
			$('[data-hl-q]', root).textContent = S[0] === 'acc' ? 'Is its 0–100 time higher or lower?' : 'Higher or lower ' + S[1] + '?';
			$('[data-hl-a]', root).innerHTML = card(A, false); $('[data-hl-b]', root).innerHTML = card(B, true);
			root.classList.remove('is-ok', 'is-no'); $('[data-hl-msg]', root).textContent = 'Is the ' + B.make + ' ' + B.model + '’s ' + S[1] + ' higher or lower than ' + fmt(A) + '?';
		}
		function guess(hi) {
			if (busy) return; busy = true;
			var ok = hi ? val(B) > val(A) : val(B) < val(A), vEl = $('[data-hl-b] [data-hl-v]', root), t0 = performance.now(), target = val(B);
			(function count() { var k = Math.min(1, (performance.now() - t0) / 700); vEl.textContent = (S[0] === 'acc' ? (target * k).toFixed(1) : Math.round(target * k).toLocaleString()) + S[2]; if (k < 1) requestAnimationFrame(count); })();
			root.classList.add(ok ? 'is-ok' : 'is-no');
			var lost = streak; if (ok) { streak++; if (streak > best) { if (best >= 3 && streak === best + 1) FX.confetti($('[data-hl-b]', root), 90); best = streak; try { localStorage.setItem(BK, best); } catch (e) {} } FX.play(streak % 5 === 0 ? 'streak' : 'ok'); if (streak % 5 === 0) FX.confetti($('[data-hl-b]', root), 70); } else { streak = 0; FX.play('no'); FX.buzz(60); }
			$('[data-hl-streak]', root).textContent = streak; $('[data-hl-best]', root).textContent = best;
			$('[data-hl-msg]', root).innerHTML = (ok ? '<b>Correct.</b> ' : '<b>Not this time.</b> ') + esc(B.model) + ': ' + fmt(B) + ' against ' + esc(A.model) + ': ' + fmt(A) + '.' + (ok ? ' Keep going.' : ' Streak reset.') + (!ok && lost >= 3 ? ' ' + FX.shareBtn('I got a streak of ' + lost + ' in Higher or Lower on Laqim Autoworld. Beat that!') : '');
			setTimeout(function () { round(ok ? B : null); }, !ok && lost >= 3 ? 3200 : 1900);
		}
		on($('[data-hl-hi]', root), 'click', function () { guess(true); });
		on($('[data-hl-lo]', root), 'click', function () { guess(false); });
		round();
	}

	/* ------------------------------------------------------------ ear test: name the car from its engine note */
	function earTest(eq) {
		var cv = $('[data-eq-cv]', eq), x = cv && cv.getContext('2d'), syn = null, an = null, buf = null, round = 0, score = 0, streak = 0, ans = null, busy = false, opts = [];
		var all = index().filter(function (c) { return c.cyl && c.img; }), G = { 4: [], 6: [], 8: [], 12: [] };
		all.forEach(function (c) { var k = c.cyl >= 12 ? 12 : c.cyl >= 8 ? 8 : c.cyl >= 6 ? 6 : 4; G[k].push(c); });
		var msg = $('[data-eq-msg]', eq), box = $('[data-eq-opts]', eq), playB = $('[data-eq-play]', eq);
		function cylOf(c) { return c.cyl >= 12 ? 12 : c.cyl >= 8 ? 8 : c.cyl >= 6 ? 6 : 4; }
		function pickRound() {
			opts = [4, 6, 8, 12].filter(function (k) { return G[k].length; }).map(function (k) { var l = G[k]; return l[Math.floor(Math.random() * l.length)]; });
			opts.sort(function () { return Math.random() - .5; }); ans = opts[Math.floor(Math.random() * opts.length)];
			box.innerHTML = opts.map(function (c, i) { return '<button type="button" data-eq-i="' + i + '"><img src="' + esc(thumb(c)) + '" alt=""><span><b>' + esc(c.model) + '</b><em>' + esc(c.engine || '') + '</em></span></button>'; }).join('');
			box.hidden = false; $$('[data-eq-i]', box).forEach(function (b) { on(b, 'click', function () { answer(+b.getAttribute('data-eq-i'), b); }); });
		}
		function scope() {
			if (!an || !x) return; var Wc = cv.clientWidth, Hc = cv.clientHeight, k = Math.min(2, w.devicePixelRatio || 1);
			if (cv.width !== Math.round(Wc * k)) { cv.width = Math.round(Wc * k); cv.height = Math.round(Hc * k); } x.setTransform(k, 0, 0, k, 0, 0);
			an.getByteTimeDomainData(buf); x.clearRect(0, 0, Wc, Hc);
			x.strokeStyle = 'rgba(255,255,255,.06)'; for (var gy = 0; gy <= 4; gy++) { x.beginPath(); x.moveTo(0, Hc * gy / 4); x.lineTo(Wc, Hc * gy / 4); x.stroke(); }
			var g = x.createLinearGradient(0, 0, Wc, 0); g.addColorStop(0, '#8a611a'); g.addColorStop(.5, '#f1d27a'); g.addColorStop(1, '#d9a93f');
			x.strokeStyle = g; x.lineWidth = 2.2; x.shadowColor = 'rgba(241,210,122,.6)'; x.shadowBlur = 8; x.beginPath();
			for (var i = 0; i < buf.length; i++) { var px = i / (buf.length - 1) * Wc, py = Hc / 2 + (buf[i] - 128) / 128 * Hc * 1.6; if (i) x.lineTo(px, py); else x.moveTo(px, py); } x.stroke(); x.shadowBlur = 0;
			if (busy) requestAnimationFrame(scope);
		}
		function play() {
			if (busy) return; if (!syn) { syn = engineSynth(); if (!syn) { msg.textContent = 'Sound is not supported in this browser.'; return; } an = syn.ac.createAnalyser(); an.fftSize = 2048; buf = new Uint8Array(an.fftSize); syn.out.connect(an); }
			if (!ans || eq.classList.contains('is-answered')) { round++; if (round > 8) { round = 1; score = 0; } eq.classList.remove('is-answered'); pickRound(); }
			$('[data-eq-round]', eq).textContent = round + ' / 8'; busy = true; playB.textContent = '♪ Listening…'; msg.textContent = 'Idle, a blip of throttle, then a full-throttle run to the redline. Which car is it?';
			var cyl = cylOf(ans), t0 = performance.now(), red = cyl >= 12 ? 8500 : cyl >= 8 ? 6800 : cyl >= 6 ? 6200 : 5800; syn.on(true); scope();
			(function f(now) { var t = (now - t0) / 1000, rpm = t < 1 ? 800 + Math.sin(t * 9) * 40 : t < 1.6 ? 800 + (t - 1) / .6 * 2600 : t < 2.2 ? 3400 - (t - 1.6) / .6 * 2500 : t < 4.4 ? 1000 + (t - 2.2) / 2.2 * (red - 1000) : red - (t - 4.4) * 4000;
				syn.set(Math.max(750, rpm), cyl, t > 2.2 && t < 4.4 ? 1 : .3); if (t < 5) requestAnimationFrame(f); else { syn.on(false); busy = false; playB.textContent = '↻ Hear it again'; msg.textContent = 'Pick the car you just heard.'; } })(t0);
		}
		function answer(i, b) {
			if (eq.classList.contains('is-answered') || !ans) return; var ok = opts[i] === ans; eq.classList.add('is-answered');
			$$('[data-eq-i]', box).forEach(function (o, j) { if (opts[j] === ans) o.classList.add('is-ok'); }); if (!ok) b.classList.add('is-no');
			if (ok) { score++; streak++; FX.play('ok'); } else { streak = 0; FX.play('no'); FX.buzz(50); } if (round >= 8 && score >= 6) FX.confetti(eq);
			$('[data-eq-score]', eq).textContent = score; $('[data-eq-streak]', eq).textContent = streak;
			var c = cylOf(ans); msg.innerHTML = (ok ? '<b>Spot on.</b> ' : '<b>Not quite.</b> ') + 'That was the ' + esc(ans.make + ' ' + ans.model) + ': ' + c + ' cylinders, firing every ' + (720 / c) + '°. ' + ({ 4: 'Fours buzz: big gaps between pulses.', 6: 'Sixes hum: smooth, even and turbine-like when pushed.', 8: 'V8s burble: the cross-plane crank fires unevenly along each bank.', 12: 'V12s wail: pulses overlap so it sounds like tearing silk.' })[c] + (round >= 8 ? ' <b>Final score ' + score + ' / 8.</b>' : '');
			playB.textContent = round >= 8 ? '▶ New game' : '▶ Next engine';
		}
		on(playB, 'click', play);
	}

	/* ------------------------------------------------------------ 3D parts map, rarity league */
	var PMAP = { 'Headlight unit': [.47, .56, .72], 'Front bumper': [.5, .28, 0], 'Windscreen': [.16, .84, 0], 'Turbocharger': [.34, .58, .32], 'Engine control unit': [.39, .62, -.55], 'Oil filter': [.36, .36, -.1],
		'Brake pads': [.33, .24, .96], 'Carbon-ceramic brake disc': [-.31, .24, .96], 'Alloy wheel': [-.31, .12, 1.02], 'Air suspension bellow': [-.31, .45, .78], 'Infotainment screen': [.06, .72, 0], 'Interior trim panel': [-.1, .6, .62] };
	function rcol(v) { return v < 4 ? '#3ddc6a' : v < 6 ? '#f1d27a' : v < 8 ? '#ff9a3c' : '#ff4d4d'; }
	function partsMap(root) {
		var cars = index().filter(function (c) { return c.glb; }); if (!cars.length) return;
		var sel = $('[data-pm-car]', root), stage = $('[data-pm-stage]', root), info = $('[data-pm-info]', root), dots = $('[data-pm-dots]', root), cur = cars.filter(function (c) { return /Urus/.test(c.model); })[0] || cars[0], part = 0; var hm = /map=(\d+)/.exec(location.hash); if (hm && byId(hm[1]) && byId(hm[1]).glb) cur = byId(hm[1]);
		sel.innerHTML = grp(cars, function (c) { return '<option value="' + c.id + '"' + (c === cur ? ' selected' : '') + '>' + esc(cname(c)) + '</option>'; });
		function ok(c, p) { return !p.need || p.need.test(c.engine + ' ' + c.hl); }
		function detail() {
			var p = PARTS[part], c = cur; if (!ok(c, p)) { part = PARTS.findIndex(function (q) { return ok(c, q); }); p = PARTS[part]; }
			var v = rarity(c, p), inf = partsInfo(v, p);
			info.innerHTML = '<p class="lx-eyebrow">' + esc(cname(c)) + '</p><h3>' + esc(p.k) + '</h3><div class="pm__meter"><i style="--p:' + v * 10 + '%;--c:' + rcol(v) + '"></i></div><p class="pm__score"><b style="color:' + rcol(v) + '">' + v.toFixed(1) + '</b> / 10 rarity</p>'
				+ '<dl class="pm__dl"><div><dt>Typical wait</dt><dd>' + esc(inf.wait) + '</dd></div><div><dt>Original part</dt><dd>' + esc(inf.oem) + '</dd></div><div><dt>Alternatives</dt><dd>' + esc(inf.alt) + '</dd></div></dl>'
				+ '<p class="pm__h">Where to look</p><ol>' + inf.where.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ol>';
			$$('button', dots).forEach(function (b) { b.classList.toggle('is-on', +b.getAttribute('data-i') === part); });
		}
		function buildDots() {
			dots.innerHTML = PARTS.map(function (p, i) { if (!ok(cur, p)) return ''; var v = rarity(cur, p); return '<button type="button" data-i="' + i + '" style="--c:' + rcol(v) + '"><span>' + esc(p.k) + ' · ' + v.toFixed(1) + '</span></button>'; }).join('');
			$$('button', dots).forEach(function (b) { on(b, 'click', function () { part = +b.getAttribute('data-i'); detail(); }); });
			detail();
		}
		var T, R, S, C, O, holder, box = null, vis = false, started = false;
		function loadCar() {
			buildDots(); if (!started) return; while (holder.children.length) holder.remove(holder.children[0]); box = null; stage.classList.add('is-loading'); var stopT = loadTag(stage, cur.glb);
			loadModel(cur.glb, function (e, m) { stopT(); stage.classList.remove('is-loading'); if (e) return; m.rotation.y = isFlip(cur) ? Math.PI : 0; holder.add(m); holder.userData.nose = -1; box = new T.Box3().setFromObject(holder); });
		}
		on(sel, 'change', function () { cur = byId(sel.value) || cur; loadCar(); });
		function start() {
			if (started) return; started = true;
			load3D(function (err) {
				if (err) return; T = w.THREE; var cv = d.createElement('canvas'); cv.className = 'pm__cv'; stage.insertBefore(cv, stage.firstChild);
				R = setupRenderer(cv, true); S = new T.Scene(); S.environment = studioEnv(R); S.add(new T.HemisphereLight(0xffffff, 0x333333, .7));
				var dl = new T.DirectionalLight(0xffffff, .9); dl.position.set(4, 8, 6); S.add(dl);
				var sh = new T.Mesh(new T.PlaneGeometry(7, 3.6), new T.MeshBasicMaterial({ map: shadowTex(), transparent: true, depthWrite: false })); sh.rotation.x = -Math.PI / 2; S.add(sh);
				holder = new T.Group(); S.add(holder);
				C = new T.PerspectiveCamera(30, 1, .1, 100); O = new T.OrbitControls(C, cv); O.enableDamping = true; O.enablePan = false; O.minDistance = 4; O.maxDistance = 14; O.maxPolarAngle = 1.5; O.target.set(0, .7, 0);
				function size() { var r = stage.getBoundingClientRect(); R.setSize(r.width, r.height, false); C.aspect = r.width / Math.max(1, r.height); C.updateProjectionMatrix(); var k = Math.max(1, 1.3 / C.aspect); C.position.set(-4.9 * k, 2.2 * k, 5.2 * k); }
				size(); on(w, 'resize', size); loadCar();
				var v = new T.Vector3(), cam = new T.Vector3();
				(function loop() {
					requestAnimationFrame(loop); if (!vis) return; O.update(); R.render(S, C);
					$$('button', dots).forEach(function (b) {
						var p = PARTS[+b.getAttribute('data-i')], f = PMAP[p.k]; if (!f || !box) { b.style.opacity = 0; return; }
						var L = box.max.x - box.min.x, H = box.max.y - box.min.y, W2 = (box.max.z - box.min.z) / 2;
						v.set(f[0] * L * (holder.userData.nose || -1), box.min.y + f[1] * H, f[2] * W2);
						var side = f[2] === 0 ? 1 : Math.sign(C.position.z) === Math.sign(f[2]) ? 1 : .35;
						v.project(C); b.style.left = ((v.x + 1) / 2 * 100) + '%'; b.style.top = ((1 - v.y) / 2 * 100) + '%'; b.style.opacity = side;
					});
				})();
			});
		}
		if ('IntersectionObserver' in w) new IntersectionObserver(function (es) { vis = es[0].isIntersecting; if (vis) start(); }, { rootMargin: '200px' }).observe(stage); else { vis = true; start(); }
		buildDots();
	}
	function rarityLeague(root) {
		var list = $('[data-rl]', root); if (!list) return;
		var rows = index().map(function (c) { var ps = PARTS.filter(function (p) { return !p.need || p.need.test(c.engine + ' ' + c.hl); }), vs = ps.map(function (p) { return { p: p, v: rarity(c, p) }; }); vs.sort(function (a, b) { return b.v - a.v; });
			return { c: c, avg: vs.reduce(function (a, x) { return a + x.v; }, 0) / vs.length, hard: vs[0], easy: vs[vs.length - 1] }; });
		var seen = {}; rows = rows.filter(function (r) { var k = r.c.make + r.c.model; if (seen[k]) return false; seen[k] = 1; return true; }).sort(function (a, b) { return b.avg - a.avg; });
		list.innerHTML = rows.map(function (r, i) { return '<li><span class="rl__n">' + (i + 1) + '</span><a class="rl__car" href="' + esc(r.c.url) + '"><img src="' + esc(thumb(r.c)) + '" alt="" loading="lazy"><span><b>' + esc(r.c.make + ' ' + r.c.model) + '</b><em>Hardest: ' + esc(r.hard.p.k.toLowerCase()) + ' · Easiest: ' + esc(r.easy.p.k.toLowerCase()) + '</em></span></a><span class="rl__bar"><i style="--p:' + (r.avg * 10).toFixed(1) + '%;--c:' + rcol(r.avg) + '"></i></span><b class="rl__v" style="color:' + rcol(r.avg) + '">' + r.avg.toFixed(1) + '</b></li>'; }).join('');
	}

	/* ------------------------------------------------------------ Paint Studio: repaint a real 3D car */
	var PAINTS = [
		['Rosso Corsa', 'Ferrari', '#c8000a'], ['Giallo Modena', 'Ferrari', '#f6c200'], ['Blu Tour de France', 'Ferrari', '#1f3f8f'], ['Verde Mantis', 'Lamborghini', '#76b82a'], ['Arancio Borealis', 'Lamborghini', '#f06a14'], ['Viola Pasifae', 'Lamborghini', '#4b1f6f'],
		['Salamanca Blue', 'Rolls-Royce', '#13264f'], ['Diamond Black', 'Rolls-Royce', '#0c0e12'], ['Arctic White', 'Rolls-Royce', '#eef0ef'], ['Beluga', 'Bentley', '#0a0a0b'], ['Verdant', 'Bentley', '#1e4a35'], ['St James Red', 'Bentley', '#7a0f1a'],
		['Guards Red', 'Porsche', '#c8102e'], ['Python Green', 'Porsche', '#5f8f2e'], ['Gulf Blue', 'Porsche', '#76b3de'], ['British Racing Green', 'Aston Martin', '#0f3d2a'], ['Obsidian Black', 'Mercedes-AMG', '#121315'], ['Batumi Gold', 'Land Rover', '#b39256']
	];
	var FIN = { gloss: [.18, .55], metallic: [.28, .9], matte: [.62, .35], chrome: [.05, 1] };
	function paintStudio(root) {
		var cars = index().filter(function (c) { return c.glb; }); if (!cars.length) return;
		var sel = $('[data-ps-car]', root), stage = $('[data-ps-stage]', root), sw = $('[data-ps-sw]', root), nameEl = $('[data-ps-name]', root);
		var hp = /paint=(\d+)(?:-([0-9a-f]{6}))?(?:-([a-z]+))?/i.exec(location.hash), cur = (hp && byId(hp[1]) && byId(hp[1]).glb ? byId(hp[1]) : null) || cars.filter(function (c) { return /Purosangue/.test(c.model); })[0] || cars[0], col = hp && hp[2] ? '#' + hp[2].toLowerCase() : '#c8000a', fin = hp && hp[3] && FIN[hp[3]] ? hp[3] : 'metallic', spin = true, light = 'studio', target = null;
		sel.innerHTML = grp(cars, function (c) { return '<option value="' + c.id + '"' + (c === cur ? ' selected' : '') + '>' + esc(cname(c)) + '</option>'; });
		sw.innerHTML = PAINTS.map(function (p, i) { return '<button type="button" data-i="' + i + '" style="--c:' + p[2] + '" title="' + esc(p[0] + ' · ' + p[1]) + '"><i></i><span>' + esc(p[0]) + '<em>' + esc(p[1]) + '</em></span></button>'; }).join('') + '<label class="ps__custom" title="Any colour"><input type="color" value="#c8000a" data-ps-pick><span>Your own<em>Any colour</em></span></label>';
		var T, R, S, C, O, holder, car = null, vis = false, started = false, hemi, key, rim;
		/* a shared spec link lands on the studio itself, not the section heading */ if (hp) setTimeout(function () { try { w.scrollBy({ top: root.getBoundingClientRect().top - 165, behavior: 'smooth' }); } catch (e) {} }, 1200);
		var SKIP = /glass|window|wind|tyre|tire|wheel|rim|interior|interno|interieur|innen|cabin|seat|dash|leather|couro|light|lamp|farol|chrome|cromado|mirror|espelho|engine|motor|exhaust|brake|freio|caliper|disc|rubber|pneu|plastic|plastico|vidro|roda|grill|carpet|steer|logo|badge|plate|black|preto|dark|trim/i;
		function area(g) { var p = g.attributes.position, ix = g.index, a = 0, A = new w.THREE.Vector3(), B = new w.THREE.Vector3(), Cc = new w.THREE.Vector3(), n = ix ? ix.count : p.count; for (var i = 0; i < n; i += 3) { var i0 = ix ? ix.getX(i) : i, i1 = ix ? ix.getX(i + 1) : i + 1, i2 = ix ? ix.getX(i + 2) : i + 2; A.fromBufferAttribute(p, i0); B.fromBufferAttribute(p, i1); Cc.fromBufferAttribute(p, i2); a += B.sub(A).cross(Cc.sub(A)).length() / 2; } return a; }
		function pickPaint(m) {
			var tally = new Map();
			m.traverse(function (o) { if (!o.isMesh || Array.isArray(o.material)) return; var mt = o.material; if (SKIP.test(mt.name || '') || SKIP.test(o.name || '') || mt.transparent && mt.opacity < .9) return;
				var c = mt.color || { r: 0, g: 0, b: 0 }, lum = c.r * .3 + c.g * .59 + c.b * .11; if (lum < .015 && !mt.map) return;
				var ar = 0; try { ar = area(o.geometry) * o.getWorldScale(new w.THREE.Vector3()).x * o.getWorldScale(new w.THREE.Vector3()).x; } catch (e) {} var mx = Math.max(c.r, c.g, c.b), mn = Math.min(c.r, c.g, c.b), sat = mx ? (mx - mn) / mx : 0; tally.set(mt, (tally.get(mt) || 0) + ar * (.35 + sat * 1.6) * (lum > .05 ? 1 : .6) * (mt.map ? .7 : 1) * (/paint|pintura|peinture|vernice|lackierung|karosserie|body|colou?red|carpaint|exterior|shell|lack/i.test((mt.name || '') + ' ' + (o.name || '')) ? 4 : 1)); });
			var best = null, bv = 0; tally.forEach(function (v, k) { if (v > bv) { bv = v; best = k; } }); return best;
		}
		function apply() {
			if (!target) return; var f = FIN[fin]; (target.length ? target : [target]).forEach(function (t) { t.color = t.color || new T.Color(); t.color.set(col).convertSRGBToLinear(); if (t.map) t.map = null; t.envMapIntensity = fin === 'chrome' ? 1.2 : .85;
			t.roughness = f[0]; t.metalness = f[1]; if ('clearcoat' in t) { t.clearcoat = fin === 'matte' ? 0 : 1; t.clearcoatRoughness = .05; } t.needsUpdate = true; });
			var p = PAINTS.filter(function (x) { return x[2] === col; })[0]; nameEl.innerHTML = (p ? '<b>' + esc(p[0]) + '</b> ' + esc(p[1]) + ' colour' : '<b>' + esc(col.toUpperCase()) + '</b> your own colour') + ' · ' + esc(fin) + ' finish on the ' + esc(cur.model);
			$$('button', sw).forEach(function (b) { b.classList.toggle('is-on', PAINTS[+b.getAttribute('data-i')][2] === col); });
		}
		function lights() { var L = { studio: [1, .9, 1, 0x222222], sunset: [.8, 1.3, .8, 0x3a1d0a], night: [.25, .5, .35, 0x050510] }[light]; R.toneMappingExposure = L[0]; key.intensity = L[1]; hemi.intensity = L[2] * .6; S.background = null; stage.style.setProperty('--bg', light === 'sunset' ? 'radial-gradient(80% 70% at 50% 40%,#5a3418,#120b06 75%)' : light === 'night' ? 'radial-gradient(80% 70% at 50% 40%,#141a2a,#05060a 75%)' : 'radial-gradient(80% 70% at 50% 45%,#3a362f,#121214 75%)'); key.color.set(light === 'sunset' ? 0xffb070 : 0xffffff); }
		function loadCar() {
			if (!started) return; while (holder.children.length) holder.remove(holder.children[0]); stage.classList.add('is-loading'); target = null; var stopT = loadTag(stage, cur.glb);
			loadModel(cur.glb, function (e, m) { stopT(); stage.classList.remove('is-loading'); if (e) return; var mm = new Map(); function cl(x) { if (!mm.has(x)) mm.set(x, x.clone()); return mm.get(x); } m.traverse(function (o) { if (o.isMesh) { o.material = Array.isArray(o.material) ? o.material.map(cl) : cl(o.material); } }); holder.add(m); car = m; target = cur.pm ? BodyKit.all(m, cur.pm) : []; if (!target.length) target = pickPaint(m); apply(); });
		}
		on(sel, 'change', function () { cur = byId(sel.value) || cur; loadCar(); });
		$$('button', sw).forEach(function (b) { on(b, 'click', function () { col = PAINTS[+b.getAttribute('data-i')][2]; apply(); }); });
		on($('[data-ps-pick]', root), 'input', function (e) { col = e.target.value; apply(); });
		$$('[data-ps-fin]', root).forEach(function (b) { on(b, 'click', function () { fin = b.getAttribute('data-ps-fin'); $$('[data-ps-fin]', root).forEach(function (o) { o.setAttribute('aria-pressed', o === b); }); apply(); }); });
		$$('[data-ps-light]', root).forEach(function (b) { on(b, 'click', function () { light = b.getAttribute('data-ps-light'); $$('[data-ps-light]', root).forEach(function (o) { o.setAttribute('aria-pressed', o === b); }); if (R) lights(); }); });
		on($('[data-ps-spin]', root), 'change', function (e) { spin = e.target.checked; });
		on($('[data-ps-share]', root), 'click', function () { var u = location.href.split('#')[0] + '#paint=' + cur.id + '-' + col.replace('#', '') + '-' + fin; var t = 'My ' + cur.make + ' ' + cur.model + ' spec in the Laqim Paint Studio'; if (navigator.share) navigator.share({ title: 'Laqim Paint Studio', text: t, url: u }).catch(function () {}); else w.open('https://wa.me/?text=' + encodeURIComponent(t + ': ' + u), '_blank', 'noopener'); FX.play('ok'); });
		if (hp) { setTimeout(function () { $$('[data-ps-fin]', root).forEach(function (o) { o.setAttribute('aria-pressed', o.getAttribute('data-ps-fin') === fin); }); root.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, 300); }
		on($('[data-ps-shot]', root), 'click', function () { FX.play('flip'); if (!R) return; R.render(S, C); var a = d.createElement('a'); a.download = 'laqim-' + (cur.model || 'car').toLowerCase().replace(/[^a-z0-9]+/g, '-') + '-paint.png'; a.href = R.domElement.toDataURL('image/png'); a.click(); });
		function start() {
			if (started) return; started = true;
			load3D(function (err) {
				if (err) return; T = w.THREE; var cv = d.createElement('canvas'); cv.className = 'ps__cv'; stage.insertBefore(cv, stage.firstChild);
				R = new T.WebGLRenderer({ canvas: cv, antialias: true, alpha: true, preserveDrawingBuffer: true }); R.setPixelRatio(Math.min(1.8, w.devicePixelRatio || 1)); R.outputEncoding = T.sRGBEncoding; R.toneMapping = T.ACESFilmicToneMapping;
				S = new T.Scene(); S.environment = studioEnv(R); hemi = new T.HemisphereLight(0xffffff, 0x222222, .6); S.add(hemi); key = new T.DirectionalLight(0xffffff, 1); key.position.set(5, 8, 4); S.add(key);
				var sh = new T.Mesh(new T.PlaneGeometry(7.5, 3.8), new T.MeshBasicMaterial({ map: shadowTex(), transparent: true, depthWrite: false })); sh.rotation.x = -Math.PI / 2; S.add(sh);
				var ring = new T.Mesh(new T.RingGeometry(3.3, 3.36, 96), new T.MeshBasicMaterial({ color: 0xd9a93f, transparent: true, opacity: .7 })); ring.rotation.x = -Math.PI / 2; ring.position.y = .005; S.add(ring);
				holder = new T.Group(); S.add(holder);
				C = new T.PerspectiveCamera(30, 1, .1, 100); O = new T.OrbitControls(C, cv); O.enableDamping = true; O.enablePan = false; O.minDistance = 4.5; O.maxDistance = 14; O.maxPolarAngle = 1.5; O.target.set(0, .65, 0);
				function size() { var r = stage.getBoundingClientRect(); R.setSize(r.width, r.height, false); C.aspect = r.width / Math.max(1, r.height); C.updateProjectionMatrix(); var k = Math.max(1, 1.35 / C.aspect); C.position.set(-5.6 * k, 2 * k, 6 * k); }
				size(); on(w, 'resize', size); lights(); loadCar();
				var ray = new T.Raycaster(), mv = new T.Vector2(), down = null;
				on(cv, 'pointerdown', function (e) { down = [e.clientX, e.clientY]; });
				on(cv, 'pointerup', function (e) { if (!down || Math.abs(e.clientX - down[0]) + Math.abs(e.clientY - down[1]) > 6 || !car) return; var r = cv.getBoundingClientRect(); mv.set((e.clientX - r.left) / r.width * 2 - 1, -(e.clientY - r.top) / r.height * 2 + 1); ray.setFromCamera(mv, C); var hit = ray.intersectObject(car, true)[0]; if (hit && hit.object.material && !Array.isArray(hit.object.material)) { target = hit.object.material; apply(); stage.classList.add('is-picked'); setTimeout(function () { stage.classList.remove('is-picked'); }, 500); } });
				(function loop() { requestAnimationFrame(loop); if (!vis) return; if (spin) holder.rotation.y += .0035; O.update(); R.render(S, C); })();
			});
		}
		if ('IntersectionObserver' in w) new IntersectionObserver(function (es) { vis = es[0].isIntersecting; if (vis) start(); }, { rootMargin: '200px' }).observe(stage); else { vis = true; start(); }
	}

	/* ------------------------------------------------------------ car page: hear the engine */
	function hearCar(b) {
		var syn = null, busy = false;
		on(b, 'click', function () {
			if (busy) return; var c = byId(b.getAttribute('data-hear-car')); if (!c) return; if (!syn) syn = engineSynth(); if (!syn) { b.textContent = 'Sound not supported'; return; }
			var cyl = c.cyl >= 12 ? 12 : c.cyl >= 8 ? 8 : c.cyl >= 6 ? 6 : 4, red = cyl >= 12 ? 8200 : cyl >= 8 ? 6800 : cyl >= 6 ? 6200 : 5800, t0 = performance.now(); busy = true; b.classList.add('is-on'); b.textContent = '🔊 Revving…'; syn.on(true);
			(function f(now) { var t = (now - t0) / 1000, rpm = t < .8 ? 800 : t < 1.3 ? 800 + (t - .8) / .5 * 3000 : t < 1.9 ? 3800 - (t - 1.3) / .6 * 2900 : t < 3.9 ? 900 + (t - 1.9) / 2 * (red - 900) : red - (t - 3.9) * 5000;
				syn.set(Math.max(750, rpm), cyl, t > 1.9 && t < 3.9 ? 1 : .3); if (t < 4.6) requestAnimationFrame(f); else { syn.on(false); busy = false; b.classList.remove('is-on'); b.textContent = '🔊 Hear it rev'; } })(t0);
		});
	}

	/* ------------------------------------------------------------ Size Up: true-scale comparison */
	function sizeUp(root) {
		var cars = index().filter(function (c) { return c.glb && c.dim && c.dim[0]; }); if (cars.length < 2) { root.hidden = true; return; }
		var sa = $('[data-su-a]', root), sb = $('[data-su-b]', root), stage = $('[data-su-stage]', root), labels = $('[data-su-labels]', root), nums = $('[data-su-nums]', root);
		function opts(sel, def) { sel.innerHTML = grp(cars, function (c) { return '<option value="' + c.id + '"' + (c.id === def ? ' selected' : '') + '>' + esc(cname(c)) + '</option>'; }); }
		var A = cars.filter(function (c) { return /Cullinan/.test(c.model); })[0] || cars[0], B = cars.filter(function (c) { return /911/.test(c.model); })[0] || cars[1];
		var hc = /cmp=(\d+),(\d+)/.exec(location.hash), pick = function (id) { return cars.filter(function (c) { return c.id === +id; })[0]; };
		if (hc && pick(hc[1]) && pick(hc[2])) { A = pick(hc[1]); B = pick(hc[2]); } /* follow the pair chosen for the duel */
		opts(sa, A.id); opts(sb, B.id);
		var view = 'side', T, R, S, C, O, slots = [null, null], person, vis = false, started = false, lines = new (w.THREE ? w.THREE.Group : Object)();
		function mm(v) { return v ? v.toLocaleString() + ' mm' : '–'; }
		function table() {
			var rows = [['Length', 0], ['Width', 1], ['Height', 2], ['Wheelbase', 3]];
			var h = '<table><thead><tr><th></th><th>' + esc(A.model) + '</th><th>' + esc(B.model) + '</th><th>Difference</th></tr></thead><tbody>' + rows.map(function (r) { var a = A.dim[r[1]], b = B.dim[r[1]], df = a && b ? a - b : 0; return '<tr><th>' + r[0] + '</th><td>' + mm(a) + '</td><td>' + mm(b) + '</td><td>' + (a && b ? (df === 0 ? 'Same' : '<b>' + esc(df > 0 ? A.model : B.model) + '</b> +' + Math.abs(df).toLocaleString() + ' mm') : '–') + '</td></tr>'; }).join('')
				+ '<tr><th>Weight</th><td>' + (A.kg ? A.kg.toLocaleString() + ' kg' : '–') + '</td><td>' + (B.kg ? B.kg.toLocaleString() + ' kg' : '–') + '</td><td>' + (A.kg && B.kg ? '<b>' + esc(A.kg > B.kg ? A.model : B.model) + '</b> +' + Math.abs(A.kg - B.kg).toLocaleString() + ' kg' : '–') + '</td></tr></tbody></table>';
			nums.innerHTML = h;
		}
		function layout() {
			if (!S) return; var T3 = w.THREE;
			while (lines.children.length) lines.remove(lines.children[0]); labels.innerHTML = '';
			var cs = [A, B], gap = view === 'front' ? .9 : 1.2, ext = [], rr = stage.getBoundingClientRect(), stack = view === 'side' && rr.width / Math.max(1, rr.height) < 1.35, Lmax = Math.max(A.dim[0], B.dim[0]) / 1000, Hb = (B.dim[2] || 1600) / 1000;
			stage.classList.toggle('is-stack', stack);
			slots.forEach(function (h, i) { if (!h) return; var c = cs[i], L = c.dim[0] / 1000, Wd = (c.dim[1] || 1950) / 1000, foot = view === 'front' ? Wd : L;
				h.rotation.y = view === 'front' ? (isFlip(c) ? Math.PI / 2 : -Math.PI / 2) : (isFlip(c) ? 0 : Math.PI);
				if (stack) h.position.set(-Lmax / 2 + L / 2, i ? 0 : Hb + 1.7, 0); else h.position.set((i ? 1 : -1) * (foot / 2 + gap / 2), 0, 0);
				ext.push([h.position.x - foot / 2, h.position.x + foot / 2, c, h.position.y]); });
			if (stack) { var ln = new w.THREE.Line(new w.THREE.BufferGeometry().setFromPoints([new w.THREE.Vector3(-Lmax / 2 - .3, Hb + 1.7, .01), new w.THREE.Vector3(Lmax / 2 + .3, Hb + 1.7, .01)]), new w.THREE.LineBasicMaterial({ color: 0x5a4a2a })); lines.add(ln); }
			person.position.set(stack ? Lmax / 2 + .8 : 0, 0, view === 'front' || stack ? 0 : (A.dim[1] || 1950) / 2000 + .9);
			var gold = new T3.LineBasicMaterial({ color: 0xf1d27a });
			ext.forEach(function (e, i) { var c = e[2], H = (c.dim[2] || 1600) / 1000, zf = view === 'front' || stack ? .02 : ((c.dim[1] || 1950) / 2000 + .15), b0 = e[3] || 0, y0 = b0 + .02;
				function seg(a, b) { var g = new T3.BufferGeometry().setFromPoints([a, b]); lines.add(new T3.Line(g, gold)); }
				seg(new T3.Vector3(e[0], y0, zf), new T3.Vector3(e[1], y0, zf)); seg(new T3.Vector3(e[0], b0, zf), new T3.Vector3(e[0], b0 + .25, zf)); seg(new T3.Vector3(e[1], b0, zf), new T3.Vector3(e[1], b0 + .25, zf));
				var hx = stack ? e[1] + .25 : (i ? e[1] + .25 : e[0] - .25); seg(new T3.Vector3(hx, b0, 0), new T3.Vector3(hx, b0 + H, 0)); seg(new T3.Vector3(hx - .12, b0 + H, 0), new T3.Vector3(hx + .12, b0 + H, 0));
				addLabel((e[0] + e[1]) / 2, b0 - .05, zf, (view === 'front' ? 'Width ' + mm(c.dim[1]) : 'Length ' + mm(c.dim[0])), 'b');
				addLabel(hx, b0 + H + .15, 0, (stack ? '↕ ' : 'Height ') + mm(c.dim[2]), stack || i ? 'r' : 'l');
				addLabel(stack ? e[0] : (e[0] + e[1]) / 2, b0 + H + (stack ? .3 : .7), 0, c.make + ' ' + c.model, stack ? 'nl' : 'n');
				if (view === 'top' && !stack) {
					var cx = (e[0] + e[1]) / 2, BL = 5.0, BW = 2.5, bay = new T3.LineLoop(new T3.BufferGeometry().setFromPoints([new T3.Vector3(cx - BL / 2, .03, -BW / 2), new T3.Vector3(cx + BL / 2, .03, -BW / 2), new T3.Vector3(cx + BL / 2, .03, BW / 2), new T3.Vector3(cx - BL / 2, .03, BW / 2)]), new T3.LineBasicMaterial({ color: 0xffffff, transparent: true, opacity: .75 })); lines.add(bay);
					var dl = Math.round((BL * 1000 - c.dim[0]) / 10), dw = Math.round((BW * 1000 - (c.dim[1] || 1950)) / 10);
					addLabel(cx, .03, BW / 2 + .45, dl >= 0 ? 'Standard 5 m × 2.5 m bay: ' + dl + ' cm spare in length, ' + Math.max(0, dw) + ' cm in width' : 'Overhangs a standard 5 m bay by ' + (-dl) + ' cm', 'b');
				}
			});
			fit();
		}
		var LB = [];
		function addLabel(x, y, z, t, k) { var el = d.createElement('span'); el.className = 'su__lb su__lb--' + k; el.textContent = t; labels.appendChild(el); LB.push({ el: el, p: new w.THREE.Vector3(x, y, z) }); }
		function fit() {
			var r = stage.getBoundingClientRect(), asp = r.width / Math.max(1, r.height), span = 0, stk = stage.classList.contains('is-stack'); slots.forEach(function (h, i) { if (h) span += (view === 'front' ? (([A, B][i].dim[1] || 1950) / 1000) : [A, B][i].dim[0] / 1000); }); span = span + 2.6;
			if (stk) span = Math.max(A.dim[0], B.dim[0]) / 1000 + 2.6;
			var hh = Math.max(span / asp, stk ? ((A.dim[2] + B.dim[2]) / 1000 + 3.2) : 4.2) * (stk ? .55 : .62); C.left = -hh * asp; C.right = hh * asp; C.top = hh; C.bottom = -hh; C.updateProjectionMatrix();
			if (view === 'side' || view === 'front') { var cy = stk ? ((B.dim[2] || 1600) / 1000 + 1.7 + (A.dim[2] || 1600) / 1000) / 2 : 1.25; C.position.set(0, cy, 40); O.target.set(0, cy, 0); O.enableRotate = false; }
			else if (view === 'top') { C.position.set(0, 40, .001); O.target.set(0, 0, 0); O.enableRotate = false; }
			else { C.position.set(18, 9, 22); O.target.set(0, .9, 0); O.enableRotate = true; }
			C.zoom = 1; C.updateProjectionMatrix(); O.update();
		}
		function load(i) {
			var c = i ? B : A; if (slots[i]) { S.remove(slots[i]); slots[i] = null; }
			var stopT = loadTag(stage, c.glb);
			loadModel(c.glb, function (e, m) { stopT(); if (e) return; var h = new w.THREE.Group(); var k = (c.dim[0] / 1000) / 4.8; m.scale.multiplyScalar(k); h.add(m); S.add(h); slots[i] = h; LB = []; layout(); });
		}
		function start() {
			if (started) return; started = true;
			load3D(function (err) {
				if (err) return; T = w.THREE; lines = new T.Group(); var cv = d.createElement('canvas'); cv.className = 'su__cv'; stage.insertBefore(cv, stage.firstChild);
				R = setupRenderer(cv, true); R.toneMappingExposure = 1; S = new T.Scene(); S.environment = studioEnv(R); S.add(new T.HemisphereLight(0xffffff, 0x333333, .7)); var dl = new T.DirectionalLight(0xffffff, .9); dl.position.set(5, 9, 6); S.add(dl); S.add(lines);
				var grid = new T.GridHelper(40, 40, 0x8a6a2a, 0x2a2620); grid.position.y = .001; S.add(grid);
				person = new T.Group(); var pm = new T.MeshStandardMaterial({ color: 0x3a3a40, roughness: .6 }); var body = new T.Mesh(new T.CylinderGeometry(.17, .2, .95, 16), pm); body.position.y = 1.0; var legs = new T.Mesh(new T.CylinderGeometry(.16, .12, .78, 16), pm); legs.position.y = .39; var head = new T.Mesh(new T.SphereGeometry(.13, 16, 12), pm); head.position.y = 1.62; person.add(body, legs, head); S.add(person);
				C = new T.OrthographicCamera(-5, 5, 3, -3, .1, 200); O = new T.OrbitControls(C, cv); O.enableDamping = true; O.enablePan = false; O.minZoom = .6; O.maxZoom = 3;
				function size() { var r = stage.getBoundingClientRect(); R.setSize(r.width, r.height, false); LB = []; layout(); }
				size(); on(w, 'resize', size); load(0); load(1);
				var v = new T.Vector3();
				(function loop() { requestAnimationFrame(loop); if (!vis) return; O.update(); R.render(S, C); var LW = labels.clientWidth; LB.forEach(function (l) { v.copy(l.p).project(C); var lx = (v.x + 1) / 2 * LW, ow = l.el.offsetWidth || 0, kk = l.el.className.split('--')[1]; /* keep every label inside the stage on narrow screens */ lx = kk === 'r' ? Math.min(lx, LW - 4 - ow) : kk === 'l' ? Math.max(lx, ow + 4) : kk === 'nl' ? Math.min(Math.max(lx, 4), LW - 4 - ow) : Math.min(Math.max(lx, ow / 2 + 4), LW - ow / 2 - 4); l.el.style.left = lx + 'px'; l.el.style.top = ((1 - v.y) / 2 * 100) + '%'; l.el.style.display = view === 'free' || view === 'top' && /l|r/.test(l.el.className.slice(-1)) ? 'none' : ''; }); })();
			});
		}
		on(sa, 'change', function () { A = byId(sa.value) || A; table(); if (started) load(0); });
		on(sb, 'change', function () { B = byId(sb.value) || B; table(); if (started) load(1); });
		$$('[data-su-view]', root).forEach(function (b) { on(b, 'click', function () { view = b.getAttribute('data-su-view'); $$('[data-su-view]', root).forEach(function (o) { o.setAttribute('aria-pressed', o === b); }); LB = []; layout(); }); });
		table();
		if ('IntersectionObserver' in w) new IntersectionObserver(function (es) { vis = es[0].isIntersecting; if (vis) start(); }, { rootMargin: '200px' }).observe(stage); else { vis = true; start(); }
	}

	/* ------------------------------------------------------------ Performance map */
	function perfMap(root) {
		var svg = $('[data-pm-svg]', root), tip = $('[data-pm-tip]', root), sx = $('[data-pm-x]', root), sy = $('[data-pm-y]', root), note = $('[data-pm-note]', root), key = $('[data-pm-key]', root);
		var seen = {}, cars = index().filter(function (c) { var k = c.make + c.model; if (seen[k] || !c.hp) return false; seen[k] = 1; return true; });
		var LAB = { acc: '0–100 km/h', hp: 'Power', tq: 'Torque', vmax: 'Top speed', kg: 'Weight', l: 'Engine size', php: 'Power to weight' }, UNIT = { acc: ' s', hp: ' hp', tq: ' Nm', vmax: ' km/h', kg: ' kg', l: ' L', php: ' hp/t' };
		var BODY = { SUV: '#d9a93f', Sedan: '#7fb4ff', Saloon: '#7fb4ff', Coupe: '#ff7a45', 'Coupé': '#ff7a45', Roadster: '#ff5d8f', Convertible: '#ff5d8f', Spider: '#ff5d8f', Cabriolet: '#ff5d8f', Estate: '#3ec9b0', Wagon: '#3ec9b0', Hatchback: '#8fd14f', 'Pick-up': '#c98b5a', 'Pickup': '#c98b5a', 'Coupé SUV': '#b48cff', 'Liftback coupé': '#6fe0ff', 'Liftback': '#6fe0ff', 'Shooting brake': '#3ec9b0', MPV: '#e8e3d6' };
		var EXTRA = ['#f1d27a', '#ff9f6b', '#9ad0ff', '#c6f07a', '#ff8ac4', '#7ef0d0'], ei = 0;
		function val(c, k) { return k === 'php' ? (c.kg ? c.hp / c.kg * 1000 : 0) : +c[k] || 0; }
		function fmt(v, k) { return (k === 'acc' || k === 'l' ? v.toFixed(1) : Math.round(v).toLocaleString()) + UNIT[k]; }
		var bodies = {}; cars.forEach(function (c) { bodies[c.body || 'Other'] = 1; });
		Object.keys(bodies).forEach(function (b) { if (!BODY[b]) BODY[b] = EXTRA[ei++ % EXTRA.length]; });
		key.innerHTML = Object.keys(bodies).map(function (b) { return '<span><i style="background:' + (BODY[b] || '#bbb') + '"></i>' + esc(b) + '</span>'; }).join('') + '<span class="pmap__sz">Bubble size = weight</span>';
		function draw() {
			var kx = sx.value, ky = sy.value, pts = cars.filter(function (c) { return val(c, kx) > 0 && val(c, ky) > 0; });
			var xs = pts.map(function (c) { return val(c, kx); }), ys = pts.map(function (c) { return val(c, ky); });
			var x0 = Math.min.apply(0, xs), x1 = Math.max.apply(0, xs), y0 = Math.min.apply(0, ys), y1 = Math.max.apply(0, ys), px = (x1 - x0) * .08 || 1, py = (y1 - y0) * .1 || 1; x0 -= px; x1 += px; y0 -= py; y1 += py;
			var L = 80, Rr = 970, Tt = 24, B = 500; function X(v) { return L + (v - x0) / (x1 - x0) * (Rr - L); } function Y(v) { return B - (v - y0) / (y1 - y0) * (B - Tt); }
			var g = '';
			for (var i = 0; i <= 5; i++) { var vx = x0 + (x1 - x0) * i / 5, vy = y0 + (y1 - y0) * i / 5; g += '<line x1="' + X(vx) + '" y1="' + Tt + '" x2="' + X(vx) + '" y2="' + B + '" class="g"/><text x="' + X(vx) + '" y="' + (B + 24) + '" class="t" text-anchor="middle">' + fmt(vx, kx).replace(UNIT[kx], '') + '</text>'; g += '<line x1="' + L + '" y1="' + Y(vy) + '" x2="' + Rr + '" y2="' + Y(vy) + '" class="g"/><text x="' + (L - 10) + '" y="' + (Y(vy) + 4) + '" class="t" text-anchor="end">' + fmt(vy, ky).replace(UNIT[ky], '') + '</text>'; }
			g += '<text x="' + ((L + Rr) / 2) + '" y="552" class="ax" text-anchor="middle">' + esc(LAB[kx] + ' (' + UNIT[kx].trim() + ')') + (kx === 'acc' ? ' · quicker to the left' : '') + '</text><text x="18" y="' + ((Tt + B) / 2) + '" class="ax" text-anchor="middle" transform="rotate(-90 18 ' + ((Tt + B) / 2) + ')">' + esc(LAB[ky] + ' (' + UNIT[ky].trim() + ')') + '</text>';
			var kmin = Math.min.apply(0, cars.map(function (c) { return c.kg || 2000; })), kmax = Math.max.apply(0, cars.map(function (c) { return c.kg || 2000; }));
			pts.sort(function (a, b) { return (b.kg || 0) - (a.kg || 0); }).forEach(function (c, i) { var r = 9 + ((c.kg || 2000) - kmin) / Math.max(1, kmax - kmin) * 16; g += '<a href="' + esc(c.url) + '" data-i="' + cars.indexOf(c) + '"><circle cx="' + X(val(c, kx)) + '" cy="' + Y(val(c, ky)) + '" r="' + r.toFixed(1) + '" fill="' + (BODY[c.body] || '#bbb') + '" class="d" style="animation-delay:' + (i * 30) + 'ms"/><text x="' + X(val(c, kx)) + '" y="' + (Y(val(c, ky)) - r - 6) + '" class="n" text-anchor="middle">' + esc(c.model.replace(/ 4MATIC| Adventure| Turbo Premium/, '')) + '</text></a>'; });
			svg.innerHTML = g;
			/* phones: name only the standouts on each axis, the rest stay as tappable bubbles */
			if ((svg.parentNode.clientWidth || svg.clientWidth) < 640) { var keep = {}; pts.slice().sort(function (a, b) { return val(b, ky) - val(a, ky); }).slice(0, 5).concat(pts.slice().sort(function (a, b) { return kx === 'acc' ? val(a, kx) - val(b, kx) : val(b, kx) - val(a, kx); }).slice(0, 3)).forEach(function (c) { keep[cars.indexOf(c)] = 1; }); $$('a', svg).forEach(function (a) { if (!keep[a.getAttribute('data-i')]) { var t = a.querySelector('text'); if (t) t.remove(); } }); }
			var placed = []; $$('a', svg).forEach(function (a) { var t = a.querySelector('text'), ci = a.querySelector('circle'); if (!t) return; var bb = t.getBBox(), r = +ci.getAttribute('r'), cy = +ci.getAttribute('cy');
				function hit(b) { return placed.some(function (p) { return b.x < p.x + p.width && b.x + b.width > p.x && b.y < p.y + p.height && b.y + b.height > p.y; }); }
				if (hit(bb)) { t.setAttribute('y', cy + r + 16); bb = t.getBBox(); if (hit(bb)) { t.style.display = 'none'; return; } } placed.push(bb); });
			$$('a', svg).forEach(function (a) { var c = cars[+a.getAttribute('data-i')]; on(a, 'mouseenter', function (e) { tip.hidden = false; tip.innerHTML = '<img src="' + esc(thumb(c)) + '" alt=""><b>' + esc(cname(c)) + '</b><span>' + esc(LAB[kx]) + ': ' + fmt(val(c, kx), kx) + '</span><span>' + esc(LAB[ky]) + ': ' + fmt(val(c, ky), ky) + '</span><span>Weight: ' + (c.kg ? c.kg.toLocaleString() + ' kg' : '–') + '</span>'; var r = svg.getBoundingClientRect(), cr = a.querySelector('circle').getBoundingClientRect(); tip.style.left = Math.min(r.width - 220, Math.max(0, cr.left - r.left + cr.width / 2 - 110)) + 'px'; tip.style.top = Math.max(0, cr.top - r.top - 170) + 'px'; }); on(a, 'mouseleave', function () { tip.hidden = true; }); });
			var best = pts.slice().sort(function (a, b) { return (kx === 'acc' ? val(a, kx) - val(b, kx) : val(b, kx) - val(a, kx)); })[0];
			note.innerHTML = best ? 'Leader on ' + esc(LAB[kx].toLowerCase()) + ': <b>' + esc(best.make + ' ' + best.model) + '</b> at ' + fmt(val(best, kx), kx) + '. Tap any bubble to open the car.' : '';
		}
		on(sx, 'change', draw); on(sy, 'change', draw); draw();
	}

	/* ------------------------------------------------------------ fun facts */
	function facts(root) {
		var cards = $$('.ff__card', root), seen = {};
		cards.forEach(function (c, i) { on(c, 'click', function () { var o = c.classList.toggle('is-flip'); c.setAttribute('aria-pressed', o); FX.play('flip'); if (o && !seen[i]) { seen[i] = 1; var n = Object.keys(seen).length; if (n === cards.length) { FX.play('win'); FX.confetti(root, 120); } } }); });
	}

	/* ------------------------------------------------------------ engineers' ranking */
	function eng(root) {
		var sel = $('[data-eg-sort]', root), list = $('[data-eg-list]', root);
		var all = index().filter(function (c) { return c.hp; });
		/* hybrid and electric outputs include motors, so they would distort per-litre and per-cylinder figures */
		function ice(c) { var e = c.engine || ''; if (/mild/i.test(e)) { return !/electric/i.test(c.fuel || ''); } return !/hybrid|electric/i.test(c.fuel || '') && !/hybrid|electric|motor/i.test(e); }
		function val(c, k) { return k === 'spec' ? (c.l && ice(c) ? c.hp / c.l : 0) : k === 'cyl' ? (c.cyl && ice(c) ? c.hp / c.cyl : 0) : k === 'l' ? (c.l || 0) : c.hp; }
		function unit(k) { return k === 'spec' ? ' hp/L' : k === 'cyl' ? ' hp/cyl' : k === 'l' ? ' L' : ' hp'; }
		function draw() {
			var k = sel.value, rows = all.filter(function (c) { return val(c, k) > 0; }).sort(function (a, b) { return val(b, k) - val(a, k); }).slice(0, 10), mx = rows.length ? val(rows[0], k) : 1;
			list.innerHTML = rows.map(function (c, i) { var v = val(c, k); return '<li><span class="eg__n">' + (i + 1) + '</span><a href="' + esc(c.url) + '">' + esc(cname(c)) + '</a><span class="eg__bar"><i style="--p:' + (v / mx * 100).toFixed(1) + '%"></i></span><b>' + (k === 'l' ? v.toFixed(1) : Math.round(v)) + unit(k) + '</b></li>'; }).join('');
			requestAnimationFrame(function () { list.classList.remove('is-in'); void list.offsetWidth; list.classList.add('is-in'); });
		}
		on(sel, 'change', draw); draw();
	}

	/* ------------------------------------------------------------ Parts Hunt */
	var BRAND = { 'Toyota': 2, 'Lexus': 4, 'Mercedes-Benz': 5, 'Mercedes-AMG': 6, 'Mercedes-Maybach': 7, 'Land Rover': 6, 'Porsche': 6, 'Bentley': 8, 'Aston Martin': 8, 'Lamborghini': 8, 'Ferrari': 9, 'Rolls-Royce': 9 };
	var PARTS = [
		{ k: 'Oil filter', v: 1, t: 'service' }, { k: 'Brake pads', v: 2, t: 'service' }, { k: 'Headlight unit', v: 5, t: 'body' }, { k: 'Front bumper', v: 5, t: 'body' },
		{ k: 'Air suspension bellow', v: 5, t: 'chassis', need: /air/i }, { k: 'Turbocharger', v: 6, t: 'engine', need: /turbo|biturbo/i }, { k: 'Engine control unit', v: 7, t: 'electronic' },
		{ k: 'Infotainment screen', v: 6, t: 'electronic' }, { k: 'Interior trim panel', v: 7, t: 'trim' }, { k: 'Carbon-ceramic brake disc', v: 8, t: 'chassis', need: /ceramic/i }, { k: 'Alloy wheel', v: 4, t: 'body' }, { k: 'Windscreen', v: 4, t: 'body' }
	];
	function rarity(c, p) {
		var b = BRAND[c.make] || 6, age = c.year ? Math.max(0, 2026 - c.year) : 2, fresh = age <= 1 ? 1.2 : age >= 8 ? .8 : 0;
		var s = b * .55 + p.v * .55 + fresh - (c.make === 'Toyota' && p.t !== 'electronic' ? 1 : 0);
		if (/Land Cruiser|RAV4|Harrier|Prado/.test(c.model) && p.t === 'service') s -= 1;
		return Math.max(1, Math.min(10, Math.round(s * 10) / 10));
	}
	function partsInfo(score, p) {
		var wait = score < 3 ? 'Usually in stock locally' : score < 5 ? 'A few days to 2 weeks' : score < 7 ? '2 to 6 weeks, often imported' : score < 8.5 ? '6 to 12 weeks, factory order' : 'Months; may be built to order';
		var where = [];
		if (p.t === 'service' || score < 4) where.push('Local parts shops and trusted service centres, with the part number from your VIN');
		where.push('The brand’s authorised dealer or importer, the surest route to a genuine (OEM) part');
		if (score >= 4) where.push('Specialist independent workshops for the marque, who often know overseas suppliers');
		if (p.t !== 'electronic' && score >= 5) where.push('Online OEM parts catalogues in the UK, UAE or Japan, shipped by courier');
		if (p.t === 'body' || p.t === 'trim') where.push('Certified recyclers and breakers for used original panels');
		if (p.t === 'electronic') where.push('Coding specialists: a new unit often needs programming to your car');
		var alt = p.t === 'service' ? 'Good OE-quality aftermarket options' : p.t === 'electronic' ? 'Few; refurbished units exist for some models' : score >= 8 ? 'Very limited; usually genuine only' : 'Some aftermarket or used originals';
		return { wait: wait, where: where, alt: alt, oem: score >= 7 ? 'Genuine part strongly advised' : 'Genuine or OE-equivalent' };
	}
	function parts(root) {
		var cars = index(); if (!cars.length) return;
		var sel = $('[data-ph-car]', root), box = $('[data-ph-parts]', root), arc = $('[data-ph-arc]', root), cur = null;
		sel.innerHTML = grp(cars, function (c, i) { return '<option value="' + i + '">' + esc(c.make + ' ' + c.model + (c.year ? ' ' + c.year : '')) + '</option>'; });
		box.innerHTML = PARTS.map(function (p, i) { return '<button type="button" data-p="' + i + '">' + esc(p.k) + '</button>'; }).join('');
		function draw() {
			var c = cars[+sel.value], p = PARTS[cur]; if (!p) return;
			$$('[data-p]', box).forEach(function (b) { var pp = PARTS[+b.getAttribute('data-p')]; b.classList.toggle('is-on', +b.getAttribute('data-p') === cur); b.disabled = !!(pp.need && !pp.need.test(c.engine + ' ' + c.hl)); });
			if (p.need && !p.need.test(c.engine + ' ' + c.hl)) { $('[data-ph-verdict]', root).textContent = 'This car does not use that part. Pick another.'; return; }
			var s = rarity(c, p), info = partsInfo(s, p);
			$('[data-ph-score]', root).textContent = s.toFixed(1); arc.setAttribute('stroke-dasharray', (s * 10) + ' 100');
			$('[data-ph-verdict]', root).textContent = s < 3 ? 'Easy find. Any good parts counter.' : s < 5 ? 'Findable with a little patience.' : s < 7 ? 'A proper hunt. Plan ahead.' : s < 8.5 ? 'Rare. Specialist territory.' : 'Unicorn. Factory order and a long wait.';
			$('[data-ph-wait]', root).textContent = info.wait; $('[data-ph-oem]', root).textContent = info.oem; $('[data-ph-alt]', root).textContent = info.alt;
			$('[data-ph-where]', root).innerHTML = info.where.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('');
		}
		$$('[data-p]', box).forEach(function (b) { on(b, 'click', function () { cur = +b.getAttribute('data-p'); draw(); }); });
		on(sel, 'change', function () { if (cur == null) cur = 1; draw(); });
		cur = 1; draw();
		/* game */
		var g = $('[data-pg]', root), sc = 0, st = 0;
		function round() {
			var a = { c: cars[Math.floor(Math.random() * cars.length)], p: PARTS[Math.floor(Math.random() * 9)] }, b;
			do { b = { c: cars[Math.floor(Math.random() * cars.length)], p: PARTS[Math.floor(Math.random() * 9)] }; } while (Math.abs(rarity(a.c, a.p) - rarity(b.c, b.p)) < .6);
			g.innerHTML = [a, b].map(function (o, i) { return '<button type="button" class="ph__opt" data-o="' + i + '"><img src="' + esc(o.c.img) + '" alt=""><small>' + esc(o.c.make + ' ' + o.c.model) + '</small><b>' + esc(o.p.k) + '</b><span class="ph__res"></span></button>'; }).join('<i class="ph__or">or</i>');
			$$('[data-o]', g).forEach(function (btn) { on(btn, 'click', function () {
				var ra = rarity(a.c, a.p), rb = rarity(b.c, b.p), win = ra > rb ? 0 : 1, ok = +btn.getAttribute('data-o') === win;
				$$('[data-o]', g).forEach(function (x, i) { x.disabled = true; $('.ph__res', x).textContent = (i ? rb : ra).toFixed(1) + ' / 10'; x.classList.add(i === win ? 'is-win' : 'is-lose'); });
				if (ok) { sc++; st++; toast('Correct! Streak ' + st); } else { st = 0; toast('Not this time'); }
				$('[data-pg-score]', root).textContent = sc; $('[data-pg-streak]', root).textContent = st;
				setTimeout(round, 1800);
			}); });
		}
		round();
	}



/* ===== Laqim Racing: tracks, modes, garage, split-screen, party and ghost challenges ===== */
	function hotLap(root) {
		var rallyOnly = root.hasAttribute('data-rally'), commOn = (function () { try { return localStorage.getItem('psr-comm') !== '0'; } catch (e) { return true; } })();
		function DUO() { return mode === 'duel' || mode === 'potato'; }
		var cars = index().filter(function (c) { return c.hp && c.kg && c.acc && c.vmax; }).sort(function (a, b) { return a.acc - b.acc; });
		if (!cars.length) return;
		function isSUV(c) { return /suv|pick/i.test(c.body || '') || /4x4|land cruiser|patrol|g 63|g-class|defender|wrangler|raptor|hilux|prado|cullinan|urus|bentayga|range rover|lx /i.test(c.model + ' ' + (c.variant || '')); }
		var TRACKS = {
			circuit: { name: 'Laqim Circuit', surf: 'Tarmac', len: '1.1 km', blurb: 'Fast sweepers and two hairpins on grippy tarmac. Built for sports cars.', laps: 3, Wd: 13, theme: 'day', off: 'grass',
				P: [[0, 0], [120, 0], [200, 30], [230, 100], [200, 170], [120, 190], [60, 150], [20, 180], [-40, 230], [-120, 210], [-150, 140], [-110, 80], [-160, 30], [-120, -20], [-50, -10]] },
			trail: { name: 'Rift Valley Trail', surf: 'Dirt · mud · river', len: '1.4 km', blurb: 'Red-earth rally trail through acacia country: crests, ruts, two mud bogs and a river crossing. SUVs and lifted builds rule here.', laps: 2, Wd: 11, theme: 'savanna', off: 'bush', hills: true,
				P: [[0, 0], [90, -25], [175, 5], [225, 80], [195, 150], [130, 168], [105, 235], [25, 262], [-60, 232], [-92, 160], [-170, 140], [-205, 60], [-150, -2], [-80, -32]] },
			night: { name: 'Nairobi Night Run', surf: 'Street · walls', len: '1.0 km', blurb: 'A tight street circuit under the lights. Concrete walls, no run-off, no mercy.', laps: 3, Wd: 11.5, theme: 'night', off: 'wall',
				P: [[0, 0], [100, 0], [118, 55], [70, 78], [62, 140], [140, 152], [150, 222], [40, 235], [-40, 205], [-62, 125], [-125, 108], [-122, 30], [-60, 16]] }
		};
		var MODES = [
			['tt', 'Time trial', 'Set a lap, chase your gold ghost and the medal times. Send your lap to a friend as a ghost challenge.'],
			['race', 'Race', 'Three laps (two on the trail) against up to five rivals. Bumping is allowed.'],
			['duel', 'Split-screen', 'Two players on one screen. Player 1: WASD, Space handbrake, Left Shift nitro. Player 2: arrow keys, Enter handbrake, Right Shift nitro. Two game controllers also work.'],
			['party', 'Party', 'Up to six friends take turns for the fastest lap, then see the podium. Pass the phone, the keyboard or the controller.'],
			['convoy', 'Entourage', 'Build your own entourage: up to four cars from the collection follow you in formation. Lead them round a lap and keep the convoy tight. Drive too wild and the heavy cars fall behind. Try the drone camera.'],
			['drift', 'Drift', 'Score points for big, fast slides. Hold a drift to grow the multiplier; touching the bush or a wall loses the combo.'],
			['keys', 'Keys', 'Five rivals, one set of keys. Ram the car holding the glowing keys to steal them; whoever holds them longest in two minutes wins.', 'Party'],
			['ko', 'Knockout', 'Six cars. Every time the leader completes a lap, the car in last place is out. Be the last car standing.', 'Party'],
			['roulette', 'Car roulette', 'Four laps against three rivals, but every lap everyone is swapped into a random car from the collection. Adapt or lose.', 'Party'],
			['bomb', 'Bomb car', 'Once you pass 30 km/h the bomb is armed. Drop below the rising speed limit for more than a second and a half and it goes off.', 'Party'],
			['potato', 'Hot potato', 'Two players, one bomb. Ram the other car to pass it before the fuse runs out; going slowly makes it burn faster. Player 1: WASD. Player 2: arrow keys.', 'Party'],
			['echo', 'Past selves', 'Six laps alone, except you are not alone: every lap you finish comes back as a solid car driving exactly as you did. Every bump costs two seconds.', 'Party'],
			['salesman', 'Scare the salesman', 'A test drive with the dealer in the passenger seat. Thrill him for points, but if his panic hits 100% he faints. One lap.', 'Characters'],
			['sleeper', 'Sleeping billionaire', 'Your client is asleep in the back. Drive him home in one lap without waking him: bumps, jolts and hard braking disturb him.', 'Characters'],
			['kid', 'Thrill-seeker kid', 'The boss\u2019s kid wants excitement. Speed, slides and close calls keep them happy; drive sensibly and they get bored.', 'Characters'],
			['instructor', 'Grumpy instructor', 'A sarcastic instructor grades every corner from A to F, then hands you a report card.', 'Characters'],
			['getaway', 'Getaway', 'Four pursuit cars want to box you in. Survive 90 seconds, or lose them all for 8 seconds.', 'Chases'],
			['papz', 'Paparazzi escape', 'A celebrity is in the back. Five paparazzi scooters want the shot. Two laps; every photo costs her reputation.', 'Chases'],
			['tail', 'Tail the target', 'Follow the marked car for two laps. Closer than 15 metres and he spots you; further than 60 and you lose him.', 'Chases'],
			['tandem', 'Two people, one car', 'Two players share one car against three rivals. Player 1 steers (A, D, Space handbrake); player 2 works the pedals (arrow up and down, Right Shift nitro).', 'Party'],
			['vroom', 'Vroom mode', 'Your voice is the throttle. Make engine noises into the microphone: louder is faster, and a rising pitch fires the boost. Steer with the keys or the screen.', 'Party'],
			['champagne', 'Champagne run', 'A client ordered a champagne tower. It is stacked on your roof. Deliver it in one lap: hard corners, braking and bumps knock glasses off.', 'Challenges'],
			['gate', 'Speed gates', 'Six gates, each with a target speed. Cross at exactly that speed: within 1 km/h is perfect.', 'Challenges'],
			['stunt', 'Stunt ramps', 'Gold ramps launch you into the air and blue pads fire you forward. Two laps: big air and straight landings score.', 'Party'],
			['valet', 'Valet at the gala', 'Park five guests’ cars between the most expensive cars in the collection. Quick and straight scores; every touch goes on your bill.', 'Challenges'],
			['slalom', 'Showroom slalom', 'Eight priceless display cars stand on the straight. Weave through them against the clock, passing each one on the side of its gold cones. A touch costs three seconds and goes on your bill; the wrong side costs five.', 'Challenges'],
			['tunnel', 'Tunnel symphony', 'There is a tunnel on the straight. Inside it, high revs, downshifts and lift-off crackles score points. Three runs; your best counts.', 'Challenges'],
			['fuel', 'Hypercar on a teaspoon', 'Half a litre of fuel. How far can you get? Light throttle and high gears go further; when it runs dry, coast to a stop.', 'Challenges'],
			['sig', 'Signature challenge', 'Every car has its own challenge, built from its specs, with bronze, silver and gold medals. Pick any car.', 'Challenges'],
			['cotd', 'Car of the day', 'One car, one track, the same for everyone today. Set your best lap and share your result card. A new car every day.', 'Challenges'],
			['cards', 'Postcard hunt', 'Four postcard spots are hidden on every track. Find the gold rings, stop on them and take the photo. Your album is in the pause menu.', 'Challenges'],
			['rally', 'Rally career', 'Build a rally car from the collection, run your own team and work up from the Kenya National Rally Series to the world stage: special stages, pace notes, damage, service parks, sponsors and investors.']
		].filter(function (m) { return rallyOnly ? m[0] === 'rally' : m[0] !== 'rally'; });
		/* garage: every part changes the physics, not just the numbers */
		var PARTS = {
			engine: { n: 'Engine', o: [['stock', 'Stock'], ['s1', 'Stage 1 remap'], ['s2', 'Stage 2 turbo'], ['v12', 'V12 swap'], ['ev', 'Tri-motor EV swap']] },
			tyres: { n: 'Tyres', o: [['road', 'Road'], ['sport', 'Sport'], ['slick', 'Semi-slick'], ['at', 'All-terrain'], ['mud', 'Mud-terrain']] },
			susp: { n: 'Suspension', o: [['low', 'Lowered'], ['sport', 'Sport'], ['stock', 'Stock'], ['lift', 'Off-road lift']] },
			drive: { n: 'Drivetrain', o: [['stock', 'Stock'], ['awd', 'AWD conversion'], ['rwd', 'RWD drift spec']] },
			weight: { n: 'Weight', o: [['stock', 'Stock'], ['w1', 'Stripped −6%'], ['w2', 'Carbon −12%']] },
			aero: { n: 'Aero', o: [['none', 'None'], ['wing', 'Rear wing']] },
			nitro: { n: 'Nitro', o: [['none', 'None'], ['n1', 'Nitrous kit']] }
		};
		var PRESETS = [
			['Track day', { engine: 's1', tyres: 'slick', susp: 'low', drive: 'stock', weight: 'w1', aero: 'wing', nitro: 'none' }],
			['Rally raid', { engine: 's2', tyres: 'at', susp: 'lift', drive: 'awd', weight: 'w1', aero: 'none', nitro: 'n1' }],
			['Overlander', { engine: 'stock', tyres: 'mud', susp: 'lift', drive: 'awd', weight: 'stock', aero: 'none', nitro: 'none' }],
			['Drift king', { engine: 's2', tyres: 'sport', susp: 'sport', drive: 'rwd', weight: 'w1', aero: 'none', nitro: 'n1' }],
			['Hypercar', { engine: 'v12', tyres: 'slick', susp: 'low', drive: 'awd', weight: 'w2', aero: 'wing', nitro: 'n1' }]
		];
		var TYRE = { road: { tarmac: 1, dirt: .7, mud: .48, water: .45, grass: .55, bush: .5, sand: .5 }, sport: { tarmac: 1.08, dirt: .62, mud: .4, water: .4, grass: .5, bush: .45, sand: .45 }, slick: { tarmac: 1.18, dirt: .5, mud: .3, water: .3, grass: .42, bush: .38, sand: .38 }, at: { tarmac: .96, dirt: .98, mud: .74, water: .7, grass: .72, bush: .68, sand: .68 }, mud: { tarmac: .84, dirt: .9, mud: .97, water: .9, grass: .8, bush: .78, sand: .78 } , gravel: { tarmac: .9, dirt: 1.07, mud: .82, water: .75, grass: .82, bush: .74, sand: .9 }, rtarmac: { tarmac: 1.16, dirt: .78, mud: .5, water: .5, grass: .55, bush: .5, sand: .62 }, rmud: { tarmac: .82, dirt: .96, mud: 1.02, water: .92, grass: .86, bush: .8, sand: .95 } };
		var SUSP = { low: { lat: 1.06, rough: 1.7, ride: -.06 }, sport: { lat: 1.03, rough: 1.25, ride: -.03 }, stock: { lat: 1, rough: 1, ride: 0 }, lift: { lat: .93, rough: .3, ride: .2 } };
		var ROUGH = { tarmac: 0, dirt: .35, mud: 1.15, water: 1.5, grass: 1.3, bush: 1.4, wall: 0, sand: .95, rock: .8 };
		var GK0 = 'psr-garage';
		function garages() { try { return JSON.parse(localStorage.getItem(GK0) || '{}'); } catch (e) { return {}; } }
		function buildOf(c) { var g = garages()[c.id] || {}, b = {}; Object.keys(PARTS).forEach(function (k) { b[k] = g[k] || (k === 'tyres' ? (isSUV(c) ? 'at' : /coup|roadster/i.test(c.body || '') ? 'sport' : 'road') : k === 'susp' ? 'stock' : PARTS[k].o[0][0]); }); if (!g.susp && isSUV(c)) b.susp = 'stock'; return b; }
		function saveBuild(c, b) { var g = garages(); g[c.id] = b; try { localStorage.setItem(GK0, JSON.stringify(g)); } catch (e) {} }
		function buildTag(b) { var t = []; if (b.engine !== 'stock') t.push(b.engine === 'v12' ? 'V12' : b.engine === 'ev' ? 'EV' : b.engine.toUpperCase()); if (b.susp === 'lift') t.push('Lifted'); if (b.susp === 'low') t.push('Lowered'); if (b.tyres === 'mud' || b.tyres === 'at') t.push(b.tyres === 'mud' ? 'Mud tyres' : 'A/T tyres'); if (b.tyres === 'slick') t.push('Slicks'); if (b.drive !== 'stock') t.push(b.drive.toUpperCase()); if (b.nitro !== 'none') t.push('Nitro'); if (b.aero !== 'none') t.push('Wing'); if (b.weight !== 'stock') t.push(b.weight === 'w2' ? 'Carbon' : 'Stripped'); return t.join(' · '); }
		/* tyre curve per surface: [stiffness B, shape C]; loose surfaces are progressive, tarmac bites then lets go */
		var TBASE = { tarmac: [15, 1.5], dirt: [10, 1.3], mud: [8, 1.25], water: [8, 1.22], grass: [9, 1.28], bush: [8, 1.25], sand: [7, 1.2], rock: [11, 1.35] };
		var MIDR = /SF90|296|F8|488|Hurac|Revuelto|Aventador|Temerario|McLaren|R8\b|Valkyrie|MC20|Chiron|Veyron|Corvette|LaFerrari|Senna|Countach|Zonda|Huayra|Jesko|Agera|Regera|Artura|720|750|765|Speedtail|Elva|Daytona SP3|Emira|Evora|Exige|Cayman|Boxster|NSX|i8|Ford GT|Lotus|Rimac|Nevera|Tourbillon|Utopia/i;
		function vehOf(c, b) {
			var len = c.dim && c.dim[0] ? c.dim[0] / 1000 : 4.7, wid = c.dim && c.dim[1] ? Math.min(2.2, c.dim[1] / 1000) : 1.95, ht = c.dim && c.dim[2] ? c.dim[2] / 1000 : (isSUV(c) ? 1.8 : 1.3), Lw = Math.max(2.3, Math.min(3.4, len * .6));
			var nm = c.make + ' ' + c.model, fr = MIDR.test(nm) ? .42 : /911/.test(nm) ? .39 : /front-wheel|fwd/i.test(c.drive || '') ? .61 : isSUV(c) ? .53 : .52; /* share of weight on the front axle */
			var dr = c.drive || '', fs = /all|4wd|4matic|quattro|xdrive|four|4x4|awd/i.test(dr) ? (isSUV(c) ? .5 : MIDR.test(nm) ? .3 : .4) : /front-wheel|fwd/i.test(dr) ? 1 : 0;
			return { len: len, wid: wid, L: Lw, a: Lw * (1 - fr), b: Lw * fr, tw: wid * .86, hg: Math.max(.38, Math.min(.85, ht * .36)), front: fs, hl: len / 2, hw: wid / 2 };
		}
		function gearsFor(vTop, n) { if (n <= 1) return [vTop]; var v1 = vTop * .26, q = Math.pow(vTop / v1, 1 / (n - 1)), g = []; for (var i = 0; i < n; i++) g.push(v1 * Math.pow(q, i)); return g; }
		/* physics for a car plus its garage build */
		function physOf(c, b) {
			b = b || buildOf(c);
			var m = c.kg, Pw = c.hp * 745.7, vmax = c.vmax / 3.6, cda = Pw * .9 / (.5 * 1.2 * Math.pow(vmax, 3)), drv = /all|awd|4wd|4x4|4matic|quattro|xdrive|four/i.test(c.drive || '') ? 1 : .6;
			var veh = vehOf(c, b), evC = /electric|ev\b/i.test(c.fuel || ''), gr0 = gearsFor(vmax * 1.02, evC ? 1 : c.hp > 520 ? 7 : 6);
			function t100(k) { var v = 0, t = 0, gg = 0, sh = 0, ax = 0; while (v < 27.78 && t < 30) { if (!evC && v / gr0[gg] > 1.1 && gg < gr0.length - 1) { gg++; sh = .12; } var xx = v / gr0[gg], f = evC ? 1 : Math.max(.5, Math.min(1, xx * (2 - xx))), Pk = Pw * k, cap = evC ? 1.25 * Pk / (gr0[0] * .3) : 1.25 * Pk / gr0[gg];
				var tr = veh.front === 1 ? veh.b / veh.L - ax * veh.hg / 9.81 / veh.L : veh.front === 0 ? veh.a / veh.L + ax * veh.hg / 9.81 / veh.L : 1, F = Math.min(Math.min(Pk * f / Math.max(v, evC ? 1.2 : 2.5), cap) * (sh > 0 ? .25 : 1), 1.08 * 1.05 * m * 9.81 * tr) - .5 * 1.2 * cda * v * v - .015 * m * 9.81; ax = F / m; sh -= 1 / 120; v += ax / 120; t += 1 / 120; } return t; }
			var lo = .8, hi = 1.3; for (var it = 0; it < 20; it++) { var mid = (lo + hi) / 2; if (t100(mid) > c.acc) lo = mid; else hi = mid; }
			var P = Pw * (lo + hi) / 2, cyl = c.cyl || 8, ev = /electric|ev\b/i.test(c.fuel || '') , vmin = ev ? 1.2 : 2.5;
			if (b.engine === 's1') P *= 1.12; else if (b.engine === 's2') { P *= 1.3; m += 15; } else if (b.engine === 'v12') { P = Math.max(P * 1.15, 800 * 745.7 * (lo + hi) / 2); m += 90; cyl = 12; ev = false; vmin = 2.5; } else if (b.engine === 'ev') { P *= 1.35; m += 260; cyl = 0; ev = true; vmin = 1.2; drv = 1; }
			if (b.drive === 'awd') { drv = 1; m += 60; } else if (b.drive === 'rwd') drv = .6;
			if (b.weight === 'w1') m *= .94; else if (b.weight === 'w2') m *= .88;
			var mu = {}, ty = TYRE[b.tyres] || TYRE.road, su = SUSP[b.susp] || SUSP.stock; Object.keys(ty).forEach(function (k) { mu[k] = ty[k] * 1.05; }); mu.wall = mu.tarmac;
			if (isSUV(c)) { su = { lat: su.lat * .96, rough: su.rough * .75, ride: su.ride }; } /* tall tyres and long travel come standard */
			var down = b.aero === 'wing' ? 9e-4 : 0; if (down) cda *= 1.08;
			var vh = vehOf(c, b), ng = ev ? 1 : (P / 745.7 > 520 || b.engine === 'v12' ? 7 : 6), vTop = Math.pow(P * .97 / (.5 * 1.2 * cda), 1 / 3); vh.gears = gearsFor(Math.min(vTop * 1.02, vmax * 1.15), ng); vh.Iz = m * (vh.len * vh.len + 3.8) / 12 * 1.05;
			if (b.drive === 'awd') vh.front = isSUV(c) ? .5 : .4; else if (b.drive === 'rwd') vh.front = 0;
			var tbm = { slick: 1.25, sport: 1.1, road: 1, at: .9, mud: .8, gravel: 1.05, rtarmac: 1.2, rmud: .85 }[b.tyres] || 1; vh.tb = {}; Object.keys(TBASE).forEach(function (k) { vh.tb[k] = [TBASE[k][0] * tbm, TBASE[k][1]]; });
			if (b.susp === 'lift') vh.hg += .16; else if (b.susp === 'low') vh.hg -= .05; else if (b.susp === 'sport') vh.hg -= .025;
			return { m: m, P: P, cda: cda, mu: mu, lat: su.lat, rough: su.rough, ride: su.ride, drv: drv, down: down, nitro: b.nitro === 'n1', cyl: cyl, ev: ev, vmin: vmin, id: c.id, rwd: vh.front === 0, veh: vh };
		}
		function perf(c, b) {
			var p = physOf(c, b), v = 0, t = 0; while (v < 27.78 && t < 30) { var F = Math.min(p.P / Math.max(v, p.vmin), p.mu.tarmac * p.m * 9.81 * p.drv) - .5 * 1.2 * p.cda * v * v - .015 * p.m * 9.81; v += F / p.m / 120; t += 1 / 120; }
			var st = physOf(c, { engine: 'stock', tyres: 'road', susp: 'stock', drive: 'stock', weight: 'stock', aero: 'none', nitro: 'none' }), ratio = p.P / st.P, realHp = c.hp * ratio;
			var vt = c.vmax * Math.pow(ratio * st.cda / p.cda, 1 / 3), hand = p.mu.tarmac * p.lat * (1 + (p.down ? .08 : 0)), offr = p.mu.dirt * (1.4 - Math.min(1.2, p.rough * .5));
			var pi = Math.round(Math.min(999, 100 + (realHp * 745.7 / p.m) * .55 + hand * 150 + vt * .45 + offr * 20)), cls = pi > 760 ? 'X' : pi > 640 ? 'S' : pi > 540 ? 'A' : pi > 460 ? 'B' : pi > 390 ? 'C' : 'D';
			return { acc: t, vmax: vt, hand: hand, off: offr, pi: pi, cls: cls, hp: Math.round(realHp), kg: Math.round(p.m) };
		}
		var first3d = (cars.filter(function (c) { return c.glb; })[0] || cars[0]).id;
		function opts(sel0, filt) { var L = filt ? cars.filter(filt) : cars; if (!L.length) L = cars; return grp(L, function (c) { return '<option value="' + c.id + '"' + (c.id === sel0 ? ' selected' : '') + '>' + esc(cname(c)) + ' · ' + c.hp + ' hp' + (c.glb ? ' · 3D' : '') + '</option>'; }); }
		root.innerHTML = '<div class="rx__menu">'
			+ '<div class="rx__modes" role="tablist">' + ['Race', 'Party', 'Characters', 'Chases', 'Challenges'].map(function (g) { var L = MODES.filter(function (m) { return (m[3] || 'Race') === g; }); if (!L.length) return ''; return '<div class="rx__mg"><small>' + g + '</small><span>' + L.map(function (m) { return '<button type="button" role="tab" data-rx-mode="' + m[0] + '"' + (m === MODES[0] ? ' class="is-on" aria-selected="true"' : '') + '>' + m[1] + '</button>'; }).join('') + '</span></div>'; }).join('') + '</div>'
			+ '<p class="rx__modehelp" data-rx-modehelp>' + MODES[0][2] + '</p><div class="rl" data-rl hidden></div>'
			+ '<div class="rx__tracks">' + Object.keys(TRACKS).map(function (k, i) { var t = TRACKS[k]; return '<button type="button" class="rx__trk rx__trk--' + t.theme + (i ? '' : ' is-on') + '" data-rx-trk="' + k + '"><b>' + t.name + '</b><span>' + t.surf + ' · ' + t.len + '</span></button>'; }).join('') + '</div>'
			+ '<div class="hl__bar"><label><span data-rx-p1lab>Your car</span><select data-hl-car>' + opts(first3d) + '</select></label>'
			+ '<button type="button" class="rx__gbtn" data-rx-garage>Garage</button>'
			+ '<label data-rx-oppwrap hidden><span>Rivals</span><select data-rx-n><option>1</option><option>2</option><option selected>3</option><option>4</option><option>5</option></select></label>'
			+ '<label data-rx-p2wrap hidden><span>Player 2 car</span><select data-rx-car2>' + opts(cars[Math.min(3, cars.length - 1)].id) + '</select></label>'
			+ '<button type="button" class="rx__gbtn" data-rx-ent hidden>Entourage <b data-rx-entn>0</b></button>'
			+ '<label class="rx__names" data-rx-names hidden><span>Drivers (comma separated)</span><input type="text" data-rx-namein maxlength="120" placeholder="Moffatt, Ryan, Denzel"></label>'
			+ '<label class="rx__names" data-pm-betwrap hidden><span>Spectators betting (comma separated, optional)</span><input type="text" data-pm-bettors maxlength="120" placeholder="Ryan, Denzel"></label>'
			+ '<button type="button" class="lx-btn lx-btn--gold" data-hl-go>Start your engines</button>'
			+ '<button type="button" class="hl__snd" data-hl-snd aria-pressed="false">Engine sound off</button><button type="button" class="hl__snd" data-hl-cam title="Camera (C)">Camera: chase</button><button type="button" class="hl__snd" data-pm-comm>' + (commOn ? 'Commentator on' : 'Commentator off') + '</button></div>'
			+ '<p class="rx__build" data-rx-build></p></div>'
			+ '<div class="hl__stage" data-hl-stage><div class="hl__hud"><div class="hl__spd"><b data-hl-v>0</b><small>km/h</small><i data-hl-g>N</i><em class="rx__nos" data-rx-nos hidden><s data-rx-nosbar></s></em></div><div class="hl__laps"><span data-hl-pos hidden>P<b data-hl-p>1</b><small data-hl-of></small></span><span>Lap <b data-hl-lap>–</b></span><span>Time <b data-hl-t>0.00</b></span><span>Last <b data-hl-last>–</b></span><span>Best <b data-hl-best>–</b></span><span data-hl-prow>Gold <b data-hl-pro>–</b></span><span class="hl__delta" data-hl-delta hidden></span><span class="rx__drift" data-rx-drift hidden>Drift <b data-rx-ds>0</b><i data-rx-dm></i></span></div><canvas class="hl__map" width="180" height="180" data-hl-map></canvas></div>'
			+ '<div class="rx__hud2" data-rx-hud2 hidden><b data-rx-v2>0</b><small>km/h</small><span>P<b data-rx-p2pos>2</b> · Lap <b data-rx-lap2>1</b></span><em class="rx__nos" data-rx-nos2 hidden><s data-rx-nosbar2></s></em></div>'
			+ '<ol class="rx__board" data-rx-board hidden></ol><div class="rl__note" data-rl-note></div><div class="pm__hud" data-pm-hud hidden></div><div class="pm__flash" data-pm-flash></div><div class="pm__rp" data-pm-rp hidden><b>● REPLAY</b><button type="button" data-pm-rpx>Skip</button></div><div class="pm__album" data-pm-album hidden></div><span class="pm__draft" data-pm-draft hidden>SLIPSTREAM</span><span class="pm__billc" data-pm-billc hidden></span><div class="rl__dmg" data-rl-dmgh hidden></div><button type="button" class="rl__fan" data-rl-fan hidden>Fans: push me out (F)</button><button type="button" class="rl__rep" data-rl-rep hidden>Roadside repair (R)</button>'
			+ '<div class="hl__msg" data-hl-msg><b>Laqim Racing.</b><span>Pick a mode and a track, tune your car in the Garage, then start your engines. Arrow keys or WASD to drive, Space for the handbrake, Shift for nitro, C to change camera. Game controllers work too; on a phone, use the buttons.</span></div>'
			+ '<b class="hl__count" data-hl-count hidden></b><button type="button" class="hl__pbtn" data-hl-pbtn aria-label="Pause">❚❚</button><div class="hl__pause" data-hl-pause hidden><div><h3>Paused</h3><button type="button" data-hl-pact="resume">Resume</button><button type="button" data-hl-pact="reset">Reset car to the road</button><button type="button" data-hl-pact="restart">Restart</button><button type="button" data-hl-pact="cam">Change camera</button><button type="button" data-hl-pact="replay">Instant replay</button><button type="button" data-hl-pact="album">Postcard album</button><button type="button" data-hl-pact="quit">Quit to menu</button><p>Esc or P to pause · Backspace resets the car · Start button on a controller</p></div></div>'
			+ '<div class="rx__panel" data-rx-panel hidden></div>'
			+ '<div class="hl__touch" data-hl-touch><button type="button" data-k="l" aria-label="Steer left">◀</button><button type="button" data-k="r" aria-label="Steer right">▶</button><button type="button" class="hl__tilt" data-hl-tilt aria-pressed="false">Tilt</button><button type="button" class="rx__tn" data-k="n" aria-label="Nitro">N₂O</button><button type="button" class="rx__th" data-k="h" aria-label="Handbrake">⤺</button><button type="button" data-k="b" aria-label="Brake">Brake</button><button type="button" data-k="t" aria-label="Accelerate">Go</button></div></div>'
			+ '<div class="rx__garage" data-rx-gar hidden></div>'
			+ '<p class="hl__note">Each car starts from its published power, weight, 0–100 time and top speed. Garage parts change the physics: tyres set grip on each surface, suspension decides how hard bumps and ruts bite, engines and weight change acceleration and top speed. Everything is saved on this device.</p>';
		var stage = $('[data-hl-stage]', root), sel = $('[data-hl-car]', root), sel2 = $('[data-rx-car2]', root), msg = $('[data-hl-msg]', root), cnt = $('[data-hl-count]', root), panel = $('[data-rx-panel]', root), board = $('[data-rx-board]', root);
		var K = { l: 0, r: 0, t: 0, b: 0, h: 0, n: 0 }, K2 = { l: 0, r: 0, t: 0, b: 0, h: 0, n: 0 }, game = null, synth = null, sndOn = false;
		var tiltOn = false, tilt = 0, CAMS = ['chase', 'bonnet', 'tv', 'high', 'drone'], camI = 0, mode = 'tt', trk = 'circuit', chal = null, party = null, userPicked = false;
		var BK = 'psr-hl-best', DK = 'psr-hl-drift';
		function camNext() { camI = (camI + 1) % CAMS.length; $('[data-hl-cam]', root).textContent = 'Camera: ' + CAMS[camI]; }
		on($('[data-hl-cam]', root), 'click', camNext);
		function tiltRead(e) { var ang = w.orientation || (screen.orientation && screen.orientation.angle) || 0, land = Math.abs(ang) === 90 || ang === 270, sg = (ang === -90 || ang === 270) ? -1 : 1; tilt = land ? (e.beta || 0) * sg : (e.gamma || 0); }
		on($('[data-hl-tilt]', root), 'click', function () { var b = this; function go() { tiltOn = !tiltOn; b.setAttribute('aria-pressed', tiltOn); b.textContent = tiltOn ? 'Tilt on' : 'Tilt'; if (tiltOn) w.addEventListener('deviceorientation', tiltRead); else w.removeEventListener('deviceorientation', tiltRead); } if (!tiltOn && w.DeviceOrientationEvent && typeof DeviceOrientationEvent.requestPermission === 'function') DeviceOrientationEvent.requestPermission().then(function (r) { if (r === 'granted') go(); }).catch(function () {}); else go(); });
		function store(k) { try { return JSON.parse(localStorage.getItem(k) || '{}'); } catch (e) { return {}; } }
		function put(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
		/* bring over best laps from the first version of Hot Lap */
		(function () { try { var old = JSON.parse(localStorage.getItem('psr-hotlap-best') || 'null'); if (old) { var b = store(BK); Object.keys(old).forEach(function (id) { var kk = 'circuit:' + id; if (!b[kk] || old[id] < b[kk]) b[kk] = old[id]; }); put(BK, b); localStorage.removeItem('psr-hotlap-best'); } } catch (e) {} })();
		function fmt(t) { var m = Math.floor(t / 60), s = t - m * 60; return (m ? m + ':' + (s < 10 ? '0' : '') : '') + s.toFixed(2); }
		function bestKey(c) { return trk + ':' + c.id; }
		function showBest() { var c = byId(+sel.value); if (!c) return; var b = store(BK)[bestKey(c)]; $('[data-hl-best]', root).textContent = b ? fmt(b) : '–'; var bt = buildTag(buildOf(c)), pf = perf(c, buildOf(c)); $('[data-rx-build]', root).innerHTML = '<b class="rx__cls rx__cls--' + pf.cls + '">' + pf.cls + ' ' + pf.pi + '</b> ' + esc(cname(c)) + (bt ? ' · <span>' + esc(bt) + '</span>' : ' · stock') + (trk === 'trail' && !isSUV(c) && buildOf(c).susp !== 'lift' ? ' · <em>Tip: SUVs, a lift kit and A/T or mud tyres are much quicker on the trail.</em>' : ''); }
		function setMode(m) {
			mode = m; $$('[data-rx-mode]', root).forEach(function (b) { var onn = b.getAttribute('data-rx-mode') === m; b.classList.toggle('is-on', onn); b.setAttribute('aria-selected', onn ? 'true' : 'false'); });
			$('[data-rx-modehelp]', root).textContent = MODES.filter(function (x) { return x[0] === m; })[0][2];
			$('[data-rx-oppwrap]', root).hidden = m !== 'race'; $('[data-rx-p2wrap]', root).hidden = m !== 'duel' && m !== 'potato'; $('[data-rx-names]', root).hidden = m !== 'party'; $('[data-rx-ent]', root).hidden = m !== 'convoy'; $('[data-pm-betwrap]', root).hidden = ['race', 'ko', 'roulette'].indexOf(m) < 0;
			$('[data-rx-p1lab]', root).textContent = m === 'duel' || m === 'potato' ? 'Player 1 car' : 'Your car';
			root.classList.toggle('is-rally', m === 'rally'); msg.innerHTML = m === 'rally' ? '<b>Laqim Rally.</b><span>Build your rally car, then enter the next rally from the panel above. A game controller gives the best feel: triggers for throttle and brake, X for the handbrake, LB and RB to change gear.</span>' : '<b>Laqim Racing.</b><span>Pick a mode and a track, tune your car in the Garage, then start your engines. Arrow keys or WASD to drive, Space for the handbrake, Shift for nitro, C to change camera. Game controllers work too; on a phone, use the buttons.</span>'; rlEl = $('[data-rl]', root); rlEl.hidden = m !== 'rally'; if (m === 'rally') rlRender(); if (m !== 'party') party = null; if (game) game.stop(); msg.hidden = false; stage.classList.remove('is-live'); $('[data-hl-go]', root).textContent = m === 'party' ? 'Start the party' : 'Start your engines'; panel.hidden = true; board.hidden = true; if (m === 'sig' || m === 'cotd') sigPrep();
		}
		$$('[data-rx-mode]', root).forEach(function (b) { on(b, 'click', function () { setMode(b.getAttribute('data-rx-mode')); }); });
		function suvFirst() { var c = byId(+sel.value); if (trk === 'trail' && c && !isSUV(c) && !userPicked) { var s = cars.filter(function (x) { return isSUV(x) && x.glb; })[0] || cars.filter(isSUV)[0]; if (s) sel.value = s.id; var s2 = cars.filter(function (x) { return isSUV(x) && x.glb && x.id !== +sel.value; })[0]; if (s2) sel2.value = s2.id; } }
		function setTrack(k) { trk = k; $$('[data-rx-trk]', root).forEach(function (b) { b.classList.toggle('is-on', b.getAttribute('data-rx-trk') === k); }); suvFirst(); showBest(); if (game) { game.stop(); game.world(k); } msg.hidden = false; stage.classList.remove('is-live'); }
		$$('[data-rx-trk]', root).forEach(function (b) { on(b, 'click', function () { setTrack(b.getAttribute('data-rx-trk')); }); });
		on($('[data-pm-comm]', root), 'click', function () { commOn = !commOn; this.textContent = commOn ? 'Commentator on' : 'Commentator off'; try { localStorage.setItem('psr-comm', commOn ? '1' : '0'); } catch (e) {} if (!commOn && w.speechSynthesis) speechSynthesis.cancel(); });
		if (rallyOnly) { root.classList.add('is-rallyonly'); setTimeout(function () { setMode('rally'); }, 0); }
		/* ---------- signature challenges and car of the day ---------- */
		var SIG = null, COTD = null;
		function dayKey(t) { var d1 = new Date(t || Date.now()); return d1.getUTCFullYear() + '-' + ('0' + (d1.getUTCMonth() + 1)).slice(-2) + '-' + ('0' + d1.getUTCDate()).slice(-2); }
		function cotdPick() { var k = dayKey(), h = 7; for (var i = 0; i < k.length; i++) h = (Math.imul(h, 31) + k.charCodeAt(i)) >>> 0; h = Math.imul(h ^ (h >>> 15), 2246822507) >>> 0; var pool = cars.filter(function (c) { return c.glb; }); if (!pool.length) pool = cars.slice(); pool.sort(function (a, b) { return a.id - b.id; }); var c = pool[h % pool.length], tk = ['circuit', 'night', 'trail'][(h >>> 8) % 3]; if (tk === 'trail' && !isSUV(c)) tk = (h >>> 12) % 2 ? 'circuit' : 'night'; return { k: tk, c: c, day: k }; }
		function sigFor(c) { var hp = c.hp || 200, dr = String(c.drive || '').toLowerCase(), ev = /electric|ev\b/i.test(String(c.fuel || '')), nm = 'The ' + c.model + ' ';
			if (isSUV(c)) return { ty: 'clean', k: 'trail', n: nm + 'bush bash', d: 'One clean lap of the Rift Valley Trail: no walls, trees or rocks. Medals for time.' };
			if (hp >= 600) return { ty: 'vmax', k: 'circuit', n: nm + 'flat out', d: 'One lap of the Laqim Circuit. Medals for your top speed.' };
			if (/rear|rwd/.test(dr) && hp >= 300) return { ty: 'drift', k: 'circuit', n: nm + 'sideways', d: 'One lap of the Laqim Circuit. Medals for drift points.' };
			if (ev) return { ty: 'lap', k: 'night', n: nm + 'silent run', d: 'One lap of the Nairobi Night Run against the clock.' };
			return hp > 300 ? { ty: 'lap', k: 'night', n: nm + 'street fight', d: 'One lap of the Nairobi Night Run against the clock.' } : { ty: 'lap', k: 'circuit', n: nm + 'momentum lap', d: 'One lap of the Laqim Circuit. Carry your speed: medals for time.' }; }
		function sigPrep() { var help = $('[data-rx-modehelp]', root), M3 = ['No medal yet', '🥉 Bronze', '🥈 Silver', '🥇 Gold'];
			if (mode === 'sig') { var c = byId(+sel.value); if (!c) return; SIG = sigFor(c); if (trk !== SIG.k) { userPicked = true; setTrack(SIG.k); } var bk = store('psr-sig'), o = bk[c.id], golds = Object.keys(bk).filter(function (k) { return bk[k].m === 3; }).length; help.textContent = SIG.n + ': ' + SIG.d + ' Your medal: ' + M3[o ? o.m : 0] + '. Gold on ' + golds + ' of ' + cars.filter(function (x) { return x.glb; }).length + ' cars. Every car has its own challenge: change the car to see it.'; }
			else if (mode === 'cotd') { COTD = cotdPick(); if (trk !== COTD.k) { userPicked = true; setTrack(COTD.k); } sel.value = COTD.c.id; showBest(); var ck = store('psr-cotd'), b = ck.days && ck.days[COTD.day]; help.textContent = 'Today (' + COTD.day + '): the ' + cname(COTD.c) + ' on the ' + TRACKS[COTD.k].name + '. Everyone gets the same car and track today. ' + (b ? 'Your best today: ' + fmt(b) + '.' : 'Set a lap, then share your result card.') + (ck.streak ? ' Day streak: ' + ck.streak + '.' : ''); } }
		on(sel, 'change', function () { if (mode === 'sig' || mode === 'cotd') sigPrep(); });
		/* ---------- draw it, drive it ---------- */
		var DRAWK = null, DRAWC = null, trWrap = $('.rx__tracks', root);
		trWrap.insertAdjacentHTML('beforeend', '<button type="button" class="rx__trk rx__trk--day rx__trk--own" data-rx-trk="" data-pm-own hidden><b>Your track</b><span></span></button><button type="button" class="rx__trk rx__trk--draw" data-pm-draw><b>✎ Draw a track</b><span>Draw it, drive it, share it</span></button>');
		d.body.insertAdjacentHTML('beforeend', '<div class="pm__draw" data-pm-drawbox hidden><div><h3>Draw it, drive it</h3><p>Draw one loop with your finger or mouse; it closes itself. Keep the lines apart so the road does not cross itself.</p><canvas width="640" height="420" data-pm-cv></canvas><p class="pm__dmsg" data-pm-dmsg></p><div class="pm__dbtns"><button type="button" class="pm__db pm__db--gold" data-pm-dok disabled>Drive it</button><button type="button" class="pm__db" data-pm-dshare disabled>Share the track</button><button type="button" class="pm__db" data-pm-dclr>Clear</button><button type="button" class="pm__db" data-pm-dx>Close</button></div></div></div>');
		var ownB = $('[data-pm-own]', root), dBox = d.body.lastElementChild, dCv = $('[data-pm-cv]', dBox), dX = dCv.getContext('2d'), dMsg = $('[data-pm-dmsg]', dBox), dRaw = [], dP = null, dDown = false;
		function trkHash(s) { var h = 5381; for (var i = 0; i < s.length; i++) h = (Math.imul(h, 33) ^ s.charCodeAt(i)) >>> 0; return h.toString(36); }
		function trkCode(P) { var u = new Uint8Array(P.length * 2); P.forEach(function (p, i) { u[i * 2] = Math.max(0, Math.min(255, Math.round(p[0] / 4) + 128)); u[i * 2 + 1] = Math.max(0, Math.min(255, Math.round(p[1] / 4) + 128)); }); return b64u(u); }
		function trkFrom(code) { try { var u = unb64u(code), P = []; for (var i = 0; i + 1 < u.length; i += 2) P.push([(u[i] - 128) * 4, (u[i + 1] - 128) * 4]); return P.length >= 6 && P.length <= 60 ? P : null; } catch (e) { return null; } }
		function trkLen(P) { var L = 0; P.forEach(function (p, i) { var q = P[(i + 1) % P.length]; L += Math.hypot(q[0] - p[0], q[1] - p[1]); }); return L; }
		function trkInstall(P, code) { var k = 'u' + trkHash(code); if (DRAWK && DRAWK !== k && trk !== DRAWK) delete TRACKS[DRAWK]; DRAWK = k; DRAWC = code; TRACKS[k] = { name: 'Your track', surf: 'Hand-drawn tarmac', len: (trkLen(P) * 1.04 / 1000).toFixed(1) + ' km', blurb: 'Drawn by hand.', laps: 3, Wd: 13, theme: 'day', off: 'grass', P: P }; try { localStorage.setItem('psr-draw', code); } catch (e) {} ownB.setAttribute('data-rx-trk', k); ownB.hidden = false; $('span', ownB).textContent = TRACKS[k].surf + ' · ' + TRACKS[k].len; }
		function resample(L, n) { var M = L.concat([L[0]]), sl = [], tot = 0, i; for (i = 1; i < M.length; i++) { var l = Math.hypot(M[i][0] - M[i - 1][0], M[i][1] - M[i - 1][1]); sl.push(l); tot += l; } var out = [], acc = 0, j = 0; for (var k = 0; k < n; k++) { var tg = k * tot / n; while (j < sl.length - 1 && acc + sl[j] < tg) { acc += sl[j]; j++; } var f = sl[j] ? (tg - acc) / sl[j] : 0; out.push([M[j][0] + (M[j + 1][0] - M[j][0]) * f, M[j][1] + (M[j + 1][1] - M[j][1]) * f]); } return { p: out, len: tot }; }
		function dPaint(P, col) { dX.clearRect(0, 0, 640, 420); dX.fillStyle = '#20301f'; dX.fillRect(0, 0, 640, 420); if (!P || P.length < 2) return; dX.lineJoin = dX.lineCap = 'round'; [[22, '#f4f4f4'], [18, col || '#3a3a40']].forEach(function (q) { dX.strokeStyle = q[1]; dX.lineWidth = q[0]; dX.beginPath(); P.forEach(function (p, i) { if (i) dX.lineTo(p[0], p[1]); else dX.moveTo(p[0], p[1]); }); if (P.closed) dX.closePath(); dX.stroke(); }); }
		function dPos(e) { var r = dCv.getBoundingClientRect(); return [(e.clientX - r.left) / r.width * 640, (e.clientY - r.top) / r.height * 420]; }
		function dDone() { dP = null; $('[data-pm-dok]', dBox).disabled = true; $('[data-pm-dshare]', dBox).disabled = true; if (dRaw.length < 8) return; var r = resample(dRaw, 22); if (r.len < 500) { dMsg.textContent = 'Draw a bigger loop: use most of the box.'; return; }
			var sc = 1150 / r.len, cx = 0, cz = 0; r.p.forEach(function (p) { cx += p[0]; cz += p[1]; }); cx /= r.p.length; cz /= r.p.length; var P = r.p.map(function (p) { return [Math.round((p[0] - cx) * sc / 4) * 4, Math.round((p[1] - cz) * sc / 4) * 4]; });
			var f = resample(P, 110).p, bad = false; for (var i = 0; i < 110 && !bad; i++) for (var j = i + 9; j < 110; j++) { if (Math.min(j - i, 110 - (j - i)) < 9) continue; if (Math.hypot(f[i][0] - f[j][0], f[i][1] - f[j][1]) < 30) { bad = true; break; } }
			for (i = 0; i < P.length && !bad; i++) { var a = P[(i - 1 + P.length) % P.length], b = P[i], c = P[(i + 1) % P.length], t1 = Math.atan2(b[1] - a[1], b[0] - a[0]), t2 = Math.atan2(c[1] - b[1], c[0] - b[0]), dd = Math.abs(Math.atan2(Math.sin(t2 - t1), Math.cos(t2 - t1))); if (dd > 2.5) bad = 'sharp'; }
			var sm = r.p.slice(); sm.closed = true; dPaint(sm, bad ? '#7a2b2b' : '#3a3a40'); if (bad) { dMsg.textContent = bad === 'sharp' ? 'One corner folds back on itself. Round it off and try again.' : 'The road gets too close to itself. Keep the lines further apart.'; return; }
			dP = P; dMsg.textContent = 'Looks good: about ' + (trkLen(P) * 1.04 / 1000).toFixed(1) + ' km of tarmac.'; $('[data-pm-dok]', dBox).disabled = false; $('[data-pm-dshare]', dBox).disabled = false; }
		on(dCv, 'pointerdown', function (e) { e.preventDefault(); dDown = true; dRaw = [dPos(e)]; try { dCv.setPointerCapture(e.pointerId); } catch (e2) {} dMsg.textContent = ''; });
		on(dCv, 'pointermove', function (e) { if (!dDown) return; var p = dPos(e), q = dRaw[dRaw.length - 1]; if (Math.hypot(p[0] - q[0], p[1] - q[1]) > 4) { dRaw.push(p); dPaint(dRaw); } });
		on(dCv, 'pointerup', function () { if (!dDown) return; dDown = false; dDone(); });
		on(ownB, 'click', function () { if (DRAWK) setTrack(DRAWK); });
		on($('[data-pm-draw]', root), 'click', function () { dBox.hidden = false; dRaw = []; dP = null; dPaint(null); dMsg.textContent = ''; $('[data-pm-dok]', dBox).disabled = true; $('[data-pm-dshare]', dBox).disabled = true; });
		on($('[data-pm-dclr]', dBox), 'click', function () { dRaw = []; dP = null; dPaint(null); dMsg.textContent = ''; $('[data-pm-dok]', dBox).disabled = true; $('[data-pm-dshare]', dBox).disabled = true; });
		on($('[data-pm-dx]', dBox), 'click', function () { dBox.hidden = true; }); on(dBox, 'click', function (e) { if (e.target === dBox) dBox.hidden = true; }); on(d, 'keydown', function (e) { if (e.key === 'Escape' && !dBox.hidden) dBox.hidden = true; });
		on($('[data-pm-dok]', dBox), 'click', function () { if (!dP) return; trkInstall(dP, trkCode(dP)); dBox.hidden = true; userPicked = true; setTrack(DRAWK); msg.innerHTML = '<b>Your track is ready.</b><span>Pick any mode and car, then start your engines. Share the track from the drawing box to challenge friends.</span>'; });
		on($('[data-pm-dshare]', dBox), 'click', function () { if (!dP) return; var code = trkCode(dP), sec = root.closest('[id]'), url = location.origin + location.pathname + '?trk=' + code + (sec ? '#' + sec.id : ''); trkInstall(dP, code); if (navigator.share) navigator.share({ title: 'Laqim Racing: drive my track', url: url }).catch(function () {}); else if (navigator.clipboard) navigator.clipboard.writeText(url).then(function () { dMsg.textContent = 'Link copied. Send it to a friend.'; }, function () { dMsg.textContent = url; }); else dMsg.textContent = url; });
		(function () { var q = null; try { q = new URLSearchParams(location.search).get('trk'); } catch (e) {} var code = q || (function () { try { return localStorage.getItem('psr-draw'); } catch (e) { return null; } })(), P = code && trkFrom(code); if (!P || rallyOnly) return; trkInstall(P, code); if (q) setTimeout(function () { userPicked = true; setTrack(DRAWK); msg.innerHTML = '<b>A friend drew this track for you.</b><span>Pick a car and a mode, then start your engines.</span>'; }, 50); })();
		on(sel, 'change', function () { userPicked = true; showBest(); if (game && game.live) game.stop(); });
		/* ---------- garage ---------- */
		var gar = $('[data-rx-gar]', root);
		function bar(lbl, v, v0, max, fmtf, lowGood) { var pc = Math.max(4, Math.min(100, v / max * 100)), pc0 = Math.max(4, Math.min(100, v0 / max * 100)), better = lowGood ? v < v0 - .005 : v > v0 + .005, worse = lowGood ? v > v0 + .005 : v < v0 - .005; return '<div class="rx__stat"><span>' + lbl + '</span><i><s style="width:' + pc0 + '%"></s><b class="' + (better ? 'is-up' : worse ? 'is-dn' : '') + '" style="width:' + pc + '%"></b></i><em>' + fmtf(v) + '</em></div>'; }
		function openGarage() {
			var c = byId(+sel.value); if (!c) return; var b = buildOf(c), stock = {}; Object.keys(PARTS).forEach(function (k) { stock[k] = PARTS[k].o[0][0]; }); stock.tyres = buildOf({ id: -1, body: c.body, model: c.model }).tyres; stock.susp = 'stock';
			function draw() {
				var p = perf(c, b), p0 = perf(c, stock);
				gar.innerHTML = '<div class="rx__gin"><div class="rx__ghead"><div><small>Garage</small><h3>' + esc(cname(c)) + '</h3><p><b class="rx__cls rx__cls--' + p.cls + '">' + p.cls + ' ' + p.pi + '</b> ' + Math.round(p.hp) + ' hp · ' + p.kg + ' kg</p></div><button type="button" class="rx__x" data-rx-gclose aria-label="Close the garage">×</button></div>'
					+ '<div class="rx__stats">' + bar('0–100', p.acc, p0.acc, 12, function (x) { return x.toFixed(1) + ' s'; }, true) + bar('Top speed', p.vmax, p0.vmax, 420, function (x) { return Math.round(x) + ' km/h'; }) + bar('Handling', p.hand, p0.hand, 1.45, function (x) { return Math.min(10, x / 1.45 * 10).toFixed(1); }) + bar('Off-road', p.off, p0.off, 1.45, function (x) { return Math.min(10, x / 1.45 * 10).toFixed(1); }) + '</div>'
					+ '<div class="rx__presets"><span>Quick builds</span>' + PRESETS.map(function (pr, i) { return '<button type="button" data-rx-pre="' + i + '">' + pr[0] + '</button>'; }).join('') + '</div>'
					+ '<div class="rx__parts">' + Object.keys(PARTS).map(function (k) { return '<div class="rx__part"><span>' + PARTS[k].n + '</span><div>' + PARTS[k].o.map(function (o) { return '<button type="button" data-rx-part="' + k + '" data-v="' + o[0] + '"' + (b[k] === o[0] ? ' class="is-on"' : '') + '>' + o[1] + '</button>'; }).join('') + '</div></div>'; }).join('') + '</div>'
					+ '<div class="rx__gfoot"><button type="button" class="hl__snd" data-rx-greset>Back to stock</button><button type="button" class="lx-btn lx-btn--gold" data-rx-gdone>Save build</button></div></div>';
				$$('[data-rx-pre]', gar).forEach(function (bt) { on(bt, 'click', function () { var pr = PRESETS[+bt.getAttribute('data-rx-pre')][1]; Object.keys(pr).forEach(function (k) { b[k] = pr[k]; }); FX.play('ok'); draw(); }); });
				$$('[data-rx-part]', gar).forEach(function (bt) { on(bt, 'click', function () { b[bt.getAttribute('data-rx-part')] = bt.getAttribute('data-v'); FX.play('tick'); draw(); }); });
				on($('[data-rx-gclose]', gar), 'click', close); on($('[data-rx-greset]', gar), 'click', function () { b = JSON.parse(JSON.stringify(stock)); draw(); });
				on($('[data-rx-gdone]', gar), 'click', function () { saveBuild(c, b); FX.play('ok'); close(); showBest(); if (game) game.stop(); });
			}
			function close() { gar.hidden = true; }
			draw(); gar.hidden = false; FX.play('flip');
		}
		on($('[data-rx-garage]', root), 'click', openGarage);
		/* ---------- entourage ---------- */
		var EK = 'psr-hl-entourage';
		function entourage() { var l = []; try { l = JSON.parse(localStorage.getItem(EK) || '[]'); } catch (e) {} l = l.filter(function (id) { return byId(id); }); if (!l.length) l = (cars.filter(function (c) { return c.glb && isSUV(c); }).length ? cars.filter(function (c) { return c.glb && isSUV(c); }) : cars).slice(0, 3).map(function (c) { return c.id; }); return l.slice(0, 4); }
		function showEnt() { $('[data-rx-entn]', root).textContent = entourage().length; }
		function openEnt() {
			var picked = entourage();
			function draw() {
				var L = (cars.filter(function (c) { return c.glb; }).length > 8 ? cars.filter(function (c) { return c.glb; }) : cars.slice()).sort(function (a, b) { return (isSUV(b) - isSUV(a)) || String(a.make).localeCompare(b.make); });
				gar.innerHTML = '<div class="rx__gin"><div class="rx__ghead"><div><small>Entourage</small><h3>Pick up to four cars</h3><p>They follow you in this order. Each one drives with its own garage build.</p></div><button type="button" class="rx__x" data-rx-gclose aria-label="Close">×</button></div><div class="rx__ent">' + L.map(function (c) { var i = picked.indexOf(c.id); return '<button type="button" data-rx-pick="' + c.id + '"' + (i > -1 ? ' class="is-on"' : '') + '>' + (i > -1 ? '<b>' + (i + 1) + '</b>' : '') + esc(cname(c)) + '<small>' + (isSUV(c) ? 'SUV · ' : '') + c.hp + ' hp</small></button>'; }).join('') + '</div><div class="rx__gfoot"><button type="button" class="hl__snd" data-rx-eclear>Clear</button><button type="button" class="lx-btn lx-btn--gold" data-rx-gdone>Save entourage</button></div></div>';
				$$('[data-rx-pick]', gar).forEach(function (bt) { on(bt, 'click', function () { var id = +bt.getAttribute('data-rx-pick'), i = picked.indexOf(id); if (i > -1) picked.splice(i, 1); else if (picked.length < 4) picked.push(id); else { FX.play('no'); return; } FX.play('tick'); draw(); }); });
				on($('[data-rx-gclose]', gar), 'click', function () { gar.hidden = true; }); on($('[data-rx-eclear]', gar), 'click', function () { picked = []; draw(); });
				on($('[data-rx-gdone]', gar), 'click', function () { put(EK, picked); showEnt(); gar.hidden = true; FX.play('ok'); if (game) game.stop(); });
			}
			draw(); gar.hidden = false; FX.play('flip');
		}
		on($('[data-rx-ent]', root), 'click', openEnt); showEnt();
		/* ---------- inputs ---------- */
		on($('[data-hl-snd]', root), 'click', function () { sndOn = !sndOn; this.setAttribute('aria-pressed', sndOn ? 'true' : 'false'); this.textContent = sndOn ? 'Engine sound on' : 'Engine sound off'; if (sndOn) { synth = synth || engineSynth(); if (synth) synth.on(true); } else if (synth) synth.on(false); });
		$$('[data-k]', root).forEach(function (b) { var k = b.getAttribute('data-k'); function dn(e) { e.preventDefault(); K[k] = 1; } function up() { K[k] = 0; } on(b, 'pointerdown', dn); on(b, 'pointerup', up); on(b, 'pointerleave', up); on(b, 'pointercancel', up); });
		var KEY1 = { KeyA: 'l', KeyD: 'r', KeyW: 't', KeyS: 'b', Space: 'h', ShiftLeft: 'n' }, KEY2 = { ArrowLeft: 'l', ArrowRight: 'r', ArrowUp: 't', ArrowDown: 'b', Enter: 'h', NumpadEnter: 'h', ShiftRight: 'n', Slash: 'h' };
		function keyTarget(code) { if (mode === 'tandem') { var tm = { KeyA: 'l', KeyD: 'r', Space: 'h', ArrowUp: 't', ArrowDown: 'b', ShiftRight: 'n' }; return tm[code] ? [K, tm[code]] : null; } if (DUO()) { if (KEY1[code]) return [K, KEY1[code]]; if (KEY2[code]) return [K2, KEY2[code]]; return null; } var k = KEY1[code] || KEY2[code]; if (code === 'ShiftRight') k = 'n'; return k ? [K, k] : null; }
		function stageOnScreen() { var r = stage.getBoundingClientRect(); return r.bottom > 0 && r.top < innerHeight; }
		on(d, 'keydown', function (e) { if (!game || !game.live || !stageOnScreen()) return; if (e.target && /input|select|textarea/i.test(e.target.tagName)) return; if (e.code === 'KeyC') { camNext(); return; } if ((e.code === 'Escape' || e.code === 'KeyP') && !e.repeat) { e.preventDefault(); game.pause(); return; } if (e.code === 'Backspace' && !e.repeat) { e.preventDefault(); game.reset(); return; } if (e.code === 'KeyE' && !e.repeat) { K.gu = 1; return; } if (e.code === 'KeyQ' && !e.repeat) { K.gd = 1; return; } if (mode === 'rally' && e.code === 'KeyF' && !$('[data-rl-fan]', root).hidden) { game.fanPush(); return; } if (mode === 'rally' && e.code === 'KeyR' && !$('[data-rl-rep]', root).hidden) { game.repair(); return; } var t = keyTarget(e.code); if (!t) return; if (e.target && /input|select|textarea/i.test(e.target.tagName)) return; e.preventDefault(); t[0][t[1]] = 1; });
		on(d, 'keyup', function (e) { var t = keyTarget(e.code); if (t) t[0][t[1]] = 0; if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') { K.n = 0; K2.n = 0; } });
		/* ---------- ghost challenge links (no server: the lap travels inside the link) ---------- */
		function b64u(u8) { var s = ''; for (var i = 0; i < u8.length; i++) s += String.fromCharCode(u8[i]); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); }
		function unb64u(s) { s = s.replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '='; var b = atob(s), u = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; }
		function pack(obj) { var txt = new TextEncoder().encode(JSON.stringify(obj)); if (!w.CompressionStream) return Promise.resolve('j' + b64u(txt)); return new Response(new Blob([txt]).stream().pipeThrough(new CompressionStream('deflate-raw'))).arrayBuffer().then(function (ab) { return 'z' + b64u(new Uint8Array(ab)); }); }
		function unpack(s) { var u; try { u = unb64u(s.slice(1)); if (s[0] === 'j') return Promise.resolve(JSON.parse(new TextDecoder().decode(u))); } catch (e) { return Promise.reject(e); } return new Response(new Blob([u]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).text().then(JSON.parse); }
		function myName() { try { return localStorage.getItem('psr-hl-name') || ''; } catch (e) { return ''; } }
		function challengeLink(lap) {
			var nm = (lap.nm || myName() || '').slice(0, 24); try { if (nm) localStorage.setItem('psr-hl-name', nm); } catch (e) {}
			var c = byId(+sel.value), smp = [], step = Math.max(1, Math.round(lap.rec.length / 400));
			for (var i = 0; i < lap.rec.length; i += step) { var r = lap.rec[i]; smp.push([Math.round(r[0] * 100), Math.round(r[1] * 10), Math.round(r[2] * 10), Math.round(r[3] * 100)]); }
			return pack({ v: 1, k: trk, c: c.id, b: buildOf(c), n: nm, t: Math.round(lap.t * 1000), s: smp }).then(function (code) { return location.origin + location.pathname + '#race=' + code; });
		}
		function readChallenge() {
			var m = /[#&]race=([zj][A-Za-z0-9_-]{40,})/.exec(location.hash); if (!m) return;
			unpack(m[1]).then(function (o) {
				if (!o || !TRACKS[o.k] || !o.s) return; chal = o; chal.ghost = { p: o.s.map(function (r) { return [r[0] / 100, r[1] / 10, r[2] / 10, r[3] / 100]; }), s: [] };
				setMode('tt'); setTrack(o.k); var cc = byId(o.c);
				msg.innerHTML = '<b>' + esc(o.n || 'A friend') + ' challenged you.</b><span>' + fmt(o.t / 1000) + ' on ' + TRACKS[o.k].name + (cc ? ' in a ' + esc(cname(cc)) + (buildTag(o.b || {}) ? ' (' + esc(buildTag(o.b)) + ')' : '') : '') + '. Their ghost is waiting on the grid. Pick any car and beat it.</span>';
				var wrap = root.closest('section') || root; setTimeout(function () { wrap.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, 600);
			}).catch(function () {});
		}
		readChallenge(); on(w, 'hashchange', readChallenge);
		showBest();
		/* warm up: fetch the engine and the chosen car while the visitor scrolls towards the circuit */ if ('IntersectionObserver' in w && !(navigator.connection && navigator.connection.saveData)) { var hio = new IntersectionObserver(function (es) { if (!es[0].isIntersecting) return; hio.disconnect(); load3D(function (err) { var c0 = byId(+sel.value); if (!err && c0 && c0.glb) loadModel(c0.glb, function () {}); }); }, { rootMargin: '400px' }); hio.observe(stage); }
		/* ---------- start ---------- */
		function partyNames() { var v = ($('[data-rx-namein]', root).value || '').split(/[,\n]/).map(function (x) { return x.trim().slice(0, 18); }).filter(Boolean).slice(0, 6); return v.length ? v : ['Driver 1', 'Driver 2']; }
		on($('[data-hl-go]', root), 'click', function () {
			var btn = this; btn.disabled = true; btn.textContent = 'Loading the track…';
			load3D(function (err) {
				btn.disabled = false; if (err) { btn.textContent = 'Start your engines'; return; }
				if (!game) game = build();
				if (mode === 'party' && (!party || party.done)) party = { names: partyNames(), i: 0, res: [] };
				game.start(); btn.textContent = 'Restart'; msg.hidden = true; gar.hidden = true; stage.classList.add('is-live');
				var hr = stage.getBoundingClientRect(), hvh = w.innerHeight; w.scrollBy({ top: hr.top - Math.max(160, (hvh - hr.height) / 2), behavior: 'smooth' });
			});
		});
		/* =========================== LAQIM RALLY: career, car builder, championships =========================== */
		var RLK = 'psr-rally-v1';
		var RCLS = {
			n: { n: 'Group N', sub: 'Production rally car', hp: 0, kg: 0, drive: 'stock', travel: .55, tyre: 'gravel', gears: 6, cost: 900000, tier: 0, about: 'The road car with a roll cage, rally seats, gravel tyres and longer-travel dampers. The drivetrain stays standard and the engine gets the class restrictor (320 hp at most), so a heavy luxury car stays heavy.' },
			r3: { n: 'Rally3', sub: 'Entry four-wheel drive', hp: 260, kg: 1210, drive: 'awd', travel: .42, tyre: 'gravel', gears: 5, cost: 3800000, tier: 0, about: 'A purpose-built rally car on the chosen body: 1.5-litre turbo class power, permanent four-wheel drive and a five-speed sequential box.' },
			r2: { n: 'Rally2', sub: 'The workhorse of the sport', hp: 290, kg: 1230, drive: 'awd', travel: .34, tyre: 'gravel', gears: 5, cost: 9500000, tier: 1, about: 'A 1.6-litre turbo with a restrictor, sequential gearbox, mechanical diffs and long-travel suspension. Fast, tough and fixable at the roadside.' },
			r1: { n: 'Rally1', sub: 'Hybrid top class', hp: 380, kg: 1260, drive: 'awd', travel: .3, tyre: 'gravel', gears: 5, cost: 38000000, tier: 2, boost: 1, about: 'Top-class hybrid: 380 hp from the engine plus an electric boost you deploy on the straights and recharge under braking. Needs serious money.' },
			t1: { n: 'Safari raid T1+', sub: 'Long-distance SUV', hp: 400, kg: 2000, drive: 'awd', travel: .22, tyre: 'rmud', gears: 6, cost: 6500000, tier: 0, suv: 1, about: 'Big-travel off-roader for the roughest Safari stages: 37-inch tyres, twin dampers on each corner and a tough engine. Slower on smooth roads, unbeatable on rough ones.' }
		};
		var RUP = { eng: ['Engine', ['Standard', 'Remap', 'Race internals', 'Full build'], [0, 450000, 1400000, 3200000], [1, 1.04, 1.08, 1.12]], susp: ['Suspension', ['Standard', 'Gravel dampers', 'Works dampers', 'Factory spec'], [0, 350000, 900000, 2200000], [1, .85, .72, .62]], brk: ['Brakes', ['Standard', 'Uprated', 'Works', 'Factory spec'], [0, 200000, 600000, 1300000], [1, 1.04, 1.08, 1.12]], gbx: ['Gearbox', ['Standard', 'Uprated', 'Works', 'Factory spec'], [0, 300000, 900000, 1900000], [1, .8, .65, .5]], cool: ['Cooling', ['Standard', 'Bigger radiator', 'Works', 'Factory spec'], [0, 150000, 420000, 900000], [1, .75, .55, .4]], guard: ['Underbody guard', ['None', 'Alloy', 'Kevlar', 'Works'], [0, 120000, 380000, 800000], [1, 1.5, 2.2, 3]] };
		var RTIERS = [
			{ n: 'Kenya National Rally Series', short: 'National series', entry: 80000, prize: [600000, 400000, 280000, 200000, 150000, 110000, 80000, 60000, 40000, 25000], sk: [.82, .96], stages: [3, 4], len: [1700, 2600], rep: 3,
				ev: [['Nakuru Highlands Rally', 'gravel', 'Red murram roads above Lake Nakuru'], ['Naivasha Fesh-Fesh Rally', 'fesh', 'Powder-fine volcanic dust that hides ruts and rocks'], ['Machakos Hills Rally', 'gravel', 'Crests and fast sweepers through the hills'], ['Nanyuki Forest Rally', 'forest', 'Wet forest tracks under Mount Kenya'], ['Kajiado Plains Rally', 'gravel', 'Flat-out savanna roads, one night stage'], ['Kilifi Coast Rally', 'coast', 'Sandy coast roads and a tarmac blast']] },
			{ n: 'Pan-African Rally Cup', short: 'Pan-African cup', entry: 300000, prize: [2400000, 1600000, 1100000, 800000, 600000, 450000, 320000, 240000, 160000, 100000], sk: [.88, .99], stages: [4, 5], len: [2300, 3300], rep: 6,
				ev: [['Kigali Highlands Rally', 'forest', 'Steep red-earth hill roads in Rwanda'], ['Jinja Riverlands Rally', 'gravel', 'Fast roads along the Nile in Uganda'], ['Arusha Plains Rally', 'fesh', 'Dusty plains below Mount Meru'], ['Copperbelt Rally', 'gravel', 'Rolling Zambian bush roads'], ['Lake Malawi Rally', 'coast', 'Sand and gravel along the lake shore'], ['Harare Rally', 'tarmac', 'A rare all-tarmac round'], ['Safari Classic', 'gravel', 'The Kenyan classic: rough, long and night-bound']] },
			{ n: 'World Rally Series', short: 'World series', entry: 1200000, prize: [18000000, 12000000, 8500000, 6000000, 4500000, 3400000, 2600000, 1900000, 1300000, 800000], sk: [.93, 1.02], stages: [4, 6], len: [2800, 3900], rep: 10,
				ev: [['Monte Carlo Night', 'tarmac', 'Mountain tarmac by night'], ['Sweden Forest', 'forest', 'Fast, wet forest roads'], ['Mexico Mountains', 'gravel', 'High-altitude gravel'], ['Safari Rally Kenya', 'fesh', 'Your home round: fesh-fesh, rocks and the crowds of Naivasha'], ['Portugal Gravel', 'gravel', 'Sandy pine forest gravel'], ['Sardinia Sand', 'coast', 'Narrow, sandy and rough'], ['Finland Flat-out', 'forest', 'The fastest gravel rally of all'], ['Greece Rocks', 'gravel', 'Slow, rough and car-breaking'], ['Japan Forest Tarmac', 'tarmac', 'Twisty tarmac through the cedars']] }
		];
		var RNAMES = ['Wanjiru Kamau', 'Otieno Odhiambo', 'Hamza Anwar', 'Kiprotich Kosgei', 'Amani Mwangi', 'Baraka Njoroge', 'Zawadi Achieng', 'Imran Rashid', 'Faith Chebet', 'Jomo Kariuki', 'Leila Hassan', 'Tunde Adebayo', 'Thandi Mokoena', 'Pierre Lambert', 'Ville Korhonen', 'Sofia Romano', 'Mateo Silva', 'Kenji Aoki', 'Emma Lindqvist', 'Oscar Vidal', 'Nikos Pappas', 'Ana Ferreira'];
		var RSPON = [['Kilele Coffee', 'Coffee roasters, Nyeri'], ['Upepo Solar', 'Solar power for homes and farms'], ['Mara Mobile', 'Mobile network'], ['Jambo Logistics', 'Freight across East Africa'], ['Simba Lubricants', 'Engine oils'], ['Rift Valley Tea', 'Tea growers'], ['Nyota Insurance', 'Motor insurance'], ['Tembo Tyres', 'Tyre distributor'], ['Pwani Water', 'Bottled water'], ['Safari Air', 'Charter flights']];
		var RINV = [['Harambee Ventures', 'Nairobi growth fund'], ['Savanna Capital Partners', 'Sports and media investors'], ['Kilimanjaro Holdings', 'Regional family office'], ['Indigo Motorsport Fund', 'International racing fund']];
		var ROBJ = { finish: ['Finish the rally', 1], top5: ['Finish in the top five', 1.6], podium: ['Finish on the podium', 2.4], stage: ['Win at least one stage', 2], clean: ['Finish without a retirement or major repair', 1.4] };
		function rlNew() { return { v: 1, team: 'Laqim Rally Team', money: 2500000, rep: 10, tier: 0, season: 1, round: 0, car: null, tyres: 'gravel', spares: 2, staff: { co: { n: 'Kevin Mutua', r: .45, w: 30000 }, mech: { n: 'Peter Ouma', r: .45, w: 40000 }, eng: { n: 'Grace Nduta', r: .4, w: 35000 } }, spon: [], inv: [], offers: null, pts: {}, log: [], field: null, voice: true, assists: { tc: 1, esc: 1, abs: 1, man: 0 } }; }
		function rlLoad() { try { var o = JSON.parse(localStorage.getItem(RLK) || 'null'); if (o && o.v === 1) return o; } catch (e) {} return rlNew(); }
		function rlSave() { try { localStorage.setItem(RLK, JSON.stringify(RL)); } catch (e) {} }
		var RL = rlLoad();
		function ksh(n) { return 'KSh ' + Math.round(n).toLocaleString('en-GB'); }
		function rnd(seed) { var x = Math.sin(seed * 9301 + 49297) * 233280; return x - Math.floor(x); }
		/* the field for a season: fixed names, cars and pace */
		function makeField() { var T0 = RTIERS[RL.tier], pool = cars.filter(function (c) { return c.glb; }), f = []; for (var i = 0; i < 11; i++) { var r = rnd(RL.season * 31 + RL.tier * 7 + i), c = pool[Math.floor(rnd(i * 13 + RL.season) * pool.length)]; f.push({ n: RNAMES[(i * 5 + RL.season * 3 + RL.tier * 7) % RNAMES.length], car: c ? c.id : 0, sk: T0.sk[0] + (T0.sk[1] - T0.sk[0]) * r, cons: .006 + rnd(i + 99) * .02 }); } return f; }
		/* stage generator: a star-shaped loop never crosses itself; harmonics make it twisty */
		function makeStage(ev, si) {
			var T0 = RTIERS[RL.tier], E = T0.ev[ev], kind = E[1], seed = RL.season * 1000 + RL.tier * 100 + ev * 10 + si, L = T0.len[0] + (T0.len[1] - T0.len[0]) * rnd(seed + 3), R0 = L / (2 * Math.PI) / 1.18, P = [], h = [], k;
			for (k = 2; k <= 7; k++) h.push([k, (.22 / Math.pow(k, .55)) * (.6 + rnd(seed * k) * .8), rnd(seed + k * 17) * 6.28]);
			for (var i = 0; i < 44; i++) { var th = i / 44 * Math.PI * 2, r = 1; h.forEach(function (q) { r += q[1] * Math.sin(q[0] * th + q[2]); }); r = Math.max(.45, r); P.push([Math.cos(th) * R0 * r, 110 + Math.sin(th) * R0 * r]); }
			var segs = [], base = kind === 'tarmac' ? 'tarmac' : 'dirt';
			if (kind === 'fesh') { segs.push([.12 + rnd(seed + 5) * .1, .2 + rnd(seed + 5) * .1, 'sand'], [.55 + rnd(seed + 6) * .1, .62 + rnd(seed + 6) * .1, 'sand']); }
			if (kind === 'forest') { segs.push([.3, .34 + rnd(seed + 7) * .05, 'mud'], [.7, .73, 'mud']); }
			if (kind === 'gravel' && rnd(seed + 8) > .4) segs.push([.45, .47, 'water']);
			if (kind === 'coast') { segs.push([.2, .32, 'sand'], [.6, .68, 'tarmac']); }
			if (kind === 'tarmac' && rnd(seed + 9) > .5) segs.push([.4, .46, 'dirt']);
			var night = (kind !== 'tarmac' && si === T0.stages[0] - 1 && ev % 2 === 0) || (kind === 'tarmac' && ev === 0 && RL.tier === 2);
			return { name: 'SS' + (si + 1) + ' · ' + E[0].replace(/ Rally$/, ''), surf: kind, len: (L / 1000).toFixed(1) + ' km', laps: 1, Wd: kind === 'tarmac' ? 8 : kind === 'forest' ? 7.4 : 8.2, theme: kind === 'forest' ? 'day' : 'savanna', off: kind === 'forest' ? 'grass' : 'bush', hills: true, hAmp: kind === 'forest' ? 1.4 : kind === 'coast' ? .6 : 1.1, P: P, rally: true, kind: kind, base: base, segs: segs, N: Math.round(L / 1.25), gantry: 'S S ' + (si + 1) + '   ·   ' + E[0].toUpperCase().replace(/ RALLY$/, '').split('').join(' '), dark: night, seed: seed };
		}
		function stagesOf(ev) { var T0 = RTIERS[RL.tier], n = T0.stages[0] + (ev % 2 ? 1 : 0); n = Math.min(T0.stages[1], n); var a = []; for (var i = 0; i < n; i++) a.push(makeStage(ev, i)); return a; }
		/* the rally car: body, wheelbase and weight balance from the showroom car; power, weight and running gear from the class */
		function rallyPhys(c, rc) {
			var K0 = RCLS[rc.cls] || RCLS.n, up = rc.up || {}, st = rc.set || {}, b = { engine: 'stock', tyres: RL.tyres || K0.tyre, susp: 'stock', drive: K0.drive === 'awd' ? 'awd' : 'stock', weight: 'stock', aero: 'none', nitro: K0.boost ? 'n1' : 'none' }, p = physOf(c, b);
			var hpBase = K0.hp || Math.min(c.hp, 320), hp = hpBase * RUP.eng[3][up.eng || 0], kg = K0.kg ? Math.max(K0.kg, c.kg * (isSUV(c) && !K0.suv ? .72 : .62)) : c.kg * .97;
			if (K0.suv && !isSUV(c)) kg *= 1.1; p.P = hp * 745.7 * .93; p.m = kg; p.ev = false; p.vmin = 2.5;
			var vTop = (st.gear === 0 ? 168 : st.gear === 2 ? 212 : 190) / 3.6 * (K0.hp ? 1 : Math.min(1.25, c.vmax / 200)); p.cda = p.P * .82 / (.5 * 1.2 * Math.pow(vTop * 1.06, 3)); p.veh.gears = gearsFor(vTop, K0.gears);
			p.rough = K0.travel * RUP.susp[3][up.susp || 0] * (st.spring === 0 ? .85 : st.spring === 2 ? 1.2 : 1); p.lat = st.spring === 2 ? 1.03 : st.spring === 0 ? .97 : 1;
			p.veh.hg = Math.max(.42, p.veh.hg * (K0.suv ? 1.05 : .9) + (st.ride === 2 ? .06 : st.ride === 0 ? -.04 : 0)); p.veh.Iz = p.m * (p.veh.len * p.veh.len + 3.8) / 12 * 1.02;
			if (K0.drive === 'awd') p.veh.front = st.diff == null ? .45 : st.diff; p.brk = RUP.brk[3][up.brk || 0]; p.bias = st.bias == null ? .58 : st.bias;
			p.gbxW = RUP.gbx[3][up.gbx || 0]; p.coolW = RUP.cool[3][up.cool || 0]; p.guard = RUP.guard[3][up.guard || 0]; p.nitro = !!K0.boost; p.hybrid = !!K0.boost; p.rally = 1;
			return p;
		}
		function specRows(c, rc) {
			var p = rallyPhys(c, rc), v = 0, t = 0, g = 0, tt = null; /* straight-line test with the gearbox */
			while (t < 60) { var vp = p.veh.gears[g], x = v / vp; if (x > 1.1 && g < p.veh.gears.length - 1) { g++; x = v / p.veh.gears[g]; } var f = Math.max(.5, Math.min(1, x * (2 - x))) * (x > 1.14 ? .2 : 1), tr = p.veh.front > 0 ? 1 : p.veh.a / p.veh.L, F = Math.min(Math.min(p.P * f / Math.max(v, 2.5), 1.25 * p.P / vp), 1.1 * p.m * 9.81 * tr * (p.mu.dirt || 1)) - .5 * 1.2 * p.cda * v * v - .015 * p.m * 9.81; v += F / p.m / 60; t += 1 / 60; if (tt === null && v >= 27.78) tt = t; if (F < .5) break; }
			var hp = p.P / 745.7 / .93, rpmPk = 6500, tq = p.P / .93 / (rpmPk * 2 * Math.PI / 60);
			return [['Power', Math.round(hp) + ' hp'], ['Torque', Math.round(tq * 1.25) + ' Nm'], ['Weight', Math.round(p.m) + ' kg'], ['Power to weight', Math.round(hp / p.m * 1000) + ' hp per tonne'], ['Drivetrain', p.veh.front === 0 ? 'Rear-wheel drive' : p.veh.front === 1 ? 'Front-wheel drive' : 'Four-wheel drive, ' + Math.round(p.veh.front * 100) + ':' + Math.round(100 - p.veh.front * 100) + ' torque split'], ['Weight on front axle', Math.round(p.veh.b / p.veh.L * 100) + '%'], ['Wheelbase', p.veh.L.toFixed(2) + ' m'], ['Gearbox', p.veh.gears.length + '-speed sequential'], ['0–100 km/h on gravel', tt ? tt.toFixed(1) + ' s' : '—'], ['Top speed (gearing)', Math.round(p.veh.gears[p.veh.gears.length - 1] * 3.6 * 1.06) + ' km/h'], ['Suspension', p.rough < .3 ? 'Long-travel works dampers' : p.rough < .45 ? 'Gravel rally dampers' : 'Uprated dampers with extra travel'], ['Tyres', { gravel: 'Gravel', rtarmac: 'Tarmac', rmud: 'Mud and snow' }[RL.tyres] || RL.tyres]];
		}
		/* ---------- rally hub UI ---------- */
		var rlEl = null, rlTab = 'event', EVS = null;
		function rlCar() { return RL.car ? byId(RL.car.base) : null; }
		function rlEligible() { var K0 = RL.car && RCLS[RL.car.cls]; return K0 && K0.tier <= RL.tier + (RL.car.cls === 'n' || RL.car.cls === 'r3' || RL.car.cls === 't1' ? 0 : 0) && (RL.tier === 0 || K0.tier >= RL.tier - 0 || RL.car.cls === 'r2' || RL.car.cls === 'r1'); }
		function rlTop() { var T0 = RTIERS[RL.tier], ev = T0.ev[RL.round] || null; return '<div class="rl__top"><div><small>' + esc(RL.team) + '</small><b>' + esc(T0.n) + '</b><span>Season ' + RL.season + ' · Round ' + Math.min(RL.round + 1, T0.ev.length) + ' of ' + T0.ev.length + '</span></div><div class="rl__kpi"><span><small>Budget</small><b>' + ksh(RL.money) + '</b></span><span><small>Reputation</small><b>' + Math.round(RL.rep) + '</b><i style="width:' + Math.min(100, RL.rep) + '%"></i></span><span><small>Points</small><b>' + (RL.pts.You || 0) + '</b></span></div></div>'; }
		function rlRender() {
			if (!rlEl) return; var T0 = RTIERS[RL.tier], c = rlCar(), h = rlTop();
			h += '<nav class="rl__tabs">' + [['event', 'Next rally'], ['car', 'Rally car'], ['team', 'Team & money'], ['table', 'Standings'], ['help', 'How to play']].map(function (t) { return '<button type="button" data-rl-tab="' + t[0] + '" class="' + (rlTab === t[0] ? 'is-on' : '') + '">' + t[1] + '</button>'; }).join('') + '</nav><div class="rl__body">';
			if (rlTab === 'event') {
				var ev = T0.ev[RL.round];
				if (!c) h += '<div class="rl__card rl__hero"><h3>Build your first rally car</h3><p>Every career starts small: pick a car from the collection, turn it into a Group N or Rally3 car within your ' + ksh(RL.money) + ' budget, and enter the ' + esc(T0.n) + '. Results bring prize money, reputation, sponsors and, later, investors.</p><button type="button" class="lx-btn lx-btn--gold" data-rl-go="car">Open the rally car builder</button></div>';
				else if (!ev) h += '<div class="rl__card"><h3>Season complete</h3><p>' + rlSeasonText() + '</p><button type="button" class="lx-btn lx-btn--gold" data-rl-newseason>Start the next season</button></div>';
				else { var st = stagesOf(RL.round), tot = st.reduce(function (a, s) { return a + parseFloat(s.len); }, 0);
					h += '<div class="rl__card rl__ev rl__ev--' + ev[1] + '"><small>Round ' + (RL.round + 1) + ' · ' + esc(T0.short) + '</small><h3>' + esc(ev[0]) + '</h3><p>' + esc(ev[2]) + '.</p><ol class="rl__ss">' + st.map(function (s, i) { return '<li><b>SS' + (i + 1) + '</b><span>' + s.len + ' · ' + rlSurf(s) + (s.dark ? ' · night' : '') + (i === st.length - 1 ? ' · Power Stage' : '') + '</span></li>'; }).join('') + '</ol><p class="rl__meta">' + st.length + ' stages · ' + tot.toFixed(1) + ' km · service after SS' + svcPlan(st.length).map(function (x) { return x + 1; }).join(' and SS') + ' · entry ' + ksh(T0.entry) + ' · winner earns ' + ksh(T0.prize[0]) + '</p>'
						+ '<div class="rl__pick"><label><span>Tyres</span><select data-rl-tyre>' + [['gravel', 'Gravel'], ['rtarmac', 'Tarmac'], ['rmud', 'Mud and snow']].map(function (o) { return '<option value="' + o[0] + '"' + (RL.tyres === o[0] ? ' selected' : '') + '>' + o[1] + '</option>'; }).join('') + '</select></label><label><span>Spare wheels</span><select data-rl-spares>' + [0, 1, 2].map(function (n) { return '<option' + (RL.spares === n ? ' selected' : '') + '>' + n + '</option>'; }).join('') + '</select></label><label class="rl__chk"><input type="checkbox" data-rl-voice' + (RL.voice ? ' checked' : '') + '> Co-driver voice</label></div>'
						+ '<button type="button" class="lx-btn lx-btn--gold" data-rl-enter' + (RL.money < T0.entry ? ' disabled' : '') + '>Enter the rally · ' + ksh(T0.entry) + '</button>' + (RL.money < T0.entry ? '<p class="rl__warn">Not enough budget for the entry fee. Sign a sponsor in Team & money.</p>' : '') + '</div>';
					h += '<div class="rl__card rl__mini"><h4>Your car</h4><p><b>' + esc(cname(c)) + '</b> · ' + RCLS[RL.car.cls].n + '</p><p>Tip: on fesh-fesh and forest mud, softer springs and the mud tyre help; on tarmac rounds pick tarmac tyres and stiff springs.</p></div>'; }
			} else if (rlTab === 'car') h += rlCarUI();
			else if (rlTab === 'team') h += rlTeamUI();
			else if (rlTab === 'table') h += rlTableUI();
			else h += '<div class="rl__card"><h3>How a rally works</h3><p>A rally is a set of special stages, each driven alone against the clock. Your stage times add up; the lowest total wins. Points go to the top ten (25, 18, 15, 12, 10, 8, 6, 4, 2, 1) and the fastest five on the final Power Stage earn bonus points.</p><h4>Driving</h4><p>W/S or triggers for throttle and brake, A/D or the stick to steer, Space or X for the handbrake. Q and E (or LB and RB) shift gears manually; the gearbox is automatic until you do. Shift deploys hybrid boost in a Rally1 car. C changes camera. A game controller is the best way to play.</p><h4>Breakdowns</h4><p>Hard hits damage the radiator, suspension, steering and gearbox, and rough ground causes punctures. If you are stuck or on your roof, the fans will push you out for a time penalty. Stop and press R for roadside repairs: change a wheel, tape a radiator, straighten a steering arm. Between stages you get 30 minutes of service; going over costs 10 seconds a minute.</p><h4>Career</h4><p>Results earn prize money and reputation. Reputation brings sponsors with targets, and from 35 upwards, investors. Top three in a season earns promotion to the next series, and the next class of car.</p></div>';
			h += '</div>'; rlEl.innerHTML = h; rlBind();
		}
		function rlSurf(s) { var m = { gravel: 'Gravel', fesh: 'Gravel and fesh-fesh', forest: 'Forest gravel and mud', tarmac: 'Tarmac', coast: 'Sand, gravel and tarmac' }; return m[s.kind] || 'Gravel'; }
		function svcPlan(n) { return n <= 3 ? [0] : n === 4 ? [1] : [1, 3]; }
		function rlCarUI() {
			var c = rlCar(), K0 = RL.car ? RCLS[RL.car.cls] : null, base = RL.car ? RL.car.base : (cars.filter(function (x) { return x.glb; })[0] || cars[0]).id, sel0 = RL.draft || { base: base, cls: RL.car ? RL.car.cls : 'n' };
			RL.draft = sel0; var dc = byId(sel0.base) || cars[0], K1 = RCLS[sel0.cls];
			var h = '<div class="rl__grid"><div class="rl__card"><h3>Rally car builder</h3><label class="rl__lab"><span>Base car (3D models only)</span><select data-rl-base>' + cars.filter(function (x) { return x.glb; }).map(function (x) { return '<option value="' + x.id + '"' + (x.id === sel0.base ? ' selected' : '') + '>' + esc(cname(x)) + ' · ' + x.hp + ' hp · ' + x.kg + ' kg</option>'; }).join('') + '</select></label>';
			h += '<div class="rl__cls">' + Object.keys(RCLS).map(function (k) { var q = RCLS[k], ok = !(q.suv && !isSUV(dc)); return '<button type="button" data-rl-cls="' + k + '" class="' + (sel0.cls === k ? 'is-on' : '') + '"' + (ok ? '' : ' disabled') + '><b>' + q.n + '</b><small>' + q.sub + '</small><em>' + ksh(q.cost) + '</em></button>'; }).join('') + '</div><p class="rl__about">' + esc(K1.about) + '</p>';
			var own = RL.car && RL.car.base === sel0.base && RL.car.cls === sel0.cls, cost = own ? 0 : K1.cost + (RL.car ? -Math.round(RCLS[RL.car.cls].cost * .45) : 0);
			h += own ? '<p class="rl__ok">This is your current rally car.</p>' : '<button type="button" class="lx-btn lx-btn--gold" data-rl-build' + (RL.money < cost ? ' disabled' : '') + '>' + (RL.car ? 'Rebuild (old car part-exchanged)' : 'Build it') + ' · ' + ksh(Math.max(0, cost)) + '</button>' + (RL.money < cost ? '<p class="rl__warn">Not enough budget yet.</p>' : '');
			h += '</div><div class="rl__card"><h3>Spec sheet</h3><p class="rl__sub">' + esc(cname(dc)) + ' · ' + K1.n + '</p><table class="rl__spec">' + specRows(dc, { cls: sel0.cls, up: own ? RL.car.up : {}, set: own ? RL.car.set : {} }).map(function (r) { return '<tr><th>' + r[0] + '</th><td>' + esc(r[1]) + '</td></tr>'; }).join('') + '</table></div></div>';
			if (RL.car) { var up = RL.car.up, st = RL.car.set;
				h += '<div class="rl__grid"><div class="rl__card"><h3>Upgrades</h3>' + Object.keys(RUP).map(function (k) { var u = RUP[k], lv = up[k] || 0, nx = lv + 1; return '<div class="rl__up"><span><b>' + u[0] + '</b><small>' + u[1][lv] + '</small><i>' + [0, 1, 2, 3].map(function (q) { return '<s class="' + (q <= lv ? 'is-on' : '') + '"></s>'; }).join('') + '</i></span>' + (nx < 4 ? '<button type="button" data-rl-up="' + k + '"' + (RL.money < u[2][nx] ? ' disabled' : '') + '>' + u[1][nx] + ' · ' + ksh(u[2][nx]) + '</button>' : '<em>Maxed</em>') + '</div>'; }).join('') + '</div>';
				h += '<div class="rl__card"><h3>Setup</h3><p class="rl__sub">Free to change before every rally. Your engineer explains each one.</p>' + [['gear', 'Gearing', ['Short: acceleration', 'Medium', 'Long: top speed']], ['spring', 'Springs', ['Soft: rough roads', 'Medium', 'Stiff: smooth and tarmac']], ['ride', 'Ride height', ['Low', 'Standard', 'High: rocks and ruts']]].map(function (o) { var v = st[o[0]] == null ? 1 : st[o[0]]; return '<div class="rl__set"><b>' + o[1] + '</b><span>' + o[2].map(function (t, i) { return '<button type="button" data-rl-set="' + o[0] + '" data-v="' + i + '" class="' + (v === i ? 'is-on' : '') + '">' + t + '</button>'; }).join('') + '</span></div>'; }).join('')
					+ (RCLS[RL.car.cls].drive === 'awd' ? '<div class="rl__set"><b>Centre diff (front torque)</b><input type="range" min="30" max="55" step="1" value="' + Math.round((st.diff == null ? .45 : st.diff) * 100) + '" data-rl-diff><output>' + Math.round((st.diff == null ? .45 : st.diff) * 100) + '%</output></div>' : '')
					+ '<div class="rl__set"><b>Brake bias (front)</b><input type="range" min="50" max="70" step="1" value="' + Math.round((st.bias == null ? .58 : st.bias) * 100) + '" data-rl-bias><output>' + Math.round((st.bias == null ? .58 : st.bias) * 100) + '%</output></div>'
					+ '<div class="rl__set"><b>Driving aids</b><span>' + [['tc', 'Traction control'], ['esc', 'Stability control'], ['abs', 'ABS']].map(function (a) { return '<button type="button" data-rl-aid="' + a[0] + '" class="' + (RL.assists[a[0]] ? 'is-on' : '') + '">' + a[1] + (RL.assists[a[0]] ? ' on' : ' off') + '</button>'; }).join('') + '</span></div></div></div>'; }
			return h;
		}
		function rlTeamUI() {
			var h = '<div class="rl__grid"><div class="rl__card"><h3>Team</h3>' + [['co', 'Co-driver', 'Reads the pace notes. Better co-drivers call corners earlier and never get the number wrong.'], ['mech', 'Chief mechanic', 'Faster, cheaper service-park repairs and better roadside fixes.'], ['eng', 'Engineer', 'Better setups: each level adds a little pace on every stage.']].map(function (r) { var s = RL.staff[r[0]], nx = Math.min(.98, s.r + .15), fee = Math.round((nx * nx) * 1200000); return '<div class="rl__staff"><span><b>' + r[1] + ': ' + esc(s.n) + '</b><small>' + r[2] + '</small><i style="width:' + Math.round(s.r * 100) + '%"></i></span><em>' + ksh(s.w) + ' a rally</em>' + (s.r < .95 ? '<button type="button" data-rl-hire="' + r[0] + '"' + (RL.money < fee ? ' disabled' : '') + '>Hire a better one · ' + ksh(fee) + '</button>' : '') + '</div>'; }).join('') + '</div>';
			h += '<div class="rl__card"><h3>Sponsors</h3>' + (RL.spon.length ? RL.spon.map(function (s, i) { return '<div class="rl__sp"><b>' + esc(s.n) + '</b><small>' + ksh(s.pay) + ' a rally · bonus ' + ksh(s.bonus) + ' if you ' + ROBJ[s.obj][0].toLowerCase() + ' · strikes ' + s.miss + '/3</small><button type="button" data-rl-drop="' + i + '">End deal</button></div>'; }).join('') : '<p>No sponsors yet.</p>');
			var offers = rlOffers(); h += offers.length ? '<h4>Offers</h4>' + offers.map(function (o, i) { return '<div class="rl__sp rl__sp--o"><b>' + esc(o.n) + '</b><small>' + esc(o.d) + ' · ' + ksh(o.pay) + ' a rally · bonus ' + ksh(o.bonus) + ' if you ' + ROBJ[o.obj][0].toLowerCase() + '</small>' + (RL.spon.length < 3 ? '<button type="button" data-rl-sign="' + i + '">Sign</button>' : '<em>Three slots full</em>') + '</div>'; }).join('') : '<p class="rl__sub">More sponsors come as your reputation grows.</p>';
			h += '</div></div><div class="rl__grid"><div class="rl__card"><h3>Investors</h3>' + (RL.inv.length ? RL.inv.map(function (v) { return '<div class="rl__sp"><b>' + esc(v.n) + '</b><small>Invested ' + ksh(v.amt) + ' for ' + v.eq + '% · target: finish the season top ' + v.target + ' · board confidence ' + Math.round(v.conf) + '%</small></div>'; }).join('') : '<p>No investors yet.</p>');
			var io = rlInvOffer(); h += io ? '<div class="rl__sp rl__sp--o"><b>' + esc(io.n) + '</b><small>' + esc(io.d) + ': ' + ksh(io.amt) + ' for ' + io.eq + '% of the team. Target: top ' + io.target + ' this season. Miss it and they take ' + ksh(io.amt * .3) + ' back.</small><button type="button" data-rl-invest>Accept</button></div>' : '<p class="rl__sub">' + (RL.rep < 35 ? 'Investors start calling at reputation 35.' : 'No open investor offers this round.') + '</p>';
			h += '</div><div class="rl__card"><h3>Ledger</h3><ul class="rl__log">' + (RL.log.slice(-12).reverse().map(function (l) { return '<li><span>' + esc(l[0]) + '</span><b class="' + (l[1] < 0 ? 'is-neg' : '') + '">' + (l[1] < 0 ? '−' : '+') + ksh(Math.abs(l[1])).replace('KSh ', 'KSh ') + '</b></li>'; }).join('') || '<li>Nothing yet.</li>') + '</ul><label class="rl__lab"><span>Team name</span><input type="text" maxlength="28" value="' + esc(RL.team) + '" data-rl-team></label><button type="button" class="rl__reset" data-rl-reset>Start a new career</button></div></div>';
			return h;
		}
		function rlOffers() { if (RL.offers && RL.offers.r === RL.round + RL.season * 100) return RL.offers.l; var n = 1 + Math.floor(RL.rep / 25), l = [], keys = Object.keys(ROBJ); for (var i = 0; i < n; i++) { var sp = RSPON[Math.floor(rnd(RL.season * 77 + RL.round * 13 + i) * RSPON.length)]; if (RL.spon.some(function (s) { return s.n === sp[0]; }) || l.some(function (s) { return s.n === sp[0]; })) continue; var o = keys[Math.floor(rnd(i * 3 + RL.round + RL.season) * keys.length)], base = (60000 + RL.rep * 4000) * (RL.tier ? RL.tier * 4 : 1); l.push({ n: sp[0], d: sp[1], obj: o, pay: Math.round(base / 1000) * 1000, bonus: Math.round(base * ROBJ[o][1] / 1000) * 1000 }); } RL.offers = { r: RL.round + RL.season * 100, l: l }; return l; }
		function rlInvOffer() { if (RL.rep < 35 || RL.inv.length >= 2) return null; var r = rnd(RL.season * 5 + RL.round * 11); if (r < .45) return null; var iv = RINV[Math.floor(r * 10) % RINV.length]; if (RL.inv.some(function (v) { return v.n === iv[0]; })) return null; var amt = (2500000 + RL.rep * 90000) * (RL.tier + 1) * (RL.tier === 2 ? 4 : 1); return { n: iv[0], d: iv[1], amt: Math.round(amt / 100000) * 100000, eq: Math.round(8 + r * 12), target: RL.tier === 0 ? 3 : 5, conf: 70 }; }
		function rlTableUI() { if (!RL.field) RL.field = makeField(); var all = RL.field.map(function (f) { return [f.n, RL.pts[f.n] || 0, byId(f.car)]; }); all.push(['You', RL.pts.You || 0, rlCar()]); all.sort(function (a, b) { return b[1] - a[1]; });
			return '<div class="rl__card"><h3>' + esc(RTIERS[RL.tier].n) + ' · season ' + RL.season + '</h3><table class="rl__tab"><thead><tr><th>Pos</th><th>Driver</th><th>Car</th><th>Points</th></tr></thead><tbody>' + all.map(function (r, i) { return '<tr class="' + (r[0] === 'You' ? 'is-me' : '') + '"><td>' + (i + 1) + '</td><td>' + esc(r[0] === 'You' ? RL.team : r[0]) + '</td><td>' + esc(r[2] ? cname(r[2]) : '—') + '</td><td>' + r[1] + '</td></tr>'; }).join('') + '</tbody></table>' + (RL.lastRes ? '<h4>Last rally: ' + esc(RL.lastRes.n) + '</h4><ol class="rl__res">' + RL.lastRes.l.slice(0, 10).map(function (r) { return '<li class="' + (r.me ? 'is-me' : '') + '"><b>' + esc(r.me ? RL.team : r.n) + '</b><span>' + (r.ret ? 'Rally2 restart' : fmt(r.t)) + '</span></li>'; }).join('') + '</ol>' : '') + '</div>'; }
		function rlSeasonText() { var pos = rlPos(); return 'You finished ' + ordinal(pos) + ' in the ' + RTIERS[RL.tier].n + ' with ' + (RL.pts.You || 0) + ' points. ' + (pos <= 3 && RL.tier < 2 ? 'That earns promotion to the ' + RTIERS[RL.tier + 1].n + '.' : pos <= 3 ? 'A top-three finish at world level.' : 'Finish top three to earn promotion.'); }
		function rlPos() { if (!RL.field) RL.field = makeField(); var me = RL.pts.You || 0; return 1 + RL.field.filter(function (f) { return (RL.pts[f.n] || 0) > me; }).length; }
		function ordinal(n) { return n + (n % 10 === 1 && n % 100 !== 11 ? 'st' : n % 10 === 2 && n % 100 !== 12 ? 'nd' : n % 10 === 3 && n % 100 !== 13 ? 'rd' : 'th'); }
		function money(lbl, v) { RL.money += v; RL.log.push([lbl, v]); if (RL.log.length > 80) RL.log.shift(); }
		function rlBind() {
			$$('[data-rl-tab]', rlEl).forEach(function (b) { on(b, 'click', function () { rlTab = b.getAttribute('data-rl-tab'); rlRender(); }); });
			$$('[data-rl-go]', rlEl).forEach(function (b) { on(b, 'click', function () { rlTab = b.getAttribute('data-rl-go'); rlRender(); }); });
			var q = function (s) { return $(s, rlEl); };
			if (q('[data-rl-base]')) on(q('[data-rl-base]'), 'change', function () { RL.draft.base = +this.value; var dc = byId(RL.draft.base); if (RCLS[RL.draft.cls].suv && !isSUV(dc)) RL.draft.cls = 'n'; rlRender(); });
			$$('[data-rl-cls]', rlEl).forEach(function (b) { on(b, 'click', function () { RL.draft.cls = b.getAttribute('data-rl-cls'); rlRender(); }); });
			if (q('[data-rl-build]')) on(q('[data-rl-build]'), 'click', function () { var K1 = RCLS[RL.draft.cls], cost = K1.cost + (RL.car ? -Math.round(RCLS[RL.car.cls].cost * .45) : 0); if (RL.money < cost) return; money('Built ' + K1.n + ' ' + cname(byId(RL.draft.base)), -Math.max(0, cost)); RL.car = { base: RL.draft.base, cls: RL.draft.cls, up: {}, set: {} }; RL.tyres = K1.tyre; FX.play('win'); rlSave(); rlTab = 'event'; rlRender(); });
			$$('[data-rl-up]', rlEl).forEach(function (b) { on(b, 'click', function () { var k = b.getAttribute('data-rl-up'), lv = (RL.car.up[k] || 0) + 1, c0 = RUP[k][2][lv]; if (RL.money < c0) return; money(RUP[k][0] + ': ' + RUP[k][1][lv], -c0); RL.car.up[k] = lv; FX.play('ok'); rlSave(); rlRender(); }); });
			$$('[data-rl-set]', rlEl).forEach(function (b) { on(b, 'click', function () { RL.car.set[b.getAttribute('data-rl-set')] = +b.getAttribute('data-v'); rlSave(); rlRender(); }); });
			if (q('[data-rl-diff]')) on(q('[data-rl-diff]'), 'change', function () { RL.car.set.diff = +this.value / 100; rlSave(); rlRender(); });
			if (q('[data-rl-bias]')) on(q('[data-rl-bias]'), 'change', function () { RL.car.set.bias = +this.value / 100; rlSave(); rlRender(); });
			$$('[data-rl-aid]', rlEl).forEach(function (b) { on(b, 'click', function () { var k = b.getAttribute('data-rl-aid'); RL.assists[k] = RL.assists[k] ? 0 : 1; rlSave(); rlRender(); }); });
			if (q('[data-rl-tyre]')) on(q('[data-rl-tyre]'), 'change', function () { RL.tyres = this.value; rlSave(); });
			if (q('[data-rl-spares]')) on(q('[data-rl-spares]'), 'change', function () { RL.spares = +this.value; rlSave(); });
			if (q('[data-rl-voice]')) on(q('[data-rl-voice]'), 'change', function () { RL.voice = this.checked; rlSave(); });
			$$('[data-rl-hire]', rlEl).forEach(function (b) { on(b, 'click', function () { var k = b.getAttribute('data-rl-hire'), s = RL.staff[k], nx = Math.min(.98, s.r + .15), fee = Math.round(nx * nx * 1200000); if (RL.money < fee) return; money('Hired a new ' + { co: 'co-driver', mech: 'chief mechanic', eng: 'engineer' }[k], -fee); var nm = RNAMES[Math.floor(rnd(fee) * RNAMES.length)]; RL.staff[k] = { n: nm, r: nx, w: Math.round(30000 + nx * nx * 200000) }; rlSave(); rlRender(); }); });
			$$('[data-rl-sign]', rlEl).forEach(function (b) { on(b, 'click', function () { var o = rlOffers()[+b.getAttribute('data-rl-sign')]; if (!o || RL.spon.length >= 3) return; RL.spon.push({ n: o.n, pay: o.pay, bonus: o.bonus, obj: o.obj, miss: 0 }); RL.offers.l = RL.offers.l.filter(function (x) { return x !== o; }); FX.play('win'); rlSave(); rlRender(); }); });
			$$('[data-rl-drop]', rlEl).forEach(function (b) { on(b, 'click', function () { RL.spon.splice(+b.getAttribute('data-rl-drop'), 1); rlSave(); rlRender(); }); });
			if (q('[data-rl-invest]')) on(q('[data-rl-invest]'), 'click', function () { var io = rlInvOffer(); if (!io) return; RL.inv.push(io); money('Investment from ' + io.n, io.amt); RL.equity = (RL.equity || 0) + io.eq; FX.play('win'); FX.confetti(rlEl, 120); rlSave(); rlRender(); });
			if (q('[data-rl-team]')) on(q('[data-rl-team]'), 'change', function () { RL.team = this.value.trim().slice(0, 28) || 'Laqim Rally Team'; rlSave(); rlRender(); });
			if (q('[data-rl-reset]')) on(q('[data-rl-reset]'), 'click', function () { if (this.textContent !== 'Tap again to confirm') { this.textContent = 'Tap again to confirm'; return; } RL = rlNew(); rlSave(); rlTab = 'event'; rlRender(); });
			if (q('[data-rl-newseason]')) on(q('[data-rl-newseason]'), 'click', rlNewSeason);
			if (q('[data-rl-enter]')) on(q('[data-rl-enter]'), 'click', rlEnter);
		}
		function rlNewSeason() { var pos = rlPos(); RL.inv.forEach(function (v) { if (pos > v.target) { money(v.n + ' recovered part of its investment', -Math.round(v.amt * .3)); v.conf = 0; } }); RL.inv = RL.inv.filter(function (v) { return v.conf > 0; }); if (pos <= 3 && RL.tier < 2) { RL.tier++; RL.rep += 10; } RL.season++; RL.round = 0; RL.pts = {}; RL.field = makeField(); RL.offers = null; rlSave(); rlRender(); }
		/* ---------- running an event ---------- */
		function rlEnter() {
			var T0 = RTIERS[RL.tier], c = rlCar(); if (!c || RL.money < T0.entry) return; if (!RL.field) RL.field = makeField();
			money('Entry: ' + T0.ev[RL.round][0], -T0.entry); rlSave();
			EVS = { ev: RL.round, stages: stagesOf(RL.round), si: 0, me: [], ai: RL.field.map(function () { return []; }), dmg: null, pun: [0, 0, 0, 0], spares: RL.spares, svc: svcPlan(stagesOf(RL.round).length), majors: 0, retired: 0, stageWins: 0 };
			load3D(function (err) { if (err) return; if (!game) game = build(); rlStage(); });
		}
		function rlStage() {
			var sd = EVS.stages[EVS.si], c = rlCar(), ph = rallyPhys(c, RL.car); EVS.ph = ph; msg.hidden = true; stage.classList.add('is-live');
			game.rallyIntro(sd, c, ph, { co: RL.staff.co.r, guard: ph.guard, voice: RL.voice, dmg: EVS.dmg, pun: EVS.pun, spares: EVS.spares, mech: RL.staff.mech.r, assists: RL.assists, si: EVS.si, n: EVS.stages.length, ev: RTIERS[RL.tier].ev[EVS.ev][0] }, rlStageDone);
			var hr = stage.getBoundingClientRect(); w.scrollBy({ top: hr.top - Math.max(140, (innerHeight - hr.height) / 2), behavior: 'smooth' });
		}
		function rlStageDone(res) {
			var sd = EVS.stages[EVS.si], T0 = RTIERS[RL.tier], ref = res.ref, eng = 1 - RL.staff.eng.r * .015;
			var my = res.retired ? null : res.time; EVS.dmg = res.dmg; EVS.pun = res.pun || [0, 0, 0, 0]; EVS.spares = res.spares; if (res.major) EVS.majors++;
			if (my == null) { EVS.retired = 1; my = ref * 1.6 + 300; } EVS.me.push({ t: my, ret: !!res.retired });
			RL.field.forEach(function (f, i) { var r = rnd(EVS.ev * 31 + EVS.si * 7 + i * 13 + RL.season * 101), r2 = rnd(r * 977), t = ref / f.sk * (1 + (r - .5) * 2 * f.cons) * (1 / eng); if (r2 < .07) t += 5 + r2 * 250; else if (r2 > .975) t += 40 + r2 * 40; if (r2 > .993) { t = ref * 1.6 + 300; EVS.ai[i].ret = 1; } EVS.ai[i].push(t); });
			var rows = RL.field.map(function (f, i) { return { n: f.n, t: EVS.ai[i][EVS.si], car: f.car }; }); rows.push({ n: RL.team, me: 1, t: my, ret: res.retired }); rows.sort(function (a, b) { return a.t - b.t; });
			if (rows[0].me && !res.retired) EVS.stageWins++;
			var tot = rlOverall(), pos = tot.findIndex(function (r) { return r.me; }) + 1;
			var h = '<h3>' + esc(sd.name) + (res.retired ? ': retired' : ': ' + fmt(my)) + '</h3><p>' + (res.retired ? 'You rejoin under the restart rules with a time penalty.' : 'Stage position ' + (rows.findIndex(function (r) { return r.me; }) + 1) + ' · overall ' + ordinal(pos) + (res.pen ? ' · includes ' + res.pen.toFixed(0) + ' s of penalties' : '')) + '</p><div class="rl__two"><div><h4>Stage</h4><ol class="rl__res">' + rows.slice(0, 8).map(function (r, i) { return '<li class="' + (r.me ? 'is-me' : '') + '"><b>' + esc(r.n) + '</b><span>' + fmt(r.t) + (i ? ' <em>+' + (r.t - rows[0].t).toFixed(1) + '</em>' : '') + '</span></li>'; }).join('') + '</ol></div><div><h4>Overall</h4><ol class="rl__res">' + tot.slice(0, 8).map(function (r, i) { return '<li class="' + (r.me ? 'is-me' : '') + '"><b>' + esc(r.n) + '</b><span>' + fmt(r.t) + (i ? ' <em>+' + (r.t - tot[0].t).toFixed(1) + '</em>' : '') + '</span></li>'; }).join('') + '</ol></div></div>';
			var last = EVS.si >= EVS.stages.length - 1, svc = EVS.svc.indexOf(EVS.si) >= 0 && !last;
			h += '<button type="button" class="lx-btn lx-btn--gold" data-rl-next>' + (last ? 'Final classification' : svc ? 'Go to the service park' : 'Next stage: SS' + (EVS.si + 2)) + '</button>';
			game.panel(h); FX.play(rows[0].me ? 'win' : 'ok'); if (rows[0].me) FX.confetti(stage, 120);
			on($('[data-rl-next]', stage), 'click', function () { if (last) rlFinal(); else if (svc) rlService(); else { EVS.si++; rlStage(); } });
		}
		function rlOverall() { var rows = RL.field.map(function (f, i) { return { n: f.n, t: EVS.ai[i].reduce(function (a, b) { return a + b; }, 0), ret: EVS.ai[i].ret }; }); rows.push({ n: RL.team, me: 1, t: EVS.me.reduce(function (a, b) { return a + b.t; }, 0) }); rows.sort(function (a, b) { return a.t - b.t; }); return rows; }
		/* service park: 30 minutes, choose the jobs */
		function rlService() {
			var d = EVS.dmg || { eng: 0, susp: 0, toe: 0, body: 0, rad: 0, gbx: 0 }, mf = 1.6 - RL.staff.mech.r, jobs = [];
			function job(id, n, mins, cost, need) { if (need) jobs.push({ id: id, n: n, m: Math.max(1, Math.round(mins * mf)), c: Math.round(cost * (1.3 - RL.staff.mech.r * .5)) }); }
			job('eng', 'Engine: change damaged ancillaries', 8 + d.eng * 40, 60000 + d.eng * 600000, d.eng > .05); job('rad', 'Radiator and cooling', 5 + (d.rad || 0) * 18, 40000 + (d.rad || 0) * 150000, (d.rad || 0) > .05); job('gbx', 'Gearbox', 10 + (d.gbx || 0) * 30, 80000 + (d.gbx || 0) * 500000, (d.gbx || 0) > .05); job('susp', 'Suspension arms and dampers', 6 + d.susp * 30, 50000 + d.susp * 400000, d.susp > .05); job('toe', 'Steering alignment', 4, 15000, Math.abs(d.toe) > .005); job('body', 'Bodywork and lights', 4 + d.body * 14, 20000 + d.body * 120000, d.body > .1); job('tyres', 'Fresh tyres and spares', 4, 60000, true);
			var sel = {}; jobs.forEach(function (j) { sel[j.id] = j.id !== 'body'; });
			function draw() { var used = jobs.reduce(function (a, j) { return a + (sel[j.id] ? j.m : 0); }, 0), cost = jobs.reduce(function (a, j) { return a + (sel[j.id] ? j.c : 0); }, 0), over = Math.max(0, used - 30);
				var h = '<h3>Service park · 30 minutes</h3><p>' + esc(RL.staff.mech.n) + ' and the crew are ready. Pick the jobs; every minute over 30 costs a 10-second penalty.</p><div class="rl__jobs">' + jobs.map(function (j) { return '<label class="' + (sel[j.id] ? 'is-on' : '') + '"><input type="checkbox" data-rl-job="' + j.id + '"' + (sel[j.id] ? ' checked' : '') + '><b>' + esc(j.n) + '</b><span>' + j.m + ' min · ' + ksh(j.c) + '</span></label>'; }).join('') + '</div><div class="rl__clock"><i style="width:' + Math.min(100, used / 30 * 100) + '%" class="' + (over ? 'is-over' : '') + '"></i><b>' + used + ' of 30 min' + (over ? ' · penalty ' + over * 10 + ' s' : '') + ' · ' + ksh(cost) + '</b></div><button type="button" class="lx-btn lx-btn--gold" data-rl-svc>Leave service</button>';
				game.panel(h); $$('[data-rl-job]', stage).forEach(function (b) { on(b, 'change', function () { sel[b.getAttribute('data-rl-job')] = b.checked; draw(); }); });
				on($('[data-rl-svc]', stage), 'click', function () { jobs.forEach(function (j) { if (!sel[j.id]) return; if (j.id === 'tyres') { EVS.pun = [0, 0, 0, 0]; EVS.spares = RL.spares; } else if (j.id === 'toe') d.toe = 0; else d[j.id] = 0; }); EVS.dmg = d; if (over) EVS.me[EVS.me.length - 1].t += over * 10; money('Service at ' + RTIERS[RL.tier].ev[EVS.ev][0], -cost); EVS.si++; rlStage(); }); }
			draw();
		}
		function rlFinal() {
			var T0 = RTIERS[RL.tier], tot = rlOverall(), PTS = [25, 18, 15, 12, 10, 8, 6, 4, 2, 1], pos = tot.findIndex(function (r) { return r.me; }) + 1, ls = EVS.stages.length - 1;
			var ps = RL.field.map(function (f, i) { return { n: f.n, t: EVS.ai[i][ls] }; }); ps.push({ n: 'You', t: EVS.me[ls].t, me: 1 }); ps.sort(function (a, b) { return a.t - b.t; });
			tot.forEach(function (r, i) { var k = r.me ? 'You' : r.n; RL.pts[k] = (RL.pts[k] || 0) + (PTS[i] || 0); }); ps.slice(0, 5).forEach(function (r, i) { RL.pts[r.n] = (RL.pts[r.n] || 0) + (5 - i); });
			var prize = T0.prize[pos - 1] || 0, wages = RL.staff.co.w + RL.staff.mech.w + RL.staff.eng.w, sp = [];
			if (prize) money('Prize money: ' + ordinal(pos) + ' at ' + T0.ev[EVS.ev][0], prize); money('Team wages', -wages);
			RL.spon.forEach(function (s) { money(s.n + ' sponsorship', s.pay); var ok = s.obj === 'finish' ? !EVS.retired : s.obj === 'top5' ? pos <= 5 : s.obj === 'podium' ? pos <= 3 : s.obj === 'stage' ? EVS.stageWins > 0 : !EVS.retired && EVS.majors === 0; if (ok) { money(s.n + ' bonus', s.bonus); s.miss = 0; sp.push(s.n + ': target met'); } else { s.miss++; sp.push(s.n + ': target missed (' + s.miss + '/3)'); } });
			var gone = RL.spon.filter(function (s) { return s.miss >= 3; }); RL.spon = RL.spon.filter(function (s) { return s.miss < 3; });
			RL.inv.forEach(function (v) { v.conf = Math.max(0, Math.min(100, v.conf + (pos <= v.target ? 8 : -10))); });
			RL.rep = Math.max(0, Math.min(100, RL.rep + (11 - Math.min(11, pos)) * .9 * T0.rep / 3 + EVS.stageWins * 1.5 - (EVS.retired ? 3 : 0)));
			RL.lastRes = { n: T0.ev[EVS.ev][0], l: tot.map(function (r) { return { n: r.n, t: r.t, me: r.me }; }) }; RL.round++; RL.offers = null; rlSave();
			var h = '<h3>' + esc(T0.ev[EVS.ev][0]) + ': ' + ordinal(pos) + '</h3><p>' + (pos === 1 ? 'Victory! ' : pos <= 3 ? 'A podium. ' : '') + 'Prize ' + ksh(prize) + ' · ' + (PTS[pos - 1] || 0) + ' points' + (ps.findIndex(function (r) { return r.me; }) < 5 ? ' plus ' + (5 - ps.findIndex(function (r) { return r.me; })) + ' Power Stage points' : '') + '. Reputation ' + Math.round(RL.rep) + '.</p>' + (sp.length ? '<p class="rl__sub">' + esc(sp.join(' · ')) + (gone.length ? ' · ' + gone.map(function (g) { return g.n; }).join(', ') + ' ended the deal' : '') + '</p>' : '') + '<ol class="rl__res">' + tot.slice(0, 10).map(function (r, i) { return '<li class="' + (r.me ? 'is-me' : '') + '"><b>' + (i + 1) + '. ' + esc(r.n) + '</b><span>' + fmt(r.t) + (i ? ' <em>+' + (r.t - tot[0].t).toFixed(1) + '</em>' : '') + '</span></li>'; }).join('') + '</ol><button type="button" class="lx-btn lx-btn--gold" data-rl-hub>Back to the team</button>';
			game.panel(h); FX.play(pos <= 3 ? 'win' : 'ok'); if (pos <= 3) FX.confetti(stage, 200);
			on($('[data-rl-hub]', stage), 'click', function () { game.stop(); stage.classList.remove('is-live'); msg.hidden = false; rlTab = 'event'; rlRender(); rlEl.scrollIntoView({ behavior: 'smooth', block: 'start' }); });
		}
		/* ---------- the 3D game ---------- */
		function build() {
			var T = w.THREE, cv = d.createElement('canvas'); cv.className = 'hl__cv'; stage.insertBefore(cv, stage.firstChild);
			var R = setupRenderer(cv), S = new T.Scene(); S.fog = new T.Fog(0xe8d2a2, 120, 420); S.background = new T.Color(0xe8d2a2); S.environment = studioEnv(R);
			function lin(h) { return new T.Color(h).convertSRGBToLinear(); }
			var C = new T.PerspectiveCamera(62, 2, .1, 1200), C2 = new T.PerspectiveCamera(62, 1, .1, 1200);
			var skyM = new T.ShaderMaterial({ side: T.BackSide, depthWrite: false, fog: false, uniforms: { top: { value: new T.Color(0x3d78b8) }, hor: { value: new T.Color(0xf2d9a4) }, sun: { value: new T.Vector3(.45, .22, .86).normalize() }, sk: { value: 1 } }, vertexShader: 'varying vec3 vp;void main(){vp=normalize(position);gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}', fragmentShader: 'uniform vec3 top;uniform vec3 hor;uniform vec3 sun;uniform float sk;varying vec3 vp;void main(){float h=clamp(vp.y,0.,1.);vec3 c=mix(hor,top,pow(h,.5));float s=max(dot(vp,sun),0.);c+=vec3(1.,.82,.5)*(pow(s,350.)*1.6+pow(s,8.)*.18)*sk;float st=step(.9985,fract(sin(dot(floor(vp*400.),vec3(12.9,78.2,37.7)))*43758.5))*(1.-sk)*h;gl_FragColor=vec4(c+st,1.);}' });
			var skyMesh = new T.Mesh(new T.SphereGeometry(900, 32, 16), skyM); skyMesh.renderOrder = -1; S.add(skyMesh);
			var hemi = new T.HemisphereLight(0xfff1d6, 0x4a5a36, .7), sun = new T.DirectionalLight(0xffdcaa, 1.15); sun.position.set(140, 70, 260); S.add(hemi); S.add(sun);
			var M4 = new T.Matrix4(), Q = new T.Quaternion(), col = new T.Color(), Y = new T.Vector3(0, 1, 0);
			var W = null; /* the current world: track geometry plus its scenery */
			var N = 900, pts, tang, nor, curv, kap, seg, Wd, vBase, surfAt, hAt, TVC, theme, offSurf, minX, maxX, minZ, maxZ, msc, H = function () { return 0; };
			function signTex(w2, h2, bg, fg, txt, sz) { var c3 = d.createElement('canvas'); c3.width = w2; c3.height = h2; var x3 = c3.getContext('2d'); x3.fillStyle = bg; x3.fillRect(0, 0, w2, h2); x3.fillStyle = fg; x3.fillRect(0, 0, w2, h2 * .06); x3.fillRect(0, h2 * .94, w2, h2 * .06); x3.font = '600 ' + sz + 'px Georgia, serif'; x3.textAlign = 'center'; x3.textBaseline = 'middle'; x3.fillText(txt, w2 / 2, h2 / 2 + 2); var tx3 = new T.CanvasTexture(c3); tx3.encoding = T.sRGBEncoding; tx3.anisotropy = 4; return tx3; }
			function disposeWorld() { if (!W) return; S.remove(W); W.traverse(function (o) { if (o.geometry) o.geometry.dispose(); if (o.material) (Array.isArray(o.material) ? o.material : [o.material]).forEach(function (m) { if (m.map) m.map.dispose(); m.dispose(); }); }); W = null; }
			/* ================= RALLY: stage dressing, pace notes, damage, fans, roadside repairs ================= */
			var RS = null; /* live rally-stage state */
			var ROADC = { gravel: [0xa45a2e, 0xb4703c, 0x7e4220], fesh: [0xc9b08a, 0xd8c4a0, 0xa8916a], forest: [0x5a4330, 0x6a5038, 0x3c2c1e], tarmac: [0x2e2e32, 0x6b5a42, 0x222226], coast: [0xc8a878, 0xd6bc8e, 0x9a8058] };
			function rallyRoad(tk, ribbon) {
				var rc = ROADC[tk.kind] || ROADC.gravel;
				ribbon(-Wd / 2 - 2.2, Wd / 2 + 2.2, .03, new T.MeshStandardMaterial({ color: lin(rc[1]), roughness: 1, envMapIntensity: .1 }));
				ribbon(-Wd / 2, Wd / 2, .06, new T.MeshStandardMaterial({ color: lin(rc[0]), roughness: tk.kind === 'tarmac' ? .8 : 1, envMapIntensity: .1, side: T.DoubleSide }));
				if (tk.kind === 'tarmac') { var lm = new T.MeshBasicMaterial({ color: 0xe8e2d0 }); ribbon(-.1, .1, .11, lm); }
				else [-1.9, 1.9].forEach(function (o) { ribbon(o - .4, o + .4, .11, new T.MeshStandardMaterial({ color: lin(rc[2]), roughness: 1 })); });
				/* surface patches from the stage notes: mud, sand, water */
				var runs = [], cur = null; for (var i = 0; i < N; i++) { var su = surfAt[i]; if (su !== (cur && cur[2])) { cur = [i, i, su]; runs.push(cur); } else cur[1] = i; }
				runs.forEach(function (r) {
					if (r[2] === 'mud') ribbon(-Wd / 2 + .2, Wd / 2 - .2, .16, new T.MeshStandardMaterial({ color: lin(0x3c2a1c), roughness: .35, metalness: .1 }), r[0], r[1]);
					else if (r[2] === 'sand') ribbon(-Wd / 2 - 1, Wd / 2 + 1, .16, new T.MeshStandardMaterial({ color: lin(0xe2d2b0), roughness: 1 }), r[0], r[1]);
					else if (r[2] === 'tarmac' && tk.kind !== 'tarmac') ribbon(-Wd / 2 + .1, Wd / 2 - .1, .16, new T.MeshStandardMaterial({ color: lin(0x3a3a3e), roughness: .85 }), r[0], r[1]);
					else if (r[2] === 'water') { var a0 = r[0] - 4, a1 = r[1] + 4, OF = [-Wd / 2 - 8, -Wd / 2 - 2, 0, Wd / 2 + 2, Wd / 2 + 8], AL = [0, .78, .86, .78, 0], pos = [], colr = [], idx = [], q = 0, cw = new T.Color(0x2a5263).convertSRGBToLinear();
						for (var j = a0; j <= a1; j++) { var k = (j + N) % N, p = pts[k], n = nor[k], e = Math.min(1, (j - a0) / 5, (a1 - j) / 5); OF.forEach(function (o, jj) { var x = p.x + n.x * o, z = p.z + n.z * o; pos.push(x, H(x, z) + .22, z); colr.push(cw.r, cw.g, cw.b, AL[jj] * e); }); if (j < a1) for (var jj = 0; jj < 4; jj++) { var r0 = q + jj; idx.push(r0, r0 + 5, r0 + 1, r0 + 1, r0 + 5, r0 + 6); } q += 5; }
						var g = new T.BufferGeometry(); g.setAttribute('position', new T.Float32BufferAttribute(pos, 3)); g.setAttribute('color', new T.Float32BufferAttribute(colr, 4)); g.setIndex(idx); g.computeVertexNormals();
						var wm = new T.Mesh(g, new T.MeshStandardMaterial({ vertexColors: true, transparent: true, roughness: .55, envMapIntensity: .2, depthWrite: false, side: T.DoubleSide })); wm.renderOrder = 2; W.add(wm); }
				});
				/* corners: hay bales on the outside, spectators behind tape on the slow ones */
				var corners0 = [], ii; for (ii = 0; ii < N; ii++) { var kk = kap[ii]; if (kk > 1 / 70 && kk >= kap[(ii + 1) % N] && kk >= kap[(ii - 1 + N) % N] && (!corners0.length || ii - corners0[corners0.length - 1][0] > 25)) corners0.push([ii, kk]); }
				var bales = [], fans = [], tapes = [], col0 = new T.Color();
				corners0.forEach(function (cq, ci) {
					var i0 = cq[0], t1 = tang[(i0 - 3 + N) % N], t2 = tang[(i0 + 3) % N], turn = t1.x * t2.z - t1.z * t2.x, out = turn > 0 ? -1 : 1; /* outside of the bend */
					for (var b = -6; b <= 6; b += 3) { var k2 = (i0 + b + N) % N, bx = pts[k2].x + nor[k2].x * out * (Wd / 2 + 3.2), bz = pts[k2].z + nor[k2].z * out * (Wd / 2 + 3.2); bales.push([bx, bz, Math.atan2(tang[k2].z, tang[k2].x)]); addObs(bx, bz, .95); }
					if (cq[1] > 1 / 45 || ci % 3 === 0) { var nf = 10 + (ci * 7) % 14; for (var f = 0; f < nf; f++) { var k3 = (i0 + Math.round((f - nf / 2) * 1.2) + N) % N, off = Wd / 2 + 8 + (f % 3) * 1.2 + Math.random() * .8, fx = pts[k3].x + nor[k3].x * out * off, fz = pts[k3].z + nor[k3].z * out * off; fans.push({ x: fx, z: fz, x0: fx, z0: fz, nx: nor[k3].x * out, nz: nor[k3].z * out, ph: Math.random() * 6, c: f, run: 0 }); }
						for (var tp = -10; tp <= 10; tp += 2) { var k4 = (i0 + tp + N) % N; tapes.push([pts[k4].x + nor[k4].x * out * (Wd / 2 + 6), pts[k4].z + nor[k4].z * out * (Wd / 2 + 6)]); } }
				});
				if (bales.length) { var bm = new T.InstancedMesh(new T.CylinderGeometry(.75, .75, 1.2, 10), new T.MeshStandardMaterial({ color: lin(0xd8b45a), roughness: 1 }), bales.length); bales.forEach(function (b, j) { Q.setFromAxisAngle(new T.Vector3(1, 0, 0), Math.PI / 2); var q2 = new T.Quaternion().setFromAxisAngle(Y, -b[2]); q2.multiply(Q); M4.compose(new T.Vector3(b[0], H(b[0], b[1]) + .75, b[1]), q2, new T.Vector3(1, 1, 1)); bm.setMatrixAt(j, M4); }); bm.castShadow = true; W.add(bm); }
				if (tapes.length) { var tpm = new T.InstancedMesh(new T.CylinderGeometry(.05, .05, 1.1, 5), new T.MeshStandardMaterial({ color: 0xffffff }), tapes.length); tapes.forEach(function (t, j) { M4.makeTranslation(t[0], H(t[0], t[1]) + .55, t[1]); tpm.setMatrixAt(j, M4); tpm.setColorAt(j, col0.set(j % 2 ? 0xd8262c : 0xf2f2f2)); }); W.add(tpm); }
				if (fans.length) {
					var body = new T.InstancedMesh(new T.BoxGeometry(.5, 1.05, .32), new T.MeshStandardMaterial({ roughness: .8 }), fans.length), head = new T.InstancedMesh(new T.SphereGeometry(.17, 8, 6), new T.MeshStandardMaterial({ color: lin(0x5a3a26), roughness: .8 }), fans.length), FC = [0xc8102e, 0x1e5aa8, 0xf2c200, 0x2f8a3a, 0xf2f2f2, 0x111111, 0xe0701a, 0x6a2c8a];
					fans.forEach(function (f, j) { body.setColorAt(j, col0.set(FC[(j * 5) % FC.length])); }); W.add(body); W.add(head);
					RS_FANS = { list: fans, body: body, head: head };
				} else RS_FANS = null;
				/* stage furniture: start board and km boards */
				for (var km = 1; km * 1000 < N * seg; km++) { var ik = Math.round(km * 1000 / seg) % N, side = km % 2 ? 1 : -1, bxk = pts[ik].x + nor[ik].x * side * (Wd / 2 + 2.5), bzk = pts[ik].z + nor[ik].z * side * (Wd / 2 + 2.5), brd = new T.Mesh(new T.PlaneGeometry(1.4, .9), new T.MeshBasicMaterial({ map: signTex(128, 84, '#f2c200', '#111', km + ' km', 40), side: T.DoubleSide })); brd.position.set(bxk, H(bxk, bzk) + 1.4, bzk); brd.rotation.y = -Math.atan2(tang[ik].z, tang[ik].x) + Math.PI / 2; W.add(brd); }
			}
			var RS_FANS = null;
			function fanStep(dt, now) { if (!RS_FANS) return; var L = RS_FANS.list, m4 = M4, sx = P1.s ? P1.s.x : 1e9, sz = P1.s ? P1.s.z : 1e9, sv = P1.s ? P1.s.v : 0;
				for (var j = 0; j < L.length; j++) { var f = L[j], dx = f.x - sx, dz = f.z - sz, dd = dx * dx + dz * dz; if (dd < 400 && sv > 3) f.run = 1.2; if (f.run > 0) { f.run -= dt; f.x += f.nx * dt * 6; f.z += f.nz * dt * 6; } else { f.x += (f.x0 - f.x) * dt * .5; f.z += (f.z0 - f.z) * dt * .5; }
					var jump = f.run > 0 ? 0 : Math.max(0, Math.sin(now / 160 + f.ph)) * (sv > 3 && dd < 6400 ? .35 : .05), y = H(f.x, f.z) + jump;
					m4.makeTranslation(f.x, y + .55, f.z); RS_FANS.body.setMatrixAt(j, m4); m4.makeTranslation(f.x, y + 1.25, f.z); RS_FANS.head.setMatrixAt(j, m4); }
				RS_FANS.body.instanceMatrix.needsUpdate = true; RS_FANS.head.instanceMatrix.needsUpdate = true; }
			/* pace notes from the road itself: severity 6 (near flat) to 1 (very slow), hairpins, crests and hazards */
			function makeNotes() {
				var notes = [], i = 0, sm = new Float32Array(N); for (i = 0; i < N; i++) { var a = 0; for (var j = -3; j <= 3; j++) a += kap[(i + j + N) % N]; sm[i] = a / 7; }
				var inC = false, c0 = 0, kmax = 0, imax = 0;
				for (i = 0; i < N; i++) { var on2 = sm[i] > 1 / 260; if (on2 && !inC) { inC = true; c0 = i; kmax = 0; } if (inC && sm[i] > kmax) { kmax = sm[i]; imax = i; } if (!on2 && inC) { inC = false; if ((i - c0) * seg > 8) { var t1 = tang[(c0 - 2 + N) % N], t2 = tang[(i + 2) % N], turn = t1.x * t2.z - t1.z * t2.x, R0 = 1 / kmax, sev = R0 < 16 ? 'Hairpin' : R0 < 30 ? '1' : R0 < 48 ? '2' : R0 < 72 ? '3' : R0 < 105 ? '4' : R0 < 150 ? '5' : '6'; notes.push({ i: c0, apex: imax, end: i, dir: turn > 0 ? 'Right' : 'Left', sev: sev, long: (i - c0) * seg > 70, tight: imax - c0 > (i - c0) * .6 }); } } }
				for (i = 0; i < N; i += 4) { var h0 = H(pts[i].x, pts[i].z), h1 = H(pts[(i + 8) % N].x, pts[(i + 8) % N].z), hm = H(pts[(i - 8 + N) % N].x, pts[(i - 8 + N) % N].z); if (h0 - (h1 + hm) / 2 > .55 && (!notes.length || !notes.some(function (n) { return Math.abs(n.i - i) < 25 && n.crest; }))) notes.push({ i: i, crest: 1 }); }
				var lastS = ''; for (i = 0; i < N; i += 3) { var su = surfAt[i]; if ((su === 'water' || su === 'mud' || su === 'sand') && su !== lastS) notes.push({ i: Math.max(0, i - 6), haz: su }); lastS = su; }
				notes.sort(function (a, b) { return a.i - b.i; });
				notes.forEach(function (n, k) { var nx = notes[k + 1]; n.dist = nx ? Math.round((nx.i - (n.end || n.i)) * seg / 10) * 10 : 0; n.into = nx && n.dist < 30; });
				return notes;
			}
			function noteText(n) { if (n.crest) return 'Over crest'; if (n.haz) return n.haz === 'water' ? 'Caution, water splash' : n.haz === 'mud' ? 'Caution, mud' : 'Caution, deep sand'; return (n.sev === 'Hairpin' ? 'Hairpin ' + n.dir.toLowerCase() : n.dir + ' ' + n.sev) + (n.tight ? ' tightens' : '') + (n.long ? ' long' : '') + (n.into ? ', into' : n.dist >= 60 ? ', ' + n.dist : ''); }
			var voice = null; function say(t) { if (!RS || !RS.voice || !w.speechSynthesis) return; try { if (!voice) { var vs = speechSynthesis.getVoices(); voice = vs.filter(function (v) { return /en-GB/i.test(v.lang); })[0] || vs.filter(function (v) { return /^en/i.test(v.lang); })[0] || null; } var u = new SpeechSynthesisUtterance(t); if (voice) u.voice = voice; u.rate = 1.25; u.pitch = .95; speechSynthesis.speak(u); } catch (e) {} }
			function rallyTick(dt, now) {
				if (!RS || !P1.s) return; var s = P1.s, notes = RS.notes;
				fanStep(dt, now);
				/* co-driver: read the next note early enough for the speed, later and sometimes wrong with a weaker co-driver */
				var lead = 45 + s.v * (2.6 + RS.co * 1.4), pr = s.idx > N * .8 && !s.half ? s.idx - N : s.idx; while (RS.ni < notes.length && notes[RS.ni].i < pr - 2) RS.ni++;
				var nx = notes[RS.ni]; if (nx && nx !== RS.said && (nx.i - pr) * seg < lead && nx.i >= pr) { RS.said = nx; var txt = noteText(nx); if (RS.co < .5 && Math.random() < (.5 - RS.co) * .3 && nx.sev && /\d/.test(nx.sev)) txt = txt.replace(/\d/, function (d) { return String(Math.min(6, +d + 1)); }); say(txt); RS.noteEl.innerHTML = '<b>' + esc(txt) + '</b>' + (notes[RS.ni + 1] ? '<span>then ' + esc(noteText(notes[RS.ni + 1])) + '</span>' : ''); RS.noteEl.classList.add('is-on', 'is-new'); clearTimeout(RS.nt); RS.nt = setTimeout(function () { RS.noteEl.classList.remove('is-new'); }, 900); }
				/* engine heat: a holed radiator cooks the engine */
				var d0 = s.dmg; if (d0) { var rad = d0.rad || 0; s.temp = Math.max(0, Math.min(1.3, (s.temp || 0) + dt * (rad > .25 ? (rad - .2) * .045 * (s.rpm || .5) : -.01))); if (s.temp > 1) d0.eng = Math.min(1, d0.eng + dt * .03); if (d0.eng >= .97 && !RS.dead) { RS.dead = 1; flash('Engine failure. Retired from the stage.', 4000); FX.play('lose'); setTimeout(function () { rallyRetire(); }, 2500); } }
				/* punctures from rough ground and rocks */
				if (s.v > 8 && (ROUGH[s.surf] || 0) > .3 && Math.random() < dt * Math.pow(ROUGH[s.surf] || 0, 2) * .0012 * (1 + (s.v - 8) / 20) * (s.off ? 4 : 1) / (RS.guard || 1)) puncture(s);
				/* stuck: fans can push */
				RS.stuckT = s.v < 1.2 && P1.started && !RS.paused ? RS.stuckT + dt : 0; RS.fanBtn.hidden = !(RS.stuckT > 2.5 || s.rolled);
				RS.hud(s);
			}
			function puncture(s, wi) { if (!s.pun) s.pun = [0, 0, 0, 0]; var k = wi == null ? (Math.random() * 4) | 0 : wi; if (s.pun[k]) return; s.pun[k] = 1; flash('Puncture ' + ['front left', 'front right', 'rear left', 'rear right'][k] + '!', 2600); FX.play('lose'); FX.buzz(80); }
			function fanPush() { var s = P1.s; if (!s || !RS) return; var pen = s.rolled ? 35 + Math.random() * 25 : 12 + Math.random() * 18, k = s.idx, p = pts[k]; s.x = p.x; s.z = p.z; s.h = s.va = Math.atan2(tang[k].z, tang[k].x); s.vx = s.vz = s.r = 0; s.rolled = 0; P1.H.body.rotation.x = 0; RS.pen += pen; RS.stuckT = 0; flash('The fans got you going · +' + pen.toFixed(0) + ' s', 2400); FX.play('ok'); }
			/* the stage itself: intro card, start, finish, roadside repair */
			function rallyRef(ph) { var s = spawn(N - 12, 0), t = 0, dt = 1 / 60, kk = {}, st = 0; while (t < 900) { aiDrive(s, ph, kk, .99); if (stepCar(s, ph, kk, dt)) break; t += dt; st = s.v < 1 ? st + dt : 0; if (st > 2) { var p0 = pts[s.idx]; s.x = p0.x; s.z = p0.z; s.h = s.va = Math.atan2(tang[s.idx].z, tang[s.idx].x); s.vx = s.vz = s.r = 0; st = 0; t += 15; } } return t; }
			function rallyIntro(sd, c, ph, o, done) {
				clearBots(); TRACKS.rs = sd; trk = 'rs'; world('rs'); P1.s = null; live = false; panel.hidden = true;
				var notes = makeNotes(), refC = { id: -9, make: 'Works', model: 'Benchmark', hp: 260, kg: 1210, acc: 4.4, vmax: 190, dim: [4100, 1875, 1460], drive: 'All-wheel drive', body: 'Hatchback', fuel: 'Petrol', cyl: 4 }, ref = rallyRef(rallyPhys(refC, { cls: ['r3', 'r2', 'r1'][RL.tier], up: { eng: RL.tier, susp: RL.tier + 1, brk: RL.tier }, set: {} }));
				RS = { notes: notes, ni: 0, said: null, pen: 0, ref: ref, co: o.co, guard: o.guard, voice: o.voice, spares: o.spares, mech: o.mech, onDone: done, stuckT: 0, major: 0, noteEl: $('[data-rl-note]', root), fanBtn: $('[data-rl-fan]', root), repBtn: $('[data-rl-rep]', root), dmgEl: $('[data-rl-dmgh]', root), paused: 0 };
				RS.hud = function (s) { var d = s.dmg || {}, pn = (s.pun || []).filter(Boolean).length, part = function (lbl, v) { var c2 = v > .6 ? 'is-red' : v > .25 ? 'is-amb' : v > .05 ? 'is-yel' : ''; return '<span class="' + c2 + '">' + lbl + '</span>'; };
					var html = part('ENG', d.eng || 0) + part('RAD', Math.max(d.rad || 0, (s.temp || 0) * .7)) + part('GBX', d.gbx || 0) + part('SUSP', d.susp || 0) + part('STEER', Math.abs(d.toe || 0) * 12) + '<span class="' + (pn ? 'is-red' : '') + '">TYRES ' + (pn ? pn + ' flat' : 'OK') + ' · ' + RS.spares + ' spare</span>' + (RS.pen ? '<span class="is-amb">+' + RS.pen.toFixed(0) + ' s</span>' : '') + '<em>' + Math.max(0, Math.min(100, Math.round((s.idx > N * .8 && !s.half ? 0 : s.idx) / N * 100))) + '%</em>';
					if (html !== RS.lastH) { RS.dmgEl.innerHTML = html; RS.lastH = html; } RS.repBtn.hidden = !(s.v < 1 && P1.started && (pn || (d.rad || 0) > .2 || Math.abs(d.toe || 0) > .01 || (d.gbx || 0) > .3)); };
				RS.dmgEl.hidden = false; tcOn = !!o.assists.tc; escOn = !!o.assists.esc; absOn = !!o.assists.abs;
				var sev = notes.filter(function (n) { return n.sev; }), slow = sev.filter(function (n) { return n.sev === 'Hairpin' || n.sev === '1' || n.sev === '2'; }).length;
				showPanel('<small class="rl__kick">' + esc(o.ev) + ' · stage ' + (o.si + 1) + ' of ' + o.n + '</small><h3>' + esc(sd.name) + '</h3><p>' + sd.len + ' · ' + esc({ gravel: 'gravel', fesh: 'gravel with fesh-fesh', forest: 'forest gravel and mud', tarmac: 'tarmac', coast: 'sand, gravel and tarmac' }[sd.kind]) + (sd.dark ? ' · in the dark' : '') + ' · ' + sev.length + ' corners, ' + slow + ' of them slow' + (o.si === o.n - 1 ? ' · Power Stage: bonus points for the fastest five' : '') + '</p><p class="rl__sub">' + (o.dmg && (o.dmg.eng > .1 || o.dmg.susp > .1 || (o.dmg.rad || 0) > .1) ? 'You start this stage with damage from the last one.' : 'The car is in good shape.') + ' Target time for a works driver: about ' + fmt(ref) + '.</p><button type="button" class="lx-btn lx-btn--gold" data-rl-go2>Start the stage</button>');
				on($('[data-rl-go2]', root), 'click', function () { panel.hidden = true; rallyStart(c, ph, o); });
			}
			function rallyStart(c, ph, o) {
				var K0 = RCLS[RL.car.cls], kit = { engine: 'stock', tyres: 'gravel', susp: K0.suv ? 'lift' : 'stock', drive: 'stock', weight: 'stock', aero: RL.car.cls === 'r1' || RL.car.cls === 'r2' ? 'wing' : 'none', nitro: 'none', rally: 1, num: 7 + RL.tier * 10 };
				P1.c = c; P1.b = kit; P1.p = ph; dress(P1.H, c, kit); P2.s = null; p2h.holder.visible = false; gh.visible = false;
				P1.s = spawn(N - 12, 0); P1.started = false; P1.done = false; P1.rec = []; P1.spl = []; P1.recT = 0; P1.cam = null;
				P1.s.dmg = o.dmg ? JSON.parse(JSON.stringify(o.dmg)) : null; P1.s.pun = (o.pun || [0, 0, 0, 0]).slice(); P1.s.temp = 0;
				race = { phase: 'count', t: performance.now() - lostT, laps: 1, rally: 1 }; cnt.hidden = false; board.hidden = true; $('[data-hl-pos]', root).hidden = true; $('[data-hl-prow]', root).hidden = true; $('[data-rx-drift]', root).hidden = true; $('[data-hl-lap]', root).textContent = 'SS' + (o.si + 1);
				$('[data-rx-nos]', root).hidden = !ph.nitro; root.querySelector('.rx__tn').hidden = !ph.nitro; $('[data-hl-t]', root).textContent = '0.00'; $('[data-hl-last]', root).textContent = '–'; $('[data-hl-best]', root).textContent = '–';
				headlight.visible = !!TRACKS.rs.dark; headlight2.visible = false; RS.ni = 0; RS.said = null; RS.noteEl.classList.remove('is-on'); RS.noteEl.innerHTML = ''; live = true; size();
			}
			function rallyFinish(tl) { if (!RS || RS.done) return; RS.done = 1; race.phase = 'done'; P1.done = true; flash('Stage complete · ' + fmt(tl + RS.pen), 2600); FX.play('go'); var s = P1.s, cb = RS.onDone; setTimeout(function () { live = false; cb({ time: tl + RS.pen, pen: RS.pen, dmg: s.dmg, pun: s.pun, spares: RS.spares, ref: RS.ref, major: RS.major }); }, 1600); }
			function rallyRetire() { if (!RS || RS.done) return; RS.done = 1; race.phase = 'done'; var s = P1.s, cb = RS.onDone; live = false; cb({ retired: true, dmg: { eng: .5, susp: .3, toe: 0, body: .5, rad: .3, gbx: .2 }, pun: [0, 0, 0, 0], spares: RS.spares, ref: RS.ref }); }
			function rallyRepair() {
				var s = P1.s; if (!s || !RS || s.v > 1) return; var d = s.dmg || (s.dmg = { eng: 0, susp: 0, toe: 0, body: 0 }), opts = [], mk = .5 + RS.mech * .5;
				if ((s.pun || []).some(Boolean)) opts.push(['wheel', RS.spares ? 'Change the wheel (' + RS.spares + ' spare left)' : 'No spare: drive on the flat', RS.spares ? 70 : 0, 1]);
				if ((d.rad || 0) > .2) opts.push(['rad', 'Tape up the radiator', 55, .55 + mk * .35]);
				if (Math.abs(d.toe || 0) > .01 || d.susp > .3) opts.push(['steer', 'Straighten the steering arm', 95, .4 + mk * .4]);
				if ((d.gbx || 0) > .3) opts.push(['gbx', 'Free the jammed gear selector', 45, .45 + mk * .35]);
				RS.paused = 1; showPanel('<h3>Roadside repair</h3><p>You and your co-driver have the toolkit. The clock is running.</p><div class="rl__jobs">' + opts.map(function (q, i) { return '<button type="button" data-rl-fix="' + i + '"' + (q[2] ? '' : ' disabled') + '><b>' + esc(q[1]) + '</b><span>' + (q[2] ? '~' + q[2] + ' s · ' + Math.round(q[3] * 100) + '% chance' : '') + '</span></button>'; }).join('') + '</div><button type="button" class="lx-btn" data-rl-fixx>Back to the stage</button>');
				$$('[data-rl-fix]', root).forEach(function (b) { on(b, 'click', function () { var q = opts[+b.getAttribute('data-rl-fix')], ok = Math.random() < q[3], tcost = q[2] * (.85 + Math.random() * .4); RS.pen += tcost; RS.major = 1;
					if (q[0] === 'wheel') { var k = s.pun.indexOf(1); if (k >= 0) s.pun[k] = 0; RS.spares--; }
					else if (ok) { if (q[0] === 'rad') d.rad = Math.max(0, d.rad - .45); if (q[0] === 'steer') { d.toe = 0; d.susp = Math.max(0, d.susp - .3); } if (q[0] === 'gbx') d.gbx = Math.max(0, d.gbx - .35); s.temp = Math.max(0, (s.temp || 0) - .4); }
					flash((q[0] === 'wheel' || ok ? 'Fixed' : 'It did not hold') + ' · +' + tcost.toFixed(0) + ' s', 2600); FX.play(ok ? 'ok' : 'no'); RS.paused = 0; panel.hidden = true; }); });
				on($('[data-rl-fixx]', root), 'click', function () { RS.paused = 0; panel.hidden = true; });
			}
			/* ================= PARTY MODES: keys, knockout, roulette, bomb, hot potato, past selves, champagne, speed gates ================= */
			var PM = null, pmG = new T.Group(); S.add(pmG);
			function pmClear() { pmG.children.slice().forEach(function (o) { pmG.remove(o); o.traverse && o.traverse(function (q) { if (q.geometry) q.geometry.dispose(); }); }); PM = null; $('[data-pm-hud]', root).hidden = true; }
			function pmHud(h) { var e = $('[data-pm-hud]', root); e.hidden = false; if (e.__h !== h) { e.innerHTML = h; e.__h = h; } }
			function pmEnd(h) { if (!PM || PM.over) return; PM.over = 1; race && (race.phase = 'done'); setTimeout(function () { showPanel(h + '<button type="button" class="lx-btn lx-btn--gold" data-rx-again>Play again</button>'); on($('[data-rx-again]', panel), 'click', function () { start(); }); }, 900); }
			function allCars() { var L = [{ o: P1, s: P1.s, n: 'You', me: 1 }]; if (P2.s) L.push({ o: P2, s: P2.s, n: 'Player 2', p2: 1 }); bots.forEach(function (b) { if (!b.out && !b.echo && !b.stat) L.push({ o: b, s: b.s, n: b.c.model, bot: b }); }); return L; }
			function spawnRivals(n, skill) { var rv = pickRivals(n); P1.s = spawn(N - 12 - Math.ceil(n / 2) * 9, n % 2 ? 0 : -2.6); rv.forEach(function (c, i) { var Hh = makeHolder(), b0 = buildOf(c), pb = physOf(c, b0), row = Math.floor(i / 2), sd = i % 2 ? 2.6 : -2.6; dress(Hh, c, b0); bots.push({ H: Hh, c: c, b: b0, p: pb, s: spawn(N - 12 - row * 9, n % 2 ? sd : (i % 2 ? 2.6 : -2.6) * (row === Math.ceil(n / 2) - 1 && i === n - 1 ? -1 : 1)), K: {}, skill: skill || .93 + Math.random() * .06, lane: (Math.random() - .5) * 3, done: false }); }); }
			function chase(bt, tx, tz, flee) { var s = bt.s, dx = tx - s.x, dz = tz - s.z, err = angd(Math.atan2(dz, dx), s.v > 3 ? s.va : s.h), L = bt.p.veh ? bt.p.veh.L : 2.7; bt.K.l = bt.K.r = 0; bt.K.s = null; bt.K.sa = Math.max(-.6, Math.min(.6, err * 1.3 - (s.slip || 0))); bt.K.t = Math.abs(err) > 1.4 && s.v > 14 ? .3 : 1; bt.K.b = Math.abs(err) > 1.7 && s.v > 18 ? .6 : 0; bt.K.h = 0; }
			function boom(s, H0) { for (var i = 0; i < 40; i++) puff(s.x + (Math.random() - .5) * 3, H(s.x, s.z) + .6 + Math.random() * 2, s.z + (Math.random() - .5) * 3, (Math.random() - .5) * 9, (Math.random() - .5) * 9, i % 2 ? 0xff7a1a : 0x222222); s.vx *= .2; s.vz *= .2; s.v = 0; if (H0) H0.body.rotation.x = Math.PI * .9; FX.play('lose'); FX.buzz(300); rumble(1, 600); }
			function keyMesh() { var g = new T.Group(), gm = new T.MeshStandardMaterial({ color: 0xf1d27a, metalness: .9, roughness: .25, emissive: 0x5a3a08 }); var ring = new T.Mesh(new T.TorusGeometry(.45, .12, 10, 24), gm); g.add(ring); var bar = new T.Mesh(new T.BoxGeometry(.16, 1.1, .12), gm); bar.position.y = -.85; g.add(bar); var tooth = new T.Mesh(new T.BoxGeometry(.32, .14, .12), gm); tooth.position.set(.2, -1.25, 0); g.add(tooth); var glow = new T.Mesh(new T.RingGeometry(1.6, 2.6, 32), new T.MeshBasicMaterial({ color: 0xf1d27a, transparent: true, opacity: .45, side: T.DoubleSide, depthWrite: false })); glow.rotation.x = -Math.PI / 2; glow.name = 'glow'; var G = new T.Group(); G.add(g); G.add(glow); G.key = g; return G; }
			function bombMesh() { var g = new T.Group(); var b = new T.Mesh(new T.SphereGeometry(.45, 16, 12), new T.MeshStandardMaterial({ color: 0x111114, roughness: .4, metalness: .3 })); g.add(b); var f = new T.Mesh(new T.CylinderGeometry(.05, .05, .35, 6), new T.MeshStandardMaterial({ color: 0x9a7a4a })); f.position.y = .5; g.add(f); var sp = new T.Mesh(new T.SphereGeometry(.12, 8, 6), new T.MeshBasicMaterial({ color: 0xffb020 })); sp.position.y = .7; sp.name = 'spark'; g.add(sp); return g; }
			var PMS = {
				keys: { start: function () { spawnRivals(5, .95); race = { phase: 'count', t: performance.now() - lostT, laps: 9999 }; var L = allCars(); PM.hold = {}; L.forEach(function (c) { PM.hold[c.n] = 0; }); PM.holder = L[1 + ((Math.random() * (L.length - 1)) | 0)]; PM.cool = 0; PM.left = 120; PM.mark = keyMesh(); pmG.add(PM.mark); },
					tick: function (dt) { if (race.phase !== 'run') return; var L = allCars(), hd = PM.holder; PM.left -= dt; PM.cool -= dt; PM.hold[hd.n] += dt; L.forEach(function (c) { if (!c.bot) return; if (c === hd || c.o === hd.o) { aiDrive(c.s, c.o.p, c.o.K, .97, c.o.lane); } else chase(c.o, hd.s.x + hd.s.vx * .4, hd.s.z + hd.s.vz * .4); });
						if (PM.cool <= 0) L.forEach(function (c) { if (c.o === hd.o) return; var dx = c.s.x - hd.s.x, dz = c.s.z - hd.s.z; if (dx * dx + dz * dz < 16) { var rv = Math.hypot(c.s.vx - hd.s.vx, c.s.vz - hd.s.vz); if (rv > 2.5) { PM.holder = c; PM.cool = 1.5; flash((c.me ? 'You' : c.n) + ' grabbed the keys!', 1500); say2(c.me ? 'You have the keys!' : c.n + ' has the keys!'); FX.play(c.me ? 'win' : 'tick'); } } });
						hd = PM.holder; PM.mark.position.set(hd.s.x, H(hd.s.x, hd.s.z) + 3.4, hd.s.z); PM.mark.key.rotation.y += dt * 3; PM.mark.children[1].position.y = -3.3; var me = PM.hold.You || 0; pmHud('<b>' + (hd.me ? 'You have the keys' : esc(hd.n) + ' has the keys') + '</b><span>You ' + me.toFixed(1) + ' s · ' + Math.max(0, PM.left).toFixed(0) + ' s left</span>');
						if (PM.left <= 0) { var rk = Object.keys(PM.hold).map(function (k) { return [k, PM.hold[k]]; }).sort(function (a, b) { return b[1] - a[1]; }), pos = rk.findIndex(function (r) { return r[0] === 'You'; }) + 1; say2(pos === 1 ? 'And you keep the keys! What a performance.' : 'Time! ' + rk[0][0] + ' wins the keys.'); if (pos === 1) FX.confetti(stage, 200); pmEnd('<h3>' + (pos === 1 ? 'The keys are yours.' : 'You finished ' + ordinal(pos) + '.') + '</h3><ol class="rx__pod">' + rk.slice(0, 6).map(function (r, i) { return '<li><b>' + (i + 1) + '</b>' + esc(r[0]) + '<em>' + r[1].toFixed(1) + ' s</em></li>'; }).join('') + '</ol>'); } } },
				ko: { start: function () { spawnRivals(5, .94); race = { phase: 'count', t: performance.now() - lostT, laps: 9999 }; PM.top = 0; },
					tick: function () { if (race.phase !== 'run') return; var L = allCars(), mx = 0; L.forEach(function (c) { mx = Math.max(mx, c.s.lap); }); pmHud('<b>Knockout</b><span>Lap ' + (mx + 1) + ' · ' + L.length + ' cars left · last place each lap is out</span>');
						if (mx > PM.top) { PM.top = mx; var pl = placing().filter(function (r) { return !r.done; }), last = pl[pl.length - 1]; if (!last) return; if (last.me) { say2('And you are out!'); var wn = allCars().filter(function (c) { return !c.me; })[0]; pmEnd('<h3>Knocked out.</h3><p>You went out on lap ' + mx + ', finishing ' + ordinal(L.length) + ' of ' + (bots.length + 1) + '.</p>' + betsSettle(L.length === 2 && wn ? wn.n : '')); return; } var bb = bots.filter(function (b) { return b.s === last.s; })[0]; if (bb) { bb.out = 1; bb.H.holder.visible = false; bb.s.x = 1e5; flash(bb.c.model + ' is out!', 1800); say2(bb.c.model + ' is knocked out!'); FX.play('tick'); } if (allCars().length === 1) { say2('The last car standing! You win the knockout!'); FX.confetti(stage, 220); pmEnd('<h3>Last car standing.</h3><p>You survived every knockout.</p>' + betsSettle('me')); } } } },
				roulette: { start: function () { spawnRivals(3, .94); race = { phase: 'count', t: performance.now() - lostT, laps: 4 }; PM.laps = {}; },
					tick: function () { allCars().forEach(function (c) { var k = c.n + (c.me ? '' : c.o.H.holder.id); if (PM.laps[k] == null) PM.laps[k] = c.s.lap; if (c.s.lap > PM.laps[k] && c.s.lap < 4) { PM.laps[k] = c.s.lap; var pool = cars.filter(function (x) { return x.glb; }), nc = pool[(Math.random() * pool.length) | 0]; if (c.me) { setPlayerCar(P1, nc); flash('Roulette! Now you are in a ' + cname(nc), 2200); say2('Roulette! Now you are driving the ' + nc.model + '!'); FX.play('flip'); } else if (c.bot) { var bt = c.o; bt.c = nc; bt.b = buildOf(nc); bt.p = physOf(nc, bt.b); dress(bt.H, nc, bt.b); } } }); pmHud('<b>Car roulette</b><span>Your car: ' + esc(cname(P1.c)) + '</span>'); } },
				bomb: { start: function () { PM.lim = 30; PM.t = 0; PM.low = 0; PM.mk = bombMesh(); pmG.add(PM.mk); },
					tick: function (dt) { var s = P1.s; PM.mk.position.set(s.x, H(s.x, s.z) + 2.6, s.z); var sp = PM.mk.getObjectByName('spark'); sp.scale.setScalar(.7 + Math.random() * .8); if (!P1.started) { pmHud('<b>Bomb car</b><span>Get moving: once you pass 30 km/h, never drop below the limit</span>'); return; } if (!PM.armed) { if (s.v * 3.6 > 32) { PM.armed = 1; say2('The bomb is armed! Keep your speed up!'); } else return; } PM.t += dt; PM.lim = Math.min(30 + PM.t * .7, (aiProf(P1.p)[s.idx] || 30) * 3.6 * .82 + 15, 230); var kmh = s.v * 3.6;
						if (kmh < PM.lim) { PM.low += dt; if (PM.low > .3 && !PM.warn) { PM.warn = 1; say2('Too slow! Too slow!'); } } else { PM.low = Math.max(0, PM.low - dt * 2); PM.warn = 0; }
						pmHud('<b class="' + (PM.low > 0 ? 'is-red' : '') + '">MIN ' + Math.round(PM.lim) + ' km/h</b><span>Survived ' + PM.t.toFixed(1) + ' s' + (PM.low > 0 ? ' · BOOM in ' + Math.max(0, 1.6 - PM.low).toFixed(1) + ' s' : '') + '</span><i style="width:' + Math.min(100, PM.low / 1.6 * 100) + '%"></i>');
						if (PM.low >= 1.6) { boom(s, P1.H); var bk = store('psr-pm-bomb'), kb = trk, best = !bk[kb] || PM.t > bk[kb]; if (best) { bk[kb] = PM.t; put('psr-pm-bomb', bk); } say2('Boom! You lasted ' + PM.t.toFixed(0) + ' seconds.'); pmEnd('<h3>Boom. ' + PM.t.toFixed(1) + ' seconds.</h3><p>' + (best ? 'A new record on this track.' : 'Record: ' + bk[kb].toFixed(1) + ' s.') + ' The limit had reached ' + Math.round(PM.lim) + ' km/h.</p>'); } } },
				potato: { start: function () { race = { phase: 'count', t: performance.now() - lostT, laps: 9999 }; PM.fuse = 40 + Math.random() * 15; PM.holder = Math.random() < .5 ? P1 : P2; PM.cool = 0; PM.mk = bombMesh(); pmG.add(PM.mk); },
					tick: function (dt) { if (race.phase !== 'run') return; var hd = PM.holder, ot = hd === P1 ? P2 : P1, slow = hd.s.v * 3.6 < 40; PM.fuse -= dt * (slow ? 2.5 : 1); PM.cool -= dt; PM.mk.position.set(hd.s.x, H(hd.s.x, hd.s.z) + 2.6, hd.s.z); PM.mk.getObjectByName('spark').scale.setScalar(.7 + Math.random() * .8);
						var dx = ot.s.x - hd.s.x, dz = ot.s.z - hd.s.z; if (PM.cool <= 0 && dx * dx + dz * dz < 16) { PM.holder = ot; PM.cool = 1.5; flash((ot === P1 ? 'Player 1' : 'Player 2') + ' has the bomb!', 1500); say2('Passed! ' + (ot === P1 ? 'Player one' : 'Player two') + ' has the bomb!'); FX.play('flip'); }
						pmHud('<b>' + (PM.holder === P1 ? 'Player 1' : 'Player 2') + ' has the bomb</b><span>Fuse ' + Math.max(0, PM.fuse).toFixed(1) + ' s' + (slow ? ' · burning fast: speed up!' : '') + ' · ram the other car to pass it</span>');
						if (PM.fuse <= 0) { boom(hd.s, hd.H); var win = hd === P1 ? 'Player 2' : 'Player 1'; say2('Boom! ' + win + ' wins!'); FX.confetti(stage, 160); pmEnd('<h3>' + win + ' wins.</h3><p>' + (hd === P1 ? 'Player 1' : 'Player 2') + ' was holding the bomb when it went off.</p>'); } } },
				echo: { start: function () { PM.laps = 0; PM.rec = []; PM.t0 = 0; PM.pen = 0; PM.hits = 0; PM.total = 0; },
					tick: function (dt, now) { var s = P1.s; if (!P1.started) { pmHud('<b>Past selves</b><span>Each lap you finish comes back as a car on the track. Six laps; every bump costs 2 s.</span>'); return; } if (!PM.t0) PM.t0 = now; var tl = (now - PM.t0) / 1000; if (!PM.rec.length || tl - PM.rec[PM.rec.length - 1][0] > .05) PM.rec.push([tl, s.x, s.z, s.h]);
						bots.forEach(function (b) { if (!b.echo) return; var R = b.path, i = b.pi || 0; while (i < R.length - 2 && R[i + 1][0] < tl) i++; b.pi = i; var a = R[i], c = R[Math.min(R.length - 1, i + 1)], f = c[0] > a[0] ? Math.max(0, Math.min(1, (tl - a[0]) / (c[0] - a[0]))) : 0, nx = a[1] + (c[1] - a[1]) * f, nz = a[2] + (c[2] - a[2]) * f; b.s.vx = (nx - b.s.x) / Math.max(dt, 1e-3); b.s.vz = (nz - b.s.z) / Math.max(dt, 1e-3); b.s.x = nx; b.s.z = nz; b.s.h = b.s.va = a[3] + angd(c[3], a[3]) * f; b.s.r = 0; b.s.v = Math.hypot(b.s.vx, b.s.vz); if (tl > R[R.length - 1][0]) { b.s.x = 1e5; b.H.holder.visible = false; } var hx = b.s.x - s.x, hz = b.s.z - s.z; if (hx * hx + hz * hz < 10 && (b.hitCool || 0) < now) { b.hitCool = now + 1500; PM.pen += 2; PM.hits++; flash('You hit your past self · +2 s', 1200); say2(['Ouch, you met yourself!', 'Hit your own ghost!', 'Past you was in the way!'][PM.hits % 3]); } });
						pmHud('<b>Lap ' + (PM.laps + 1) + ' of 6</b><span>' + bots.filter(function (b) { return b.echo; }).length + ' past selves on track · penalties ' + PM.pen + ' s</span>'); },
					lap: function (P, tl, now) { PM.laps++; PM.total += tl; var R = PM.rec.slice(); PM.rec = []; PM.t0 = now; bots.forEach(function (b) { if (b.echo) { b.pi = 0; b.H.holder.visible = true; } }); if (PM.laps >= 6) { var tot = PM.total + PM.pen, bk = store('psr-pm-echo'), kb = trk + ':' + P1.c.id, best = !bk[kb] || tot < bk[kb]; if (best) { bk[kb] = tot; put('psr-pm-echo', bk); } say2('Six laps! You survived yourself.'); FX.confetti(stage, 160); pmEnd('<h3>' + fmt(tot) + '</h3><p>Six laps with ' + PM.hits + ' run-ins with your past selves (+' + PM.pen + ' s).' + (best ? ' New record.' : '') + '</p>'); return true; }
						var Hh = makeHolder(); dress(Hh, P1.c, P1.b); var es = spawn(N - 12, 0); es.m = 1e6; es.Iz = 1e8; es.hl = P1.s.hl; es.hw = P1.s.hw; es.vx = es.vz = es.r = 0; bots.push({ H: Hh, c: P1.c, b: P1.b, p: P1.p, s: es, K: {}, echo: 1, path: R, pi: 0 }); flash('Lap ' + PM.laps + ' · another you joins the track', 1600); say2(['And here comes you, again.', 'Another you on track!', 'Watch out, it is you!'][PM.laps % 3]); return true; } },
				champagne: { start: function () { var g = new T.Group(), gm = new T.MeshStandardMaterial({ color: 0xf6e7b0, transparent: true, opacity: .75, metalness: .1, roughness: .1 }), cnt = 0, bx = P1.H.box, top = bx ? bx.max.y : 1.3; PM.gl = [];
						[[4, 0], [3, 1], [2, 2], [1, 3]].forEach(function (row) { for (var i = 0; i < row[0]; i++) for (var j = 0; j < row[0]; j++) { if (row[0] > 1 && (i > 0 && i < row[0] - 1 && j > 0 && j < row[0] - 1)) continue; var gl = new T.Mesh(new T.CylinderGeometry(.12, .06, .34, 8), gm); gl.position.set((i - (row[0] - 1) / 2) * .28, top + .18 + row[1] * .35, (j - (row[0] - 1) / 2) * .28); g.add(gl); PM.gl.push(gl); cnt++; } });
						PM.tower = g; P1.H.body.add(g); PM.n0 = PM.gl.length; PM.slosh = 0; PM.fall = []; },
					tick: function (dt) { var s = P1.s, a = Math.hypot(s.ax || 0, s.ay || 0) / 9.81 + (ROUGH[s.surf] || 0) * s.v * .004, j = Math.abs((a - (PM.la || 0)) / Math.max(dt, 1e-3)); PM.la = a; PM.slosh += Math.max(0, a - .42) * dt * 2.4 + Math.max(0, j - 6) * dt * .03 + (s.hit > .05 ? s.hit * dt * 30 : 0); PM.tower.rotation.z = -(s.ax || 0) * .012; PM.tower.rotation.x = (s.ay || 0) * .014;
						while (PM.slosh > 1 && PM.gl.length) { PM.slosh -= 1; var gl = PM.gl.pop(), wp = new T.Vector3(); gl.getWorldPosition(wp); PM.tower.remove(gl); gl.position.copy(wp); pmG.add(gl); PM.fall.push({ m: gl, vx: s.vx * .8 + (Math.random() - .5) * 3, vy: 2, vz: s.vz * .8 + (Math.random() - .5) * 3, t: 0 }); FX.play('tick'); if (PM.gl.length % 3 === 0) say2(['There goes a glass!', 'Careful with the champagne!', 'Oh, that was expensive!', 'Mind the glasses!'][PM.gl.length % 4]); }
						PM.fall.forEach(function (f) { f.t += dt; f.vy -= 9.81 * dt; f.m.position.x += f.vx * dt; f.m.position.y += f.vy * dt; f.m.position.z += f.vz * dt; f.m.rotation.x += dt * 8; if (f.m.position.y < H(f.m.position.x, f.m.position.z)) { f.m.visible = false; } });
						pmHud('<b>Champagne: ' + PM.gl.length + ' of ' + PM.n0 + ' glasses</b><span>Smooth hands. Hard corners, braking and bumps spill them.</span><i style="width:' + Math.min(100, PM.slosh * 100) + '%"></i>');
						if (!PM.gl.length) { say2('Every glass is gone. The client is not impressed.'); pmEnd('<h3>Delivery failed.</h3><p>Every glass came off the roof.</p>'); } },
					lap: function (P, tl) { var left = PM.gl.length, sc = left * 1000 + Math.max(0, 150 - tl) * 20, bk = store('psr-pm-champ'), kb = trk, best = !bk[kb] || sc > bk[kb]; if (best) { bk[kb] = sc; put('psr-pm-champ', bk); } say2(left === PM.n0 ? 'Not a drop spilt! The client is delighted.' : left + ' glasses delivered.'); if (left > PM.n0 * .7) FX.confetti(stage, 160); pmEnd('<h3>' + left + ' of ' + PM.n0 + ' glasses delivered</h3><p>' + fmt(tl) + ' · score ' + Math.round(sc).toLocaleString('en-GB') + (best ? ' · new record' : '') + '</p>'); return true; } },
				gate: { start: function () { PM.g = []; PM.sc = 0; PM.ni = 0; var prof = aiProf(P1.p), nG = 6; for (var i = 0; i < nG; i++) { var gi = Math.floor((i + .6) / nG * N) % N, tgt = Math.round(prof[gi] * 3.6 * (.55 + Math.random() * .35) / 5) * 5; tgt = Math.max(40, tgt); var g = new T.Group(), pm = new T.MeshStandardMaterial({ color: 0xd9a93f, metalness: .6, roughness: .3 }); [-1, 1].forEach(function (sd) { var p0 = new T.Mesh(new T.BoxGeometry(.3, 4.2, .3), pm); p0.position.set(0, 2.1, sd * (Wd / 2 + .6)); g.add(p0); }); var sg = new T.Mesh(new T.PlaneGeometry(Wd + 1.6, 1.4), new T.MeshBasicMaterial({ map: signTex(512, 96, '#0d0d10', '#f1d27a', tgt + ' km/h', 60), side: T.DoubleSide })); sg.position.set(0, 4.6, 0); sg.rotation.y = Math.PI / 2; g.add(sg); g.position.set(pts[gi].x, H(pts[gi].x, pts[gi].z), pts[gi].z); g.rotation.y = -Math.atan2(tang[gi].z, tang[gi].x); pmG.add(g); PM.g.push({ i: gi, t: tgt }); } },
					tick: function () { var s = P1.s, g = PM.g[PM.ni]; if (!g) return; var pr = s.idx > N * .8 && !s.half ? s.idx - N : s.idx; if (pr >= g.i && pr < g.i + 30) { var kmh = s.v * 3.6, d = Math.abs(kmh - g.t), pts0 = Math.max(0, Math.round(100 - d * 10)) + (d < 1 ? 50 : 0); PM.sc += pts0; PM.ni++; flash((d < 1 ? 'PERFECT! ' : '') + Math.round(kmh) + ' km/h for ' + g.t + ' · +' + pts0, 1600); FX.play(d < 1 ? 'win' : d < 5 ? 'ok' : 'no'); if (d < 1) say2(['Perfect! Right on the number!', 'Bang on!', 'Exactly ' + g.t + '!'][PM.ni % 3]); } pmHud('<b>Next gate: ' + (PM.g[PM.ni] ? PM.g[PM.ni].t + ' km/h' : 'finish') + '</b><span>Score ' + PM.sc + ' · gate ' + Math.min(PM.ni + 1, PM.g.length) + ' of ' + PM.g.length + '</span>'); },
					lap: function (P, tl) { var bk = store('psr-pm-gate'), kb = trk, best = !bk[kb] || PM.sc > bk[kb]; if (best) { bk[kb] = PM.sc; put('psr-pm-gate', bk); } if (PM.sc >= 600) FX.confetti(stage, 160); say2(PM.sc >= 700 ? 'Incredible precision!' : 'Gates complete.'); pmEnd('<h3>' + PM.sc + ' points</h3><p>Six speed gates; 150 is the maximum for each.' + (best ? ' New record.' : ' Record: ' + bk[kb] + '.') + '</p>'); return true; } }
			};
			/* ---------- batch 2: passengers, pursuits, tailing, tandem, voice ---------- */
			function gNow(s) { return Math.hypot(s.ax || 0, s.ay || 0) / 9.81; }
			function nearEdge(s) { var p0 = pts[s.idx], n0 = nor[s.idx], lat = Math.abs((s.x - p0.x) * n0.x + (s.z - p0.z) * n0.z); return lat > Wd / 2 - .6; }
			function lineOf(arr, k) { return arr[(k + (Math.random() * arr.length) | 0) % arr.length]; }
			function passenger(cfg) { return {
				start: function () { PM.m = cfg.m0; PM.sc = 0; PM.lt = 0; PM.ln = ''; PM.cn = 0; },
				tick: function (dt, now) { var s = P1.s; if (!P1.started) { pmHud('<b>' + cfg.title + '</b><span>' + cfg.intro + '</span>'); return; } var kmh = s.v * 3.6, g = gNow(s), ev = cfg.ev(s, kmh, g, dt); PM.m = Math.max(0, Math.min(100, PM.m + ev.dm)); PM.sc += ev.sc || 0;
					if (now - PM.lt > 3800) { var ln = cfg.line(PM.m, ev); if (ln) { PM.lt = now; say2(ln, true); PM.ln = ln; } }
					pmHud('<b>' + cfg.meter + ' ' + Math.round(PM.m) + '%</b><span>' + (PM.ln ? '“' + esc(PM.ln) + '”' : cfg.intro) + ' · score ' + Math.round(PM.sc) + '</span><i style="width:' + PM.m + '%;background:' + cfg.col + '"></i>');
					if (cfg.fail(PM.m)) { boom2(); var t = cfg.failTxt; say2(cfg.failSay, true); pmEnd('<h3>' + t + '</h3><p>Score ' + Math.round(PM.sc) + '.</p>'); } },
				lap: function (P, tl) { var sc = Math.round(cfg.final(PM.sc, PM.m, tl)), k = 'psr-pm-' + cfg.id, bk = store(k), kb = trk + ':' + P1.c.id, best = !bk[kb] || sc > bk[kb]; if (best) { bk[kb] = sc; put(k, bk); } say2(cfg.winSay(PM.m), true); if (sc > 0) FX.confetti(stage, 140); pmEnd('<h3>' + cfg.winTxt(PM.m) + '</h3><p>Score ' + sc.toLocaleString('en-GB') + ' · ' + fmt(tl) + (best ? ' · new record' : '') + '</p>'); return true; } }; }
			function boom2() { FX.play('lose'); FX.buzz(200); }
			PMS.salesman = passenger({ id: 'salesman', title: 'Scare the salesman', intro: 'He is in the passenger seat. Thrill him, but do not make him faint.', meter: 'Panic', col: '#ff5a4a', m0: 10,
				ev: function (s, kmh, g, dt) { var dm = -dt * 6; if (kmh > 120) dm += (kmh - 120) * dt * .09; if (g > .7) dm += (g - .7) * dt * 40; if (Math.abs(s.slip || 0) > .2) dm += dt * 18; if (nearEdge(s) && kmh > 80) dm += dt * 12; if (s.hit > .1) dm += 25 * s.hit; return { dm: dm, sc: PM.m > 35 && PM.m < 92 ? PM.m * dt * (kmh / 100) : 0 }; },
				line: function (m) { return m > 85 ? lineOf(['Oh God, oh God, oh God!', 'Please! This car is on consignment!', 'I have a family!', 'Stop! STOP!'], 1) : m > 60 ? lineOf(['Er, the brakes are on the left. I mean, the middle!', 'That was a wall. That was very close to a wall.', 'Is this how you drive at home?', 'My manager is going to kill me.'], 2) : m > 35 ? lineOf(['She pulls well, doesn’t she? Ha. Ha.', 'Perhaps a little slower round here?', 'The test drive route is usually... gentler.'], 3) : lineOf(['Lovely and smooth. You could go a bit quicker, sir.', 'Nice car, isn’t it? Finance is available.', 'Feel that leather.'], 4); },
				fail: function (m) { return m >= 100; }, failTxt: 'He fainted.', failSay: 'And the salesman has fainted. That is a no sale.',
				final: function (sc, m) { return sc + (m < 100 ? 500 : 0); }, winTxt: function (m) { return m > 60 ? 'He is shaking, but he signed the paperwork.' : 'Back at the showroom. He is still smiling.'; }, winSay: function (m) { return m > 60 ? 'He survived! Barely.' : 'A calm test drive. Perhaps too calm.'; } });
			PMS.sleeper = passenger({ id: 'sleeper', title: 'Sleeping billionaire', intro: 'Drive him home without waking him. Bumps, jolts and hard braking disturb him.', meter: 'Asleep', col: '#5a8cff', m0: 100,
				ev: function (s, kmh, g, dt) { var dm = dt * 1.5, j = Math.abs(g - (PM.lg || 0)) / Math.max(dt, 1e-3); PM.lg = g; if (g > .38) dm -= (g - .38) * dt * 40; if (j > 4) dm -= (j - 4) * dt * .5; dm -= (ROUGH[s.surf] || 0) * kmh * dt * .15; if (s.hit > .05) dm -= 40 * s.hit; return { dm: dm, sc: dt * 10 * (PM.m / 100) }; },
				line: function (m) { return m < 25 ? lineOf(['Mmm? Are we there yet?', 'Who is driving this car?', 'Hmph. Driver!'], 1) : m < 60 ? lineOf(['Mmm... Monaco... no...', 'Sell... the... yacht...', 'Zzz... more caviar...'], 2) : null; },
				fail: function (m) { return m <= 0; }, failTxt: 'He woke up.', failSay: 'He is awake. And he is not happy. You are fired.',
				final: function (sc, m, tl) { return m * 30 + Math.max(0, 200 - tl) * 10; }, winTxt: function (m) { return m > 80 ? 'Home, and he never stirred.' : 'Home. He grumbled, but he tipped.'; }, winSay: function (m) { return m > 80 ? 'Not a stir. Five stars.' : 'Home safely, if a little bumpy.'; } });
			PMS.kid = passenger({ id: 'kid', title: 'Thrill-seeker kid', intro: 'The boss’s kid wants excitement. Speed, slides and close calls keep them happy.', meter: 'Bored', col: '#f1d27a', m0: 30,
				ev: function (s, kmh, g, dt) { var dm = dt * 9, sc = 0; if (kmh > 140) { dm -= (kmh - 140) * dt * .12; sc += dt * (kmh - 140) * .3; } if (Math.abs(s.slip || 0) > .18) { dm -= dt * 30; sc += dt * 40; } if (g > .9) { dm -= dt * 10; sc += dt * 10; } if (nearEdge(s) && kmh > 90) { dm -= dt * 12; sc += dt * 15; } if (s.boost) { dm -= dt * 20; sc += dt * 20; } return { dm: dm, sc: sc }; },
				line: function (m) { return m > 75 ? lineOf(['Boooring!', 'My gran drives faster than this.', 'Are we there yet? This is so dull.'], 1) : m > 40 ? lineOf(['Faster! Go faster!', 'Do a skid! Do a skid!', 'Use the nitro thing!'], 2) : lineOf(['Wheeee!', 'Again! Again!', 'This is the best day ever!', 'Sideways! Yes!'], 3); },
				fail: function (m) { return m >= 100; }, failTxt: 'The kid fell asleep from boredom.', failSay: 'And the kid is asleep. You have failed the coolest-driver test.',
				final: function (sc) { return sc; }, winTxt: function (m) { return m < 30 ? 'The kid wants to do it again.' : 'The kid says it was "fine".'; }, winSay: function (m) { return m < 30 ? 'Best day of their life!' : 'Mild approval.'; } });
			/* instructor: grades every corner */
			PMS.instructor = { start: function () { PM.cs = []; var sm = 0, inC = false, c0 = 0; for (var i = 0; i < N; i++) { var on2 = kap[i] > 1 / 90; if (on2 && !inC) { inC = true; c0 = i; } if (!on2 && inC) { inC = false; if (i - c0 > 6) PM.cs.push({ a: c0, b: i, min: 1e9, off: 0, hit: 0 }); } } PM.ci = 0; PM.grades = []; PM.prof = aiProf(P1.p); PM.lt = 0; },
				tick: function (dt, now) { var s = P1.s; if (!P1.started) { pmHud('<b>Grumpy instructor</b><span>Every corner gets a grade. Do try to impress him.</span>'); return; } var c = PM.cs[PM.ci]; if (!c) return; var pr = s.idx > N * .8 && !s.half ? s.idx - N : s.idx; if (pr >= c.a && pr <= c.b) { c.min = Math.min(c.min, s.v); if (s.off) c.off = 1; if (s.hit > .05) c.hit = 1; c.in = 1; }
					if (c.in && pr > c.b) { var tgt = Infinity; for (var k = c.a; k <= c.b; k++) tgt = Math.min(tgt, PM.prof[k]); var r = c.min / tgt, gr = c.hit ? 'F' : c.off ? 'D' : r > .97 ? 'A' : r > .9 ? 'B' : r > .8 ? 'C' : 'D'; PM.grades.push(gr); var ln = c.hit ? lineOf(['You hit it. You actually hit it.', 'I am writing that one down in red.'], 1) : c.off ? lineOf(['That was not the road.', 'The track is the grey bit.'], 2) : gr === 'A' ? lineOf(['Hm. Acceptable.', 'Fine. That was... fine.', 'I suppose that was competent.'], 3) : gr === 'B' ? lineOf(['Late on the throttle.', 'You lifted. Why did you lift?'], 4) : lineOf(['My grandmother corners faster.', 'Were you looking at the scenery?', 'Brake earlier, carry more speed. Basic stuff.'], 5); say2(ln, true); flash('Corner ' + (PM.ci + 1) + ': ' + gr, 1400); PM.ci++; }
					pmHud('<b>Corner ' + Math.min(PM.ci + 1, PM.cs.length) + ' of ' + PM.cs.length + '</b><span>Grades: ' + (PM.grades.join(' ') || '—') + '</span>'); },
				lap: function (P, tl) { var pts0 = { A: 4, B: 3, C: 2, D: 1, F: 0 }, avg = PM.grades.length ? PM.grades.reduce(function (a, g) { return a + pts0[g]; }, 0) / PM.grades.length : 0, fin = avg > 3.6 ? 'A' : avg > 2.8 ? 'B' : avg > 2 ? 'C' : avg > 1.2 ? 'D' : 'F'; say2(fin === 'A' ? 'An A. Do not let it go to your head.' : fin === 'F' ? 'An F. Please never drive again.' : 'A ' + fin + '. Must try harder.', true); if (fin === 'A') FX.confetti(stage, 140); var bk = store('psr-pm-instr'), kb = trk + ':' + P1.c.id; if (!bk[kb] || avg > bk[kb]) { bk[kb] = avg; put('psr-pm-instr', bk); }
					pmEnd('<h3>Report card: ' + fin + '</h3><p>' + PM.grades.map(function (g, i) { return 'C' + (i + 1) + ' ' + g; }).join(' · ') + '</p><p>Lap ' + fmt(tl) + '.</p>'); return true; } };
			/* getaway: pursuit cars try to box you in */
			function lightBar(Hh) { var g = new T.Group(), r = new T.Mesh(new T.BoxGeometry(.25, .12, .5), new T.MeshBasicMaterial({ color: 0xff2020 })), b = new T.Mesh(new T.BoxGeometry(.25, .12, .5), new T.MeshBasicMaterial({ color: 0x2060ff })); r.position.z = .3; b.position.z = -.3; g.add(r); g.add(b); g.position.y = (Hh.box ? Hh.box.max.y : 1.4) + .1; Hh.kit.add(g); return g; }
			PMS.getaway = { start: function () { var pool = cars.filter(function (c) { return c.glb && isSUV(c); }); if (!pool.length) pool = cars.filter(isSUV); if (!pool.length) pool = cars; var n = 4; PM.bust = 0; PM.t = 0; PM.far = 0; PM.bars = []; for (var i = 0; i < n; i++) { var c = pool[(Math.random() * pool.length) | 0] || cars[0], Hh = makeHolder(), b0 = buildOf(c), pb = physOf(c, b0); pb.P *= 1.15; dress(Hh, c, b0); var bt = { H: Hh, c: c, b: b0, p: pb, s: spawn((N - 60 - i * 10 + N) % N, (i % 2 ? 2 : -2)), K: {}, skill: 1, lane: 0 }; bots.push(bt); PM.bars.push(Hh); } PM.ctrl = 1; },
				tick: function (dt, now) { var s = P1.s; PM.bars.forEach(function (Hh, i) { var lb = Hh.kit.children[Hh.kit.children.length - 1]; if (!Hh.lb && Hh.box) { Hh.lb = lightBar(Hh); } if (Hh.lb) { var f = ((now / 140) | 0) % 2; Hh.lb.children[0].visible = !!f; Hh.lb.children[1].visible = !f; } }); if (!P1.started) { pmHud('<b>Getaway</b><span>Four pursuit cars are coming. Survive 90 seconds or lose them all.</span>'); bots.forEach(function (b) { b.K.t = 0; b.K.b = 1; }); return; }
					PM.t += dt; var close = 0, far = true; bots.forEach(function (b) { var dx = b.s.x - s.x, dz = b.s.z - s.z, d = Math.hypot(dx, dz); if (d < 9) close++; if (d < 140) far = false; if (d > 60) aiDrive(b.s, b.p, b.K, 1.05, 0); else chase(b, s.x + s.vx * .5, s.z + s.vz * .5); });
					if (close >= 2 || (close && s.v < 8)) PM.bust += dt * (close >= 2 ? 30 : 18); else PM.bust = Math.max(0, PM.bust - dt * 8); PM.far = far ? PM.far + dt : 0;
					pmHud('<b class="' + (PM.bust > 50 ? 'is-red' : '') + '">' + (close ? 'They are on you!' : 'Keep running') + '</b><span>' + Math.max(0, 90 - PM.t).toFixed(0) + ' s to survive' + (PM.far > 0 ? ' · lost them for ' + PM.far.toFixed(0) + ' of 8 s' : '') + '</span><i style="width:' + PM.bust + '%"></i>');
					if (PM.bust >= 100) { say2('Boxed in! Busted!', true); boom2(); pmEnd('<h3>Boxed in.</h3><p>They caught you after ' + PM.t.toFixed(1) + ' s.</p>'); } else if (PM.t >= 90 || PM.far >= 8) { say2(PM.far >= 8 ? 'Gone! You lost them completely!' : 'Ninety seconds! You got away!', true); FX.confetti(stage, 180); var k = store('psr-pm-getaway'), kb = trk; k[kb] = (k[kb] || 0) + 1; put('psr-pm-getaway', k); pmEnd('<h3>You got away.</h3><p>' + (PM.far >= 8 ? 'You lost all four pursuers in ' + PM.t.toFixed(1) + ' s.' : 'Ninety seconds without being boxed in.') + ' Escapes on this track: ' + k[kb] + '.</p>'); } } };
			/* paparazzi: scooters chase and photograph your celebrity passenger */
			function scooterMesh() { var g = new T.Group(), bm = new T.MeshStandardMaterial({ color: [0xe8e2d6, 0x1b1c20, 0xc8102e, 0x2f8a3a][(Math.random() * 4) | 0], roughness: .5 }), dk = new T.MeshStandardMaterial({ color: 0x111114 }); var bd = new T.Mesh(new T.BoxGeometry(1.5, .45, .45), bm); bd.position.y = .55; g.add(bd); [.6, -.6].forEach(function (x) { var wh = new T.Mesh(new T.CylinderGeometry(.28, .28, .14, 12), dk); wh.rotation.x = Math.PI / 2; wh.position.set(x, .28, 0); g.add(wh); }); var rider = new T.Mesh(new T.BoxGeometry(.35, .7, .4), dk); rider.position.set(-.1, 1.05, 0); g.add(rider); var head = new T.Mesh(new T.SphereGeometry(.18, 8, 6), new T.MeshStandardMaterial({ color: 0x222222 })); head.position.set(-.05, 1.55, 0); g.add(head); var cam = new T.Mesh(new T.BoxGeometry(.18, .14, .14), dk); cam.position.set(.25, 1.25, .18); g.add(cam); return g; }
			PMS.papz = { start: function () { PM.ph = 0; PM.ctrl = 1; PM.flashT = 0; for (var i = 0; i < 5; i++) { var Hh = makeHolder(), m = scooterMesh(); Hh.body.add(m); Hh.model = m; Hh.box = new T.Box3().setFromObject(m); var pb = { m: 180, P: 42000, cda: .55, mu: { tarmac: 1.15, dirt: 1, mud: .7, water: .6, grass: .9, bush: .8, sand: .8 }, lat: 1.05, rough: .6, ride: 0, drv: .6, down: 0, nitro: false, cyl: 1, ev: false, vmin: 2, id: -50 - i, veh: { len: 1.8, wid: .7, L: 1.3, a: .65, b: .65, tw: .5, hg: .6, front: 0, hl: .9, hw: .35, gears: gearsFor(37, 5), Iz: 60, tb: TBASE } }; bots.push({ H: Hh, c: { model: 'Paparazzo', make: '' }, b: null, p: pb, s: spawn((N - 30 - i * 6 + N) % N, (i % 2 ? 2 : -2)), K: {}, skill: 1.1, lane: 0, scoot: 1 }); } race = { phase: 'count', t: performance.now() - lostT, laps: 9999 }; },
				tick: function (dt, now) { var s = P1.s, sp = Math.hypot(s.vx, s.vz) || 1; if (race.phase !== 'run') return; bots.forEach(function (b) { var dx = b.s.x - s.x, dz = b.s.z - s.z, d = Math.hypot(dx, dz); if (d > 70) aiDrive(b.s, b.p, b.K, 1.15, 0); else chase(b, s.x + s.vx * .3 - s.vz / sp * 4 * (b.p.id % 2 ? 1 : -1), s.z + s.vz * .3 + s.vx / sp * 4 * (b.p.id % 2 ? 1 : -1)); if (d < 14 && (b.cool || 0) < now) { b.cool = now + 900 + Math.random() * 700; PM.ph++; PM.flashT = now; FX.play('tick'); } });
					var fl = $('[data-pm-flash]', root); fl.style.opacity = now - PM.flashT < 120 ? .8 : 0; if (PM.ph && PM.ph % 6 === 0 && PM.lastSay !== PM.ph) { PM.lastSay = PM.ph; say2(lineOf(['They got another shot!', 'Flash! Flash! Flash!', 'The front pages are going to love this.', 'Lose them!'], PM.ph), true); }
					pmHud('<b>Photos taken: ' + PM.ph + '</b><span>Get your celebrity to the venue in two laps. Lap ' + Math.min(2, s.lap + 1) + ' of 2</span>');
					if (s.lap >= 2 && !PM.done2) { PM.done2 = 1; var fame = Math.max(0, 100 - PM.ph * 3), k = store('psr-pm-papz'), kb = trk, best = k[kb] == null || PM.ph < k[kb]; if (best) { k[kb] = PM.ph; put('psr-pm-papz', k); } say2(PM.ph < 5 ? 'Clean getaway! Not a single good shot!' : 'You made it. The tabloids made it too.', true); if (PM.ph < 8) FX.confetti(stage, 140); pmEnd('<h3>' + PM.ph + ' photos taken</h3><p>Your client’s reputation: ' + fame + '%.' + (best ? ' Your best escape on this track.' : '') + '</p>'); } } };
			/* tail the target */
			PMS.tail = { start: function () { var pool = cars.filter(function (c) { return c.glb; }); if (!pool.length) pool = cars; var c = pool[(Math.random() * pool.length) | 0], Hh = makeHolder(), b0 = buildOf(c), pb = physOf(c, b0); dress(Hh, c, b0); PM.tgt = { H: Hh, c: c, b: b0, p: pb, s: spawn((N - 12 + 30) % N, 0), K: {}, skill: .8, lane: 0 }; bots.push(PM.tgt); PM.ctrl = 1; PM.spot = 0; PM.lost = 0; PM.t = 0; PM.sk = .8; PM.mk = new T.Mesh(new T.ConeGeometry(.5, .9, 4), new T.MeshBasicMaterial({ color: 0xff3a3a })); PM.mk.rotation.x = Math.PI; pmG.add(PM.mk); },
				tick: function (dt) { var s = P1.s, t = PM.tgt.s; PM.t += P1.started ? dt : 0; if (!P1.started) { PM.tgt.K.t = 0; PM.tgt.K.b = 1; pmHud('<b>Tail the target</b><span>Follow the marked car for two laps. Stay between 15 and 60 metres.</span>'); return; } if (Math.random() < dt * .3) PM.sk = .65 + Math.random() * .35; aiDrive(t, PM.tgt.p, PM.tgt.K, PM.sk, Math.sin(PM.t * .2) * 2.5); PM.mk.position.set(t.x, H(t.x, t.z) + 3, t.z); PM.mk.rotation.y += dt * 2;
					var d = Math.hypot(t.x - s.x, t.z - s.z); if (d < 15) { PM.spot += dt * (15 - d) * 2.5; if (PM.spot > 30 && !PM.ws) { PM.ws = 1; say2('Too close! Back off!', true); } } else { PM.spot = Math.max(0, PM.spot - dt * 5); PM.ws = 0; } if (d > 60) { PM.lost += dt * (d - 60) * .5; if (PM.lost > 30 && !PM.wl) { PM.wl = 1; say2('You are losing him!', true); } } else { PM.lost = Math.max(0, PM.lost - dt * 6); PM.wl = 0; }
					pmHud('<b>' + Math.round(d) + ' m</b><span>' + (d < 15 ? 'Too close: he will spot you' : d > 60 ? 'Too far: you will lose him' : 'Good distance') + ' · spotted ' + Math.round(PM.spot) + '% · lost ' + Math.round(PM.lost) + '%</span><i style="width:' + Math.max(PM.spot, PM.lost) + '%"></i>');
					if (PM.spot >= 100 || PM.lost >= 100) { say2(PM.spot >= 100 ? 'He has spotted you. Mission failed.' : 'He is gone. Mission failed.', true); boom2(); pmEnd('<h3>' + (PM.spot >= 100 ? 'Spotted.' : 'Lost him.') + '</h3><p>You tailed him for ' + PM.t.toFixed(0) + ' seconds.</p>'); } else if (t.lap >= 2) { say2('He never knew you were there. Perfect tail.', true); FX.confetti(stage, 140); pmEnd('<h3>Perfect tail.</h3><p>Two laps unseen. Spotted meter peaked under 100%.</p>'); } } };
			/* two people, one car: one steers, the other drives the pedals */
			PMS.tandem = { start: function () { spawnRivals(3, .9); race = { phase: 'count', t: performance.now() - lostT, laps: 2 }; },
				tick: function () { pmHud('<b>Two people, one car</b><span>Player 1 steers: A and D, Space handbrake · Player 2 drives: ↑ throttle, ↓ brake, Right Shift nitro</span>'); } };
			/* vroom: your voice is the throttle */
			PMS.vroom = { start: function () { spawnRivals(3, .88); race = { phase: 'count', t: performance.now() - lostT, laps: 2 }; PM.vol = 0; PM.pitch = 0; if (!mic.an) { try { navigator.mediaDevices.getUserMedia({ audio: true }).then(function (st) { var A = new (w.AudioContext || w.webkitAudioContext)(), src = A.createMediaStreamSource(st), an = A.createAnalyser(); an.fftSize = 1024; src.connect(an); mic.an = an; mic.buf = new Float32Array(an.fftSize); mic.fr = new Uint8Array(an.frequencyBinCount); mic.st = st; }).catch(function () { flash('Microphone blocked: allow it in the browser to play Vroom', 4000); }); } catch (e) { flash('This browser has no microphone access', 3000); } } },
				tick: function (dt) { if (!mic.an) { pmHud('<b>Vroom mode</b><span>Allow the microphone, then make engine noises: louder is faster, a rising pitch fires the boost</span>'); return; } mic.an.getFloatTimeDomainData(mic.buf); var r = 0; for (var i = 0; i < mic.buf.length; i++) r += mic.buf[i] * mic.buf[i]; r = Math.sqrt(r / mic.buf.length); mic.an.getByteFrequencyData(mic.fr); var num = 0, den = 0; for (i = 2; i < 200; i++) { num += i * mic.fr[i]; den += mic.fr[i]; } var cen = den ? num / den : 0; PM.vol += (Math.min(1, Math.max(0, (r - .015) * 9)) - PM.vol) * Math.min(1, dt * 12); var dp = cen - PM.pitch; PM.pitch += dp * Math.min(1, dt * 4); PM.rise = dp > 4 && PM.vol > .4;
					pmHud('<b>VROOM ' + Math.round(PM.vol * 100) + '%</b><span>' + (PM.rise ? 'BOOST!' : 'Louder is faster · a rising pitch fires the boost') + '</span><i style="width:' + PM.vol * 100 + '%;background:#f1d27a"></i>'); } };
			var mic = {};
			/* call it: spectators bet chips on the winner before the lights go out */
			var BETS = null;
			function betNames() { return ($('[data-pm-bettors]', root).value || '').split(/[,\n]/).map(function (x) { return x.trim().slice(0, 16); }).filter(Boolean).slice(0, 6); }
			function betsOpen() { var names = betNames(); if (!names.length || !race || ['race', 'ko', 'roulette'].indexOf(mode) < 0) return; var chips = store('psr-pm-chips'), ent = [{ id: 'me', n: 'Driver (' + cname(P1.c) + ')', pi: perf(P1.c, P1.b).pi }].concat(bots.filter(function (b) { return !b.echo; }).map(function (b) { return { id: b.c.model, n: b.c.model, pi: perf(b.c, b.b || buildOf(b.c)).pi }; })), tot = ent.reduce(function (a, e) { return a + Math.pow(e.pi, 3); }, 0); ent.forEach(function (e) { e.odds = Math.max(1.2, Math.round(tot / Math.pow(e.pi, 3) * .85 * 10) / 10); }); names.forEach(function (n) { if (chips[n] == null) chips[n] = 1000; }); put('psr-pm-chips', chips); BETS = { ent: ent, b: {} }; race.phase = 'bets';
				var h = '<h3>Call it</h3><p>Spectators: pick a winner and a stake before the lights go out.</p><div class="pm__bets">' + names.map(function (n, i) { return '<div class="pm__bet"><b>' + esc(n) + ' <small>' + chips[n].toLocaleString('en-GB') + ' chips</small></b><select data-bet-p="' + i + '">' + ent.map(function (e) { return '<option value="' + esc(e.id) + '">' + esc(e.n) + ' · ' + e.odds + '×</option>'; }).join('') + '</select><input type="range" min="0" max="' + chips[n] + '" step="50" value="' + Math.min(200, chips[n]) + '" data-bet-s="' + i + '"><output data-bet-o="' + i + '">' + Math.min(200, chips[n]) + '</output></div>'; }).join('') + '</div><button type="button" class="lx-btn lx-btn--gold" data-bet-go>Lock the bets · lights out</button>';
				showPanel(h); $$('[data-bet-s]', panel).forEach(function (r) { on(r, 'input', function () { $('[data-bet-o="' + r.getAttribute('data-bet-s') + '"]', panel).textContent = r.value; }); });
				on($('[data-bet-go]', panel), 'click', function () { names.forEach(function (n, i) { var st = +$('[data-bet-s="' + i + '"]', panel).value, pk = $('[data-bet-p="' + i + '"]', panel).value; if (st > 0) BETS.b[n] = { pick: pk, st: st, odds: BETS.ent.filter(function (e) { return e.id === pk; })[0].odds }; }); panel.hidden = true; race.phase = 'count'; race.t = performance.now() - lostT; say2('Bets are locked. Lights out!', true); }); }
			function betsSettle(winId) { if (!BETS) return ''; var chips = store('psr-pm-chips'), rows = Object.keys(BETS.b).map(function (n) { var b = BETS.b[n], won = b.pick === winId, d = won ? Math.round(b.st * (b.odds - 1)) : -b.st; chips[n] = Math.max(0, (chips[n] || 0) + d); if (chips[n] < 50) chips[n] = 500; return '<li><b>' + esc(n) + '</b><span>' + (won ? 'won ' + d.toLocaleString('en-GB') : 'lost ' + b.st.toLocaleString('en-GB')) + ' · ' + chips[n].toLocaleString('en-GB') + ' chips</span></li>'; }); put('psr-pm-chips', chips); BETS = null; var lb = Object.keys(chips).sort(function (a, b) { return chips[b] - chips[a]; }).slice(0, 6); return rows.length ? '<h4 class="pm__bh">Spectator bets</h4><ol class="rl__res">' + rows.join('') + '</ol><p class="rl__sub">Chip leaders: ' + lb.map(function (n) { return esc(n) + ' ' + chips[n].toLocaleString('en-GB'); }).join(' · ') + '</p>' : ''; }
			/* ---------- batch 3: stunts, valet, slalom, tunnel, fuel, replay, postcards ---------- */
			function staticCar(c, x, z, h) { var Hh = makeHolder(), b0 = buildOf(c); dress(Hh, c, b0); var ph = physOf(c, b0), st = { x: x, z: z, h: h, va: h, v: 0, vx: 0, vz: 0, r: 0, idx: nearest(x, z, 0)[0], m: 1e6, Iz: 1e8, hl: ph.veh.hl, hw: ph.veh.hw, lap: 0, dist: 0, slip: 0, hit: 0 }; var bt = { H: Hh, c: c, b: b0, p: ph, s: st, K: {}, stat: 1 }; bots.push(bt); return bt; }
			function glbPool() { var g = cars.filter(function (c) { return c.glb; }); return g.length >= 4 ? g : cars.slice(); }
			function priciest(n) { return glbPool().sort(function (a, b) { return carValue(b) - carValue(a); }).slice(0, n); }
			function neighbourBill(bt, k) { var v = carValue(bt.c), cst = Math.round(v * .04 * Math.min(2, k * 4) / 100) * 100; P1.bill = P1.bill || {}; var key = 'Repairs to a ' + cname(bt.c); P1.bill[key] = (P1.bill[key] || 0) + cst; P1.billT = (P1.billT || 0) + cst; return cst; }
			/* stunts: ramps launch you, boost pads fire you forward, landings are scored */
			PMS.stunt = { start: function () { PM.sc = 0; PM.ramps = []; PM.pads = []; var rm = new T.MeshStandardMaterial({ color: 0xd9a93f, metalness: .5, roughness: .4 }), stripe = new T.MeshBasicMaterial({ color: 0x111114 });
					var straights = [], i, j; for (i = 0; i < N; i += 6) { var ok = true; for (var j = -18; j <= 18; j++) if (kap[(i + j + N) % N] > 1 / 220) ok = false; if (ok && (!straights.length || i - straights[straights.length - 1] > 120)) straights.push(i); }
					straights.slice(0, 5).forEach(function (i0, k) { var p = pts[i0], t = tang[i0], h = Math.atan2(t.z, t.x), g = new T.Mesh(new T.BoxGeometry(7, .6, 6), rm); g.position.set(p.x, H(p.x, p.z) + .1, p.z); g.rotation.y = -h; g.rotation.z = .16; g.scale.y = 1; var wedge = new T.Group(); wedge.add(g); pmG.add(wedge); PM.ramps.push({ i: i0, x: p.x, z: p.z, h: h });
						var pi2 = (i0 + 60) % N, pp = pts[pi2], pad = new T.Mesh(new T.PlaneGeometry(4, 5), new T.MeshBasicMaterial({ map: signTex(256, 256, '#1b6aff', '#ffffff', '>>>', 120), transparent: true, opacity: .9 })); pad.rotation.x = -Math.PI / 2; pad.rotation.z = -Math.atan2(tang[pi2].z, tang[pi2].x) - Math.PI / 2; pad.position.set(pp.x, H(pp.x, pp.z) + .12, pp.z); pmG.add(pad); PM.pads.push({ i: pi2, cool: 0 }); }); },
				tick: function (dt, now) { var s = P1.s; pmHud('<b>Stunt score ' + Math.round(PM.sc) + '</b><span>' + (s.air ? 'AIRBORNE ' + (s.airT || 0).toFixed(1) + ' s' : 'Hit the gold ramps fast, land straight. Blue pads boost you.') + '</span>');
					PM.ramps.forEach(function (r) { if (s.air) return; var dx = s.x - r.x, dz = s.z - r.z, al = dx * Math.cos(r.h) + dz * Math.sin(r.h), lt = Math.abs(-dx * Math.sin(r.h) + dz * Math.cos(r.h)); if (Math.abs(al) < 2 && lt < 3 && s.v > 12 && (r.cool || 0) < now) { r.cool = now + 1500; s.air = 1; s.y = .6; s.vy = s.v * .28; s.airT = 0; s.airD = 0; s.ax0 = s.x; s.az0 = s.z; say2(lineOf(['Big air!', 'He is flying!', 'Up, up and away!'], 1)); FX.play('flip'); } });
					PM.pads.forEach(function (pd) { var dI = Math.abs(s.idx - pd.i); if (dI < 3 && pd.cool < now && !s.air) { pd.cool = now + 1200; var h2 = s.va; s.vx += Math.cos(h2) * 9; s.vz += Math.sin(h2) * 9; flash('BOOST!', 700); FX.play('go'); } });
					if (s.air) { s.airT += dt; s.vy -= 9.81 * dt; s.y += s.vy * dt; if (s.y <= 0) { s.y = 0; s.air = 0; var dist = Math.hypot(s.x - s.ax0, s.z - s.az0), straight = Math.abs(s.slip || 0) < .15, land = Math.abs(s.vy); var pts1 = Math.round(dist * 12 + s.airT * 200) * (straight ? 1.5 : .7); if (land > 9) { hurt(s, land - 4, s.x + Math.cos(s.h) * 2, s.z + Math.sin(s.h) * 2); pts1 = Math.round(pts1 * .5); } PM.sc += pts1; flash((straight ? 'Clean landing! ' : 'Sketchy landing · ') + Math.round(dist) + ' m · +' + pts1, 1600); if (straight && dist > 25) say2(lineOf(['What a landing!', 'Stuck it!', 'Textbook!'], 2)); FX.play(straight ? 'win' : 'no'); } } },
				lap: function (P, tl) { if (P1.s.lap < 2) { flash('Lap ' + P1.s.lap + ' · ' + Math.round(PM.sc) + ' points', 1600); return true; } var bk = store('psr-pm-stunt'), kb = trk, best = !bk[kb] || PM.sc > bk[kb]; if (best) { bk[kb] = PM.sc; put('psr-pm-stunt', bk); } FX.confetti(stage, 160); pmEnd('<h3>' + Math.round(PM.sc).toLocaleString('en-GB') + ' stunt points</h3><p>Two laps.' + (best ? ' New record.' : '') + '</p>'); return true; } };
			/* valet: park guests' cars between priceless neighbours */
			PMS.valet = { start: function () { PM.n = 0; PM.t = 0; PM.sc = 0; PM.hits = 0; PM.bay = null; PM.next = function () { pmG.children.slice().forEach(function (o) { if (o.bay) pmG.remove(o); }); bots.filter(function (b) { return b.stat; }).forEach(function (b) { S.remove(b.H.holder); }); bots = bots.filter(function (b) { return !b.stat; }); var bi = Math.floor((PM.n + 1) / 6 * N + 40) % N, p = pts[bi], n0 = nor[bi], t0 = tang[bi], par = barrierD && barrierD < Wd / 2 + 4, h = Math.atan2(t0.z, t0.x) + (par ? 0 : Math.PI / 2), off = par ? Wd / 2 - 1.6 : Wd / 2 + (barrierD ? Math.min(5, barrierD - Wd / 2 - 3.2) : 5), bx = p.x + n0.x * off, bz = p.z + n0.z * off, pool = priciest(10); PM.bay = { x: bx, z: bz, h: h, i: bi, t0: PM.t, par: par };
						[-1, 1].forEach(function (sd, k) { var ah = par ? h : h + Math.PI / 2, gap = par ? 6.4 : 2.9, cx = bx + Math.cos(ah) * sd * gap, cz = bz + Math.sin(ah) * sd * gap; staticCar(pool[(PM.n * 2 + k) % pool.length], cx, cz, h); });
						var lm = new T.MeshBasicMaterial({ color: 0xffffff }), g = new T.Group(); g.bay = 1; [[0, 1.2, 5.6, .12], [0, -1.2, 5.6, .12], [-2.8, 0, .12, 2.5]].forEach(function (q) { var m = new T.Mesh(new T.PlaneGeometry(q[2], q[3]), lm); m.rotation.x = -Math.PI / 2; m.position.set(q[0], .1, q[1]); g.add(m); }); var arrow = new T.Mesh(new T.ConeGeometry(.7, 1.4, 4), new T.MeshBasicMaterial({ color: 0xf1d27a })); arrow.rotation.x = Math.PI; arrow.position.y = 3.5; arrow.name = 'ar'; g.add(arrow); g.position.set(bx, H(bx, bz), bz); g.rotation.y = -h + Math.PI; pmG.add(g); PM.mark = g; }; PM.next(); },
				tick: function (dt, now) { var s = P1.s, b = PM.bay; if (P1.started) PM.t += dt; if (PM.mark) PM.mark.getObjectByName('ar').rotation.y += dt * 3; bots.forEach(function (bt) { if (!bt.stat) return; var dx = bt.s.x - s.x, dz = bt.s.z - s.z; if (bt.touch && (bt.hc || 0) < now) { bt.hc = now + 1000; var c0 = neighbourBill(bt, bt.touch / 10); bt.touch = 0; PM.hits++; say2(lineOf(['Oh no, that was the ' + bt.c.model + '!', 'The owner saw that.', 'That is coming out of your wages.'], PM.hits), true); flash('You touched a ' + cname(bt.c) + ' · $' + c0.toLocaleString('en-GB'), 1800); } });
					var d = Math.hypot(s.x - b.x, s.z - b.z), ang = Math.abs(Math.cos(angd(s.h, b.h))); pmHud('<b>Bay ' + (PM.n + 1) + ' of 5 · ' + Math.round(d) + ' m</b><span>' + (b.par ? 'Parallel park between the cars' : 'Stop inside the lines, straight') + ' · ' + (PM.t - b.t0).toFixed(1) + ' s · touches ' + PM.hits + '</span>');
					if (d < 1.4 && s.v < .4 && ang > .96) { var tt = PM.t - b.t0, pts1 = Math.max(100, Math.round(1000 - tt * 20 - d * 200)); PM.sc += pts1; PM.n++; flash('Parked! +' + pts1, 1400); FX.play('win'); say2(lineOf(['Perfectly parked.', 'Lovely. Next guest!', 'Keys on the hook. Next!'], PM.n)); if (PM.n >= 5) { var bk = store('psr-pm-valet'), kb = P1.c.id, best = !bk[kb] || PM.sc > bk[kb]; if (best) { bk[kb] = PM.sc; put('psr-pm-valet', bk); } FX.confetti(stage, 160); pmEnd('<h3>Five cars parked</h3><p>Score ' + PM.sc.toLocaleString('en-GB') + ' · ' + PM.hits + ' touches on the guests’ cars.' + (best ? ' New record.' : '') + '</p>'); } else PM.next(); } } };
			/* showroom slalom: thread between priceless display cars */
			PMS.slalom = { start: function () { PM.t = 0; PM.hits = 0; var pool = priciest(12), st = null; for (var i = 0; i < N; i += 6) { var ok = true; for (var j = 0; j <= 160; j++) if (kap[(i + j) % N] > 1 / 260) ok = false; if (ok) { st = i; break; } } st = st == null ? 20 : st; PM.a = st; PM.b = (st + 150) % N; PM.gates = []; PM.gi = 0; PM.miss = 0; var coneM = new T.MeshStandardMaterial({ color: lin(0xd9a93f), emissive: lin(0x3a2a08), metalness: .5, roughness: .4 }); for (var k = 0; k < 8; k++) { var ii = (st + 15 + k * 18) % N, p = pts[ii], n0 = nor[ii], sd = k % 2 ? .5 : -.5, side = k % 2 ? -1 : 1, h = Math.atan2(tang[ii].z, tang[ii].x) + (k % 2 ? .25 : -.25); staticCar(pool[k % pool.length], p.x + n0.x * sd, p.z + n0.z * sd, h); PM.gates.push({ ii: ii, side: side }); [3.6, 6].forEach(function (o3) { var cm = new T.Mesh(new T.ConeGeometry(.4, 1.15, 12), coneM), cx3 = p.x + n0.x * side * o3, cz3 = p.z + n0.z * side * o3; cm.position.set(cx3, H(cx3, cz3) + .57, cz3); pmG.add(cm); }); } PM.b = (PM.gates[7].ii + 25) % N; PM.go = 0; },
				tick: function (dt, now) { var s = P1.s, pr = s.idx; if (!PM.go && Math.abs(angd(pr / N * 6.283, PM.a / N * 6.283)) < .03) { PM.go = 1; PM.t0 = now; } if (PM.go === 1) PM.t = (now - PM.t0) / 1000; bots.forEach(function (bt) { if (!bt.stat) return; var dx = bt.s.x - s.x, dz = bt.s.z - s.z; if (bt.touch && (bt.hc || 0) < now) { bt.hc = now + 1000; var c0 = neighbourBill(bt, bt.touch / 10); bt.touch = 0; PM.hits++; flash('Touched a ' + cname(bt.c) + ' · $' + c0.toLocaleString('en-GB') + ' · +3 s', 1800); say2(lineOf(['That was a showroom car!', 'Not the display car!', 'The sales team just fainted.'], PM.hits), true); } });
					var g = PM.gates[PM.gi]; if (PM.go === 1 && g && (s.idx - g.ii + N) % N < 12) { var lat = (s.x - pts[g.ii].x) * nor[g.ii].x + (s.z - pts[g.ii].z) * nor[g.ii].z; if (lat * g.side < 0) { PM.miss++; flash('Wrong side! +5 s · pass between the gold cones', 1600); FX.play('no'); } else FX.play('tick'); PM.gi++; }
					pmHud('<b>Showroom slalom' + (PM.go ? ' · car ' + Math.min(8, PM.gi + 1) + ' of 8' : '') + '</b><span>' + (PM.go ? 'Time ' + PM.t.toFixed(2) + ' s · touches ' + PM.hits + ' · wrong side ' + PM.miss : 'Weave through the eight display cars: pass each one on the side of its gold cones') + '</span>');
					if (PM.go === 1 && PM.gi >= 8 && (s.idx - PM.b + N) % N < 40) { PM.go = 2; var tot = PM.t + PM.hits * 3 + PM.miss * 5, bk = store('psr-pm-slalom'), kb = trk + ':' + P1.c.id, best = !bk[kb] || tot < bk[kb]; if (best) { bk[kb] = tot; put('psr-pm-slalom', bk); } if (!PM.hits && !PM.miss) { say2('Clean! Not a scratch on the collection.', true); FX.confetti(stage, 160); } pmEnd('<h3>' + tot.toFixed(2) + ' s</h3><p>' + (PM.hits ? PM.hits + ' touches (+' + PM.hits * 3 + ' s). ' : 'Not a scratch. ') + (PM.miss ? PM.miss + ' wrong side (+' + PM.miss * 5 + ' s).' : 'Every car on the right side.') + (best ? ' New record.' : '') + '</p>'); } } };
			/* tunnel symphony: the engine note scores inside the tunnel */
			PMS.tunnel = { start: function () { PM.sc = 0; PM.pass = 0; var st = 0; for (var i = 0; i < N; i += 6) { var ok = true; for (var j = 0; j <= 120; j++) if (kap[(i + j) % N] > 1 / 300) ok = false; if (ok) { st = i; break; } } PM.a = st; PM.b = (st + Math.round(160 / seg)) % N; var tm = new T.MeshStandardMaterial({ color: 0x3a3a40, roughness: .9, side: T.DoubleSide }), lm = new T.MeshBasicMaterial({ color: 0xffd9a0 });
					for (var k = PM.a; k < PM.a + Math.round(160 / seg); k += 3) { var kk = k % N, p = pts[kk], n0 = nor[kk], h = Math.atan2(tang[kk].z, tang[kk].x); [-1, 1].forEach(function (sd) { var wl = new T.Mesh(new T.BoxGeometry(seg * 3.2, 6, .4), tm); wl.position.set(p.x + n0.x * sd * (Wd / 2 + 1.5), H(p.x, p.z) + 3, p.z + n0.z * sd * (Wd / 2 + 1.5)); wl.rotation.y = -h; pmG.add(wl); }); var rf = new T.Mesh(new T.BoxGeometry(seg * 3.2, .4, Wd + 3.4), tm); rf.position.set(p.x, H(p.x, p.z) + 6, p.z); rf.rotation.y = -h; pmG.add(rf); if ((k / 3 | 0) % 4 === 0) { var lp = new T.Mesh(new T.BoxGeometry(1.2, .1, .4), lm); lp.position.set(p.x, H(p.x, p.z) + 5.75, p.z); lp.rotation.y = -h; pmG.add(lp); } } },
				tick: function (dt) { var s = P1.s, inT = (s.idx - PM.a + N) % N <= (PM.b - PM.a + N) % N; if (inT) { if (!PM.inT) { PM.inT = 1; PM.cur = 0; PM.lg = s.gear; say2('In the tunnel. Make it sing!'); } var add = (s.rpm > .9 ? 60 : s.rpm > .75 ? 25 : 0) * dt; if (s.gear < PM.lg) { add += 120; flash('Downshift! +120', 600); } if (PM.lt && !(lastE1 && lastE1.t) && s.rpm > .8) { add += 80; flash('Crackle! +80', 600); } PM.lg = s.gear; PM.lt = lastE1 && lastE1.t; PM.cur += add; } else if (PM.inT) { PM.inT = 0; PM.pass++; PM.sc = Math.max(PM.sc, PM.cur); flash('Tunnel run ' + PM.pass + ': ' + Math.round(PM.cur) + ' points', 1800); say2(PM.cur > 600 ? 'What a sound!' : 'More revs next time.'); }
					pmHud('<b>' + (inT ? 'IN THE TUNNEL · ' + Math.round(PM.cur) : 'Tunnel symphony') + '</b><span>High revs, downshifts and lift-off crackles score inside the tunnel · best ' + Math.round(PM.sc) + ' · run ' + Math.min(3, PM.pass + 1) + ' of 3</span>'); if (PM.pass >= 3) { var bk = store('psr-pm-tunnel'), kb = P1.c.id, best = !bk[kb] || PM.sc > bk[kb]; if (best) { bk[kb] = PM.sc; put('psr-pm-tunnel', bk); } pmEnd('<h3>' + Math.round(PM.sc) + ' points</h3><p>Your best tunnel run in the ' + esc(cname(P1.c)) + '.' + (best ? ' New record for this car.' : '') + '</p>'); } } };
			/* hypercar on a teaspoon */
			PMS.fuel = { start: function () { PM.f = .5; PM.d = 0; PM.lx = null; },
				tick: function (dt) { var s = P1.s; if (PM.lx) PM.d += Math.hypot(s.x - PM.lx[0], s.z - PM.lx[1]); PM.lx = [s.x, s.z]; if (PM.f > 0 && lastE1 && lastE1.t) { var pw = P1.p.P * (lastE1.t || 0) * Math.max(.3, s.rpm || .5); PM.f = Math.max(0, PM.f - pw * dt / 8.9e6 * (1 + (s.rpm || .5))); } if (PM.f <= 0 && !PM.empty) { PM.empty = 1; P1.p = Object.assign({}, P1.p, { P: 1 }); say2('That is the last drop. Coast it home!', true); }
					pmHud('<b>' + (PM.d / 1000).toFixed(2) + ' km</b><span>Fuel ' + (PM.f * 1000).toFixed(0) + ' ml · ' + (PM.f > 0 ? 'light throttle, high gears, coast' : 'empty: coasting') + '</span><i style="width:' + PM.f / .5 * 100 + '%;background:#5aa86a"></i>');
					if (PM.empty && s.v > .1) { var fdk = Math.max(0, 1 - 1.4 * dt / s.v); s.vx *= fdk; s.vz *= fdk; }
					if (PM.empty && s.v < 1.5 && !PM.over) { var bk = store('psr-pm-fuel'), kb = P1.c.id, best = !bk[kb] || PM.d > bk[kb]; if (best) { bk[kb] = PM.d; put('psr-pm-fuel', bk); } say2('Rolled to a stop at ' + (PM.d / 1000).toFixed(2) + ' kilometres.', true); pmEnd('<h3>' + (PM.d / 1000).toFixed(2) + ' km on half a litre</h3><p>' + esc(cname(P1.c)) + ' · ' + Math.round(P1.c.hp) + ' hp.' + (best ? ' New record for this car.' : ' Record: ' + (bk[kb] / 1000).toFixed(2) + ' km.') + '</p>'); } },
				lap: function () { flash('Lap complete · keep rolling', 1200); return true; } };
			/* instant replay: the last ten seconds, slowed down, from a cinematic camera */
			var RP = { buf: [], on: 0 };
			function rpRecord(now) { if (RP.on || !P1.s || now - (RP.lr || 0) < 33) return; RP.lr = now; var L = [[P1, P1.s]]; if (P2.s) L.push([P2, P2.s]); bots.forEach(function (b) { if (!b.out) L.push([b, b.s]); }); RP.buf.push([now, L.map(function (q) { return [q[0], q[1].x, q[1].z, q[1].h, q[1].y || 0, q[1].rolled || 0]; })]); while (RP.buf.length && now - RP.buf[0][0] > 8000) RP.buf.shift(); }
			function rpStart() { if (RP.buf.length < 8) return false; RP.on = 1; RP.i = 0; RP.k = 0; RP.wasLive = live; live = false; RP.fov = C.fov; RP.fromPanel = !panel.hidden; panel.hidden = true; $('[data-pm-rp]', root).hidden = false; RP.ang = 0; return true; }
			function rpStep(dt) { if (!RP.on) return false; RP.k += dt * .6 * 1000; var t0 = RP.buf[0][0], tgt = t0 + RP.k; while (RP.i < RP.buf.length - 1 && RP.buf[RP.i + 1][0] < tgt) RP.i++; var fr = RP.buf[RP.i]; fr[1].forEach(function (q) { var o = q[0], Hh = o.H || (o === P1 ? me : o === P2 ? p2h : null); if (!Hh) return; Hh.holder.position.set(q[1], H(q[1], q[2]) + q[4], q[2]); Hh.holder.rotation.set(0, -q[3], 0); });
				var me0 = fr[1][0], gy = H(me0[1], me0[2]) + me0[4], ph = Math.floor(RP.k / 2600) % 3, fx = Math.cos(me0[3]), fz = Math.sin(me0[3]); RP.ang += dt * .35;
				if (ph !== RP.ph) { RP.ph = ph; RP.tx = me0[1] + fx * 26 - fz * 9; RP.tz = me0[2] + fz * 26 + fx * 9; }
				if (ph === 0) { C.position.set(me0[1] + Math.cos(RP.ang) * 9, gy + 3.5, me0[2] + Math.sin(RP.ang) * 9); C.fov = 50; }
				else if (ph === 1) { C.position.set(me0[1] - fx * 6.5 + fz * 1.2, gy + .9, me0[2] - fz * 6.5 - fx * 1.2); C.fov = 62; }
				else { C.position.set(RP.tx, H(RP.tx, RP.tz) + 1.6, RP.tz); C.fov = Math.max(18, Math.min(45, 900 / Math.max(8, Math.hypot(RP.tx - me0[1], RP.tz - me0[2])))); }
				C.lookAt(me0[1], gy + 1, me0[2]); C.updateProjectionMatrix(); if (RP.i >= RP.buf.length - 1) rpStop(); return true; }
			function rpStop() { if (!RP.on) return; RP.on = 0; live = RP.wasLive; C.fov = RP.fov || C.fov; C.updateProjectionMatrix(); $('[data-pm-rp]', root).hidden = true; if (RP.rec) { try { RP.rec.stop(); } catch (e) {} } if (RP.fromPanel) panel.hidden = false; RP.fromPanel = 0; }
			function rpClip() { if (RP.buf.length < 8) return; try { var st = R.domElement.captureStream(30), mr = new MediaRecorder(st, { mimeType: MediaRecorder.isTypeSupported('video/webm;codecs=vp9') ? 'video/webm;codecs=vp9' : 'video/webm' }), ch = []; mr.ondataavailable = function (e) { if (e.data.size) ch.push(e.data); }; mr.onstop = function () { var blob = new Blob(ch, { type: 'video/webm' }), f = new File([blob], 'laqim-replay.webm', { type: 'video/webm' }); if (navigator.canShare && navigator.canShare({ files: [f] })) navigator.share({ files: [f], title: 'Laqim Racing replay' }).catch(function () {}); else { var a = d.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'laqim-replay.webm'; a.click(); } RP.rec = null; }; RP.rec = mr; mr.start(); } catch (e) { flash('This browser cannot record clips', 2000); } rpStart(); }
			/* postcards: hidden scenic spots on every track */
			function pcSpots() { var L = [], rng = function (k) { var x = Math.sin((trk.length * 31 + k) * 9301.7) * 43758.5; return x - Math.floor(x); }; for (var k = 0; k < 4; k++) { var i0 = Math.floor(rng(k) * N), sd = rng(k + 9) > .5 ? 1 : -1, off = Wd / 2 - 2.2 - rng(k + 4) * 1.5, p = pts[i0]; L.push({ id: trk + ':' + k, x: p.x + nor[i0].x * sd * off, z: p.z + nor[i0].z * sd * off }); } return L; }
			var PC = { m: null, L: [] };
			function pcBuild() { PC.g = new T.Group(); pmG.add(PC.g); var got = store('psr-pc'); PC.L = pcSpots(); PC.L.forEach(function (sp) { if (got[sp.id]) return; var m = new T.Group(), cm = new T.MeshBasicMaterial({ color: 0xf1d27a }); var body = new T.Mesh(new T.BoxGeometry(.8, .5, .3), cm); body.position.y = 2.2; m.add(body); var lens = new T.Mesh(new T.CylinderGeometry(.16, .16, .25, 12), new T.MeshBasicMaterial({ color: 0x111114 })); lens.rotation.x = Math.PI / 2; lens.position.set(0, 2.2, .25); m.add(lens); var ring = new T.Mesh(new T.RingGeometry(3.2, 3.8, 32), new T.MeshBasicMaterial({ color: 0xf1d27a, transparent: true, opacity: .5, side: T.DoubleSide })); ring.rotation.x = -Math.PI / 2; ring.position.y = .15; m.add(ring); m.position.set(sp.x, H(sp.x, sp.z), sp.z); m.sp = sp; PC.g.add(m); }); }
			function pcTick(dt) { if (!PC.g || !P1.s) return; var s = P1.s; PC.g.children.forEach(function (m) { if (!m.visible) return; m.children[0].rotation.y += dt * 2; var d = Math.hypot(s.x - m.sp.x, s.z - m.sp.z); m.visible = true; if (d < 4 && s.v < 1.5) { m.visible = false; var got = store('psr-pc'); got[m.sp.id] = 1; put('psr-pc', got); pcSnap(m.sp); } }); }
			function pcSnap(sp) { FX.play('win'); var fl = $('[data-pm-flash]', root); fl.style.opacity = .9; setTimeout(function () { fl.style.opacity = 0; }, 140); try { R.render(S, C); var src = R.domElement, cv = d.createElement('canvas'), wd = 360, ht = Math.round(src.height / src.width * wd); cv.width = wd; cv.height = ht; var x = cv.getContext('2d'); x.drawImage(src, 0, 0, wd, ht); x.fillStyle = 'rgba(0,0,0,.5)'; x.fillRect(0, ht - 34, wd, 34); x.fillStyle = '#f1d27a'; x.font = '600 15px Georgia, serif'; x.fillText('Greetings from the ' + TRACKS[trk].name, 12, ht - 12); var al = store('psr-pc-al'); al[sp.id] = { img: cv.toDataURL('image/jpeg', .72), car: cname(P1.c), t: Date.now() }; put('psr-pc-al', al); } catch (e) {} var n = Object.keys(store('psr-pc')).length; flash('Postcard found! ' + n + ' in your album', 2200); say2(lineOf(['Say cheese!', 'Lovely spot for a photo.', 'That one is going on the fridge.'], n) + ' That is ' + n + ' in the album.', true); }
			var lastE1 = null;
			/* postcard hunt */
			PMS.cards = { start: function () { pcBuild(); PM.c0 = Object.keys(store('psr-pc')).length; },
				tick: function (dt) { pcTick(dt); var s = P1.s, left = PC.g ? PC.g.children.filter(function (m) { return m.visible; }) : [], nd = 1e9; left.forEach(function (m) { nd = Math.min(nd, Math.hypot(s.x - m.sp.x, s.z - m.sp.z)); }); var tot = Object.keys(store('psr-pc')).length;
					pmHud('<b>Postcards · ' + (4 - left.length) + ' of 4 here</b><span>' + (left.length ? 'Nearest ' + Math.round(nd) + ' m · stop on the gold ring to take the photo' : 'All four found on this track. Try another one!') + ' · album ' + tot + '</span>');
					if (!left.length && !PM.all) { PM.all = 1; FX.confetti(stage, 120); say2('Every postcard on this track. Nice work, photographer.', true); } },
				lap: function () { flash('Lap complete · keep exploring', 1200); return true; } };
			function pcAlbum() { var al = store('psr-pc-al'), ks = Object.keys(al), el = $('[data-pm-album]', root); el.innerHTML = '<div><h3>Postcard album</h3><p>' + ks.length + (ks.length === 1 ? ' postcard' : ' postcards') + ' collected. Find the gold rings in Postcard hunt: four on every track.</p><div class="pm__alg">' + (ks.length ? ks.map(function (k) { var a = al[k]; return '<figure><img src="' + a.img + '" alt="Postcard"><figcaption>' + esc(a.car) + '</figcaption></figure>'; }).join('') : '<p>No postcards yet.</p>') + '</div><button type="button" class="pm__db" data-pm-albx>Close</button></div>'; el.hidden = false; }
			/* signature challenge: every car gets its own, built from its specs */
			function medalOf(v, T, low) { var m = 0; T.forEach(function (t) { if (low ? v <= t : v >= t) m++; }); return m; }
			var MEDN = ['No medal', 'Bronze', 'Silver', 'Gold'], MEDE = ['', '🥉', '🥈', '🥇'];
			PMS.sig = { start: function () { var c = P1.c; SIG = sigFor(c); PM.ty = SIG.ty; PM.mx = 0; PM.dirty = 0; var pro = proTime(c, P1.p);
					if (SIG.ty === 'vmax') { var vmk = trk + ':' + c.id + ':' + Math.round(P1.p.P), vmc = store('psr-vm'), vm = vmc[vmk]; if (!vm) { var s0 = spawn(N - 12, 0), kk = {}, t = 0; vm = 0; while (t < 400) { aiDrive(s0, P1.p, kk, 1); if (stepCar(s0, P1.p, kk, 1 / 30)) break; t += 1 / 30; vm = Math.max(vm, s0.v); } vm *= 3.6; vmc[vmk] = vm; put('psr-vm', vmc); } PM.T = [vm * .9, vm * .96, vm * 1.0]; }
					else if (SIG.ty === 'drift') PM.T = [900, 1800, 3000];
					else if (SIG.ty === 'clean') PM.T = [pro * 1.2, pro * 1.1, pro * 1.03];
					else PM.T = [pro * 1.12, pro * 1.06, pro * 1.01];
					PM.low = SIG.ty === 'lap' || SIG.ty === 'clean'; say2(SIG.n + '. ' + SIG.d, true); },
				tick: function (dt) { var s = P1.s, v = 0, u = ''; PM.mx = Math.max(PM.mx, s.v * 3.6); if (PM.ty === 'drift') { driftStep(s, dt); v = Math.round(s.drift + s.dcombo * s.dmul); u = ' pts'; } else if (PM.ty === 'vmax') { v = Math.round(PM.mx); u = ' km/h'; }
					if (PM.ty === 'clean' && P1.started && s.hit > 0 && !PM.dirty) { PM.dirty = 1; flash('Contact! This lap will not count', 1600); FX.play('no'); }
					var tg = PM.T.map(function (t, i) { return MEDE[i + 1] + ' ' + (PM.low ? fmt(t) : Math.round(t) + u); }).join(' · ');
					pmHud('<b>' + esc(SIG.n) + (v ? ' · ' + v.toLocaleString('en-GB') + u : '') + (PM.dirty ? ' · VOID' : '') + '</b><span>' + tg + '</span>'); },
				lap: function (P, tl) { var s = P1.s, v; if (PM.ty === 'drift') { bankDrift(s); v = s.drift; } else if (PM.ty === 'vmax') v = PM.mx; else v = PM.ty === 'clean' && PM.dirty ? null : tl;
					if (v == null) { flash('Contact on that lap · go again', 1800); PM.dirty = 0; return true; }
					var m = medalOf(v, PM.T, PM.low), bk = store('psr-sig'), o = bk[P1.c.id] || { m: 0 }, better = m > o.m || (m === o.m && (o.v == null || (PM.low ? v < o.v : v > o.v))); if (better) { bk[P1.c.id] = { m: m, v: v }; put('psr-sig', bk); }
					var golds = Object.keys(bk).filter(function (k) { return bk[k].m === 3; }).length, nc = cars.filter(function (c) { return c.glb; }).length, vs = PM.low ? fmt(v) : Math.round(v).toLocaleString('en-GB') + (PM.ty === 'vmax' ? ' km/h' : ' points');
					if (m === 3) { FX.confetti(stage, 180); say2('Gold! The ' + P1.c.model + ' signature is yours.', true); } else say2(m ? MEDN[m] + '. ' + (m === 2 ? 'So close to gold.' : 'There is more in that car.') : 'No medal this time. Go again!', true);
					pmEnd('<h3>' + MEDE[m] + ' ' + MEDN[m] + ' · ' + vs + '</h3><p>' + esc(SIG.n) + '.' + (better ? ' Personal best.' : '') + ' Gold on ' + golds + ' of ' + nc + ' cars so far: pick another car for its own challenge.</p>'); return true; } };
			/* car of the day: the same car and track for everyone today */
			PMS.cotd = { start: function () { COTD = cotdPick(); if (P1.c.id !== COTD.c.id) setPlayerCar(P1, COTD.c); var pro = proTime(P1.c, P1.p); PM.T = [pro * 1.1, pro * 1.05, pro * 1.01]; var bk = store('psr-cotd'); PM.best = bk.days && bk.days[COTD.day]; say2('Car of the day: the ' + cname(P1.c) + ' on the ' + TRACKS[trk].name + '.', true); },
				tick: function () { pmHud('<b>Car of the day · ' + esc(cname(P1.c)) + '</b><span>' + PM.T.map(function (t, i) { return MEDE[i + 1] + ' ' + fmt(t); }).join(' · ') + (PM.best ? ' · your best today ' + fmt(PM.best) : '') + '</span>'); },
				lap: function (P, tl) { var bk = store('psr-cotd'), day = COTD.day; bk.days = bk.days || {}; if (bk.last !== day) { bk.streak = bk.last === dayKey(Date.now() - 864e5) ? (bk.streak || 0) + 1 : 1; bk.last = day; } var nb = !bk.days[day] || tl < bk.days[day]; if (nb) bk.days[day] = tl; var ks = Object.keys(bk.days).sort(); if (ks.length > 60) delete bk.days[ks[0]]; put('psr-cotd', bk); PM.best = bk.days[day];
					var m = medalOf(tl, PM.T, true); PM.card = cotdCard(tl, m, bk.streak || 1); if (m === 3) FX.confetti(stage, 180); say2(m === 3 ? 'Gold on the car of the day!' : nb ? 'A new best for today.' : 'Not your best today. Go again?', true);
					pmEnd('<h3>' + MEDE[m] + ' ' + fmt(tl) + '</h3><p>Car of the day, ' + day + ': ' + esc(cname(P1.c)) + ' on the ' + TRACKS[trk].name + '. ' + (nb ? 'Your best today.' : 'Your best today: ' + fmt(bk.days[day]) + '.') + ' Day streak: ' + (bk.streak || 1) + '. A new car arrives tomorrow.</p><button type="button" class="pm__db" data-pm-card>Share my result card</button>'); return true; } };
			function cotdCard(t, m, streak) { var cv = d.createElement('canvas'); cv.width = 1080; cv.height = 1080; var x = cv.getContext('2d'); x.fillStyle = '#0b0b0d'; x.fillRect(0, 0, 1080, 1080);
				try { R.render(S, C); var src = R.domElement, sw = src.width, sh = src.height, cw = Math.min(sw, sh * 1080 / 620), ch = cw * 620 / 1080; x.drawImage(src, (sw - cw) / 2, (sh - ch) / 2, cw, ch, 0, 0, 1080, 620); } catch (e) {}
				var g = x.createLinearGradient(0, 380, 0, 700); g.addColorStop(0, 'rgba(11,11,13,0)'); g.addColorStop(1, '#0b0b0d'); x.fillStyle = g; x.fillRect(0, 380, 1080, 320);
				var g0 = x.createLinearGradient(0, 0, 0, 220); g0.addColorStop(0, 'rgba(11,11,13,.85)'); g0.addColorStop(1, 'rgba(11,11,13,0)'); x.fillStyle = g0; x.fillRect(0, 0, 1080, 220); x.fillStyle = '#f1d27a'; x.font = '600 34px Georgia, serif'; x.fillText('LAQIM RACING · CAR OF THE DAY', 64, 96); x.fillStyle = '#fff'; x.font = '400 30px Georgia, serif'; x.fillText(COTD.day, 64, 140);
				x.font = '700 150px Georgia, serif'; x.fillText(fmt(t), 64, 800); x.font = '400 44px Georgia, serif'; x.fillText(cname(P1.c), 64, 870); x.fillStyle = 'rgba(255,255,255,.7)'; x.font = '400 34px Georgia, serif'; x.fillText(TRACKS[trk].name + ' · ' + MEDN[m] + ' · day streak ' + streak, 64, 926);
				x.fillStyle = '#f1d27a'; x.font = '600 30px Georgia, serif'; x.fillText('Beat me at laqimautoworld.com/play', 64, 1010); return cv; }
			function cardShare(cv) { cv.toBlob(function (b) { if (!b) return; var f = new File([b], 'laqim-car-of-the-day.png', { type: 'image/png' }); if (navigator.canShare && navigator.canShare({ files: [f] })) navigator.share({ files: [f], title: 'Laqim Racing · Car of the day' }).catch(function () {}); else { var a = d.createElement('a'); a.href = URL.createObjectURL(b); a.download = f.name; a.click(); } }, 'image/png'); }
			on(root, 'click', function (e) { var t = e.target && e.target.closest ? e.target.closest('[data-pm-rpgo],[data-pm-rpclip],[data-pm-rpx],[data-pm-card],[data-pm-albx]') : null; if (!t) return; if (t.hasAttribute('data-pm-rpgo')) rpStart(); else if (t.hasAttribute('data-pm-rpclip')) rpClip(); else if (t.hasAttribute('data-pm-rpx')) rpStop(); else if (t.hasAttribute('data-pm-card')) { if (PM && PM.card) cardShare(PM.card); } else if (t.hasAttribute('data-pm-albx')) $('[data-pm-album]', root).hidden = true; });
			/* slipstream: tuck in behind a car and the air resistance drops */
			function draftAll() { var L = allCars(); L.forEach(function (a) { var s = a.s, sp = Math.hypot(s.vx || 0, s.vz || 0), d0 = 0; if (sp < 15) { s.draft = 0; return; } var ux = s.vx / sp, uz = s.vz / sp; L.forEach(function (b) { if (b === a) return; var dx = b.s.x - s.x, dz = b.s.z - s.z, along = dx * ux + dz * uz, lat = Math.abs(dx * uz - dz * ux); if (along > 3 && along < 28 && lat < 2.4) d0 = Math.max(d0, (1 - along / 28) * (1 - lat / 2.4 * .5)); }); s.draft = (s.draft || 0) + (d0 - (s.draft || 0)) * .1; }); }
			/* the bill: crash damage priced against the car's value */
			var MAKEF = { 'Rolls-Royce': 1.45, 'Bugatti': 3.2, 'Bentley': 1.05, 'Lamborghini': .95, 'Ferrari': .92, 'McLaren': .88, 'Aston Martin': .86, 'Porsche': .74, 'Mercedes-Benz': .66, 'Mercedes-AMG': .7, 'Mercedes-Maybach': 1.05, 'Maybach': 1.05, 'Land Rover': .62, 'BMW': .52, 'Audi': .56, 'Lexus': .55, 'Toyota': .42, 'Nissan': .45, 'Koenigsegg': 2.4, 'Pagani': 3, 'Rimac': 2.2 };
			function carValue(c) { return Math.round((c.hp * 470 * (MAKEF[c.make] || .6) + 25000) / 1000) * 1000; }
			function billAdd(sv, k, fwd, side) { var P = sv === P1.s ? P1 : sv === (P2 && P2.s) ? P2 : null; if (!P || !P.c || k <= 0) return; var v = carValue(P.c), it = fwd > .8 ? [['Front bumper and splitter', .05], ['Headlights', .03], ['Bonnet', .025], ['Radiator', .02]] : fwd < -.8 ? [['Rear bumper and diffuser', .045], ['Tail lights', .02], ['Exhaust', .015]] : [[side > 0 ? 'Right-side doors and panels' : 'Left-side doors and panels', .05], ['Mirror', .006], ['Wheel and tyre', .012], ['Suspension arm', .015]]; P.bill = P.bill || {}; it.forEach(function (q) { var c0 = Math.round(v * q[1] * Math.min(1.5, k * 3)); P.bill[q[0]] = (P.bill[q[0]] || 0) + c0; }); P.billT = Object.keys(P.bill).reduce(function (a, q) { return a + P.bill[q]; }, 0); }
			function billHtml(P) { if (!P.billT) return ''; var rows = Object.keys(P.bill).sort(function (a, b) { return P.bill[b] - P.bill[a]; }).map(function (q) { return '<tr><td>' + esc(q) + '</td><td>$' + P.bill[q].toLocaleString('en-GB') + '</td></tr>'; }).join(''); return '<details class="pm__bill"><summary>Damage bill: <b>$' + P.billT.toLocaleString('en-GB') + '</b></summary><table>' + rows + '<tr class="is-tot"><td>Labour, paint and detailing</td><td>$' + Math.round(P.billT * .18).toLocaleString('en-GB') + '</td></tr><tr class="is-tot"><td>Total owed to Laqim</td><td>$' + Math.round(P.billT * 1.18).toLocaleString('en-GB') + '</td></tr></table></details>'; }
			/* commentator */
			var sayT = 0; function say2(t, force) { if (!commOn || !w.speechSynthesis) return; var nw = performance.now(); if (!force && nw - sayT < 2600) return; sayT = nw; try { if (!voice) { var vs = speechSynthesis.getVoices(); voice = vs.filter(function (v) { return /en-GB/i.test(v.lang); })[0] || vs.filter(function (v) { return /^en/i.test(v.lang); })[0] || null; } speechSynthesis.cancel(); var u = new SpeechSynthesisUtterance(t); if (voice) u.voice = voice; u.rate = 1.12; u.pitch = 1.05; speechSynthesis.speak(u); } catch (e) {} }
			function commTick() { if (!commOn || !P1.s || !P1.started) return; var s = P1.s; if (Math.abs(s.slip || 0) > .35 && s.v > 14 && Math.random() < .02) say2(['Look at that slide!', 'Sideways! Beautiful!', 'He is hanging the tail out!'][(Math.random() * 3) | 0]); if (s.hit > .3 && !commHit) { commHit = 1; say2(['Oh, that is going to cost him!', 'Big impact!', 'Ouch! The bill is climbing!'][(Math.random() * 3) | 0]); setTimeout(function () { commHit = 0; }, 3000); } if (race && race.phase === 'run' && (mode === 'race' || mode === 'roulette' || mode === 'ko')) { var p0 = placing().findIndex(function (r) { return r.me; }) + 1; if (commPos && p0 < commPos) say2(['Up into P' + p0 + '!', 'A brilliant pass! P' + p0 + '!', 'He is through! Now P' + p0 + '.'][(Math.random() * 3) | 0]); else if (commPos && p0 > commPos) say2('He loses a place. Down to P' + p0 + '.'); commPos = p0; } }
			var commHit = 0, commPos = 0;
			function world(key) {
				disposeWorld(); W = new T.Group(); S.add(W); var tk = TRACKS[key]; theme = tk.theme; Wd = tk.Wd; offSurf = tk.off; obsGrid = {}; barrierD = key === 'night' ? Wd / 2 + 1.1 : key === 'circuit' ? Wd / 2 + 9 : 0; barrierE = key === 'night' ? .12 : .3; barrierF = key === 'night' ? .25 : .55; barOK = null;
				/* terrain height: rolling for the trail, flat elsewhere */
				N = tk.N || 900; var hA = tk.hAmp || 1;
				H = tk.hills ? function (x, z) { return hA * HB(x, z); } : function () { return 0; }; function HB(x, z) { return 2.6 * Math.sin(x * .021 + 1.3) + 2.2 * Math.cos(z * .026) + 1.3 * Math.sin((x + z) * .047) + .6 * Math.sin(x * .11) * Math.cos(z * .09); }
				var curve = new T.CatmullRomCurve3(tk.P.map(function (p) { return new T.Vector3(p[0], 0, p[1]); }), true, 'centripetal'); pts = curve.getSpacedPoints(N).slice(0, N); seg = curve.getLength() / N; tang = []; nor = []; curv = []; hAt = [];
				for (var i = 0; i < N; i++) { var a = pts[(i - 1 + N) % N], b = pts[(i + 1) % N], t = b.clone().sub(a).normalize(); tang.push(t); nor.push(new T.Vector3(-t.z, 0, t.x)); hAt.push(H(pts[i].x, pts[i].z)); }
				for (i = 0; i < N; i++) curv.push(tang[(i + 4) % N].angleTo(tang[(i - 4 + N) % N]));
				surfAt = []; for (i = 0; i < N; i++) { var f = i / N, s = tk.base || 'tarmac'; if (tk.segs) tk.segs.forEach(function (sg) { if (f >= sg[0] && f < sg[1]) s = sg[2]; }); if (key === 'trail') { s = 'dirt'; if ((f > .18 && f < .225) || (f > .72 && f < .76)) s = 'mud'; if (f > .52 && f < .555) s = 'water'; } surfAt.push(s); }
				kap = new Float32Array(N); for (i = 0; i < N; i++) { var pa = pts[(i - 6 + N) % N], pb = pts[i], pc = pts[(i + 6) % N], abx = pb.x - pa.x, abz = pb.z - pa.z, bcx = pc.x - pb.x, bcz = pc.z - pb.z, cr = abx * bcz - abz * bcx, la = Math.hypot(abx, abz), lb = Math.hypot(bcx, bcz), lc = Math.hypot(pc.x - pa.x, pc.z - pa.z); kap[i] = Math.abs(2 * cr / (la * lb * lc + 1e-6)); }
				vBase = []; for (i = 0; i < N; i++) { var mc = 0; for (var j = 0; j < 70; j += 2) mc = Math.max(mc, curv[(i + j) % N] * (1 - j / 140)); vBase.push(Math.sqrt(9.81 * 8 * seg / Math.max(mc, 1e-3))); }
				/* sky and light per theme */
				var night = theme === 'night' || !!tk.dark, sav = theme === 'savanna', HOR = night ? 0x0b0d16 : sav ? 0xf0c890 : 0xe8d2a2;
				S.fog.color.setHex(HOR); S.background.setHex(HOR); S.fog.near = night ? 60 : 120; S.fog.far = night ? 330 : 460;
				skyM.uniforms.top.value.setHex(night ? 0x05060c : sav ? 0x4a86c0 : 0x3d78b8); skyM.uniforms.hor.value.setHex(night ? 0x1a1c2c : sav ? 0xf6cf8e : 0xf2d9a4); skyM.uniforms.sk.value = night ? 0 : 1;
				hemi.color.setHex(night ? 0x8090c0 : 0xfff1d6); hemi.groundColor.setHex(night ? 0x101018 : sav ? 0x6a4a2a : 0x4a5a36); hemi.intensity = night ? .35 : .7; sun.intensity = night ? .25 : 1.15; sun.color.setHex(night ? 0x8899cc : sav ? 0xffcf8a : 0xffdcaa);
				R.toneMappingExposure = night ? 1.05 : .82;
				/* ground: a height-mapped grid that matches the track */
				var gG = new T.PlaneGeometry(1500, 1500, tk.hills ? 150 : 1, tk.hills ? 150 : 1); gG.rotateX(-Math.PI / 2); if (tk.hills) { var gp = gG.attributes.position, rr0 = Wd / 2 + 9; for (i = 0; i < gp.count; i++) { var gx0 = gp.getX(i), gz0 = gp.getZ(i) + 110, md = 1e9; for (var q0 = 0; q0 < N; q0 += 4) { var ddx = pts[q0].x - gx0, ddz = pts[q0].z - gz0, dd0 = ddx * ddx + ddz * ddz; if (dd0 < md) md = dd0; } md = Math.sqrt(md); gp.setY(i, H(gx0, gz0) - .08 - (md < rr0 ? .9 * (1 - md / rr0) : 0)); } /* the ground dips slightly under the trail so it never pokes through */ gG.translate(0, 0, 110); gG.computeVertexNormals(); } else gG.translate(0, -.02, 110);
				W.add(new T.Mesh(gG, new T.MeshStandardMaterial({ color: lin(night ? 0x14161c : sav ? 0x9a6a3c : 0x4f6b34), roughness: 1, envMapIntensity: .15 })));
				function ribbon(o0, o1, y, mat, from, to) { var pos = [], idx = [], n0 = from || 0, n1 = to == null ? N : to, q = 0; for (var i = n0; i <= n1; i++) { var k = i % N, p = pts[k], n = nor[k], x0 = p.x + n.x * o0, z0 = p.z + n.z * o0, x1 = p.x + n.x * o1, z1 = p.z + n.z * o1; pos.push(x0, H(x0, z0) + y, z0, x1, H(x1, z1) + y, z1); if (i < n1) { idx.push(q, q + 1, q + 2, q + 1, q + 3, q + 2); } q += 2; } var g = new T.BufferGeometry(); g.setAttribute('position', new T.Float32BufferAttribute(pos, 3)); g.setIndex(idx); g.computeVertexNormals(); var m = new T.Mesh(g, mat); W.add(m); return m; }
				if (tk.rally) rallyRoad(tk, ribbon);
				else if (key === 'trail') {
					ribbon(-Wd / 2 - 2.5, Wd / 2 + 2.5, .03, new T.MeshStandardMaterial({ color: lin(0xb4703c), roughness: 1, envMapIntensity: .1 }));
					ribbon(-Wd / 2, Wd / 2, .06, new T.MeshStandardMaterial({ color: lin(0xa45a2e), roughness: 1, envMapIntensity: .1, side: T.DoubleSide }));
					[-2.2, 2.2].forEach(function (o) { ribbon(o - .45, o + .45, .08, new T.MeshStandardMaterial({ color: lin(0x7e4220), roughness: 1 })); }); /* wheel ruts */
					[[.18, .225], [.72, .76]].forEach(function (r) { ribbon(-Wd / 2 + .3, Wd / 2 - .3, .1, new T.MeshStandardMaterial({ color: lin(0x3c2a1c), roughness: .35, metalness: .1 }), Math.floor(r[0] * N), Math.floor(r[1] * N)); });
					(function () { /* a shallow ford: water fades out at its banks instead of ending in a hard edge */
						var a0 = Math.floor(.515 * N), a1 = Math.floor(.56 * N), OF = [-Wd / 2 - 9, -Wd / 2 - 2, 0, Wd / 2 + 2, Wd / 2 + 9], AL = [0, .78, .86, .78, 0], pos = [], colr = [], idx = [], q = 0, cw = new T.Color(0x2a5263).convertSRGBToLinear();
						for (var i = a0; i <= a1; i++) { var k = i % N, p = pts[k], n = nor[k], e = Math.min(1, (i - a0) / 5, (a1 - i) / 5); OF.forEach(function (o, j) { var x = p.x + n.x * o, z = p.z + n.z * o; pos.push(x, H(x, z) + .12, z); colr.push(cw.r, cw.g, cw.b, AL[j] * e); }); if (i < a1) for (var j = 0; j < 4; j++) { var r0 = q + j; idx.push(r0, r0 + 5, r0 + 1, r0 + 1, r0 + 5, r0 + 6); } q += 5; }
						var g = new T.BufferGeometry(); g.setAttribute('position', new T.Float32BufferAttribute(pos, 3)); g.setAttribute('color', new T.Float32BufferAttribute(colr, 4)); g.setIndex(idx); g.computeVertexNormals();
						var wm = new T.Mesh(g, new T.MeshStandardMaterial({ vertexColors: true, transparent: true, roughness: .55, metalness: 0, envMapIntensity: .2, depthWrite: false, side: T.DoubleSide })); wm.renderOrder = 2; W.add(wm);
					})();
				} else if (night) {
					ribbon(-Wd / 2 - 1, Wd / 2 + 1, .01, new T.MeshStandardMaterial({ color: lin(0x3a3a40), roughness: .9 }));
					ribbon(-Wd / 2, Wd / 2, .02, new T.MeshStandardMaterial({ color: lin(0x1d1e22), roughness: .55, metalness: .15, envMapIntensity: .5, side: T.DoubleSide }));
					var ln = new T.MeshBasicMaterial({ color: 0xf1d27a }); ribbon(-.12, .12, .03, new T.MeshBasicMaterial({ color: 0xe8e8e8 })); ribbon(Wd / 2 - .5, Wd / 2 - .3, .03, ln); ribbon(-Wd / 2 + .3, -Wd / 2 + .5, .03, ln);
					/* concrete walls with a gold stripe */
					var wallM = new T.MeshStandardMaterial({ color: lin(0xb9b6ae), roughness: .9 }), strM = new T.MeshBasicMaterial({ color: 0xc99a3a });
					[-1, 1].forEach(function (sd) { var pos = [], idx = [], q = 0; for (var i = 0; i <= N; i++) { var k = i % N, p = pts[k], n = nor[k], o = sd * (Wd / 2 + 1.1), x = p.x + n.x * o, z = p.z + n.z * o; pos.push(x, 0, z, x, 1.15, z); if (i < N) idx.push(q, q + 1, q + 2, q + 1, q + 3, q + 2); q += 2; } var g = new T.BufferGeometry(); g.setAttribute('position', new T.Float32BufferAttribute(pos, 3)); g.setIndex(idx); g.computeVertexNormals(); var mw = new T.Mesh(g, wallM); mw.material.side = T.DoubleSide; W.add(mw); ribbon(sd * (Wd / 2 + 1.05), sd * (Wd / 2 + 1.15), 1.0, strM); });
				} else {
					ribbon(-Wd / 2 - 3, Wd / 2 + 3, .0, new T.MeshStandardMaterial({ color: lin(0x7d6a4c), roughness: 1, envMapIntensity: .15 }));
					ribbon(-Wd / 2, Wd / 2, .02, new T.MeshStandardMaterial({ color: lin(0x2b2b2f), roughness: .9, envMapIntensity: .25, side: T.DoubleSide }));
					var lineM = new T.MeshBasicMaterial({ color: 0xf2f2f2 }); ribbon(Wd / 2 - .55, Wd / 2 - .3, .03, lineM); ribbon(-Wd / 2 + .3, -Wd / 2 + .55, .03, lineM);
					var kerbs = []; for (i = 0; i < N; i += 2) if (curv[i] > .09) [-1, 1].forEach(function (sd) { kerbs.push([i, sd]); });
					var kerb = new T.InstancedMesh(new T.BoxGeometry(2.6, .1, 1.1), new T.MeshStandardMaterial({ roughness: .6 }), Math.max(1, kerbs.length)); W.add(kerb);
					kerbs.forEach(function (k, j) { var p = pts[k[0]], n = nor[k[0]], t = tang[k[0]]; Q.setFromUnitVectors(new T.Vector3(1, 0, 0), t); M4.compose(new T.Vector3(p.x + n.x * k[1] * (Wd / 2 + .5), .05, p.z + n.z * k[1] * (Wd / 2 + .5)), Q, new T.Vector3(1, 1, 1)); kerb.setMatrixAt(j, M4); kerb.setColorAt(j, col.setHex(Math.floor(k[0] / 2) % 2 ? 0xd8262c : 0xf2f2f2).convertSRGBToLinear()); });
					var tw = []; for (var q = 0; q < N; q += 2) { if (curv[q] < .09) continue; var t1 = tang[q], t2 = tang[(q + 4) % N], dd = (t2.x - t1.x) * nor[q].x + (t2.z - t1.z) * nor[q].z; for (var lv = 0; lv < 2; lv++) tw.push([q, dd > 0 ? -1 : 1, lv]); }
					if (tw.length) { var tm = new T.MeshStandardMaterial({ color: 0xffffff, roughness: .9 }), ti = new T.InstancedMesh(new T.CylinderGeometry(.42, .42, .36, 10), tm, tw.length * 3), k3 = 0; tw.forEach(function (e) { var p3 = pts[e[0]], n3 = nor[e[0]], t3 = tang[e[0]]; for (var a3 = -1; a3 <= 1; a3++) { M4.makeTranslation(p3.x + n3.x * e[1] * (Wd / 2 + 5.2) + t3.x * a3 * .86, .18 + e[2] * .36, p3.z + n3.z * e[1] * (Wd / 2 + 5.2) + t3.z * a3 * .86); ti.setMatrixAt(k3, M4); ti.setColorAt(k3, col.set(e[2] && (e[0] / 2 + a3) % 4 === 0 ? 0xc99a3a : 0x161618)); k3++; } }); W.add(ti); }
				}
				/* where a barrier would cut across another part of the track, leave a gap */
				if (barrierD) { barOK = []; for (var bk = 0; bk < N; bk++) { var okS = [1, 1]; [-1, 1].forEach(function (sd, si) { var bx = pts[bk].x + nor[bk].x * sd * barrierD, bz = pts[bk].z + nor[bk].z * sd * barrierD; for (var j2 = 0; j2 < N; j2 += 3) { var di = Math.abs(j2 - bk); if (Math.min(di, N - di) < 30) continue; var ex = pts[j2].x - bx, ez = pts[j2].z - bz; if (ex * ex + ez * ez < Math.pow(Wd / 2 + 3, 2)) { okS[si] = 0; break; } } }); barOK.push(okS); } }
				if (key === 'circuit') { /* tyre walls and armco at the edge of the run-off */
					var tyreG = new T.CylinderGeometry(.42, .42, .9, 10), tyres = [], stepT = Math.max(1, Math.round(1.05 / seg));
					for (var tk2 = 0; tk2 < N; tk2 += stepT) [-1, 1].forEach(function (sd, si) { if (!barOK[tk2][si]) return; var bx = pts[tk2].x + nor[tk2].x * sd * (barrierD + .45), bz = pts[tk2].z + nor[tk2].z * sd * (barrierD + .45); tyres.push([bx, bz, tk2]); });
					var tyreM = new T.InstancedMesh(tyreG, new T.MeshStandardMaterial({ roughness: .85 }), tyres.length), tcol = new T.Color(); tyres.forEach(function (t, j) { M4.makeTranslation(t[0], H(t[0], t[1]) + .45, t[1]); tyreM.setMatrixAt(j, M4); tyreM.setColorAt(j, tcol.set(Math.floor(t[2] / (stepT * 4)) % 2 ? 0x111114 : (Math.floor(t[2] / (stepT * 8)) % 2 ? 0xe8e4dc : 0xb3202a))); }); tyreM.castShadow = true; W.add(tyreM);
				}
				/* start line and gantry (every track) */
				var cc = d.createElement('canvas'); cc.width = 256; cc.height = 32; var cx2 = cc.getContext('2d'); for (var a2 = 0; a2 < 16; a2++) for (var b2 = 0; b2 < 2; b2++) { cx2.fillStyle = (a2 + b2) % 2 ? '#111' : '#fff'; cx2.fillRect(a2 * 16, b2 * 16, 16, 16); }
				var line = new T.Mesh(new T.PlaneGeometry(Wd, 2), new T.MeshBasicMaterial({ map: new T.CanvasTexture(cc) })); line.rotation.x = -Math.PI / 2; line.rotation.z = Math.atan2(-tang[0].x, -tang[0].z); line.position.set(pts[0].x, hAt[0] + .1, pts[0].z); W.add(line);
				var goldM = new T.MeshStandardMaterial({ color: lin(0xc99a3a), metalness: .7, roughness: .3, emissive: night ? lin(0x3a2a08) : 0x000000 });
				[-1, 1].forEach(function (sd) { var post = new T.Mesh(new T.BoxGeometry(.6, 7, .6), goldM), px0 = pts[0].x + nor[0].x * sd * (Wd / 2 + 1.5), pz0 = pts[0].z + nor[0].z * sd * (Wd / 2 + 1.5); post.position.set(px0, H(px0, pz0) + 3.5, pz0); W.add(post); addObs(px0, pz0, .5); });
				var beamF = new T.MeshBasicMaterial({ map: signTex(1024, 96, '#0d0d10', '#d4ad57', tk.gantry ? tk.gantry : key === 'trail' ? 'R I F T   V A L L E Y   T R A I L' : night ? 'N A I R O B I   N I G H T   R U N' : 'L A Q I M   A U T O W O R L D', 46) }), beamD = new T.MeshStandardMaterial({ color: lin(0x111114) });
				var beam = new T.Mesh(new T.BoxGeometry(Wd + 4, 1.4, .6), [beamD, beamD, beamD, beamD, beamF, beamF]); beam.position.set(pts[0].x, hAt[0] + 7, pts[0].z); beam.rotation.y = Math.atan2(-nor[0].z, nor[0].x); W.add(beam);
				/* trackside boards */
				(function () { var bm = [new T.MeshBasicMaterial({ map: signTex(512, 64, '#0d0d10', '#d4ad57', 'LAQIM AUTOWORLD', 34), side: T.DoubleSide }), new T.MeshBasicMaterial({ map: signTex(512, 64, '#c99a3a', '#0d0d10', night ? 'NAIROBI NIGHTS' : sav ? 'KARIBU KENYA' : 'THE COLLECTION', 34), side: T.DoubleSide })], spots = [[], []];
					for (var q = 8; q < N - 8; q += 11) { if (curv[q] > .05) continue; spots[(q / 11 | 0) % 4 < 2 ? 0 : 1].push([q, (q / 11 | 0) % 2 ? 1 : -1]); }
					var bg = new T.PlaneGeometry(8, 1.3); bg.translate(0, .9, 0);
					spots.forEach(function (lst, mi) { if (!lst.length) return; var im = new T.InstancedMesh(bg, bm[mi], lst.length); lst.forEach(function (sp, k2) { var p2 = pts[sp[0]], n2 = nor[sp[0]], off = Wd / 2 + (night ? 1.6 : 4.2), x = p2.x + n2.x * sp[1] * off, z = p2.z + n2.z * sp[1] * off; M4.compose(new T.Vector3(x, H(x, z) + (night ? 1.2 : 0), z), Q.setFromAxisAngle(Y, Math.atan2(-n2.x * sp[1], -n2.z * sp[1])), new T.Vector3(1, 1, 1)); im.setMatrixAt(k2, M4); }); W.add(im); }); })();
				/* scenery */
				function clear(x, z, r) { for (var j = 0; j < N; j += 6) { var dx = pts[j].x - x, dz = pts[j].z - z; if (dx * dx + dz * dz < r * r) return false; } return true; }
				var hm = new T.InstancedMesh(new T.SphereGeometry(1, 10, 6), new T.MeshStandardMaterial({ color: lin(night ? 0x0e1014 : sav ? 0x7a5636 : 0x47603a), roughness: 1, flatShading: true }), 30);
				var bigR = 0; for (q = 0; q < N; q += 10) bigR = Math.max(bigR, Math.hypot(pts[q].x - 30, pts[q].z - 110)); for (q = 0; q < 30; q++) { var an = q / 30 * Math.PI * 2, rr = Math.max(360, bigR + 140) + Math.random() * 70, sx = 40 + Math.random() * 60; M4.makeScale(sx, (sav ? 30 : 18) + Math.random() * (sav ? 70 : 40), sx * .8).setPosition(Math.cos(an) * rr + 30, -4, Math.sin(an) * rr + 110); hm.setMatrixAt(q, M4); } W.add(hm);
				if (sav) {
					/* acacias: flat crowns on thin trunks, plus rocks and dry grass tufts */
					var ac = []; for (var tr = 0; tr < 3000 && ac.length < 120; tr++) { var x = (Math.random() - .5) * 760, z = (Math.random() - .5) * 760 + 110; if (clear(x, z, 22)) ac.push([x, z, .8 + Math.random() * .9]); }
					var crown = new T.InstancedMesh(new T.SphereGeometry(1, 9, 5), new T.MeshStandardMaterial({ color: lin(0x52622c), roughness: 1, flatShading: true }), ac.length), trunk = new T.InstancedMesh(new T.CylinderGeometry(.18, .3, 1, 5), new T.MeshStandardMaterial({ color: lin(0x4a3424), roughness: 1 }), ac.length);
					ac.forEach(function (t, j) { addObs(t[0], t[1], .3 * t[2] + .12); var y0 = H(t[0], t[1]); M4.makeScale(5.5 * t[2], 1.1 * t[2], 5 * t[2]).setPosition(t[0], y0 + 5.6 * t[2], t[1]); crown.setMatrixAt(j, M4); M4.makeScale(t[2], 5.4 * t[2], t[2]).setPosition(t[0], y0 + 2.7 * t[2], t[1]); trunk.setMatrixAt(j, M4); }); W.add(crown); W.add(trunk);
					var rk = []; for (tr = 0; tr < 2000 && rk.length < 90; tr++) { x = (Math.random() - .5) * 520; z = (Math.random() - .5) * 520 + 110; if (clear(x, z, Wd / 2 + 4)) rk.push([x, z, .5 + Math.random() * 1.6]); }
					var rock = new T.InstancedMesh(new T.DodecahedronGeometry(1, 0), new T.MeshStandardMaterial({ color: lin(0x6e5a48), roughness: 1, flatShading: true }), rk.length); rk.forEach(function (r, j) { if (r[2] > .8) addObs(r[0], r[1], r[2] * .8); M4.compose(new T.Vector3(r[0], H(r[0], r[1]) + r[2] * .3, r[1]), Q.setFromAxisAngle(Y, r[0]), new T.Vector3(r[2], r[2] * .7, r[2] * 1.2)); rock.setMatrixAt(j, M4); }); W.add(rock);
					/* marker poles every corner, rally style */
					var poles = []; for (q = 0; q < N; q += 18) if (curv[q] > .06) poles.push(q); var pm2 = new T.InstancedMesh(new T.CylinderGeometry(.12, .12, 1.6, 6), new T.MeshStandardMaterial({ color: 0xffffff }), Math.max(1, poles.length * 2)), pk = 0; poles.forEach(function (q2) { [-1, 1].forEach(function (sd) { var x2 = pts[q2].x + nor[q2].x * sd * (Wd / 2 + 1), z2 = pts[q2].z + nor[q2].z * sd * (Wd / 2 + 1); M4.makeTranslation(x2, H(x2, z2) + .8, z2); pm2.setMatrixAt(pk, M4); pm2.setColorAt(pk, col.set(pk % 2 ? 0xd8262c : 0xf2f2f2)); pk++; }); }); W.add(pm2);
				} else if (night) {
					/* city blocks with lit windows, and street lamps */
					var wc = d.createElement('canvas'); wc.width = 64; wc.height = 128; var wx = wc.getContext('2d'); wx.fillStyle = '#0b0c12'; wx.fillRect(0, 0, 64, 128); for (var yy = 4; yy < 128; yy += 9) for (var xx = 4; xx < 64; xx += 9) { if (Math.random() < .55) { wx.fillStyle = Math.random() < .2 ? '#f6d48a' : Math.random() < .5 ? '#c9b98a' : '#7a8ab0'; wx.fillRect(xx, yy, 5, 6); } }
					var wt = new T.CanvasTexture(wc); wt.encoding = T.sRGBEncoding; wt.wrapS = wt.wrapT = T.RepeatWrapping; wt.repeat.set(2, 3);
					var bl = []; for (tr = 0; tr < 3000 && bl.length < 110; tr++) { x = (Math.random() - .5) * 640; z = (Math.random() - .5) * 640 + 110; if (clear(x, z, 16 + Wd)) bl.push([x, z, 10 + Math.random() * 14, 10 + Math.random() * 14, 14 + Math.random() * 70]); }
					var bm2 = new T.InstancedMesh(new T.BoxGeometry(1, 1, 1), new T.MeshStandardMaterial({ map: wt, emissive: 0xffffff, emissiveMap: wt, emissiveIntensity: .9, roughness: .8, color: 0x444444 }), bl.length); bl.forEach(function (b0, j) { M4.makeScale(b0[2], b0[4], b0[3]).setPosition(b0[0], b0[4] / 2, b0[1]); bm2.setMatrixAt(j, M4); }); W.add(bm2);
					var lamps = []; for (q = 0; q < N; q += 22) lamps.push(q); var poleG = new T.InstancedMesh(new T.CylinderGeometry(.12, .16, 8, 6), new T.MeshStandardMaterial({ color: lin(0x2a2a30) }), lamps.length * 2), bulb = new T.InstancedMesh(new T.SphereGeometry(.5, 8, 6), new T.MeshBasicMaterial({ color: 0xffe2a8 }), lamps.length * 2), pool = new T.InstancedMesh(new T.CircleGeometry(5.5, 20), new T.MeshBasicMaterial({ color: 0xffd38a, transparent: true, opacity: .16, depthWrite: false }), lamps.length * 2), lk = 0;
					pool.geometry.rotateX(-Math.PI / 2);
					lamps.forEach(function (q2) { [-1, 1].forEach(function (sd) { var x2 = pts[q2].x + nor[q2].x * sd * (Wd / 2 + 1.8), z2 = pts[q2].z + nor[q2].z * sd * (Wd / 2 + 1.8); M4.makeTranslation(x2, 4, z2); poleG.setMatrixAt(lk, M4); M4.makeTranslation(x2 - nor[q2].x * sd * 1.2, 8, z2 - nor[q2].z * sd * 1.2); bulb.setMatrixAt(lk, M4); M4.makeTranslation(x2 - nor[q2].x * sd * 3, .05, z2 - nor[q2].z * sd * 3); pool.setMatrixAt(lk, M4); lk++; }); }); W.add(poleG); W.add(bulb); W.add(pool);
				} else {
					var trees = []; for (tr = 0; tr < 4000 && trees.length < 160; tr++) { x = (Math.random() - .5) * 700; z = (Math.random() - .5) * 700 + 100; if (clear(x, z, 26)) trees.push([x, z, .8 + Math.random() * .8]); }
					var cr2 = new T.InstancedMesh(new T.ConeGeometry(2.6, 7, 7), new T.MeshStandardMaterial({ color: lin(0x2f4a24), roughness: 1, flatShading: true }), trees.length), tk2 = new T.InstancedMesh(new T.CylinderGeometry(.25, .35, 2.4, 6), new T.MeshStandardMaterial({ color: lin(0x5a4330) }), trees.length);
					trees.forEach(function (t, j) { M4.makeScale(t[2], t[2], t[2]).setPosition(t[0], 3.5 * t[2] + 1.6, t[1]); cr2.setMatrixAt(j, M4); M4.makeScale(t[2], t[2], t[2]).setPosition(t[0], 1.2 * t[2], t[1]); tk2.setMatrixAt(j, M4); }); W.add(cr2); W.add(tk2);
					var stand = new T.Group(), stM = new T.MeshStandardMaterial({ color: lin(0x2a2a2e), roughness: .7 }), crowdC = d.createElement('canvas'); crowdC.width = 512; crowdC.height = 32; (function () { var x4 = crowdC.getContext('2d'), pal = ['#c99a3a', '#e8e2d4', '#8a1c1c', '#1d2b4a', '#3a3a3e', '#f1d27a', '#5b5b60']; x4.fillStyle = '#1a1a1d'; x4.fillRect(0, 0, 512, 32); for (var u = 0; u < 512; u += 5) { x4.fillStyle = pal[(Math.random() * pal.length) | 0]; x4.fillRect(u + 1, 8 + Math.random() * 6, 3, 14); } })();
					var crowdT = new T.CanvasTexture(crowdC); crowdT.encoding = T.sRGBEncoding; crowdT.wrapS = T.RepeatWrapping; crowdT.repeat.set(10, 1); var crowdM = new T.MeshStandardMaterial({ map: crowdT, roughness: .9 });
					for (tr = 0; tr < 5; tr++) { var step = new T.Mesh(new T.BoxGeometry(60, 1.2, 2), [stM, stM, stM, stM, crowdM, stM]); step.position.set(0, .6 + tr * 1.2, 4 - tr * 2); stand.add(step); var base = new T.Mesh(new T.BoxGeometry(60, tr * 1.2 + .01, 2), stM); base.position.set(0, tr * .6, 4 - tr * 2); stand.add(base); }
					var roof = new T.Mesh(new T.BoxGeometry(62, .4, 12), goldM); roof.position.set(0, 10.5, 0); stand.add(roof); [-29, 0, 29].forEach(function (px) { var c2 = new T.Mesh(new T.BoxGeometry(.5, 10.5, .5), stM); c2.position.set(px, 5.25, -5.5); stand.add(c2); });
					var sI = -1, sS = -1; [N - 30, N - 90, Math.floor(N * .25), Math.floor(N * .5), Math.floor(N * .75)].some(function (qi) { return [-1, 1].some(function (sg) { var cx = pts[qi].x + nor[qi].x * sg * (Wd / 2 + 14), cz = pts[qi].z + nor[qi].z * sg * (Wd / 2 + 14), ok = [-30, -15, 0, 15, 30].every(function (a2) { return [-6, 6].every(function (dp) { return clear(cx + tang[qi].x * a2 + nor[qi].x * sg * dp, cz + tang[qi].z * a2 + nor[qi].z * sg * dp, Wd / 2 + 3); }); }); if (ok) { sI = qi; sS = sg; } return ok; }); });
					if (sI >= 0) { stand.position.set(pts[sI].x + nor[sI].x * sS * (Wd / 2 + 14), 0, pts[sI].z + nor[sI].z * sS * (Wd / 2 + 14)); stand.rotation.y = -Math.atan2(tang[sI].z, tang[sI].x) + (sS > 0 ? Math.PI : 0); W.add(stand); }
				}
				/* TV cameras, minimap bounds */
				TVC = []; for (var tv = 0; tv < N; tv += 70) { var sd5 = tv % 140 ? 1 : -1, x5 = pts[tv].x + nor[tv].x * sd5 * (Wd / 2 + (night ? 1.6 : 9)), z5 = pts[tv].z + nor[tv].z * sd5 * (Wd / 2 + (night ? 1.6 : 9)); TVC.push([x5, z5, H(x5, z5)]); }
				minX = 1e9; maxX = -1e9; minZ = 1e9; maxZ = -1e9; pts.forEach(function (p) { minX = Math.min(minX, p.x); maxX = Math.max(maxX, p.x); minZ = Math.min(minZ, p.z); maxZ = Math.max(maxZ, p.z); }); msc = 150 / Math.max(maxX - minX, maxZ - minZ);
				headlight.visible = night; headlight2.visible = night && DUO(); PRO = {}; skI = 0; M5.makeScale(0, 0, 0); for (var z6 = 0; z6 < SKN; z6++) skid.setMatrixAt(z6, M5); skid.instanceMatrix.needsUpdate = true;
			}
			/* cars */
			var shT = shadowTex();
			function makeHolder() { var holder = new T.Group(), body = new T.Group(); holder.add(body); S.add(holder); var sh = new T.Mesh(new T.PlaneGeometry(5.6, 2.9), new T.MeshBasicMaterial({ map: shT, transparent: true, depthWrite: false })); sh.rotation.x = -Math.PI / 2; sh.position.y = .05; holder.add(sh); var kit = new T.Group(); body.add(kit); var flame = new T.Mesh(new T.ConeGeometry(.22, 1.4, 10), new T.MeshBasicMaterial({ color: 0x6fb8ff, transparent: true, opacity: .85, depthWrite: false })); flame.rotation.z = Math.PI / 2; flame.visible = false; holder.add(flame); return { holder: holder, body: body, kit: kit, flame: flame, url: '', model: null, box: null }; }
			var me = makeHolder(), p2h = makeHolder(), bots = [];
			var headlight = new T.SpotLight(0xfff0d0, 2.2, 90, .55, .5, 1.2), headlight2 = new T.SpotLight(0xfff0d0, 2.2, 90, .55, .5, 1.2); me.holder.add(headlight); me.holder.add(headlight.target); headlight.position.set(1.8, 1, 0); headlight.target.position.set(30, -2, 0); p2h.holder.add(headlight2); p2h.holder.add(headlight2.target); headlight2.position.set(1.8, 1, 0); headlight2.target.position.set(30, -2, 0);
			/* garage kit that you can see: a rear wing, a roof light bar for lifted builds, nitro flames */
			var kitM = new T.MeshStandardMaterial({ color: lin(0x111114), metalness: .4, roughness: .4 }), barM = new T.MeshBasicMaterial({ color: 0xfff3c4 });
			function dressKit(Hh, b) { Hh.kit.children.slice().forEach(function (o) { Hh.kit.remove(o); }); if (!Hh.box) return; var bx = Hh.box, L = bx.max.x - bx.min.x, ht = bx.max.y, wd = bx.max.z - bx.min.z; Hh.body.position.y = (SUSP[b.susp] || SUSP.stock).ride; Hh.flame.position.set(bx.min.x - .5, .45 + Hh.body.position.y, 0);
				if (b.aero === 'wing') { var wing = new T.Mesh(new T.BoxGeometry(.5, .06, wd * .9), kitM); wing.position.set(bx.min.x + L * .06, ht + .12, 0); Hh.kit.add(wing); [-1, 1].forEach(function (s) { var st0 = new T.Mesh(new T.BoxGeometry(.08, .3, .06), kitM); st0.position.set(bx.min.x + L * .08, ht - .04, s * wd * .25); Hh.kit.add(st0); }); }
				if (b.susp === 'lift') { var lb = new T.Mesh(new T.BoxGeometry(.18, .14, wd * .7), kitM), lt = new T.Mesh(new T.BoxGeometry(.04, .09, wd * .66), barM); lb.position.set(bx.max.x - L * .42, ht + .1, 0); lt.position.set(bx.max.x - L * .42 + .1, ht + .1, 0); Hh.kit.add(lb); Hh.kit.add(lt); }
				if (b.rally) { /* rally kit: bonnet light pod, mud flaps, roof scoop, door numbers */
					var podY = bx.max.y * .62, pod = new T.Mesh(new T.BoxGeometry(.16, .22, wd * .62), kitM); pod.position.set(bx.max.x - .12, podY, 0); Hh.kit.add(pod);
					for (var lp = 0; lp < 4; lp++) { var lamp0 = new T.Mesh(new T.CylinderGeometry(.09, .09, .05, 14), barM); lamp0.rotation.z = Math.PI / 2; lamp0.position.set(bx.max.x - .03, podY, (lp - 1.5) * wd * .15); Hh.kit.add(lamp0); }
					var flapM = new T.MeshStandardMaterial({ color: 0x111114, roughness: .9 });[[.22, 1], [.22, -1], [.74, 1], [.74, -1]].forEach(function (q) { var fl = new T.Mesh(new T.BoxGeometry(.02, .26, .34), flapM); fl.position.set(bx.min.x + L * q[0] - .3, .2, q[1] * (wd / 2 - .2)); Hh.kit.add(fl); });
					var scoop = new T.Mesh(new T.BoxGeometry(.5, .08, .3), kitM); scoop.position.set(bx.min.x + L * .5, ht + .03, 0); Hh.kit.add(scoop);
					var nTex = (function () { var c4 = d.createElement('canvas'); c4.width = 128; c4.height = 128; var x4 = c4.getContext('2d'); x4.fillStyle = '#fff'; x4.beginPath(); x4.arc(64, 64, 60, 0, 7); x4.fill(); x4.fillStyle = '#111'; x4.font = '800 72px Arial, sans-serif'; x4.textAlign = 'center'; x4.textBaseline = 'middle'; x4.fillText(String(b.num || 7), 64, 68); var t4 = new T.CanvasTexture(c4); t4.encoding = T.sRGBEncoding; return t4; })();
					[-1, 1].forEach(function (sd) { var dn = new T.Mesh(new T.PlaneGeometry(.5, .5), new T.MeshBasicMaterial({ map: nTex, transparent: true })); dn.position.set(bx.min.x + L * .5, ht * .5, sd * (wd / 2 + .01)); dn.rotation.y = sd > 0 ? 0 : Math.PI; Hh.kit.add(dn); });
				}
			}
			function dress(Hh, c, b) {
				var url = c.glb || 'box'; if (url === Hh.url) { dressKit(Hh, b); return; } Hh.url = url; if (Hh.model) { Hh.body.remove(Hh.model); Hh.model = null; }
				if (!c.glb) { var hsh = 0; String(c.id || c.model).split('').forEach(function (ch) { hsh = (hsh * 31 + ch.charCodeAt(0)) >>> 0; }); var g0 = genericCar([0x1b1c20, 0xe9e6df, 0x24364a, 0x5c1d26, 0x8d9299, 0x2f4a3a, 0xc99a3a][hsh % 7], isSUV(c)); var k0 = (c.dim && c.dim[0] ? c.dim[0] / 1000 : 4.8) / 4.8; g0.scale.setScalar(k0); Hh.body.add(g0); Hh.model = g0; Hh.box = new T.Box3().setFromObject(g0); dressKit(Hh, b); return; }
				var stop = loadTag(stage, c.glb); loadModel(c.glb, function (err, mm) { stop(); if (err || Hh.url !== url) return; var g = new T.Group(); g.add(mm); g.rotation.y = isFlip(c) ? Math.PI : 0; var k = (c.dim && c.dim[0] ? c.dim[0] / 1000 : 4.8) / 4.8; g.scale.setScalar(k); Hh.body.add(g); Hh.model = g; Hh.box = new T.Box3().setFromObject(g); dressKit(Hh, b); });
			}
			/* tyre marks and dust */
			var SKN = 900, skG = new T.PlaneGeometry(.32, 1.2); skG.rotateX(-Math.PI / 2);
			var skid = new T.InstancedMesh(skG, new T.MeshBasicMaterial({ color: 0x0c0c0c, transparent: true, opacity: .5, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2 }), SKN), skI = 0, M5 = new T.Matrix4(), Q5 = new T.Quaternion(), V5 = new T.Vector3(), ONE = new T.Vector3(1, 1, 1);
			M5.makeScale(0, 0, 0); for (var z5 = 0; z5 < SKN; z5++) skid.setMatrixAt(z5, M5); skid.frustumCulled = false; S.add(skid);
			function markAt(s) { var c = Math.cos(s.h), sn = Math.sin(s.h); Q5.setFromAxisAngle(Y, Math.PI / 2 - s.h); [-.78, .78].forEach(function (lat) { var x = s.x - c * 1.35 - sn * lat, z = s.z - sn * 1.35 + c * lat; V5.set(x, H(x, z) + .1, z); M5.compose(V5, Q5, ONE); skid.setMatrixAt(skI, M5); skI = (skI + 1) % SKN; }); skid.instanceMatrix.needsUpdate = true; }
			var DN = 260, dPos = new Float32Array(DN * 3), dVel = new Float32Array(DN * 3), dLife = new Float32Array(DN), dI = 0, dG = new T.BufferGeometry(); dG.setAttribute('position', new T.BufferAttribute(dPos, 3));
			var dTex = (function () { var c4 = d.createElement('canvas'); c4.width = c4.height = 64; var x4 = c4.getContext('2d'), gr = x4.createRadialGradient(32, 32, 0, 32, 32, 32); gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(.5, 'rgba(255,255,255,.45)'); gr.addColorStop(1, 'rgba(255,255,255,0)'); x4.fillStyle = gr; x4.fillRect(0, 0, 64, 64); return new T.CanvasTexture(c4); })();
			var dustM = new T.PointsMaterial({ map: dTex, color: 0xc8925a, size: 1.6, transparent: true, opacity: .55, depthWrite: false, sizeAttenuation: true }), dust = new T.Points(dG, dustM); dust.frustumCulled = false; S.add(dust);
			function puff(x, y, z, vx, vz, colr) { var i = dI; dI = (dI + 1) % DN; dPos[i * 3] = x; dPos[i * 3 + 1] = y; dPos[i * 3 + 2] = z; dVel[i * 3] = vx + (Math.random() - .5) * 2; dVel[i * 3 + 1] = 1 + Math.random() * 2.2; dVel[i * 3 + 2] = vz + (Math.random() - .5) * 2; dLife[i] = 1; if (colr) dustM.color.setHex(colr); }
			function dustStep(dt) { for (var i = 0; i < DN; i++) { if (dLife[i] <= 0) { dPos[i * 3 + 1] = -99; continue; } dLife[i] -= dt * .9; dPos[i * 3] += dVel[i * 3] * dt; dPos[i * 3 + 1] += dVel[i * 3 + 1] * dt; dPos[i * 3 + 2] += dVel[i * 3 + 2] * dt; dVel[i * 3 + 1] -= 3 * dt; } dG.attributes.position.needsUpdate = true; }
			/* ghost */
			var gh = new T.Group(), ghM = new T.MeshBasicMaterial({ color: 0xf1d27a, transparent: true, opacity: .32, depthWrite: false }); gh.visible = false; S.add(gh);
			(function () { var gc = genericCar(0xf1d27a); gc.traverse(function (o) { if (o.isMesh) o.material = ghM; }); gh.add(gc); })();
			var GK = 'psr-hl-ghost-', ghost = null, ghI = 0;
			function loadGhost(c) { if (chal && chal.k === trk) { ghost = chal.ghost; ghM.color.setHex(0x7fd0ff); ghI = 0; return; } ghM.color.setHex(0xf1d27a); try { ghost = JSON.parse(localStorage.getItem(GK + trk + '-' + c.id) || (trk === 'circuit' ? localStorage.getItem('psr-hotlap-ghost-' + c.id) : 'null') || 'null'); } catch (e) { ghost = null; } ghI = 0; }
			function saveGhost(c, P) { var g = { p: P.rec.map(function (r) { return [Math.round(r[0] * 100) / 100, Math.round(r[1] * 10) / 10, Math.round(r[2] * 10) / 10, Math.round(r[3] * 100) / 100]; }), s: P.spl.slice() }; try { localStorage.setItem(GK + trk + '-' + c.id, JSON.stringify(g)); } catch (e) {} if (!chal) ghost = g; }
			/* ---------- simulation ---------- */
			function angd(a, b) { var x = a - b; while (x > Math.PI) x -= 2 * Math.PI; while (x < -Math.PI) x += 2 * Math.PI; return x; }
			function spawn(i0, lat) { var p = pts[i0], n = nor[i0], h = Math.atan2(tang[i0].z, tang[i0].x); return { x: p.x + n.x * lat, z: p.z + n.z * lat, h: h, va: h, v: 0, steer: 0, idx: i0, half: false, lap: 0, dist: 0, nos: 1, slip: 0, drift: 0, dmul: 1, dcombo: 0, dcool: 0, hit: 0 }; }
			function nearest(x, z, from) { var bi = from, bd = 1e9; for (var o = -40; o <= 40; o++) { var k = (from + o + N) % N, dx = pts[k].x - x, dz = pts[k].z - z, dd = dx * dx + dz * dz; if (dd < bd) { bd = dd; bi = k; } } return [bi, Math.sqrt(bd)]; }
			function stepCar(s, p, k, dt) {
				var res = nearest(s.x, s.z, s.idx), prev = s.idx; s.idx = res[0]; var lat = res[1], edge = Wd / 2 + .4, off = lat > edge, surf = off ? offSurf : surfAt[s.idx]; s.surf = surf; s.off = off;
				if (lat > 45) { var p0 = pts[s.idx]; s.x = p0.x; s.z = p0.z; s.h = s.va = Math.atan2(tang[s.idx].z, tang[s.idx].x); s.v = 0; s.vx = s.vz = s.r = 0; }
				/* ---- vehicle dynamics: four tyres, each with its own load, slip angle and grip; weight moves under braking, power and cornering ---- */
				var VG0 = p.veh, cs = Math.cos(s.h), sn = Math.sin(s.h);
				if (s.vx == null) { s.vx = cs * s.v; s.vz = sn * s.v; s.r = 0; s.ax = 0; s.ay = 0; s.gear = 1; s.rpm = .3; s.spin = 0; }
				var u = s.vx * cs + s.vz * sn, w = -s.vx * sn + s.vz * cs, sp = Math.sqrt(u * u + w * w), L = VG0.L, A = VG0.a, B = VG0.b, TW = VG0.tw, HG = VG0.hg, m = p.m, g9 = 9.81;
				var steerT = k.s != null ? k.s : (k.r ? 1 : 0) - (k.l ? 1 : 0), dmg = s.dmg || null;
				var dMax = .6 / (1 + Math.max(0, u) / 20), assist = k.s == null && u > 6 ? Math.max(-.3, Math.min(.3, Math.atan2(w, u) * .55)) : 0; /* keyboard drivers get a little automatic counter-steer to catch slides */
				s.steer += (steerT - s.steer) * Math.min(1, dt * (Math.abs(steerT) < Math.abs(s.steer) ? 9 : 6));
				var muS0 = (p.mu[s.surf] || .8) * p.lat, dGrip = u > 4 ? L * muS0 * g9 * 1.35 / (u * u) + .035 + Math.abs(s.slip || 0) * 1.1 : dMax, delta = (k.sa != null ? Math.max(-dMax, Math.min(dMax, k.sa)) : s.steer * Math.min(dMax, dGrip) + assist) + (dmg ? dmg.toe : 0);
				/* engine: power from the published figure, delivered through a gearbox */
				var Pn = p.P * (dmg ? 1 - dmg.eng * .55 : 1); if (p.nitro && k.n && s.nos > 0 && sp > 2) { Pn *= 1.45; s.nos = Math.max(0, s.nos - dt / 3.2); s.boost = 1; } else { s.boost = 0; if (p.nitro) s.nos = Math.min(1, s.nos + dt / 11); }
				var NG = VG0.gears.length, gi = Math.max(0, Math.min(NG - 1, s.gear - 1)), vpk = VG0.gears[gi], x = Math.max(0, u) / vpk;
				var gMax = NG - (dmg && dmg.gbx > .3 ? Math.min(NG - 2, Math.floor((dmg.gbx - .2) * 4)) : 0); if (k.gu) { k.gu = 0; s.manual = 1; if (s.gear < gMax) { s.gear++; s.shiftT = .08; } } if (k.gd) { k.gd = 0; s.manual = 1; if (s.gear > 1) { s.gear--; s.shiftT = .08; } } if (s.gear > gMax) s.gear = gMax; if (dmg && dmg.gbx > .55 && Math.random() < dt * dmg.gbx * .15) s.shiftT = .5;
				if (!p.ev && !s.manual) { if (x > 1.1 && gi < NG - 1 && s.gear < gMax) { s.gear++; s.shiftT = .12 * (p.gbxW || 1); } else if (gi > 0 && Math.max(0, u) / VG0.gears[gi - 1] < .78) s.gear--; vpk = VG0.gears[Math.max(0, s.gear - 1)]; x = Math.max(0, u) / vpk; }
				s.shiftT = Math.max(0, (s.shiftT || 0) - dt); s.rpm = Math.min(1.15, Math.max(.22, x));
				var fx = p.ev ? 1 : Math.max(.5, Math.min(1, x * (2 - x) + (x > 1 ? 0 : 0))) * (x > 1.14 ? .2 : 1);
				var thr = k.t ? (k.t < 1 ? k.t : 1) : 0, brk = k.b ? (k.b < 1 ? k.b : 1) : 0, rev = false; if (s.rolled) { thr = 0; brk = 1; steerT = 0; } if (p.hybrid && brk && sp > 5) s.nos = Math.min(1, s.nos + dt * brk / 4);
				if (brk && !thr && u < .6) { rev = true; brk = 0; } /* hold brake when stopped to reverse */
				var Fdrive = thr * Math.min(Pn * fx / Math.max(u, p.vmin), p.ev ? 1.25 * Pn / (VG0.gears[0] * .3) : 1.25 * Pn / vpk) * (s.shiftT > 0 ? .25 : 1);
				if (rev) Fdrive = -Math.min(Pn / 4, p.m * 4) * (u > -7 ? 1 : 0);
				if (!thr && !rev && u > 1) Fdrive = -m * (.6 + s.rpm * .9); /* engine braking */
				var Fbrake = brk * 1.25 * m * g9 * (p.brk || 1), bF = p.bias || .62;
				/* stability control: compare the yaw rate with what the steering asks for; trim power and brake one side to catch a slide */
				var escM = 0; if (escOn && u > 6 && !k.h) { var muA = ((p.mu[s.surf] || .8) * p.lat), rD = Math.max(-muA * g9 / u, Math.min(muA * g9 / u, u * Math.tan(delta) / L)), er = s.r - rD; if (Math.abs(er) > .06 && (Math.sign(er) === Math.sign(s.r) || Math.abs(rD) < .02)) { escM = -Math.sign(er) * Math.min(m * g9 * .35 * TW / 2, Math.abs(er) * VG0.Iz * 6); Fdrive *= Math.max(.25, 1 - Math.abs(er) * 3); s.esc = 1; } else s.esc = 0; }
				/* loads */
				var Fd0 = p.down * m * sp * sp, Fzf = (m * g9 * B / L + Fd0 * .5) / 2, Fzr = (m * g9 * A / L + Fd0 * .5) / 2, dLon = m * s.ax * HG / L / 2, dLat = m * s.ay * HG / TW;
				var Fz0 = m * g9 / 4, rough = 0, MU = p.mu, TB = VG0.tb;
				var rsf = VG0.rollF || .6, W4 = [[A, TW / 2, Fzf - dLon - dLat * rsf, 1], [A, -TW / 2, Fzf - dLon + dLat * rsf, 1], [-B, TW / 2, Fzr + dLon - dLat * (1 - rsf), 0], [-B, -TW / 2, Fzr + dLon + dLat * (1 - rsf), 0]];
				var FX = 0, FY = 0, MZ = 0, slideSum = 0, spinAny = 0, fdShare = VG0.front, cnt = 0;
				for (var wi = 0; wi < 4; wi++) {
					var Wl = W4[wi], xi = Wl[0], yi = Wl[1], front = Wl[3], wx = s.x + cs * xi - sn * yi, wz = s.z + sn * xi + cs * yi;
					var latw = Math.abs((wx - pts[s.idx].x) * nor[s.idx].x + (wz - pts[s.idx].z) * nor[s.idx].z), su = latw > Wd / 2 + .3 ? offSurf : surfAt[s.idx]; if (su === 'wall') su = 'tarmac';
					var rgh = (ROUGH[su] || 0); rough += rgh / 4;
					var Fz = s.air ? 0 : Math.max(0, Wl[2] * (1 + (rgh ? Math.sin(s.odo * (2.1 + wi * .7) + wi * 1.7) * rgh * p.rough * .22 : 0)));
					var mu = (MU[su] || .6) * p.lat * (front ? (dmg ? 1 - dmg.susp * .25 : 1) : 1.06) * (s.pun && s.pun[wi] ? .45 : 1), D = mu * Fz * (1.12 - .12 * Fz / Fz0), tb = TB[su] || TB.dirt;
					var del = front ? delta : 0, cd = Math.cos(del), sd = Math.sin(del), vix = u - s.r * yi, viy = w + s.r * xi, vl = vix * cd + viy * sd, vt = -vix * sd + viy * cd;
					var Fx = 0, Fy = 0;
					if (!front && k.h && sp > 1) { var vm = Math.sqrt(vl * vl + vt * vt) || 1; Fx = -vl / vm * D * .82; Fy = -vt / vm * D * .82; slideSum += 1; }
					else {
						var share = (front ? fdShare : 1 - fdShare) / 2, dem = Fdrive * share - Fbrake * (front ? bF : 1 - bF) / 2 * (vl > 0 ? 1 : -1) * (Math.abs(vl) > .3 ? 1 : Math.abs(vl) / .3);
						var al = Math.atan2(vt, Math.max(Math.abs(vl), 3.5)), mf = Math.sin(tb[1] * Math.atan(tb[0] * al)), DL = D * 1.15, DLt = (tcOn || dem < 0) ? DL * Math.sqrt(Math.max(.12, 1 - mf * mf * .92)) : DL;
						if (Math.abs(dem) > DLt) { if (dem < 0 && !absOn && Math.abs(dem) > DL) { Fx = Math.sign(dem) * DL * .92; } else if (dem < 0 || tcOn) Fx = Math.sign(dem) * DLt * .97; else { Fx = Math.sign(dem) * DL * (dem > 0 ? .86 : .95); if (dem > 0) spinAny = 1; } } else Fx = dem;
						var fr2 = DL > 1 ? Fx / DL : 0, cap = D * Math.sqrt(Math.max(0, 1 - fr2 * fr2));
						Fy = -mf * cap; if (Math.abs(al) > .14) slideSum += Math.min(1, (Math.abs(al) - .14) * 4);
					}
					FX += Fx * cd - Fy * sd; var fby = Fx * sd + Fy * cd; FY += fby; MZ += xi * fby - yi * (Fx * cd - Fy * sd);
				}
				/* resistance, rough ground, slopes */
				var Fdr = .5 * 1.2 * p.cda * sp * sp * (1 - .38 * (s.draft || 0)) + .015 * m * g9 + m * rough * p.rough * 1.7 * Math.min(1, sp / 6) + (s.pun ? (s.pun[0] + s.pun[1] + s.pun[2] + s.pun[3]) * m * .9 : 0) + (s.rolled ? m * 8 : 0);
				if (sp > .05) { FX -= Fdr * u / sp; FY -= Fdr * w / sp; }
				var gx = H(s.x + .6, s.z) - H(s.x - .6, s.z), gz = H(s.x, s.z + .6) - H(s.x, s.z - .6), Gx = -m * g9 * gx / 1.2, Gz = -m * g9 * gz / 1.2;
				FX += Gx * cs + Gz * sn; FY += -Gx * sn + Gz * cs;
				MZ += escM;
				var axN = FX / m, ayN = FY / m, sm = Math.min(1, dt * 12); s.ax += (axN - s.ax) * sm; s.ay += (ayN - s.ay) * sm;
				u += (axN + s.r * w) * dt; w += (ayN - s.r * u) * dt; s.r += MZ / VG0.Iz * dt;
				if (sp < 2.5 && !thr && !rev) { var dmp = Math.exp(-dt * 5); w *= dmp; s.r = s.r * dmp + (1 - dmp) * u * Math.tan(delta) / L; if (Math.abs(u) < .15 && !brk) u *= .9; }
				if (sp < 6) { var rk = u * Math.tan(delta) / L, bl = 1 - sp / 6; s.r += (rk - s.r) * bl * Math.min(1, dt * 8); }
				s.h += s.r * dt; cs = Math.cos(s.h); sn = Math.sin(s.h);
				s.vx = u * cs - w * sn; s.vz = u * sn + w * cs; s.x += s.vx * dt; s.z += s.vz * dt; s.odo = (s.odo || 0) + sp * dt;
				s.v = Math.sqrt(s.vx * s.vx + s.vz * s.vz); s.va = s.v > .4 ? Math.atan2(s.vz, s.vx) : s.h; s.slip = u > 1.5 ? -Math.atan2(w, u) : 0; s.spin = spinAny; s.slide = slideSum; s.rev = u < -.3;
				s.m = m; s.Iz = VG0.Iz; s.hl = VG0.hl; s.hw = VG0.hw;
				if (!(isFinite(s.x) && isFinite(s.z) && isFinite(s.vx) && isFinite(s.r) && isFinite(s.h))) { var p9 = pts[s.idx] || pts[0]; s.x = p9.x; s.z = p9.z; s.h = s.va = Math.atan2(tang[s.idx].z, tang[s.idx].x); s.vx = s.vz = s.r = s.v = s.ax = s.ay = 0; }
				hitWorld(s);
				if (s.idx > N * .45 && s.idx < N * .55) s.half = true;
				var crossed = prev > N * .9 && s.idx < N * .1 && s.half; if (crossed) { s.half = false; s.lap++; }
				s.dist = s.lap * N + s.idx + (s.idx > N * .9 && !s.half && s.lap === 0 ? -N : 0);
				return crossed;
			}
			var KO = { l: 0, r: 0, t: 0, b: 0, h: 0, n: 0 };
			/* AI: pure-pursuit steering on the racing line, speed from each car's own grip with a braking profile */
			function aiProf(p) { var key = trk + '|' + p.id + '|' + JSON.stringify(p.mu) + p.lat + p.P; if (p.prof && p.profK === key) return p.prof; var v = new Float32Array(N), i, g9 = 9.81, ab = 0;
				for (i = 0; i < N; i++) { var mu = (p.mu[surfAt[i]] || .8) * p.lat * (1 - Math.min(.3, (ROUGH[surfAt[i]] || 0) * p.rough * .12)); v[i] = Math.min(95, Math.sqrt(mu * g9 * (ROUGH[surfAt[i]] ? .8 : .9) / Math.max(kap[i], 1e-4))); }
				for (var pass = 0; pass < 3; pass++) for (i = N - 1; i >= 0; i--) { var j = (i + 1) % N, mu2 = (p.mu[surfAt[i]] || .8) * p.lat * (1 - Math.min(.3, (ROUGH[surfAt[i]] || 0) * p.rough * .12)), lim = Math.sqrt(v[j] * v[j] + 2 * mu2 * g9 * .7 * seg); if (v[i] > lim) v[i] = lim; }
				p.prof = v; p.profK = key; return v; }
			function aiDrive(s, p, kk, skill, laneOff) {
				var sp = Math.max(s.v, 0), Ld = 5.5 + sp * .36, ti = (s.idx + Math.round(Ld / seg)) % N, q = pts[ti], qn = nor[ti], lo = laneOff || 0, tx = q.x + qn.x * lo - s.x, tz = q.z + qn.z * lo - s.z, dl = Math.sqrt(tx * tx + tz * tz) || 1;
				var hd = sp > 3 ? s.va : s.h, err = angd(Math.atan2(tz, tx), hd), kap0 = 2 * Math.sin(err) / dl, L = p.veh ? p.veh.L : 2.7, dMax = .6 / (1 + Math.max(0, sp) / 20), pc0 = pts[s.idx], nc0 = nor[s.idx], eLat = (s.x - pc0.x) * nc0.x + (s.z - pc0.z) * nc0.z - lo, del = Math.atan(kap0 * L) - (sp > 3 ? (s.slip || 0) : 0) - Math.max(-.12, Math.min(.12, eLat * .06 / (1 + sp / 18)));
				kk.s = Math.max(-1, Math.min(1, del / dMax)); kk.sa = del; kk.l = kk.r = 0;
				var prof = aiProf(p), vt = Math.min(prof[s.idx] * 1.03, prof[(s.idx + Math.round((4 + sp * .35) / seg)) % N]) * (skill || .97); w.__vt = vt; var muH = (p.mu[s.surf] || .8) * p.lat * 9.81, latU = Math.min(1, Math.abs(s.ay || 0) / muH); if (s.dmg) vt *= 1 - s.dmg.eng * .2;
				kk.t = sp < vt ? Math.min(1, (vt - sp) * .6 + .25) * Math.max(.15, 1 - latU * latU * .85) * (Math.abs(s.slip || 0) > .2 ? .4 : 1) : 0; kk.b = sp > vt + .3 ? Math.min(1, (sp - vt) / 1.5) : 0; kk.h = 0; kk.n = p.nitro && sp < vt - 8 && curv[(s.idx + 25) % N] < .03 ? 1 : 0;
			}
			var PRO = {};
			function proTime(c, p) { var key = trk + ':' + c.id + ':' + JSON.stringify(buildOf(c)); if (PRO[key]) return PRO[key]; var s = spawn(N - 12, 0), t = 0, dt = 1 / 60, kk = {}; while (t < 500) { aiDrive(s, p, kk, 1); if (stepCar(s, p, kk, dt)) break; t += dt; } return (PRO[key] = t); }
			function medal(tl, pro) { return tl <= pro * 1.0 ? ['Gold', '🥇'] : tl <= pro * 1.05 ? ['Silver', '🥈'] : tl <= pro * 1.12 ? ['Bronze', '🥉'] : null; }
			/* players */
			function mkPlayer(Hh, keys) { return { H: Hh, K: keys, s: null, p: null, c: null, b: null, cam: null, rec: [], spl: [], recT: 0, t0: 0, started: false, done: false, finT: 0 }; }
			var trail = [], trailLen = 0, coh = { t: 0, ok: 0 };
			/* followers drive for real: they steer for their slot on your breadcrumb trail and must use their own power and grip to keep up */
			function followDrive(bt, dt) {
				var s = bt.s, gap = 9 * bt.follow, want = trailLen - gap, tp = null; if (trail.length < 2 || want < 0) { bt.K.t = 0; bt.K.b = 1; bt.K.l = bt.K.r = 0; return 0; }
				var lo = 0, hi = trail.length - 1; while (lo < hi) { var mid = (lo + hi) >> 1; if (trail[mid][4] < want) lo = mid + 1; else hi = mid; } tp = trail[lo];
				var la = trail[Math.min(trail.length - 1, lo + 6 + Math.round(s.v * .6))], lat = (bt.follow % 2 ? 1 : -1) * 1.2, tx = la[0] - Math.sin(la[2]) * lat, tz = la[1] + Math.cos(la[2]) * lat, err = angd(Math.atan2(tz - s.z, tx - s.x), s.h);
				bt.K.s = Math.max(-1, Math.min(1, err * 3.2)); bt.K.sa = null; bt.K.r = bt.K.l = 0;
				var dx = tp[0] - s.x, dz = tp[1] - s.z, dist = Math.sqrt(dx * dx + dz * dz), behind = dx * Math.cos(tp[2]) + dz * Math.sin(tp[2]), vT = Math.max(0, Math.min(tp[3] + Math.max(-6, Math.min(9, behind * .6)), aiProf(bt.p)[(s.idx + 6) % N] * 1.04));
				bt.K.t = s.v < vT ? 1 : 0; bt.K.b = s.v > vT + 3 ? 1 : 0; bt.K.h = 0; bt.K.n = 0;
				if (dist > 16 && behind > 0) { /* fallen back: race the track line to catch up rather than cut across the bush */ bt.K.s = null; aiDrive(s, bt.p, bt.K, 1.22, lat); bt.K.t = bt.K.t ? 1 : 0; if (s.v > tp[3] + 12) { bt.K.t = 0; } }
				return dist;
			}
			var paused = false, barrierD = 0, barrierE = .3, barrierF = .5, barOK = null, obsGrid = {}, dmgOn = true, tcOn = true, escOn = true, absOn = true; function addObs(x, z, r) { var gx = Math.floor(x / 12), gz = Math.floor(z / 12); for (var ix = -1; ix <= 1; ix++) for (var iz = -1; iz <= 1; iz++) { var key2 = (gx + ix + 500) * 1000 + gz + iz + 500; (obsGrid[key2] = obsGrid[key2] || []).push([x, z, r]); } }
			var P1 = mkPlayer(me, K), P2 = mkPlayer(p2h, K2), live = false, last = 0, lostT = 0, race = null, VG = [58, 98, 138, 178, 218, 262, 330];
			function setPlayerCar(P, c) { P.c = c; P.b = buildOf(c); P.p = physOf(c, P.b); dress(P.H, c, P.b); }
			function pickRivals(n) { var me0 = P1.c, pool = cars.filter(function (c) { return c.id !== me0.id && c.model !== me0.model && c.glb && (trk === 'trail' ? isSUV(c) : true); }); if (pool.length < n) pool = cars.filter(function (c) { return c.id !== me0.id; }); pool.sort(function (a, b) { return Math.abs(a.acc - me0.acc) - Math.abs(b.acc - me0.acc); }); var top = pool.slice(0, Math.max(n * 3, 8)), out = []; while (out.length < n && top.length) out.push(top.splice((Math.random() * top.length) | 0, 1)[0]); return out; }
			function clearBots() { bots.forEach(function (bt) { S.remove(bt.H.holder); }); bots = []; }
			function stop() { paused = false; $('[data-hl-pause]', root).hidden = true; live = false; race = null; cnt.hidden = true; board.hidden = true; panel.hidden = true; }
			function start() {
				pmClear(); RP.buf = []; RP.lr = 0; commPos = 0; P1.bill = {}; P1.billT = 0; P2.bill = {}; P2.billT = 0; clearBots(); panel.hidden = true; board.hidden = true; $('[data-rx-hud2]', root).hidden = !DUO(); stage.classList.toggle('is-duel', DUO()); stage.classList.toggle('is-drift', mode === 'drift');
				setPlayerCar(P1, byId(+sel.value)); loadGhost(P1.c); $('[data-hl-prow]', root).hidden = mode === 'drift'; $('[data-rx-drift]', root).hidden = mode !== 'drift';
				$('[data-hl-pro]', root).textContent = fmt(chal && chal.k === trk ? chal.t / 1000 : proTime(P1.c, P1.p)); $('[data-hl-prow]', root).firstChild.textContent = chal && chal.k === trk ? 'Rival ' : 'Gold '; $('[data-hl-prow]', root).hidden = mode !== 'tt';
				var grid = mode === 'race' ? 0 : DUO() ? -2.6 : 0;
				P1.s = spawn(N - 12, grid); P1.started = false; P1.done = false; P1.rec = []; P1.spl = []; P1.recT = 0; P1.cam = null; P2.s = null; p2h.holder.visible = false;
				if (DUO()) { setPlayerCar(P2, byId(+sel2.value)); P2.s = spawn(N - 12, 2.6); P2.done = false; P2.cam = null; p2h.holder.visible = true; }
				if (mode === 'race') { var n = +$('[data-rx-n]', root).value || 3, rv = pickRivals(n); P1.s = spawn(N - 12 - Math.ceil(n / 2) * 9, n % 2 ? 0 : -2.6); rv.forEach(function (c, i) { var Hh = makeHolder(), b0 = buildOf({ id: -1, body: c.body, model: c.model }), pb = physOf(c, b0), row = Math.floor(i / 2), sd = i % 2 ? 2.6 : -2.6; dress(Hh, c, b0); bots.push({ H: Hh, c: c, p: pb, s: spawn(N - 12 - row * 9, n % 2 ? sd : (i % 2 ? 2.6 : -2.6) * (row === Math.ceil(n / 2) - 1 && i === n - 1 ? -1 : 1)), K: {}, skill: .93 + Math.random() * .06, lane: (Math.random() - .5) * 3, done: false }); }); }
				trail = []; trailLen = 0; coh = { t: 0, ok: 0 };
				if (mode === 'convoy') { entourage().forEach(function (id, i) { var c = byId(id); if (!c || c.id === P1.c.id) return; var Hh = makeHolder(), b0 = buildOf(c), pb = physOf(c, b0); dress(Hh, c, b0); var lp = P1.p, mu2 = {}; Object.keys(pb.mu).forEach(function (sk) { mu2[sk] = Math.max(pb.mu[sk], (lp.mu[sk] || 0) * 1.08); }); pb.mu = mu2; pb.P = Math.max(pb.P, lp.P * pb.m / lp.m * 1.2); pb.veh.tb = lp.veh.tb; pb.rough = Math.min(pb.rough, lp.rough * 1.05); pb.lat = Math.max(pb.lat, lp.lat * .97); /* entourage drivers are pros: they match most of the leader's grip and pace */ var i0 = (N - 12 - (bots.length + 1) * 7 + N) % N; bots.push({ H: Hh, c: c, b: b0, p: pb, s: spawn(i0, (bots.length % 2 ? 1 : -1) * 1.6), K: {}, follow: bots.length + 1, done: false }); }); }
				if (mode === 'convoy') { for (var pi0 = N - 12 - 45; pi0 <= N - 12; pi0++) { var kq = (pi0 + N) % N, lq = trail[trail.length - 1]; if (lq) trailLen += Math.hypot(pts[kq].x - lq[0], pts[kq].z - lq[1]); trail.push([pts[kq].x, pts[kq].z, Math.atan2(tang[kq].z, tang[kq].x), 0, trailLen]); } } /* the grid counts as road already driven, so the convoy rolls off together */
				var laps = mode === 'race' || DUO() ? TRACKS[trk].laps : 0;
				race = laps ? { phase: 'count', t: performance.now() - lostT, laps: laps, order: [] } : (mode === 'party' ? { phase: 'count', t: performance.now() - lostT, laps: 1, party: true } : null);
				BETS = null; if (PMS[mode]) { PM = { ctrl: mode === 'keys' }; PMS[mode].start(); if (mode === 'vroom') { P1.p.nitro = true; P1.p.hybrid = false; } say2({ keys: 'Grab the keys and hold on to them!', ko: 'Knockout! Last car each lap goes home.', roulette: 'Car roulette! Every lap, a new car.', bomb: 'The bomb is on board. Do not slow down!', potato: 'Hot potato! Pass the bomb before it blows!', echo: 'Six laps. Your past is coming back to haunt you.', champagne: 'A tower of champagne on the roof. Gently does it.', gate: 'Six speed gates. Hit the number exactly.' }[mode] || '', true); }
				cnt.hidden = !race; $('[data-hl-pos]', root).hidden = !(mode === 'race' || mode === 'ko' || mode === 'roulette' || DUO()); $('[data-hl-of]', root).textContent = mode === 'race' ? '/' + (bots.length + 1) : DUO() ? '/2' : '';
				gh.visible = false; $('[data-hl-delta]', root).hidden = true; $('[data-hl-lap]', root).textContent = laps ? '1 / ' + laps : (mode === 'party' && party ? '1 · ' + party.names[party.i] : '1'); $('[data-hl-last]', root).textContent = '–'; $('[data-hl-t]', root).textContent = '0.00'; $('[data-rx-ds]', root).textContent = '0'; $('[data-rx-dm]', root).textContent = '';
				$('[data-rx-nos]', root).hidden = !P1.p.nitro; $('[data-rx-nos2]', root).hidden = !(DUO() && P2.p && P2.p.nitro); root.querySelector('.rx__tn').hidden = !P1.p.nitro;
				headlight.visible = theme === 'night'; headlight2.visible = theme === 'night' && DUO();
				if (mode === 'party' && party) { flash(party.names[party.i] + ', you are up', 2600); }
				live = true; size(); if (['race', 'ko', 'roulette'].indexOf(mode) >= 0) betsOpen();
			}
			/* HUD helpers */
			var mp = $('[data-hl-map]', root), mx = mp.getContext('2d');
			function MX(x) { return 15 + (x - minX) * msc; } function MZ(z) { return 15 + (z - minZ) * msc; }
			function dot(s, c, r) { mx.fillStyle = c; mx.beginPath(); mx.arc(MX(s.x), MZ(s.z), r, 0, 7); mx.fill(); }
			function drawMap() { mx.clearRect(0, 0, 180, 180); mx.strokeStyle = 'rgba(255,255,255,.75)'; mx.lineWidth = 4; mx.beginPath(); pts.forEach(function (p, i) { if (i) mx.lineTo(MX(p.x), MZ(p.z)); else mx.moveTo(MX(p.x), MZ(p.z)); }); mx.closePath(); mx.stroke(); mx.fillStyle = '#fff'; mx.fillRect(MX(pts[0].x) - 3, MZ(pts[0].z) - 3, 6, 6); bots.forEach(function (b) { dot(b.s, '#7fb4ff', 4.5); }); if (P2.s) dot(P2.s, '#ff7a7a', 6); dot(P1.s, '#f1d27a', 6); }
			var fl = d.createElement('b'); fl.className = 'hl__flash'; stage.appendChild(fl);
			function flash(t, ms) { fl.textContent = t; fl.classList.add('is-on'); clearTimeout(fl.__t); fl.__t = setTimeout(function () { fl.classList.remove('is-on'); }, ms || 2200); }
			function showPanel(html) { if (mode !== 'rally' && P1.billT && !/data-rl-go2|Paused/.test(html)) html += billHtml(P1); if (P1.billT && mode !== 'rally') { var lb = store('psr-hl-bill'); lb.t = (lb.t || 0) + Math.round(P1.billT * 1.18); put('psr-hl-bill', lb); P1.bill = {}; P1.billT = 0; } if (RP.buf.length > 8 && mode !== 'rally' && !/Paused|data-rl-go2/.test(html)) { var rpb = '<button type="button" class="pm__db" data-pm-rpgo>Watch replay</button><button type="button" class="pm__db" data-pm-rpclip>Save a clip</button>'; if (/data-rx-again/.test(html)) html = html.replace(/<button type="button" class="lx-btn lx-btn--gold" data-rx-again>Play again<\/button>/, '<div class="pm__rpb"><button type="button" class="pm__db pm__db--gold" data-rx-again>Play again</button>' + rpb + '</div>'); else html += '<div class="pm__rpb">' + rpb + '</div>'; } panel.innerHTML = '<div class="rx__pin">' + html + '</div>'; panel.hidden = false; }
			function placing() { var all = [{ n: P1.c ? cname(P1.c) : 'You', s: P1.s, me: 1, done: P1.done, ft: P1.finT }]; if (P2.s) all.push({ n: 'Player 2 · ' + cname(P2.c), s: P2.s, p2: 1, done: P2.done, ft: P2.finT }); bots.forEach(function (b) { if (!b.out && !b.echo && !b.stat) all.push({ n: b.c.model, s: b.s, done: b.done, ft: b.finT }); }); all.sort(function (a, b) { if (a.done && b.done) return a.ft - b.ft; if (a.done) return -1; if (b.done) return 1; return b.s.dist - a.s.dist; }); return all; }
			function drawBoard() { if (!(mode === 'race' || DUO())) return; var all = placing(); board.innerHTML = all.map(function (r, i) { return '<li class="' + (r.me ? 'is-me' : r.p2 ? 'is-p2' : '') + '"><b>' + (i + 1) + '</b>' + esc(DUO() ? (r.me ? 'Player 1' : 'Player 2') : r.me ? 'You' : r.n) + '</li>'; }).join(''); board.hidden = false; return all; }
			function finishRace(now) {
				race.phase = 'done'; var all = placing(), myPos = all.findIndex ? all.findIndex(function (r) { return r.me; }) + 1 : 1;
				if (DUO()) { var p1w = all[0].me; flash((p1w ? 'Player 1' : 'Player 2') + ' wins', 6000); FX.play('win'); FX.confetti(stage, 140); showPanel('<h3>' + (p1w ? 'Player 1' : 'Player 2') + ' takes it.</h3><p>' + esc(cname(P1.c)) + ' vs ' + esc(cname(P2.c)) + ' on ' + TRACKS[trk].name + '.</p><button type="button" class="lx-btn lx-btn--gold" data-rx-again>Rematch</button>'); }
				else { var podium = all.slice(0, 3).map(function (r, i) { return '<li><b>' + ['🥇', '🥈', '🥉'][i] + '</b>' + esc(r.me ? 'You · ' + r.n : r.n) + '</li>'; }).join(''); showPanel('<h3>' + (myPos === 1 ? 'Victory.' : 'You finished P' + myPos + '.') + '</h3><ol class="rx__pod">' + podium + '</ol><button type="button" class="lx-btn lx-btn--gold" data-rx-again>Race again</button>' + FX.shareBtn('I finished P' + myPos + ' of ' + all.length + ' on ' + TRACKS[trk].name + ' in a ' + cname(P1.c) + ' at Laqim Racing.')); if (myPos === 1) { FX.play('win'); FX.confetti(stage, 160); } else FX.play(myPos <= 3 ? 'ok' : 'lose'); }
				var bh = betsSettle(all[0].me ? 'me' : all[0].n); if (bh) { panel.querySelector('.rx__pin').insertAdjacentHTML('beforeend', bh); }
				var ag = $('[data-rx-again]', panel); if (ag) on(ag, 'click', function () { start(); });
			}
			function partyLap(tl) {
				var c = P1.c; party.res.push({ n: party.names[party.i], c: cname(c), t: tl, b: buildTag(P1.b) }); party.i++; live = false; FX.play('ok');
				var rows = party.res.slice().sort(function (a, b) { return a.t - b.t; }).map(function (r, i) { return '<li><b>' + (i + 1) + '</b>' + esc(r.n) + ' <span>' + esc(r.c) + '</span><em>' + fmt(r.t) + '</em></li>'; }).join('');
				if (party.i >= party.names.length) { party.done = true; var win = party.res.slice().sort(function (a, b) { return a.t - b.t; })[0]; FX.play('win'); FX.confetti(stage, 220); showPanel('<h3>' + esc(win.n) + ' wins the party.</h3><ol class="rx__pod">' + rows + '</ol><button type="button" class="lx-btn lx-btn--gold" data-rx-again>New party</button>' + FX.shareBtn(win.n + ' won our Laqim Racing party on ' + TRACKS[trk].name + ' with ' + fmt(win.t) + '.')); on($('[data-rx-again]', panel), 'click', function () { party = { names: party.names, i: 0, res: [] }; start(); }); }
				else { showPanel('<h3>' + esc(party.res[party.res.length - 1].n) + ': ' + fmt(tl) + '</h3><ol class="rx__pod">' + rows + '</ol><p>Next up: <b>' + esc(party.names[party.i]) + '</b>. Change the car or the build if you like, then go.</p><button type="button" class="lx-btn lx-btn--gold" data-rx-again>Start ' + esc(party.names[party.i]) + '’s lap</button>'); on($('[data-rx-again]', panel), 'click', function () { start(); }); }
			}
			function lapDone(P, tl, now) {
				if (PM && PMS[mode] && PMS[mode].lap) { if (PMS[mode].lap(P, tl, now)) return; }
				if (PM && mode === 'bomb') { flash('Lap · ' + fmt(tl), 1400); return; }
				if (mode === 'party') { partyLap(tl); return; }
				$('[data-hl-last]', root).textContent = fmt(tl); $('[data-hl-lap]', root).textContent = P.s.lap + 1;
				if (mode === 'convoy') { var pc = coh.t ? Math.round(coh.ok / coh.t * 100) : 100, sc = Math.round(pc * 40 + Math.max(0, 300 - tl) * 6), ek = store('psr-hl-convoy'), kc = trk + ':' + entourage().join('-'), rec2 = !ek[kc] || sc > ek[kc]; if (rec2) { ek[kc] = sc; put('psr-hl-convoy', ek); } live = false; FX.play(pc > 80 ? 'win' : 'ok'); if (pc > 80) FX.confetti(stage, 140); showPanel('<h3>Entourage home in ' + fmt(tl) + '.</h3><p>Convoy kept tight for <b>' + pc + '%</b> of the lap · score <b>' + sc.toLocaleString('en-GB') + '</b>' + (rec2 ? ' · new record' : '') + '.</p><ol class="rx__pod"><li><b>1</b>' + esc(cname(P.c)) + ' (lead)</li>' + bots.map(function (b, i) { return '<li><b>' + (i + 2) + '</b>' + esc(cname(b.c)) + '</li>'; }).join('') + '</ol><button type="button" class="lx-btn lx-btn--gold" data-rx-again>Roll out again</button>' + FX.shareBtn('My Laqim Racing entourage: ' + [cname(P.c)].concat(bots.map(function (b) { return cname(b.c); })).join(', ') + '. ' + pc + '% tight round ' + TRACKS[trk].name + '.')); on($('[data-rx-again]', panel), 'click', function () { start(); }); return; }
				if (mode === 'drift') { bankDrift(P.s); var tot = Math.round(P.s.drift), db = store(DK), kd = trk + ':' + P.c.id; if (!db[kd] || tot > db[kd]) { db[kd] = tot; put(DK, db); flash('New drift record · ' + tot.toLocaleString('en-GB') + ' pts'); FX.play('win'); FX.confetti(stage, 120); } else { flash('Lap ' + P.s.lap + ' · ' + tot.toLocaleString('en-GB') + ' pts'); FX.play('ok'); } P.s.drift = 0; P.t0 = now; return; }
				var c = P.c, bb = store(BK), kk = bestKey(c), md = medal(tl, proTime(c, P.p)), isBest = !bb[kk] || tl < bb[kk], lap = { t: tl, rec: P.rec.slice() };
				if (isBest) { bb[kk] = tl; put(BK, bb); if (P.rec.length > 20) saveGhost(c, P); }
				var beat = chal && chal.k === trk ? tl - chal.t / 1000 : null;
				flash(beat != null ? (beat < 0 ? 'You beat ' + (chal.n || 'your friend') + ' by ' + (-beat).toFixed(2) + ' s' : (chal.n || 'Your friend') + ' is ' + beat.toFixed(2) + ' s ahead') : (md ? md[1] + ' ' + md[0] + ' · ' : '') + (isBest ? 'New best lap · ' : 'Lap · ') + fmt(tl), 3200);
				if (isBest || (beat != null && beat < 0)) { FX.play('win'); FX.confetti(stage, md && md[0] === 'Gold' ? 200 : 100); } else FX.play(md ? 'ok' : 'tick');
				showBest(); P.t0 = now; P.rec = []; P.spl = []; P.recT = 0; ghI = 0;
				/* offer the lap as a challenge */
				var chw = d.createElement('div'), ch = d.createElement('button'), chn = d.createElement('input'); chw.className = 'rx__chalw'; chn.className = 'rx__chaln'; chn.placeholder = 'Your name'; chn.maxLength = 24; chn.value = myName(); chn.setAttribute('aria-label', 'Your name for the challenge'); ch.type = 'button'; ch.className = 'rx__chal'; ch.textContent = 'Challenge a friend with this ' + fmt(tl); chw.appendChild(chn); chw.appendChild(ch); stage.appendChild(chw); var chT = setTimeout(function () { if (chw.parentNode) chw.parentNode.removeChild(chw); }, 12000); on(chn, 'focus', function () { clearTimeout(chT); });
				on(ch, 'click', function () { clearTimeout(chT); setTimeout(function () { if (chw.parentNode) chw.parentNode.removeChild(chw); }, 8000); lap.nm = chn.value.trim(); ch.textContent = 'Making the link…'; challengeLink(lap).then(function (url) { var txt = 'Beat my ' + fmt(tl) + ' on ' + TRACKS[trk].name + ' in a ' + cname(c) + ' at Laqim Racing: ' + url; if (navigator.share) navigator.share({ title: 'Laqim Racing challenge', text: txt }).catch(function () {}); else if (navigator.clipboard) navigator.clipboard.writeText(txt).then(function () { ch.textContent = 'Link copied. Paste it to your friend.'; }); else ch.textContent = url; if (navigator.share) ch.textContent = 'Sent'; }).catch(function () { ch.textContent = 'Could not make the link'; }); });
			}
			function bankDrift(s) { if (s.dcombo > 0) { s.drift += s.dcombo * s.dmul; s.dcombo = 0; s.dmul = 1; } }
			function driftStep(s, dt) {
				var ang = Math.abs(s.slip), ok = ang > .22 && s.v > 11 && !s.off;
				if (s.off || s.hit > 0) { if (s.dcombo > 0) flash('Combo lost', 900); s.dcombo = 0; s.dmul = 1; s.dcool = 0; return; }
				if (ok) { s.dcombo += ang * s.v * dt * 12; s.dhold = (s.dhold || 0) + dt; if (s.dhold > 1.4) { s.dhold = 0; s.dmul = Math.min(6, s.dmul + .5); FX.play('tick'); } s.dcool = 0; }
				else { s.dcool += dt; s.dhold = 0; if (s.dcool > .9) bankDrift(s); }
				$('[data-rx-ds]', root).textContent = Math.round(s.drift + s.dcombo * s.dmul).toLocaleString('en-GB'); $('[data-rx-dm]', root).textContent = s.dcombo > 0 ? ' ×' + s.dmul.toFixed(1) : '';
			}
			/* rigid-body contact: car boxes push, spin and scrape each other; impulses also feed damage */
			function impulse(sa, px, pz, nx, nz, pen, sb, e, fr) {
				var ma = 1 / (sa.m || 1500), ia = 1 / (sa.Iz || 3000), mb = sb ? 1 / (sb.m || 1500) : 0, ib = sb ? 1 / (sb.Iz || 3000) : 0;
				var rax = px - sa.x, raz = pz - sa.z, rbx = sb ? px - sb.x : 0, rbz = sb ? pz - sb.z : 0;
				var vax = sa.vx - sa.r * raz, vaz = sa.vz + sa.r * rax, vbx = sb ? sb.vx - sb.r * rbz : 0, vbz = sb ? sb.vz + sb.r * rbx : 0, rvx = vax - vbx, rvz = vaz - vbz, vn = rvx * nx + rvz * nz;
				var tot = ma + mb; if (pen > 0) { var cx = nx * pen / tot, cz = nz * pen / tot; sa.x += cx * ma; sa.z += cz * ma; if (sb) { sb.x -= cx * mb; sb.z -= cz * mb; } }
				if (vn >= 0) return 0;
				var cra = rax * nz - raz * nx, crb = rbx * nz - rbz * nx, j = -(1 + e) * vn / (ma + mb + cra * cra * ia + crb * crb * ib);
				var tx = -nz, tz = nx, vt = rvx * tx + rvz * tz, cta = rax * tz - raz * tx, ctb = rbx * tz - rbz * tx, jt = -vt / (ma + mb + cta * cta * ia + ctb * ctb * ib); jt = Math.max(-fr * j, Math.min(fr * j, jt));
				var ix = nx * j + tx * jt, iz = nz * j + tz * jt;
				sa.vx += ix * ma; sa.vz += iz * ma; sa.r += (rax * iz - raz * ix) * ia; if (sb) { sb.vx -= ix * mb; sb.vz -= iz * mb; sb.r -= (rbx * iz - rbz * ix) * ib; }
				var dv = j * ma; if (dv > 2.5) { sa.hit = Math.min(.5, dv / 20); hurt(sa, dv, px, pz); } if (sb && j * mb > 2.5) { sb.hit = Math.min(.5, j * mb / 20); hurt(sb, j * mb, px, pz); }
				return j;
			}
			function corners(sv, pad) { var c = Math.cos(sv.h), n = Math.sin(sv.h), hl = (sv.hl || 2.35) + (pad || 0), hw = (sv.hw || .97) + (pad || 0), o = []; [[hl, hw], [hl, -hw], [-hl, hw], [-hl, -hw], [hl, 0], [-hl, 0], [0, hw], [0, -hw]].forEach(function (q) { o.push([sv.x + c * q[0] - n * q[1], sv.z + n * q[0] + c * q[1]]); }); return o; }
			function collide(a, b) {
				if (a.vx == null || b.vx == null) return; var dx = b.x - a.x, dz = b.z - a.z, rr = (a.hl || 2.35) + (b.hl || 2.35) + .4; if (dx * dx + dz * dz > rr * rr) return;
				[[a, b], [b, a]].forEach(function (pr) { var A0 = pr[0], B0 = pr[1], cb = Math.cos(B0.h), sb2 = Math.sin(B0.h), hl = B0.hl || 2.35, hw = B0.hw || .97;
					corners(A0).forEach(function (pt) { var lx = (pt[0] - B0.x) * cb + (pt[1] - B0.z) * sb2, ly = -(pt[0] - B0.x) * sb2 + (pt[1] - B0.z) * cb; if (Math.abs(lx) > hl || Math.abs(ly) > hw) return;
						var px = hl - Math.abs(lx), py = hw - Math.abs(ly), nx, nz, pen; if (px < py) { nx = cb * Math.sign(lx); nz = sb2 * Math.sign(lx); pen = px; } else { nx = -sb2 * Math.sign(ly); nz = cb * Math.sign(ly); pen = py; }
						impulse(A0, pt[0], pt[1], nx, nz, pen, B0, .28, .35); }); });
			}
			/* walls, barriers, gantry posts, trees and rocks */
			function hitWorld(sv) {
				var bd = barrierD, cs8 = corners(sv);
				for (var ci = 0; ci < cs8.length; ci++) { var pt = cs8[ci];
					if (bd) { var r0 = nearest(pt[0], pt[1], sv.idx), k0 = r0[0], sdv = (pt[0] - pts[k0].x) * nor[k0].x + (pt[1] - pts[k0].z) * nor[k0].z, ad = Math.abs(sdv); if (ad > bd && ad < bd + 3 && (!barOK || barOK[k0][sdv < 0 ? 0 : 1])) { var sg = Math.sign(sdv); impulse(sv, pt[0], pt[1], -nor[k0].x * sg, -nor[k0].z * sg, ad - bd, null, barrierE, barrierF); } }
					var cell = obsGrid[((Math.floor(pt[0] / 12) + 500) * 1000 + Math.floor(pt[1] / 12) + 500)]; if (cell) for (var oi = 0; oi < cell.length; oi++) { var ob = cell[oi], ox = pt[0] - ob[0], oz = pt[1] - ob[1], od = ox * ox + oz * oz; if (od < ob[2] * ob[2] && od > 1e-6) { od = Math.sqrt(od); impulse(sv, pt[0], pt[1], ox / od, oz / od, ob[2] - od, null, .2, .5); } }
				}
			}
			function hurt(sv, dv, px, pz) { if (!sv.dmg) sv.dmg = { eng: 0, susp: 0, toe: 0, body: 0, rad: 0, gbx: 0 }; var d = sv.dmg, k = Math.max(0, dv - 2.5) / 40 / (sv === P1.s && RS && RS.guard ? Math.sqrt(RS.guard) : 1), c0 = Math.cos(sv.h), s0 = Math.sin(sv.h), fwd = (px - sv.x) * c0 + (pz - sv.z) * s0, side = -(px - sv.x) * s0 + (pz - sv.z) * c0;
				d.body = Math.min(1, d.body + k); d.rad = d.rad || 0; d.gbx = d.gbx || 0; billAdd(sv, k, fwd, side);
				if (fwd > .8) { d.eng = Math.min(.8, d.eng + k * .6); d.rad = Math.min(1, d.rad + k * 1.1); d.susp = Math.min(1, d.susp + k * .5); d.toe = Math.max(-.06, Math.min(.06, d.toe + (side > 0 ? 1 : -1) * k * .06)); }
				else if (fwd < -.8) { d.gbx = Math.min(1, d.gbx + k * .7); d.susp = Math.min(1, d.susp + k * .3); }
				else { d.susp = Math.min(1, d.susp + k * .8); d.toe = Math.max(-.06, Math.min(.06, d.toe + (side > 0 ? 1 : -1) * k * .08)); }
				if (mode === 'rally' && sv === P1.s && RS) { if (k > .08 && Math.random() < k * 1.6) puncture(sv, (fwd > 0 ? 0 : 2) + (side > 0 ? 1 : 0)); if (k > .1) RS.major = 1; var lat2 = Math.abs(side) > Math.abs(fwd) * .6; if (dv > 9 && lat2 && Math.random() < .55) { sv.rolled = 1; flash('You rolled it! The fans can put you back on your wheels.', 3200); } }
				if (sv === P1.s) { FX.buzz(Math.min(120, 20 + dv * 6)); rumble(Math.min(1, dv / 12), 160 + dv * 20); } if (dmgOn === false) { d.eng = d.susp = d.toe = d.rad = d.gbx = 0; } }
			function rumble(mag, ms) { try { var gps = navigator.getGamepads ? navigator.getGamepads() : []; for (var i = 0; i < gps.length; i++) { var gp = gps[i]; if (gp && gp.vibrationActuator && gp.vibrationActuator.playEffect) gp.vibrationActuator.playEffect('dual-rumble', { duration: ms, strongMagnitude: mag, weakMagnitude: mag * .6 }); } } catch (e) {} }
			/* render setup */
			function size() { var r = stage.getBoundingClientRect(); R.setSize(r.width, r.height, false); var duo = DUO() && live, wide = r.width > r.height * 1.2; C.aspect = duo ? (wide ? r.width / 2 / r.height : r.width / (r.height / 2)) : r.width / Math.max(1, r.height); C2.aspect = C.aspect; C.updateProjectionMatrix(); C2.updateProjectionMatrix(); }
			size(); on(w, 'resize', size);
			var vis = true; if ('IntersectionObserver' in w) new IntersectionObserver(function (es) { vis = es[0].isIntersecting; }).observe(stage);
			var tmpF = new T.Vector3(), tmpC = new T.Vector3();
			function place(Hh, s, b) { var y = H(s.x, s.z) + (s.y || 0); Hh.holder.position.set(s.x, y, s.z); Hh.holder.rotation.set(0, -s.h, 0); var ahead = H(s.x + Math.cos(s.h) * 2, s.z + Math.sin(s.h) * 2), side = H(s.x - Math.sin(s.h) * 1.2, s.z + Math.cos(s.h) * 1.2); Hh.body.rotation.z = Math.atan2(ahead - y, 2) - (s.ax || 0) * .0065; if (s.rolled) { Hh.body.rotation.x = Math.PI * .92; Hh.body.position.y = 1.1; return; } Hh.body.rotation.x = -Math.atan2(side - y, 1.2) * .8 + (s.ay || 0) * .0075 * (b && b.susp === 'lift' ? 1.5 : b && b.susp === 'low' ? .6 : 1); var rough = ROUGH[s.surf] || 0; if (rough && s.v > 3) Hh.body.position.y = (b ? (SUSP[b.susp] || SUSP.stock).ride : 0) + (Math.random() - .5) * .05 * rough * (b && b.susp === 'lift' ? .4 : 1); Hh.flame.visible = !!s.boost; if (s.boost) Hh.flame.scale.set(1, .8 + Math.random() * .5, 1); }
			function camFor(P, Cm, dt) {
				var s = P.s, hh = s.h, fwd = tmpF.set(Math.cos(hh), 0, Math.sin(hh)), px = s.x, pz = s.z, py = H(px, pz), want = tmpC.set(px - Math.cos(s.va) * 8.5, py + 3.1, pz - Math.sin(s.va) * 8.5), cm = CAMS[camI];
				if (cm === 'bonnet') { Cm.position.set(px + fwd.x * .4, py + 1.25 + (P.b ? (SUSP[P.b.susp] || SUSP.stock).ride : 0), pz + fwd.z * .4); Cm.lookAt(px + fwd.x * 20, py + 1, pz + fwd.z * 20); P.cam = null; }
				else if (cm === 'tv') { var bi = 0, bd = 1e9; TVC.forEach(function (q, k) { var dx = q[0] - px, dz = q[1] - pz, dd = dx * dx + dz * dz; if (dd < bd) { bd = dd; bi = k; } }); Cm.position.set(TVC[bi][0], TVC[bi][2] + 7, TVC[bi][1]); Cm.lookAt(px, py + 1, pz); P.cam = null; }
				else if (cm === 'drone') { var mxp = px, mzp = pz, nb = 1; bots.forEach(function (b) { if (b.follow) { mxp += b.s.x; mzp += b.s.z; nb++; } }); mxp /= nb; mzp /= nb; var sx = -Math.sin(hh), sz = Math.cos(hh), dw = tmpC.set(mxp + sx * (16 + nb * 3) - fwd.x * 6, H(mxp, mzp) + 10 + nb * 1.5, mzp + sz * (16 + nb * 3) - fwd.z * 6); if (!P.cam) P.cam = dw.clone(); P.cam.lerp(dw, 1 - Math.exp(-dt * 2.5)); Cm.position.copy(P.cam); Cm.lookAt(mxp, H(mxp, mzp) + 1, mzp); }
				else { if (cm === 'high') want.set(px - fwd.x * 15, py + 9, pz - fwd.z * 15); if (!P.cam) P.cam = want.clone(); P.cam.lerp(want, 1 - Math.exp(-dt * 9)); var gy = H(P.cam.x, P.cam.z) + 1.2; if (P.cam.y < gy) P.cam.y = gy; Cm.position.copy(P.cam); Cm.lookAt(px + fwd.x * 6, py + 1.1, pz + fwd.z * 6); }
				var shake = s.v > 6 && (s.off || (ROUGH[s.surf] || 0) > .3) ? .05 + (ROUGH[s.surf] || 0) * .03 : 0; if (s.hit > 0) shake = .25; if (shake) { Cm.position.x += (Math.random() - .5) * shake; Cm.position.y += (Math.random() - .5) * shake; }
				Cm.fov = (cm === 'bonnet' ? 68 : cm === 'tv' ? 40 : 60) + Math.min(16, s.v * .18) + (s.boost ? 5 : 0); Cm.near = cm === 'chase' ? 2.4 : cm === 'high' ? 3 : .1; Cm.updateProjectionMatrix();
			}
			function inputFor(P, idx) {
				var E = { l: P.K.l, r: P.K.r, t: mode === 'vroom' && idx === 0 && PM && mic.an ? PM.vol : P.K.t, b: P.K.b, h: P.K.h, n: mode === 'vroom' && idx === 0 && PM && PM.rise ? 1 : P.K.n, s: idx === 0 && tiltOn && Math.abs(tilt) > 3 ? Math.max(-1, Math.min(1, tilt / 28)) : null }; E.gu = P.K.gu; E.gd = P.K.gd; P.K.gu = P.K.gd = 0;
				var gps = navigator.getGamepads ? navigator.getGamepads() : null, list = []; for (var gi = 0; gps && gi < gps.length; gi++) if (gps[gi]) list.push(gps[gi]);
				var gp = DUO() ? list[idx] : (idx === 0 ? list[0] : null); if (mode === 'tandem' && idx === 0 && list[1]) { var g2 = list[1], rt2 = g2.buttons[7] ? g2.buttons[7].value : 0, lt2 = g2.buttons[6] ? g2.buttons[6].value : 0; if (g2.buttons[0] && g2.buttons[0].pressed) rt2 = 1; if (rt2 > .05) E.t = rt2; if (lt2 > .1) E.b = 1; if (g2.buttons[1] && g2.buttons[1].pressed) E.n = 1; if (gp) { gp = { axes: [gp.axes[0] || 0], buttons: [{}, {}, gp.buttons[2], gp.buttons[3], gp.buttons[4], {}, {}, {}, gp.buttons[8], gp.buttons[9]] }; } }
				if (gp) { var ax = gp.axes[0] || 0, rt = gp.buttons[7] ? gp.buttons[7].value : 0, lt = gp.buttons[6] ? gp.buttons[6].value : 0; if (gp.buttons[0] && gp.buttons[0].pressed) rt = 1; if (Math.abs(ax) > .12) E.s = ax; if (rt > .05) E.t = Math.max(E.t, rt); if (lt > .1) E.b = 1; if (gp.buttons[2] && gp.buttons[2].pressed) E.h = 1; if ((gp.buttons[1] && gp.buttons[1].pressed) || (mode !== 'rally' && gp.buttons[5] && gp.buttons[5].pressed)) E.n = 1; var yb = gp.buttons[3] && gp.buttons[3].pressed; if (yb && !P.yb) camNext(); P.yb = yb; var lb = gp.buttons[4] && gp.buttons[4].pressed, rbb = mode === 'rally' && gp.buttons[5] && gp.buttons[5].pressed; if (lb && !P.lb) P.K.gd = 1; if (rbb && !P.rbb) P.K.gu = 1; P.lb = lb; P.rbb = rbb; var stB = gp.buttons[9] && gp.buttons[9].pressed, bkB = gp.buttons[8] && gp.buttons[8].pressed; if (stB && !P.stB) pauseGame(); if (bkB && !P.bkB) resetCar(); P.stB = stB; P.bkB = bkB; }
				return E;
			}
			var aqT = 0, aqN = 0;
			(function loop(now) {
				requestAnimationFrame(loop); if (paused) { try { var gq = navigator.getGamepads ? navigator.getGamepads() : []; for (var gi9 = 0; gi9 < gq.length; gi9++) { var g9 = gq[gi9]; if (!g9) continue; var st9 = g9.buttons[9] && g9.buttons[9].pressed; if (st9 && !P1.stB) pauseGame(false); P1.stB = st9; } } catch (e) {} } if (!vis || paused) { if (last) lostT += now - last; last = now; return; } var rawD = last ? (now - last) / 1000 : 0, dtAll = Math.min(.25, rawD); if (rawD > .25) lostT += (rawD - .25) * 1000; last = now; now -= lostT;
				if (RP.on) { lostT += dtAll * 1000; rpStep(dtAll); skyMesh.position.copy(C.position); R.render(S, C); return; }
				if (dtAll > 0 && dtAll < .25) { aqT += dtAll; aqN++; if (aqN >= 120) { if (aqT / aqN > 1 / 40 && R.getPixelRatio() > 1) { R.setPixelRatio(Math.max(1, R.getPixelRatio() - .3)); size(); } aqT = 0; aqN = 0; } }
				if (!pts) return;
				var dt = Math.min(.1, dtAll), nSub = Math.max(1, Math.ceil(dtAll / (1 / 120))), dts = dtAll / nSub;
				if (race && race.phase === 'count') { var left = 3 - Math.floor((now - race.t) / 1000), ctx2 = left > 0 ? String(left) : 'GO'; if (cnt.textContent !== ctx2) FX.play(left > 0 ? 'beep' : 'go'); cnt.textContent = ctx2; if (left <= 0) { race.phase = 'run'; P1.started = true; P1.t0 = now; if (P2.s) { P2.started = true; P2.t0 = now; } setTimeout(function () { cnt.hidden = true; }, 700); } }
				var frozen = race && (race.phase === 'count' || race.phase === 'bets'), E1 = inputFor(P1, 0), E2 = P2.s ? inputFor(P2, 1) : null; lastE1 = E1;
				if (live && P1.s && !frozen) for (var sub = 0; sub < nSub; sub++) {
					if (!P1.started && (E1.t || E1.b || E1.l || E1.r || E1.s)) { P1.started = true; P1.t0 = now; }
					var brakeAll = { l: 0, r: 0, t: 0, b: 1 };
					if (w.__rxAuto) { aiDrive(P1.s, P1.p, K, 1); E1 = { l: K.l, r: K.r, s: K.s, sa: K.sa, t: K.t, b: K.b, h: 0, n: K.n }; if (!P1.started) { P1.started = true; P1.t0 = now; } } var cr = stepCar(P1.s, P1.p, P1.done ? brakeAll : E1, dts);
					if (cr && P1.started && !P1.done) {
						var tl = (now - P1.t0) / 1000;
						if (mode === 'rally') rallyFinish(tl); else if (race && !race.party) { if (P1.s.lap >= race.laps) { P1.done = true; P1.finT = now; if (DUO() || placing()[0].me) finishRace(now); else { flash('Finished P' + (placing().findIndex(function (r) { return r.me; }) + 1)); setTimeout(function () { if (race && race.phase !== 'done') finishRace(performance.now() - lostT); }, 2500); } } else { $('[data-hl-lap]', root).textContent = (P1.s.lap + 1) + ' / ' + race.laps; $('[data-hl-last]', root).textContent = fmt(tl); if (P1.s.lap === race.laps - 1) flash('Final lap'); P1.t0 = now; } }
						else lapDone(P1, tl, now);
					}
					if (P2.s) { var c2 = stepCar(P2.s, P2.p, P2.done ? brakeAll : E2, dts); if (c2 && race && race.phase === 'run' && !P2.done) { if (P2.s.lap >= race.laps) { P2.done = true; P2.finT = now; if (race.phase !== 'done') finishRace(now); } } collide(P1.s, P2.s); }
					if (mode === 'convoy' && P1.started) { var lt0 = trail[trail.length - 1]; if (!lt0 || Math.abs(lt0[0] - P1.s.x) + Math.abs(lt0[1] - P1.s.z) > .6) { if (lt0) trailLen += Math.sqrt(Math.pow(lt0[0] - P1.s.x, 2) + Math.pow(lt0[1] - P1.s.z, 2)); trail.push([P1.s.x, P1.s.z, P1.s.va, P1.s.v, trailLen]); if (trail.length > 4000) trail.splice(0, 1000); } }
					var tight = true, nF = 0, nT = 0;
					bots.forEach(function (bt) { if (bt.out) return; if (bt.stat) { var v0x = P1.s.vx, v0z = P1.s.vz; collide(P1.s, bt.s); var dvv = Math.hypot(P1.s.vx - v0x, P1.s.vz - v0z); if (dvv > .3) bt.touch = Math.max(bt.touch || 0, dvv); bt.s.vx = bt.s.vz = bt.s.r = 0; return; } if (bt.echo) { collide(P1.s, bt.s); return; } if (bt.follow) { var fd = followDrive(bt, dts); nF++; if (fd <= 26) nT++; bt.stk = bt.s.v < 2.5 && fd > 30 ? (bt.stk || 0) + dts : 0; if (bt.stk > 2.5) { bt.stk = 0; var ri = (P1.s.idx - 8 * bt.follow + N) % N, sp0 = spawn(ri, (bt.follow % 2 ? 1 : -1) * 1.6); bt.s.x = sp0.x; bt.s.z = sp0.z; bt.s.h = bt.s.va = sp0.h; bt.s.idx = ri; bt.s.vx = Math.cos(sp0.h) * P1.s.v * .8; bt.s.vz = Math.sin(sp0.h) * P1.s.v * .8; bt.s.r = 0; } } else if (bt.done) { bt.K.t = 0; bt.K.b = 1; bt.K.l = bt.K.r = 0; } else if (!(PM && PM.ctrl)) aiDrive(bt.s, bt.p, bt.K, bt.skill, bt.lane); var cb = stepCar(bt.s, bt.p, bt.K, dts); if (cb && race && bt.s.lap >= race.laps && !bt.done) { bt.done = true; bt.finT = now; } collide(P1.s, bt.s); if (P2.s) collide(P2.s, bt.s); });
					for (var i1 = 0; i1 < bots.length; i1++) for (var i2 = i1 + 1; i2 < bots.length; i2++) if (!bots[i1].out && !bots[i2].out && !bots[i1].echo && !bots[i2].echo && !bots[i1].stat && !bots[i2].stat) collide(bots[i1].s, bots[i2].s);
					if (PM && PMS[mode] && PMS[mode].tick && !PM.over) PMS[mode].tick(dts, now); if (bots.length || P2.s) draftAll();
					if (mode === 'drift') driftStep(P1.s, dts);
					if (mode === 'rally' && RS && !RS.done) rallyTick(dts, now);
					if (mode === 'convoy' && P1.started && trailLen > 80) { coh.t += dts; coh.ok += dts * (nF ? nT / nF : 1); }
				}
				if (live && P1.s) {
					var s = P1.s; rpRecord(now); if (P1.started && !P1.done && !(race && race.phase === 'done')) $('[data-hl-t]', root).textContent = fmt((now - P1.t0) / 1000);
					commTick(); var dch = $('[data-pm-draft]', root), dv = (s.draft || 0) > .15; if (dch.hidden === dv) dch.hidden = !dv; var bch = $('[data-pm-billc]', root); if (P1.billT) { bch.hidden = false; var bt0 = '$' + Math.round(P1.billT * 1.18).toLocaleString('en-GB'); if (bch.__t !== bt0) { bch.textContent = 'Bill ' + bt0; bch.__t = bt0; } } else bch.hidden = true;
					var kmh = s.v * 3.6, gear = s.rev ? 'R' : (s.gear || 1);
					$('[data-hl-v]', root).textContent = Math.round(kmh); $('[data-hl-g]', root).textContent = s.v < .3 ? 'N' : P1.p.ev ? 'E' : gear;
					if (P1.p.nitro) $('[data-rx-nosbar]', root).style.width = Math.round(s.nos * 100) + '%';
					if ((mode === 'race' || DUO()) && race) { var all = drawBoard(); $('[data-hl-p]', root).textContent = all.findIndex(function (r) { return r.me; }) + 1; if (P2.s) { $('[data-rx-p2pos]', root).textContent = all.findIndex(function (r) { return r.p2; }) + 1; $('[data-rx-v2]', root).textContent = Math.round(P2.s.v * 3.6); $('[data-rx-lap2]', root).textContent = Math.min(P2.s.lap + 1, race.laps); if (P2.p.nitro) $('[data-rx-nosbar2]', root).style.width = Math.round(P2.s.nos * 100) + '%'; } }
					if (synth && sndOn) { var x = Math.max(0, Math.min(1, ((s.rpm || .3) - .22) / .93)); if (s.spin && E1.t) x = Math.min(1, x + .25); synth.set(P1.p.ev ? 700 + kmh * 18 : 1100 + x * 5600, P1.p.ev ? 2 : P1.p.cyl, E1.t ? 1 : .2); }
					/* ghost and splits in solo modes */
					if (P1.started && !race && mode !== 'drift' && mode !== 'convoy') {
						var lt = (now - P1.t0) / 1000; if (lt - P1.recT >= 1 / 15 || !P1.rec.length) { P1.rec.push([lt, s.x, s.z, s.h]); P1.recT = lt; }
						var pre = s.idx > N * .9 && !s.half, bk = Math.floor(s.idx / 10); if (!pre && P1.spl[bk] == null) P1.spl[bk] = lt;
						if (ghost && ghost.p && ghost.p.length > 2) { var gp = ghost.p; while (ghI < gp.length - 2 && gp[ghI + 1][0] < lt) ghI++; var g0 = gp[ghI], g1 = gp[ghI + 1], f = Math.max(0, Math.min(1, (lt - g0[0]) / Math.max(1e-3, g1[0] - g0[0]))), dh = angd(g1[3], g0[3]), gx = g0[1] + (g1[1] - g0[1]) * f, gz = g0[2] + (g1[2] - g0[2]) * f; gh.visible = lt < gp[gp.length - 1][0]; gh.position.set(gx, H(gx, gz), gz); gh.rotation.y = -(g0[3] + dh * f);
							var gs = ghost.s && ghost.s[bk]; if (gs != null && bk > 1 && !pre) { var dl = lt - gs, de = $('[data-hl-delta]', root); de.hidden = false; de.textContent = (dl > 0 ? '+' : '−') + Math.abs(dl).toFixed(2); de.classList.toggle('is-up', dl > 0); } }
					}
				}
				/* effects for every car */
				var everyone = [[P1, me]]; if (P2.s) everyone.push([P2, p2h]); bots.forEach(function (b) { everyone.push([b, b.H]); });
				everyone.forEach(function (e) { var s = e[0].s; if (!s) return; place(e[1], s, e[0].b || null); if (s.hit > 0) s.hit -= dt; var rough = ROUGH[s.surf] || 0; if (((Math.abs(s.slip) > .12 || (s.slide || 0) > 1.4 || s.spin) && s.v > 6 && !rough) || (e[0] === P1 && E1.b && s.v > 14 && !rough)) { s.skT = (s.skT || 0) + dt; if (s.skT > .035) { s.skT = 0; markAt(s); } } if (rough && s.v > 5 && Math.random() < Math.min(.9, s.v / 30)) { var bx = s.x - Math.cos(s.h) * 2.2, bz = s.z - Math.sin(s.h) * 2.2; puff(bx, H(bx, bz) + .3, bz, -Math.cos(s.va) * s.v * .15, -Math.sin(s.va) * s.v * .15, s.surf === 'water' ? 0xdfeef6 : s.surf === 'mud' ? 0x5a3e28 : 0xc8925a); } });
				dustStep(dt);
				skyMesh.position.copy(C.position);
				if (P1.s) {
					camFor(P1, C, dt); me.holder.visible = CAMS[camI] !== 'bonnet';
					if (live) drawMap();
					if (DUO() && P2.s && live) {
						camFor(P2, C2, dt); var r0 = stage.getBoundingClientRect(), wv = r0.width, hv = r0.height, wide = wv > hv * 1.2; R.setScissorTest(true);
						p2h.holder.visible = true; me.holder.visible = true;
						if (wide) { R.setViewport(0, 0, wv / 2, hv); R.setScissor(0, 0, wv / 2, hv); R.render(S, C); R.setViewport(wv / 2, 0, wv / 2, hv); R.setScissor(wv / 2, 0, wv / 2, hv); skyMesh.position.copy(C2.position); R.render(S, C2); }
						else { R.setViewport(0, hv / 2, wv, hv / 2); R.setScissor(0, hv / 2, wv, hv / 2); R.render(S, C); R.setViewport(0, 0, wv, hv / 2); R.setScissor(0, 0, wv, hv / 2); skyMesh.position.copy(C2.position); R.render(S, C2); }
						R.setScissorTest(false); R.setViewport(0, 0, wv, hv); return;
					}
				}
				R.render(S, C);
			})(0);
			world(trk);
			function resetCar() { var s = P1.s; if (!s) return; var k = s.idx, p = pts[k]; s.x = p.x; s.z = p.z; s.h = s.va = Math.atan2(tang[k].z, tang[k].x); s.vx = s.vz = s.r = s.v = 0; s.rolled = 0; if (mode === 'rally' && RS) { RS.pen += 10; flash('Back on the road · +10 s', 1800); } else flash('Back on the road', 1200); FX.play('tick'); }
			function pauseGame(onoff) { if (!live || !P1.s) return; paused = onoff == null ? !paused : onoff; var pm = $('[data-hl-pause]', root); pm.hidden = !paused; if (paused) { FX.play('tick'); var b0 = pm.querySelector('button'); if (b0) b0.focus(); } }
			on($('[data-hl-pbtn]', root), 'click', function () { pauseGame(); });
			$$('[data-hl-pact]', root).forEach(function (b) { on(b, 'click', function () { var a = b.getAttribute('data-hl-pact'); pauseGame(false); if (a === 'reset') resetCar(); else if (a === 'restart') { if (mode === 'rally' && RS && RS.restart) RS.restart(); else $('[data-hl-go]', root).click(); } else if (a === 'cam') { camNext(); pauseGame(true); } else if (a === 'replay') { if (!rpStart()) { flash('Drive a little first', 1200); } } else if (a === 'album') { pcAlbum(); pauseGame(true); } else if (a === 'quit') { var cb = RS && RS.onQuit; stop(); RS = null; stage.classList.remove('is-live'); msg.hidden = false; $('[data-rl-dmgh]', root).hidden = true; $('[data-rl-fan]', root).hidden = true; $('[data-rl-rep]', root).hidden = true; if (cb) cb(); } }); });
			on($('[data-rl-fan]', root), 'click', fanPush); on($('[data-rl-rep]', root), 'click', rallyRepair);
			return { start: start, stop: function () { stop(); RS = null; $('[data-rl-note]', root).classList.remove('is-on'); $('[data-rl-dmgh]', root).hidden = true; $('[data-rl-fan]', root).hidden = true; $('[data-rl-rep]', root).hidden = true; }, world: function (k) { world(k); }, rallyIntro: rallyIntro, panel: function (h) { showPanel(h); }, fanPush: fanPush, repair: rallyRepair, pause: pauseGame, reset: resetCar, get live() { return live; } };
		}
	}
	/* ------------------------------------------------------------ game effects: sound, confetti, haptics, share */
	var FX = (function () {
		var ac = null, KEY = 'psr-sfx';
		function sOn() { try { return localStorage.getItem(KEY) !== '0'; } catch (e) { return true; } }
		function ctx() { if (!ac) { var A = w.AudioContext || w.webkitAudioContext; if (!A) return null; ac = new A(); } if (ac.state === 'suspended') ac.resume(); return ac; }
		function tone(f, t0, dur, type, vol, f2) { var c = ctx(); if (!c) return; var o = c.createOscillator(), g = c.createGain(), t = c.currentTime + t0; o.type = type || 'sine'; o.frequency.setValueAtTime(f, t); if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + dur); g.gain.setValueAtTime(.0001, t); g.gain.exponentialRampToValueAtTime(vol || .1, t + .012); g.gain.exponentialRampToValueAtTime(.0001, t + dur); o.connect(g); g.connect(c.destination); o.start(t); o.stop(t + dur + .03); }
		var S = {
			ok: function () { tone(660, 0, .12, 'triangle', .11); tone(990, .08, .2, 'triangle', .11); },
			no: function () { tone(210, 0, .3, 'sawtooth', .06, 120); },
			tick: function () { tone(1300, 0, .035, 'square', .03); },
			flip: function () { tone(420, 0, .09, 'triangle', .06, 880); },
			beep: function () { tone(440, 0, .2, 'square', .06); },
			go: function () { tone(880, 0, .4, 'square', .07); },
			streak: function () { [784, 988, 1175].forEach(function (f, i) { tone(f, i * .06, .14, 'triangle', .08); }); },
			win: function () { [523, 659, 784, 1047, 1319].forEach(function (f, i) { tone(f, i * .09, .3, 'triangle', .1); }); },
			lose: function () { [392, 330, 262].forEach(function (f, i) { tone(f, i * .14, .32, 'sawtooth', .045); }); }
		};
		function play(n) { if (!sOn() || !S[n]) return; try { S[n](); } catch (e) {} }
		function buzz(p) { try { if (navigator.vibrate) navigator.vibrate(p || 25); } catch (e) {} }
		function confetti(el, n) {
			if (RM) return; var r = (el || d.body).getBoundingClientRect(), cv = d.createElement('canvas'), W = innerWidth, Hh = innerHeight; cv.width = W; cv.height = Hh; cv.className = 'fx-confetti'; d.body.appendChild(cv);
			var x = cv.getContext('2d'), cols = ['#f1d27a', '#c99a3a', '#ffffff', '#8a6a22', '#e8c25a'], P = [], cx = r.width ? r.left + r.width / 2 : W / 2, cy = Math.max(60, Math.min(Hh - 60, r.top + Math.min(r.height / 2, 220)));
			for (var i = 0; i < (n || 150); i++) { var a = -Math.PI / 2 + (Math.random() - .5) * 2.4, sp = 5 + Math.random() * 10; P.push({ x: cx + (Math.random() - .5) * 60, y: cy, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, s: 5 + Math.random() * 7, r: Math.random() * 6, vr: (Math.random() - .5) * .4, c: cols[i % cols.length] }); }
			var t0 = performance.now(); (function f(now) { var k = (now - t0) / 1000; x.clearRect(0, 0, W, Hh); P.forEach(function (p) { p.vy += .32; p.vx *= .985; p.x += p.vx; p.y += p.vy; p.r += p.vr; x.save(); x.globalAlpha = Math.max(0, 1 - k / 2.4); x.translate(p.x, p.y); x.rotate(p.r); x.fillStyle = p.c; x.fillRect(-p.s / 2, -p.s / 4, p.s, p.s / 2); x.restore(); }); if (k < 2.5) requestAnimationFrame(f); else cv.remove(); })(t0);
		}
		function share(text) { var url = location.href.split('#')[0]; if (navigator.share) { navigator.share({ title: 'Laqim Autoworld', text: text, url: url }).catch(function () {}); return; } w.open('https://wa.me/?text=' + encodeURIComponent(text + ' ' + url), '_blank', 'noopener'); }
		function shareBtn(text) { return '<button type="button" class="lx-btn fx-share" data-fx-share="' + esc(text) + '">Share</button>'; }
		on(d, 'click', function (e) { var b = e.target.closest && e.target.closest('[data-fx-share]'); if (b) share(b.getAttribute('data-fx-share')); });
		/* one sound switch for every game, in the Play jump bar */
		var tries = 0; function toggle() { var j = $('.psr-jump__in'); if (!$('[data-psr-quiz], [data-psr-hilo], [data-psr-tt], [data-psr-guess]') || $('.fx-snd')) return; if (!j) { if (tries++ < 20) setTimeout(toggle, 250); return; } var b = d.createElement('button'); b.type = 'button'; b.className = 'fx-snd'; function lab() { b.textContent = sOn() ? '♪ Sound on' : '♪ Sound off'; b.setAttribute('aria-pressed', sOn() ? 'true' : 'false'); } lab(); on(b, 'click', function () { try { localStorage.setItem(KEY, sOn() ? '0' : '1'); } catch (e2) {} lab(); play('tick'); }); j.insertBefore(b, j.firstChild); }
		if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', toggle); else setTimeout(toggle, 0);
		return { play: play, buzz: buzz, confetti: confetti, share: share, shareBtn: shareBtn };
	})();
	function quiz(root) {
		var all = index().filter(function (c) { return c.hp && c.acc; }), Q = [], qi = 0, score = 0, streak = 0, right = 0, timer = 0, tLeft = 0, BK = 'psr-quiz-best';
		function sh(a) { a = a.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
		function nm(c) { return c.make + ' ' + c.model; }
		function distinct(key, n, f) { var seen = {}, out = []; sh(all).forEach(function (c) { var v = f ? f(c) : c[key]; if (!v || seen[v] || out.length >= n || out.some(function (o) { return o.model === c.model; })) return; seen[v] = 1; out.push(c); }); return out.length === n ? out : null; }
		var GEN = [
			function () { var cs = distinct('acc', 4); if (!cs) return; var a = cs.reduce(function (x, y) { return y.acc < x.acc ? y : x; }); return { q: 'Which of these reaches 100 km/h first?', o: cs.map(nm), a: nm(a), x: cs.map(function (c) { return c.model + ' ' + c.acc + ' s'; }).join(' · ') }; },
			function () { var cs = distinct('tq', 4); if (!cs) return; var a = cs.reduce(function (x, y) { return y.tq > x.tq ? y : x; }); return { q: 'Which of these has the most torque?', o: cs.map(nm), a: nm(a), x: cs.map(function (c) { return c.model + ' ' + c.tq + ' Nm'; }).join(' · ') }; },
			function () { var cs = distinct('kg', 4); if (!cs) return; var a = cs.reduce(function (x, y) { return y.kg > x.kg ? y : x; }); return { q: 'Which of these is the heaviest?', o: cs.map(nm), a: nm(a), x: cs.map(function (c) { return c.model + ' ' + c.kg.toLocaleString() + ' kg'; }).join(' · ') }; },
			function () { var c = sh(all.filter(function (c) { return c.cyl; }))[0]; if (!c) return; var opts = sh([4, 6, 8, 12].filter(function (n) { return n !== c.cyl; })).slice(0, 3).concat(c.cyl); return { q: 'How many cylinders does the ' + nm(c) + ' have?', img: c.img, o: sh(opts).map(String), a: String(c.cyl), x: 'Its engine: ' + c.engine + '.' }; },
			function () { var c = sh(all.filter(function (c) { return c.vmax; }))[0]; if (!c) return; var v = c.vmax, opts = [v]; [-40, -20, 20, 40, 60].forEach(function (d) { if (opts.length < 4 && v + d > 150 && Math.random() > .3) opts.push(v + d); }); while (opts.length < 4) opts.push(v + 10 * opts.length + 15); return { q: 'What is the top speed of the ' + nm(c) + '?', img: c.img, o: sh(opts).map(function (x) { return x + ' km/h'; }), a: v + ' km/h', x: 'Published top speed: ' + v + ' km/h' + (v === 250 || v === 210 ? ', electronically limited.' : '.') }; },
			function () { var cs = distinct(null, 4, function (c) { return c.dim && c.dim[0]; }); if (!cs) return; var a = cs.reduce(function (x, y) { return y.dim[0] > x.dim[0] ? y : x; }); return { q: 'Which of these is the longest?', o: cs.map(nm), a: nm(a), x: cs.map(function (c) { return c.model + ' ' + c.dim[0].toLocaleString() + ' mm'; }).join(' · ') }; },
			function () { var cs = distinct('engine', 4); if (!cs) return; var a = cs[Math.floor(Math.random() * 4)]; return { q: 'Which car uses this engine: ' + a.engine + '?', o: cs.map(nm), a: nm(a), x: a.model + ': ' + a.engine + ', ' + a.hp + ' hp.' }; },
			function () { var cs = distinct(null, 4, function (c) { return c.kg ? Math.round(c.hp / c.kg * 1000) : 0; }); if (!cs) return; var pw = function (c) { return Math.round(c.hp / c.kg * 1000); }, a = cs.reduce(function (x, y) { return pw(y) > pw(x) ? y : x; }); return { q: 'Which has the best power-to-weight ratio?', o: cs.map(nm), a: nm(a), x: cs.map(function (c) { return c.model + ' ' + pw(c) + ' hp per tonne'; }).join(' · ') }; },
			function () { var c = sh(all)[0], v = c.hp, opts = [v]; [-120, -60, 60, 120, 180].forEach(function (d) { if (opts.length < 4 && v + d > 100 && Math.random() > .3) opts.push(v + d); }); while (opts.length < 4) opts.push(v + 45 * opts.length); return { q: 'How much power does the ' + nm(c) + ' make?', img: c.img, o: sh(opts).map(function (x) { return x + ' hp'; }), a: v + ' hp', x: c.power ? 'Quoted as ' + c.power + ' (' + v + ' hp).' : v + ' hp.' }; }
		];
		function build() { Q = []; var order = sh(GEN.concat(GEN)).slice(0, 14), guard = 0; while (Q.length < 10 && guard++ < 60) { var g = order[guard % order.length](); if (g && !Q.some(function (x) { return x.q === g.q; })) Q.push(g); } }
		function best() { try { return +localStorage.getItem(BK) || 0; } catch (e) { return 0; } }
		root.innerHTML = '<div class="qz__top"><div><small>Question</small><b data-qz-n>–</b></div><div><small>Score</small><b data-qz-s>0</b></div><div><small>Streak</small><b data-qz-k>0</b></div><div><small>Your best</small><b data-qz-b>' + (best() || '–') + '</b></div></div><div class="qz__time"><i data-qz-t></i></div><div class="qz__card" data-qz-card><div class="qz__intro"><h3>Ten questions on the showcase.</h3><p>Figures, engines, weights and speeds, all from the cars on this site. Answer faster for bonus points.</p><button type="button" class="lx-btn lx-btn--gold" data-qz-go>Start the quiz</button></div></div>';
		var card = $('[data-qz-card]', root), bar = $('[data-qz-t]', root);
		function stat() { $('[data-qz-n]', root).textContent = Math.min(qi + 1, 10) + ' / 10'; $('[data-qz-s]', root).textContent = score; $('[data-qz-k]', root).textContent = streak; }
		function show() {
			var q = Q[qi]; stat(); clearInterval(timer); tLeft = 15; bar.style.transition = 'none'; bar.style.width = '100%';
			card.innerHTML = (q.img ? '<div class="qz__img" style="background-image:url(\'' + q.img + '\')"></div>' : '') + '<h3 class="qz__q">' + esc(q.q) + '</h3><div class="qz__opts">' + q.o.map(function (o) { var cc = all.filter(function (c) { return nm(c) === o; })[0]; return '<button type="button" data-qz-o="' + esc(o) + '"' + (cc && cc.img ? ' class="has-img"' : '') + '>' + (cc && cc.img ? '<img src="' + cc.img + '" alt="" loading="lazy">' : '') + '<span>' + esc(o) + '</span></button>'; }).join('') + '</div><p class="qz__x" data-qz-x hidden></p><button type="button" class="lx-btn lx-btn--gold qz__next" data-qz-next hidden>' + (qi < 9 ? 'Next question' : 'See your score') + '</button>';
			requestAnimationFrame(function () { bar.style.transition = 'width 15s linear'; bar.style.width = '0%'; });
			var t0 = Date.now(); timer = setInterval(function () { tLeft = 15 - (Date.now() - t0) / 1000; if (tLeft <= 0) { clearInterval(timer); answer(null); } }, 100);
		}
		function answer(pick) {
			var q = Q[qi]; if (!$('[data-qz-o]', card) || card.__done) return; card.__done = true; clearInterval(timer); bar.style.transition = 'none';
			var ok = pick === q.a; if (ok) { right++; streak++; score += 100 + Math.round(Math.max(0, tLeft) / 15 * 50) + (streak >= 3 ? 25 : 0); FX.play(streak >= 3 ? 'streak' : 'ok'); } else { streak = 0; FX.play('no'); FX.buzz(60); card.classList.remove('fx-shake'); void card.offsetWidth; card.classList.add('fx-shake'); }
			$$('[data-qz-o]', card).forEach(function (b) { var v = b.getAttribute('data-qz-o'); b.disabled = true; if (v === q.a) b.classList.add('is-right'); else if (v === pick) b.classList.add('is-wrong'); });
			var x = $('[data-qz-x]', card); x.hidden = false; x.innerHTML = '<b>' + (ok ? 'Correct.' : pick == null ? 'Out of time.' : 'Not quite.') + '</b> ' + esc(q.x); $('[data-qz-next]', card).hidden = false; stat();
		}
		function end() {
			var b = best(), pb = score > b; if (pb) try { localStorage.setItem(BK, score); } catch (e) {}
			$('[data-qz-b]', root).textContent = Math.max(b, score); bar.style.width = '0%';
			card.innerHTML = '<div class="qz__intro"><h3>' + right + ' out of 10. <em>' + score + ' points.</em></h3><p>' + (right >= 9 ? 'A true connoisseur.' : right >= 7 ? 'You know your cars.' : right >= 4 ? 'Solid. The Lab and the car pages hold every answer.' : 'Spend some time in the showcase and come back.') + (pb && b > 0 ? ' New personal best.' : '') + '</p><div class="fx-acts"><button type="button" class="lx-btn lx-btn--gold" data-qz-go>Play again</button>' + FX.shareBtn('I scored ' + score + ' points (' + right + '/10) on the Laqim Autoworld car quiz. Can you beat it?') + '</div></div>';
			if ((pb && b > 0) || right >= 8) { FX.play('win'); FX.confetti(card); } else FX.play(right >= 5 ? 'ok' : 'lose');
		}
		on(root, 'click', function (e) {
			var b = e.target.closest('button'); if (!b) return;
			if (b.hasAttribute('data-qz-go')) { build(); qi = 0; score = 0; streak = 0; right = 0; card.__done = false; show(); var hd = $('.lx-header'), tb = $('.psr-jump'); w.scrollTo({ top: (w.innerWidth < 760 && card ? card : root).getBoundingClientRect().top + w.scrollY - (hd ? hd.getBoundingClientRect().bottom : 80) - (tb ? tb.offsetHeight : 50) - 12, behavior: 'smooth' }); }
			else if (b.hasAttribute('data-qz-o')) answer(b.getAttribute('data-qz-o'));
			else if (b.hasAttribute('data-qz-next')) { qi++; card.__done = false; if (qi >= 10) end(); else show(); }
		});
	}
	function engBuilder(root) {
		var S = { cyl: 8, lay: 'v', bore: 86, stroke: 86, asp: 'tt', red: 6800 }, synth = null, revving = false;
		var ASP = { na: ['Natural', 13, 0], t: ['Single turbo', 21, 0], tt: ['Twin-turbo', 24, 0], hy: ['Twin-turbo + hybrid', 24, 150] };
		var LAYS = { i: 'Inline', v: 'V', f: 'Flat' }, OK = { 3: 'i', 4: 'if', 6: 'ivf', 8: 'v', 10: 'v', 12: 'v' };
		function chips(name, list, cur) { return list.map(function (x) { return '<button type="button" data-eb-' + name + '="' + x[0] + '" aria-pressed="' + (String(x[0]) === String(cur) ? 'true' : 'false') + '">' + x[1] + '</button>'; }).join(''); }
		function slider(k, lab, min, max, step, unit) { return '<label class="eb__sl"><span>' + lab + ' <b data-eb-v="' + k + '"></b>' + unit + '</span><input type="range" min="' + min + '" max="' + max + '" step="' + step + '" value="' + S[k] + '" data-eb-r="' + k + '"></label>'; }
		root.innerHTML = '<div class="eb__ctl"><p class="eb__k">Cylinders</p><div class="eb__chips" data-eb-g="cyl"></div><p class="eb__k">Layout</p><div class="eb__chips" data-eb-g="lay"></div>'
			+ slider('bore', 'Bore', 70, 106, 1, ' mm') + slider('stroke', 'Stroke', 60, 106, 1, ' mm') + '<p class="eb__k">Breathing</p><div class="eb__chips" data-eb-g="asp"></div>' + slider('red', 'Redline', 4000, 9500, 100, ' rpm')
			+ '<div class="eb__btns"><button type="button" class="lx-btn lx-btn--gold" data-eb-rev>Rev it</button><a class="lx-btn lx-btn--dark" data-eb-3d href="#engine">See the layout in 3D</a></div></div>'
			+ '<div class="eb__out"><div class="eb__big"><div><small>Displacement</small><b data-eb-o="l"></b></div><div><small>Peak power</small><b data-eb-o="hp"></b></div><div><small>Peak torque</small><b data-eb-o="tq"></b></div></div>'
			+ '<canvas class="eb__dyno" width="900" height="330" data-eb-dyno></canvas>'
			+ '<div class="eb__meters"><div><small>Mean piston speed at redline</small><div class="eb__bar"><i data-eb-ps></i><em></em></div><p data-eb-pst></p></div><div><small>Bore to stroke</small><p data-eb-bs></p></div><div><small>Specific output</small><p data-eb-so></p></div></div>'
			+ '<p class="eb__verdict" data-eb-verdict></p><p class="eb__near" data-eb-near></p><p class="eb__note">A simplified engineering model: displacement from bore, stroke and cylinders, torque from typical brake mean effective pressure for each type of breathing, and a power curve shaped by redline and piston speed. Real engines vary with tuning, but the trade-offs are real.</p></div>';
		function drawChips() {
			$('[data-eb-g="cyl"]', root).innerHTML = chips('cyl', [3, 4, 6, 8, 10, 12].map(function (n) { return [n, n]; }), S.cyl);
			$('[data-eb-g="lay"]', root).innerHTML = chips('lay', ['i', 'v', 'f'].filter(function (k) { return OK[S.cyl].indexOf(k) > -1; }).map(function (k) { return [k, LAYS[k]]; }), S.lay);
			$('[data-eb-g="asp"]', root).innerHTML = chips('asp', Object.keys(ASP).map(function (k) { return [k, ASP[k][0]]; }), S.asp);
		}
		function model() {
			var L = Math.PI / 4 * Math.pow(S.bore / 10, 2) * (S.stroke / 10) * S.cyl / 1000, A = ASP[S.asp], turbo = S.asp !== 'na';
			var tpk = A[1] * L * 7.958 * (S.cyl === 3 ? .97 : 1), ps = 2 * S.stroke / 1000 * S.red / 60, ve = function (r) { var p = 2 * S.stroke / 1000 * r / 60; return p > 22 ? Math.max(.55, 1 - (p - 22) / 16) : 1; };
			var pts = [], best = { hp: 0, r: 0 }, tmax = 0;
			for (var r = 1000; r <= S.red; r += 50) {
				var f;
				if (!turbo) { var rp = .72 * S.red; f = Math.max(.45, 1 - Math.pow((r - rp) / (.9 * S.red), 2) * 1.4); }
				else { var on = S.asp === 't' ? 2300 : 1800, pl = .7 * S.red; f = r < on ? .55 + .45 * (r - 1000) / Math.max(1, on - 1000) : r <= pl ? 1 : 1 - .18 * (r - pl) / Math.max(1, S.red - pl); }
				var t = tpk * f * ve(r) + (A[2] ? A[2] * Math.max(0, 1 - (r - 1000) / 3000) : 0), hp = t * r / 9549 * 1.341;
				pts.push([r, t, hp]); if (hp > best.hp) best = { hp: hp, r: r }; if (t > tmax) tmax = t;
			}
			return { L: L, pts: pts, hp: best.hp, hpR: best.r, tq: tmax, ps: ps };
		}
		function dyno(M) {
			var cv = $('[data-eb-dyno]', root), nar = cv.clientWidth > 0 && cv.clientWidth < 560; if (nar && cv.width !== 480) { cv.width = 480; cv.height = 300; } else if (!nar && cv.width !== 900) { cv.width = 900; cv.height = 330; } var x = cv.getContext('2d'), W = cv.width, H = cv.height, l = 64, b = 40, rgt = 64, maxT = Math.ceil(M.tq / 100) * 100 + 100, maxP = Math.ceil(M.hp / 100) * 100 + 100;
			function X(r) { return l + (W - l - rgt) * (r - 1000) / (S.red - 1000); }
			x.clearRect(0, 0, W, H); x.font = '600 14px Manrope, sans-serif'; x.lineWidth = 1;
			for (var i = 0; i <= 4; i++) { var y = 16 + (H - b - 16) * i / 4; x.strokeStyle = 'rgba(255,255,255,.08)'; x.beginPath(); x.moveTo(l, y); x.lineTo(W - rgt, y); x.stroke(); x.fillStyle = '#f1d27a'; x.fillText(Math.round(maxT * (1 - i / 4)), 6, y + 5); x.fillStyle = '#7fb4ff'; x.fillText(Math.round(maxP * (1 - i / 4)), W - rgt + 8, y + 5); }
			x.fillStyle = 'rgba(255,255,255,.55)'; for (var r = 1000; r <= S.red; r += 1000) x.fillText((r / 1000) + 'k', X(r) - 8, H - 14);
			[[1, '#f1d27a', maxT], [2, '#7fb4ff', maxP]].forEach(function (c) { x.strokeStyle = c[1]; x.lineWidth = 3.5; x.beginPath(); M.pts.forEach(function (p, i) { var y = H - b - (H - b - 16) * p[c[0]] / c[2]; if (i) x.lineTo(X(p[0]), y); else x.moveTo(X(p[0]), y); }); x.stroke(); });
			x.fillStyle = '#f1d27a'; x.fillText('Torque, Nm', l + 8, 34); x.fillStyle = '#7fb4ff'; x.fillText('Power, hp', l + 120, 34);
		}
		function update() {
			var M = model();
			$('[data-eb-o="l"]', root).innerHTML = M.L.toFixed(1) + '<em> L</em>'; $('[data-eb-o="hp"]', root).innerHTML = Math.round(M.hp) + '<em> hp</em><i>at ' + (Math.round(M.hpR / 100) * 100).toLocaleString() + ' rpm</i>'; $('[data-eb-o="tq"]', root).innerHTML = Math.round(M.tq) + '<em> Nm</em>';
			['bore', 'stroke', 'red'].forEach(function (k) { $('[data-eb-v="' + k + '"]', root).textContent = S[k].toLocaleString(); });
			var pct = Math.min(100, M.ps / 30 * 100), psEl = $('[data-eb-ps]', root); psEl.style.width = pct + '%'; psEl.style.background = M.ps < 20 ? '#3ddc6a' : M.ps < 25 ? '#f2a33a' : '#ff4d4d';
			$('[data-eb-pst]', root).textContent = M.ps.toFixed(1) + ' m/s · ' + (M.ps < 20 ? 'relaxed, built to last' : M.ps < 25 ? 'race-engine territory' : 'beyond what metal survives');
			var bs = S.bore / S.stroke; $('[data-eb-bs]', root).textContent = bs.toFixed(2) + ' · ' + (bs > 1.05 ? 'oversquare: loves to rev' : bs < .95 ? 'undersquare: low-down torque' : 'square: a balance of both');
			$('[data-eb-so]', root).textContent = Math.round(M.hp / M.L) + ' hp per litre';
			var v = M.ps >= 25 ? 'At ' + S.red.toLocaleString() + ' rpm each piston averages ' + M.ps.toFixed(1) + ' m/s. Rods and bearings would fail: shorten the stroke or lower the redline.' : (S.asp === 'na' && S.red >= 8500 ? 'A screaming naturally aspirated engine, the way Ferrari builds its V12s.' : S.asp === 'hy' ? 'The electric motor fills the bottom of the torque curve before the turbos spool, which is why hybrids feel instant.' : S.asp !== 'na' ? 'The turbos flatten the torque curve into a plateau: huge mid-range, less drama at the top.' : 'Torque builds with revs and peaks high, so you work the gearbox to stay on the boil.');
			$('[data-eb-verdict]', root).textContent = v;
			var near = null, bd = 1e9; index().forEach(function (c) { if (!c.l || !c.hp) return; var dd = Math.abs(c.l - M.L) / M.L + Math.abs(c.hp - M.hp) / M.hp + ((c.cyl || 0) === S.cyl ? 0 : .25); if (dd < bd) { bd = dd; near = c; } });
			$('[data-eb-near]', root).innerHTML = near ? 'Closest engine in the showcase: <a href="' + esc(near.url) + '">' + esc(near.make + ' ' + near.model) + '</a>, ' + near.l + ' L and ' + near.hp + ' hp.' : '';
			var k3 = S.lay === 'f' ? 'f6' : S.lay === 'i' ? 'i4' : S.cyl >= 12 ? 'v12' : S.cyl >= 8 ? 'v8' : 'v6'; var a3 = $('[data-eb-3d]', root); a3.href = '#engine=' + k3;
			dyno(M);
			return M;
		}
		on(root, 'click', function (e) {
			var b = e.target.closest('button'); if (!b) return;
			if (b.hasAttribute('data-eb-cyl')) { S.cyl = +b.getAttribute('data-eb-cyl'); if (OK[S.cyl].indexOf(S.lay) < 0) S.lay = OK[S.cyl][0] === 'i' && S.cyl >= 6 ? 'v' : OK[S.cyl][0]; if (S.cyl >= 8) S.lay = 'v'; drawChips(); update(); }
			else if (b.hasAttribute('data-eb-lay')) { S.lay = b.getAttribute('data-eb-lay'); drawChips(); update(); }
			else if (b.hasAttribute('data-eb-asp')) { S.asp = b.getAttribute('data-eb-asp'); drawChips(); update(); }
			else if (b.hasAttribute('data-eb-rev')) {
				if (revving) return; synth = synth || engineSynth(); if (!synth) return; revving = true; synth.on(true); var t0 = performance.now(), D = 2600;
				(function f(now) { var k = (now - t0) / D, rpm = k < .55 ? 900 + (S.red - 900) * Math.pow(k / .55, 1.4) : S.red - (S.red - 900) * Math.min(1, (k - .55) / .45); synth.set(rpm, S.cyl, k < .55 ? 1 : .2); if (k < 1) requestAnimationFrame(f); else { synth.on(false); revving = false; } })(t0);
			}
		});
		$$('[data-eb-r]', root).forEach(function (r) { on(r, 'input', function () { S[r.getAttribute('data-eb-r')] = +r.value; update(); }); });
		on($('[data-eb-3d]', root), 'click', function (e) { e.preventDefault(); var h = this.getAttribute('href'); history.replaceState(null, '', h); var t = d.getElementById('engine'); if (t) t.scrollIntoView({ behavior: 'smooth' }); var btn = $('[data-e3-lay="' + h.split('=')[1] + '"]'); if (btn) btn.click(); });
		var pre = byId(+parseHash().build);
		if (pre && pre.l && pre.cyl) {
			var e = pre.engine || '', n = [3, 4, 6, 8, 10, 12].reduce(function (a, b) { return Math.abs(b - pre.cyl) < Math.abs(a - pre.cyl) ? b : a; }, 8);
			S.cyl = n; S.lay = /flat/i.test(e) ? 'f' : (/inline|straight|4-cylinder|Dynamic Force/i.test(e) || n <= 4) ? 'i' : 'v'; if (OK[n].indexOf(S.lay) < 0) S.lay = OK[n][0];
			S.asp = /hybrid|EQ Boost/i.test(e) ? 'hy' : /twin|bi-?turbo/i.test(e) ? 'tt' : /turbo/i.test(e) ? 't' : 'na';
			var diesel = /diesel/i.test(e + ' ' + (pre.fuel || '')), bs = Math.round(Math.cbrt(4 * pre.l * 1000 / n / Math.PI) * 10);
			S.bore = Math.max(70, Math.min(106, bs)); S.stroke = Math.max(60, Math.min(106, diesel ? bs + 8 : bs)); if (diesel) S.bore = Math.max(70, Math.min(106, Math.round(Math.sqrt(4 * pre.l * 1e6 / n / Math.PI / S.stroke))));
			S.red = diesel ? 4600 : S.asp === 'na' ? (n >= 12 ? 9200 : 6800) : S.lay === 'f' ? 7200 : 6800;
			$$('[data-eb-r]', root).forEach(function (r) { r.value = S[r.getAttribute('data-eb-r')]; });
			var note = d.createElement('p'); note.className = 'eb__pre'; note.innerHTML = 'Preset: the <b>' + esc(pre.make + ' ' + pre.model) + '</b>, ' + esc(e) + (pre.hp ? ', ' + pre.hp + ' hp in reality' : '') + (diesel ? '. It is a diesel; this model is built for petrol engines, so treat the numbers as a rough guide' : '') + '. Change anything to see what happens.'; root.insertBefore(note, root.firstChild);
		}
		drawChips(); update();
	}
	function accelProfile(el) {
		var c = byId(+el.getAttribute('data-psr-accel')); if (!c || !c.hp) { el.remove(); return; }
		var sp = carSpec(c); calibrate(sp); var r = simulate(sp, CONDS.dry, DIST['1000'], 1 / 60), R0 = .18;
		function tAtV(k) { for (var i = 0; i < r.length; i++) if (r[i][2] * 3.6 >= k) return r[i][0] - R0; return null; }
		function atX(m) { for (var i = 0; i < r.length; i++) if (r[i][1] >= m) return r[i]; return null; }
		var q = atX(402), km = atX(1000), t100 = tAtV(100), t160 = tAtV(160), t200 = tAtV(200);
		var chips = [['0–100 km/h', t100], ['0–160 km/h', t160], ['0–200 km/h', t200]].filter(function (x) { return x[1]; }).map(function (x) { return '<div><small>' + x[0] + '</small><b>' + x[1].toFixed(1) + '<em> s</em></b></div>'; });
		if (q) chips.push('<div><small>Quarter mile</small><b>' + (q[0] - R0).toFixed(1) + '<em> s</em></b><i>at ' + Math.round(q[2] * 3.6) + ' km/h</i></div>');
		if (km) chips.push('<div><small>Standing kilometre</small><b>' + (km[0] - R0).toFixed(1) + '<em> s</em></b><i>at ' + Math.round(km[2] * 3.6) + ' km/h</i></div>');
		el.innerHTML = '<p class="lx-eyebrow">How it pulls</p><h3 class="pf__acch">From standstill to a <em>standing kilometre</em></h3><div class="pf__accn">' + chips.join('') + '</div><canvas class="pf__accc" width="1000" height="300"></canvas><p class="pf__accnote">Simulated from the published power, torque, kerb weight and 0–100 time on a dry road. The flat steps are gear changes.</p>';
		var cv = $('canvas', el), nar = el.clientWidth < 600, W = nar ? 460 : 1000, H = nar ? 270 : 300; cv.width = W; cv.height = H; var x = cv.getContext('2d'), T = r[r.length - 1][0] - R0, V = Math.ceil(r[r.length - 1][2] * 3.6 / 50) * 50, L = 56, B = 34;
		function px(t) { return L + (W - L - 16) * t / T; } function py(v) { return H - B - (H - B - 18) * v / V; }
		function draw(k) {
			x.clearRect(0, 0, W, H); x.font = '600 15px Manrope, sans-serif'; x.lineWidth = 1;
			for (var v = 0; v <= V; v += 50) { x.strokeStyle = 'rgba(255,255,255,.08)'; x.beginPath(); x.moveTo(L, py(v)); x.lineTo(W - 16, py(v)); x.stroke(); x.fillStyle = 'rgba(255,255,255,.55)'; x.fillText(v, 8, py(v) + 5); }
			for (var t = 0; t <= T; t += 5) { x.fillStyle = 'rgba(255,255,255,.55)'; x.fillText(t + ' s', px(t) - 10, H - 10); }
			var g = x.createLinearGradient(0, 0, W, 0); g.addColorStop(0, '#8a611a'); g.addColorStop(.5, '#f1d27a'); g.addColorStop(1, '#d9a93f');
			x.strokeStyle = g; x.lineWidth = 4; x.beginPath(); var n = Math.floor(r.length * k), started = false;
			for (var i = 0; i < n; i++) { if (r[i][0] < R0) continue; var X = px(r[i][0] - R0), Y = py(r[i][2] * 3.6); if (!started) { x.moveTo(X, Y); started = true; } else x.lineTo(X, Y); } x.stroke();
			[[t100, 100, '100'], [t200, 200, '200']].forEach(function (m) { if (!m[0] || m[0] > (T * k)) return; x.fillStyle = '#fff'; x.beginPath(); x.arc(px(m[0]), py(m[1]), 6, 0, 7); x.fill(); x.fillStyle = '#f1d27a'; x.fillText(m[2] + ' km/h · ' + m[0].toFixed(1) + ' s', px(m[0]) + 10, py(m[1]) + 22); });
			if (q && q[0] - R0 <= T * k) { var qx = px(q[0] - R0); x.strokeStyle = 'rgba(127,180,255,.6)'; x.setLineDash([6, 6]); x.lineWidth = 1.5; x.beginPath(); x.moveTo(qx, 18); x.lineTo(qx, H - B); x.stroke(); x.setLineDash([]); x.fillStyle = '#7fb4ff'; x.fillText('¼ mile', qx + 6, 34); }
		}
		draw(1);
		if ('IntersectionObserver' in w && !RM) { var io = new IntersectionObserver(function (es) { if (!es[0].isIntersecting) return; io.disconnect(); var t0 = performance.now(); (function f(now) { var k = Math.min(1, (now - t0) / 1600); draw(k); if (k < 1) requestAnimationFrame(f); })(t0); }, { threshold: .3 }); io.observe(cv); }
	}
	function boot() {
		header();
		$$('[data-psr-hero]').forEach(hero);
		$$('[data-kh-filter]').forEach(khFilter);
		$$('[data-psr-3d]').forEach(carViewer);
		$$('[data-psr-engine]').forEach(engine);
		$$('.pf').forEach(profile);
		$$('[data-psr-accel]').forEach(accelProfile);
		$$('[data-psr-print]').forEach(function (b) { on(b, 'click', function () { w.print(); }); });
		$$('[data-psr-parts]').forEach(partsCar);
		$$('[data-psr-race]').forEach(race);
		$$('[data-psr-sil]').forEach(silhouette);
		$$('[data-psr-tt]').forEach(trumps);
		$$('[data-psr-brake]').forEach(brake);
		$$('[data-psr-launch]').forEach(launch);
		$$('[data-psr-hilo]').forEach(hilo);
		$$('[data-psr-partsmap]').forEach(partsMap);
		$$('[data-psr-league]').forEach(rarityLeague);
		$$('[data-psr-paint]').forEach(paintStudio);
		$$('[data-hear-car]').forEach(hearCar);
		$$('[data-psr-sizeup]').forEach(sizeUp);
		$$('[data-psr-perfmap]').forEach(perfMap);
		$$('[data-psr-builder]').forEach(engBuilder);
		$$('[data-psr-quiz]').forEach(quiz);
		$$('[data-psr-hotlap]').forEach(hotLap);
		var dl = /^#(engine|paint|map|race|launch|hilo|build)=/.exec(location.hash); if (dl) { var tg = d.getElementById(dl[1]); if (tg) setTimeout(function () { tg.scrollIntoView({ behavior: 'smooth' }); }, 400); }
		$$('[data-psr-drag]').forEach(dragAll);
		$$('[data-psr-collection]').forEach(collection);
		jumpbar();
		$$('[data-psr-finder]').forEach(finder);
		app();
		$$('[data-psr-reel]').forEach(reel);
		$$('[data-psr-form]').forEach(form);
		$$('[data-psr-vehicle]').forEach(lightbox);
		$$('[data-psr-guess]').forEach(guess);
		$$('[data-psr-duel]').forEach(duel);
		$$('[data-psr-showroom]').forEach(showroom);
		$$('[data-psr-tech]').forEach(tech);
		$$('.ff').forEach(facts);
		$$('[data-psr-eng]').forEach(eng);
		$$('[data-psr-parts]').forEach(parts);
		reveal(); counters(); parallax();
		d.documentElement.classList.add('lx-ready');
	}
	if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', boot); else boot();
})();

/* marque list toggle */
document.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('[data-mk-more]');if(!b)return;var f=b.closest('.psr-mk'),o=f.classList.toggle('is-open');b.setAttribute('aria-expanded',o?'true':'false');b.children[0].hidden=o;b.children[1].hidden=!o;});

/* touch screens: the showroom guide shouldn't talk about keyboards */
if (window.matchMedia && matchMedia('(pointer:coarse)').matches) { document.querySelectorAll('.lx-sec p').forEach(function (p) { if (/W A S D or the arrow pad/.test(p.textContent)) p.innerHTML = p.innerHTML.replace(/walk with W A S D or the arrow pad/, 'walk with the arrow pad').replace(/Click any car/, 'Tap any car'); }); }
/* on a car page, the floating WhatsApp button should mention the car too */
(function () { var car = Array.prototype.filter.call(document.querySelectorAll('a[href*="wa.me"]'), function (a) { return /question%20about/.test(a.href); })[0]; if (!car) return; Array.prototype.forEach.call(document.querySelectorAll('a[href*="wa.me"]'), function (a) { if (!/question%20about/.test(a.href) && /text=Hello%20Laqim%2C%20?$/.test(a.href)) a.href = car.href; }); })();
