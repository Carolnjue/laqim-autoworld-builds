/* Pentarch Showroom — admin */
(function ($) {
	'use strict';

	/* Gallery manager */
	var $g = $('[data-psr-gallery]');
	function item(a) {
		var url = (a.sizes && a.sizes.thumbnail ? a.sizes.thumbnail.url : a.url);
		return $('<li>').attr('data-id', a.id)
			.append($('<img>').attr('src', url))
			.append($('<input type="hidden" name="gallery[]">').val(a.id))
			.append($('<input type="hidden" name="gallery_credit[]">').val(''))
			.append('<button type="button" class="psr-x" aria-label="Remove">×</button>');
	}
	if ($g.length) {
		$g.sortable({ tolerance: 'pointer', placeholder: 'psr-ph' });
		$g.on('click', '.psr-x', function () { $(this).closest('li').remove(); });
		var frame;
		$('[data-psr-add]').on('click', function () {
			if (!frame) {
				frame = wp.media({ title: 'Add photos', button: { text: 'Add to gallery' }, multiple: 'add', library: { type: 'image' } });
				frame.on('select', function () {
					frame.state().get('selection').each(function (m) {
						var a = m.toJSON();
						if (!$g.find('li[data-id="' + a.id + '"]').length) $g.append(item(a));
					});
				});
			}
			frame.open();
		});
		var hf;
		$('[data-psr-hero]').on('click', function () {
			hf = hf || wp.media({ title: 'Hero photo', button: { text: 'Use as hero' }, multiple: false, library: { type: 'image' } });
			hf.off('select').on('select', function () {
				var a = hf.state().get('selection').first().toJSON();
				$('input[name=hero_attachment]').val(a.id);
				$('[data-psr-heropick]').html('<img src="' + (a.sizes && a.sizes.thumbnail ? a.sizes.thumbnail.url : a.url) + '">');
			});
			hf.open();
		});
		$('[data-psr-heroclear]').on('click', function () {
			$('input[name=hero_attachment]').val(0);
			$('[data-psr-heropick]').empty();
		});
	}

	$('.psr-del').on('click', function (e) {
		if (!window.confirm('Delete this vehicle? Its photos stay in the Media Library.')) e.preventDefault();
	});

	/* Setup runner */
	function post(path, body) {
		return fetch(PSRA.rest + path, {
			method: 'POST', credentials: 'same-origin',
			headers: { 'X-WP-Nonce': PSRA.nonce, 'Content-Type': 'application/json' },
			body: JSON.stringify(body)
		}).then(function (r) { return r.json().then(function (j) { if (!r.ok) throw new Error(j.message || r.status); return j; }); });
	}
	$('[data-psr-run]').on('click', function (e) {
		e.preventDefault();
		var kind = $(this).data('psr-run'), $b = $(this).prop('disabled', true);
		var over = $('[data-psr-over="' + kind + '"]').is(':checked');
		var $log = $('[data-psr-log="' + kind + '"]').empty();
		function log(t, err) { $log.append($('<li>').text(t).toggleClass('err', !!err)); }
		if (kind === 'import') {
			(function step(n) {
				post('import', { n: n, overwrite: over }).then(function (r) {
					log(r.msg);
					if (r.done) { log('Done.'); $b.prop('disabled', false); } else step(r.next);
				}).catch(function (er) { log('Step ' + (n + 1) + ': ' + er.message, true); step(n + 1 < 40 ? n + 1 : 99); });
			})(0);
		} else {
			var steps = window.PSR_KIT_STEPS || [];
			(function step(i) {
				if (i >= steps.length) { log('Done. Open the site to see it.'); $b.prop('disabled', false); return; }
				post('kit', { step: steps[i], overwrite: over }).then(function (r) { log(r.msg); step(i + 1); })
					.catch(function (er) { log(steps[i] + ': ' + er.message, true); step(i + 1); });
			})(0);
		}
	});
})(jQuery);
