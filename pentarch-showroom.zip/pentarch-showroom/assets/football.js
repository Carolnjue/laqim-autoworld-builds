/* Laqim Football: eleven-a-side with real ball physics (drag, Magnus curl, bounce, rolling resistance), formations that move as a block,
   offside, set pieces, goalkeepers who read the shot, stamina, a broadcast camera, crowd and commentary. Low-poly players, everything else serious.
   Winners of the Laqim Cup are written to the Hall of Champions and appear on the billboards in Laqim Racing. */
(function () {
	'use strict';
	var w = window, d = document, T = null;
	/* ---------------------------------------------------------------- the pitch and the rules, in metres */
	var PL = 105, PW = 68, HL = PL / 2, HW = PW / 2, GW = 7.32, GH = 2.44, GD = 2.0, BR = 0.11, G = 9.81;
	var DT = 1 / 60;
	/* ---------------------------------------------------------------- clubs. Invented, Kenyan, each with a style */
	var CLUBS = [
		{ id: 'ncl', n: 'Nairobi City Lions', s: 'NCL', kit: ['#c8102e', '#ffffff', '#c8102e'], alt: ['#ffffff', '#c8102e', '#ffffff'], gk: '#1b1b1b', st: { pace: .82, pass: .8, shoot: .78, tack: .74, gk: .76 }, form: '433', style: 'press' },
		{ id: 'mdh', n: 'Mombasa Dhows', s: 'MDH', kit: ['#0277bd', '#ffffff', '#0277bd'], alt: ['#f5d142', '#0d3b66', '#f5d142'], gk: '#2e7d32', st: { pace: .86, pass: .76, shoot: .74, tack: .7, gk: .72 }, form: '433', style: 'wing' },
		{ id: 'ksl', n: 'Kisumu Lakers', s: 'KSL', kit: ['#1565c0', '#0d47a1', '#ffffff'], alt: ['#ffffff', '#1565c0', '#1565c0'], gk: '#ff8f00', st: { pace: .78, pass: .82, shoot: .72, tack: .76, gk: .78 }, form: '442', style: 'pass' },
		{ id: 'nkf', n: 'Nakuru Flamingos', s: 'NKF', kit: ['#ec407a', '#212121', '#ec407a'], alt: ['#212121', '#ec407a', '#212121'], gk: '#00897b', st: { pace: .8, pass: .78, shoot: .8, tack: .7, gk: .7 }, form: '433', style: 'direct' },
		{ id: 'eld', n: 'Eldoret Runners', s: 'ELD', kit: ['#2e7d32', '#ffffff', '#2e7d32'], alt: ['#ffffff', '#2e7d32', '#ffffff'], gk: '#6a1b9a', st: { pace: .92, pass: .72, shoot: .74, tack: .72, gk: .7 }, form: '442', style: 'counter' },
		{ id: 'mch', n: 'Machakos Hills', s: 'MCH', kit: ['#f9a825', '#3e2723', '#f9a825'], alt: ['#3e2723', '#f9a825', '#3e2723'], gk: '#1565c0', st: { pace: .76, pass: .74, shoot: .72, tack: .82, gk: .8 }, form: '442', style: 'block' },
		{ id: 'tka', n: 'Thika Falls', s: 'TKA', kit: ['#00acc1', '#004d40', '#00acc1'], alt: ['#004d40', '#00acc1', '#004d40'], gk: '#c62828', st: { pace: .8, pass: .8, shoot: .76, tack: .74, gk: .74 }, form: '433', style: 'pass' },
		{ id: 'hxi', n: 'Harambee XI', s: 'HXI', kit: ['#b71c1c', '#1b1b1b', '#2e7d32'], alt: ['#ffffff', '#b71c1c', '#ffffff'], gk: '#f9a825', st: { pace: .88, pass: .84, shoot: .84, tack: .8, gk: .82 }, form: '433', style: 'press' }
	];
	var FIRST = ['Michael', 'Victor', 'Dennis', 'Brian', 'Kevin', 'Eric', 'Joseph', 'Ayub', 'Duncan', 'Masoud', 'Clifton', 'Collins', 'Johanna', 'Patrick', 'Anthony', 'Lawrence', 'Musa', 'Rashid', 'Amos', 'Kenneth', 'Daniel', 'Elvis', 'Teddy', 'Benson', 'Ian', 'Felix', 'Hassan', 'Omar', 'Stephen', 'Moses'];
	var LAST = ['Olunga', 'Wanyama', 'Odhiambo', 'Omondi', 'Otieno', 'Mutua', 'Kamau', 'Njoroge', 'Wekesa', 'Masika', 'Juma', 'Ochieng', 'Kiprono', 'Simiyu', 'Ouma', 'Akumu', 'Mwangi', 'Barasa', 'Wafula', 'Onyango', 'Kibet', 'Chege', 'Nyamweya', 'Abdalla', 'Kiptoo', 'Mbugua', 'Okoth', 'Musyoka', 'Shikanda', 'Opiyo'];
	var FORMS = { // [depth 0..1 from own goal line, width -1..1, role]
		'433': [[.015, 0, 'GK'], [.2, -.72, 'FB'], [.16, -.24, 'CB'], [.16, .24, 'CB'], [.2, .72, 'FB'], [.33, 0, 'DM'], [.4, -.4, 'CM'], [.4, .4, 'CM'], [.5, -.72, 'W'], [.53, 0, 'ST'], [.5, .72, 'W']],
		'442': [[.015, 0, 'GK'], [.2, -.72, 'FB'], [.16, -.24, 'CB'], [.16, .24, 'CB'], [.2, .72, 'FB'], [.37, -.72, 'WM'], [.36, -.2, 'CM'], [.36, .2, 'CM'], [.37, .72, 'WM'], [.5, -.18, 'ST'], [.5, .18, 'ST']]
	};
	function rnd(s) { var x = Math.sin(s * 9301 + 49297) * 233280; return x - Math.floor(x); }
	function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
	function len2(x, z) { return Math.sqrt(x * x + z * z); }
	function lerp(a, b, t) { return a + (b - a) * t; }
	function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
	function shuffle(a, s) { a = a.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(rnd(s + i) * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
	function squad(club) { var s = club.id.charCodeAt(0) * 31 + club.id.charCodeAt(1) * 7 + club.id.charCodeAt(2), f = shuffle(FIRST, s), l = shuffle(LAST, s * 3 + 1), L = []; for (var i = 0; i < 11; i++) L.push({ n: f[i] + ' ' + l[i], sh: l[i], num: i === 0 ? 1 : [0, 2, 5, 4, 3, 6, 8, 10, 7, 9, 11][i], v: rnd(s + i * 13) }); return L; }

	/* ---------------------------------------------------------------- sound: crowd bed, whistle, kicks, net */
	var AU = (function () {
		var ctx = null, crowd = null, crowdG = null, master = null, on = true, ex = 0;
		function init() { if (ctx) return; try { ctx = new (w.AudioContext || w.webkitAudioContext)(); } catch (e) { return; } master = ctx.createGain(); master.gain.value = .7; master.connect(ctx.destination);
			var n = ctx.sampleRate * 3, b = ctx.createBuffer(2, n, ctx.sampleRate); for (var c = 0; c < 2; c++) { var x = b.getChannelData(c), last = 0; for (var i = 0; i < n; i++) { var wn = Math.random() * 2 - 1; last = (last + .04 * wn) / 1.04; x[i] = last * 3.2 + wn * .05; } }
			crowd = ctx.createBufferSource(); crowd.buffer = b; crowd.loop = true; var bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 700; bp.Q.value = .5; crowdG = ctx.createGain(); crowdG.gain.value = .0; crowd.connect(bp); bp.connect(crowdG); crowdG.connect(master); crowd.start(); }
		function tone(f, t, type, g, f2) { if (!ctx || !on) return; var o = ctx.createOscillator(), gg = ctx.createGain(); o.type = type || 'sine'; o.frequency.setValueAtTime(f, ctx.currentTime); if (f2) o.frequency.exponentialRampToValueAtTime(f2, ctx.currentTime + t); gg.gain.setValueAtTime(g || .2, ctx.currentTime); gg.gain.exponentialRampToValueAtTime(.001, ctx.currentTime + t); o.connect(gg); gg.connect(master); o.start(); o.stop(ctx.currentTime + t + .02); }
		function whistle(n) { if (!ctx || !on) return; for (var i = 0; i < (n || 1); i++) (function (k) { setTimeout(function () { var o = ctx.createOscillator(), lfo = ctx.createOscillator(), lg = ctx.createGain(), gg = ctx.createGain(); o.frequency.value = 2900; lfo.frequency.value = 38; lg.gain.value = 140; lfo.connect(lg); lg.connect(o.frequency); gg.gain.setValueAtTime(.0001, ctx.currentTime); gg.gain.exponentialRampToValueAtTime(.12, ctx.currentTime + .03); gg.gain.setValueAtTime(.12, ctx.currentTime + (k === n - 1 ? .55 : .2)); gg.gain.exponentialRampToValueAtTime(.0001, ctx.currentTime + (k === n - 1 ? .7 : .3)); o.connect(gg); gg.connect(master); o.start(); lfo.start(); o.stop(ctx.currentTime + .8); lfo.stop(ctx.currentTime + .8); }, k * 380); })(i); }
		function clap(at, g) { if (!ctx || !on) return; var n = ctx.sampleRate * .09, b = ctx.createBuffer(1, n, ctx.sampleRate), x = b.getChannelData(0); for (var i = 0; i < n; i++) x[i] = (Math.random() * 2 - 1) * Math.exp(-i / n * 9); var s0 = ctx.createBufferSource(), f = ctx.createBiquadFilter(), gg = ctx.createGain(); s0.buffer = b; f.type = 'bandpass'; f.frequency.value = 1400; f.Q.value = .7; gg.gain.value = g || .35; s0.connect(f); f.connect(gg); gg.connect(master); s0.start(ctx.currentTime + at); }
		function horn(at) { if (!ctx || !on) return; var o = ctx.createOscillator(), gg = ctx.createGain(), f = ctx.createBiquadFilter(); o.type = 'sawtooth'; o.frequency.value = 233 + Math.random() * 6; f.type = 'lowpass'; f.frequency.value = 900; gg.gain.setValueAtTime(.0001, ctx.currentTime + at); gg.gain.exponentialRampToValueAtTime(.05, ctx.currentTime + at + .08); gg.gain.setValueAtTime(.05, ctx.currentTime + at + .9); gg.gain.exponentialRampToValueAtTime(.0001, ctx.currentTime + at + 1.2); o.connect(f); f.connect(gg); gg.connect(master); o.start(ctx.currentTime + at); o.stop(ctx.currentTime + at + 1.3); }
		function chant() { [0, .32, .64, .8, .96].forEach(function (t0) { for (var k = 0; k < 6; k++) clap(t0 + Math.random() * .03, .12); }); if (Math.random() < .5) { horn(1.3); horn(1.45); } }
		return { chant: chant, init: init, kick: function (p) { tone(140 + p * 60, .09, 'triangle', .25 * Math.min(1, .3 + p), 60); }, net: function () { tone(220, .25, 'sawtooth', .05, 90); }, post: function () { tone(1500, .35, 'sine', .15, 1300); tone(980, .4, 'sine', .08); }, whistle: whistle,
			crowd: function (x) { ex = x; if (crowdG && on) crowdG.gain.setTargetAtTime(.05 + x * .45, ctx.currentTime, .4); }, roar: function () { if (crowdG && on) { crowdG.gain.setTargetAtTime(.9, ctx.currentTime, .05); setTimeout(function () { crowdG.gain.setTargetAtTime(.1, ctx.currentTime, 1.6); }, 2600); } }, ooh: function () { if (crowdG && on) { crowdG.gain.setTargetAtTime(.55, ctx.currentTime, .08); setTimeout(function () { crowdG.gain.setTargetAtTime(.1, ctx.currentTime, .8); }, 900); } },
			toggle: function () { on = !on; if (master) master.gain.value = on ? .7 : 0; return on; }, get on() { return on; }, stop: function () { if (ctx) try { ctx.suspend(); } catch (e) {} }, resume: function () { if (ctx) try { ctx.resume(); } catch (e) {} } };
	})();
	/* ---------------------------------------------------------------- the stadium */
	function pitchTex() {
		var S = 20, c = d.createElement('canvas'); c.width = 2048; c.height = 1360; var x = c.getContext('2d'), sx = c.width / (PL + 8), sz = c.height / (PW + 8), ox = 4, oz = 4;
		function X(m) { return (m + HL + ox) * sx; } function Z(m) { return (m + HW + oz) * sz; }
		x.fillStyle = '#2f7a34'; x.fillRect(0, 0, c.width, c.height);
		for (var i = 0; i < 18; i++) { x.fillStyle = i % 2 ? '#2b7231' : '#348a3a'; x.fillRect(X(-HL + i * PL / 18), 0, PL / 18 * sx + 1, c.height); }
		var g = x.createRadialGradient(c.width / 2, c.height / 2, 100, c.width / 2, c.height / 2, c.width * .7); g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(1, 'rgba(0,0,0,.18)'); x.fillStyle = g; x.fillRect(0, 0, c.width, c.height);
		/* wear: goalmouths and the centre */
		[[-HL + 3, 0, 6], [HL - 3, 0, 6], [0, 0, 7]].forEach(function (p) { var rg = x.createRadialGradient(X(p[0]), Z(p[1]), 2, X(p[0]), Z(p[1]), p[2] * sx); rg.addColorStop(0, 'rgba(120,100,60,.35)'); rg.addColorStop(1, 'rgba(120,100,60,0)'); x.fillStyle = rg; x.fillRect(X(p[0]) - p[2] * sx, Z(p[1]) - p[2] * sz, p[2] * 2 * sx, p[2] * 2 * sz); });
		x.strokeStyle = 'rgba(255,255,255,.92)'; x.lineWidth = .14 * sx; x.lineJoin = 'round';
		x.strokeRect(X(-HL), Z(-HW), PL * sx, PW * sz); x.beginPath(); x.moveTo(X(0), Z(-HW)); x.lineTo(X(0), Z(HW)); x.stroke();
		x.beginPath(); x.ellipse(X(0), Z(0), 9.15 * sx, 9.15 * sz, 0, 0, 7); x.stroke();
		[-1, 1].forEach(function (s) { var gx = s * HL;
			x.strokeRect(Math.min(X(gx), X(gx - s * 16.5)), Z(-20.16), 16.5 * sx, 40.32 * sz); x.strokeRect(Math.min(X(gx), X(gx - s * 5.5)), Z(-9.16), 5.5 * sx, 18.32 * sz);
			x.beginPath(); x.ellipse(X(gx - s * 11), Z(0), 9.15 * sx, 9.15 * sz, 0, s > 0 ? Math.PI - .93 : -.93, s > 0 ? Math.PI + .93 : .93); x.stroke();
			[-1, 1].forEach(function (t) { x.beginPath(); x.ellipse(X(gx), Z(t * HW), 1 * sx, 1 * sz, 0, 0, 7); x.stroke(); });
			x.fillStyle = '#fff'; x.beginPath(); x.arc(X(gx - s * 11), Z(0), .2 * sx, 0, 7); x.fill(); });
		x.fillStyle = '#fff'; x.beginPath(); x.arc(X(0), Z(0), .2 * sx, 0, 7); x.fill();
		var t = new T.CanvasTexture(c); t.anisotropy = 8; t.encoding = T.sRGBEncoding; return { tex: t, w: PL + 8, h: PW + 8 };
	}
	function boardTex(txt, bg, fg) { var c = d.createElement('canvas'); c.width = 1024; c.height = 64; var x = c.getContext('2d'); x.fillStyle = bg; x.fillRect(0, 0, 1024, 64); x.fillStyle = fg; var fs = 40; x.font = '900 ' + fs + 'px system-ui, sans-serif'; while (x.measureText(txt).width > 960 && fs > 18) { fs -= 2; x.font = '900 ' + fs + 'px system-ui, sans-serif'; } x.textBaseline = 'middle'; var tw = x.measureText(txt).width + 40; for (var px = 20; px < 1024; px += tw) x.fillText(txt, px, 34); var t = new T.CanvasTexture(c); t.encoding = T.sRGBEncoding; t.wrapS = T.RepeatWrapping; return t; }
	function buildStadium(S, opts) {
		var lin = function (h) { return new T.Color(h).convertSRGBToLinear(); }, grp = new T.Group(); S.add(grp);
		var pt = pitchTex(), pitch = new T.Mesh(new T.PlaneGeometry(pt.w, pt.h), new T.MeshStandardMaterial({ map: pt.tex, roughness: .95 })); pitch.rotation.x = -Math.PI / 2; pitch.receiveShadow = true; grp.add(pitch);
		var apron = new T.Mesh(new T.PlaneGeometry(PL + 40, PW + 36), new T.MeshStandardMaterial({ color: lin('#24602a'), roughness: 1 })); apron.rotation.x = -Math.PI / 2; apron.position.y = -.02; grp.add(apron);
		/* stands: four tiered blocks with a roof edge, filled with an instanced crowd */
		var standM = new T.MeshStandardMaterial({ color: lin('#30343c'), roughness: .9 }), roofM = new T.MeshStandardMaterial({ color: lin('#1c1f25'), roughness: .6, metalness: .3 }), seats = [];
		function stand(cx, cz, w0, rot, rows) { var g = new T.Group(); g.position.set(cx, 0, cz); g.rotation.y = rot; grp.add(g);
			for (var r = 0; r < rows; r++) { var step = new T.Mesh(new T.BoxGeometry(w0, .9, 1.6), standM); step.position.set(0, .45 + r * .9, r * 1.6); g.add(step); for (var k = -w0 / 2 + .6; k < w0 / 2; k += .62) if (Math.random() < .93) seats.push({ g: g, x: k + (Math.random() - .5) * .12, y: 1.25 + r * .9, z: r * 1.6 + .1 }); }
			var back = new T.Mesh(new T.BoxGeometry(w0, rows * .9 + 4, .8), standM); back.position.set(0, (rows * .9 + 4) / 2, rows * 1.6 + .4); g.add(back);
			var roof = new T.Mesh(new T.BoxGeometry(w0 + 2, .5, rows * 1.6 + 4), roofM); roof.position.set(0, rows * .9 + 4.5, rows * 1.6 / 2 - 1); roof.rotation.x = -.06; g.add(roof); }
		stand(0, -(HW + 9), PL + 14, Math.PI, 16); stand(-(HL + 9), 0, PW + 6, -Math.PI / 2, 12); stand(HL + 9, 0, PW + 6, Math.PI / 2, 12);
		var cols = [opts.home.kit[0], opts.home.kit[1], opts.away.kit[0], '#e8e8e8', '#202020', '#f2c94c', '#3f51b5', '#c62828'], body = new T.InstancedMesh(new T.BoxGeometry(.42, .62, .3), new T.MeshLambertMaterial(), seats.length), M4 = new T.Matrix4(), V = new T.Vector3(), cc = new T.Color();
		grp.updateMatrixWorld(true);
		seats.forEach(function (s, i) { V.set(s.x, s.y, s.z); s.g.localToWorld(V); s.wx = V.x; s.wy = V.y; s.wz = V.z; s.side = V.x < 0 ? 0 : 1; s.ph = Math.random() * 6; s.ry = s.g.rotation.y; M4.makeRotationY(s.g.rotation.y); M4.setPosition(V.x, V.y, V.z); body.setMatrixAt(i, M4); var k = Math.random(); cc.set(k < .55 ? (s.side ? opts.away.kit[0] : opts.home.kit[0]) : cols[Math.floor(Math.random() * cols.length)]).convertSRGBToLinear(); body.setColorAt(i, cc); });
		body.instanceColor.needsUpdate = true; grp.add(body);
		/* advertising boards: Laqim, REDLINE and the site's sponsor slots */
		var boards = (opts.boards && opts.boards.length ? opts.boards : ['YOUR BRAND HERE', 'ADVERTISE ON REDLINE']).concat(['LAQIM AUTOWORLD', 'REDLINE · REVIEWS · CALCULATORS']), bMats = [];
		boards.forEach(function (b, i) { var m = new T.MeshBasicMaterial({ map: boardTex('   ' + b + '   ●', ['#0b0d12', '#c8102e', '#0d47a1', '#111'][i % 4], ['#fff', '#fff', '#f2c94c', '#ff3b3b'][i % 4]) }); bMats.push(m); });
		var segs = []; for (var bx = -HL; bx < HL; bx += 15) segs.push([bx + 7.5, -(HW + 3.2), 0], [bx + 7.5, HW + 3.2, Math.PI]);
		for (var bz = -HW + 8; bz < HW - 4; bz += 15) { if (Math.abs(bz + 7.5) < 6) continue; segs.push([-(HL + 3.2), bz + 7.5, Math.PI / 2], [HL + 3.2, bz + 7.5, -Math.PI / 2]); }
		segs.forEach(function (sg, i) { var m = new T.Mesh(new T.PlaneGeometry(14.6, .95), bMats[i % bMats.length]); m.position.set(sg[0], .5, sg[1]); m.rotation.y = sg[2]; grp.add(m); });
		var arena = new T.Mesh(new T.PlaneGeometry(46, 3), new T.MeshBasicMaterial({ map: boardTex('LAQIM ARENA · NAIROBI', '#0b0d12', '#f1d27a'), transparent: false })); arena.position.set(0, 21.6, -(HW + 9) - 13); grp.add(arena);
		/* goals: posts, bar and a net */
		var postM = new T.MeshStandardMaterial({ color: 0xffffff, roughness: .4 }), netM = new T.LineBasicMaterial({ color: 0xe8e8e8, transparent: true, opacity: .55 });
		[-1, 1].forEach(function (s) { var gx = s * HL, gg = new T.Group(); grp.add(gg);
			[-1, 1].forEach(function (t) { var p = new T.Mesh(new T.CylinderGeometry(.06, .06, GH, 10), postM); p.position.set(gx, GH / 2, t * GW / 2); gg.add(p); var bp = new T.Mesh(new T.CylinderGeometry(.03, .03, GH, 6), postM); bp.position.set(gx + s * GD, GH / 2 - .1, t * GW / 2); gg.add(bp); });
			var bar = new T.Mesh(new T.CylinderGeometry(.06, .06, GW + .12, 10), postM); bar.rotation.x = Math.PI / 2; bar.position.set(gx, GH, 0); gg.add(bar);
			var P = [], k; for (k = -GW / 2; k <= GW / 2 + .01; k += .25) { P.push(gx, GH, k, gx + s * GD, GH - .2, k); P.push(gx + s * GD, GH - .2, k, gx + s * GD, 0, k); }
			for (k = 0; k <= GD + .01; k += .25) { P.push(gx + s * k, GH - .2 * k / GD, -GW / 2, gx + s * k, GH - .2 * k / GD, GW / 2); [-1, 1].forEach(function (t) { P.push(gx + s * k, 0, t * GW / 2, gx + s * k, GH - .2 * k / GD, t * GW / 2); }); }
			for (k = 0; k <= GH; k += .25) { P.push(gx + s * GD, k, -GW / 2, gx + s * GD, k, GW / 2); [-1, 1].forEach(function (t) { P.push(gx, Math.min(k, GH), t * GW / 2, gx + s * GD, Math.min(k, GH - .2), t * GW / 2); }); }
			var ng = new T.BufferGeometry(); ng.setAttribute('position', new T.Float32BufferAttribute(P, 3)); gg.add(new T.LineSegments(ng, netM)); });
		/* floodlight towers */
		var towM = new T.MeshStandardMaterial({ color: lin('#5a5f69'), metalness: .6, roughness: .4 }), lampM = new T.MeshBasicMaterial({ color: 0xfff6dc });
		[[-1, -1], [-1, 1], [1, -1], [1, 1]].forEach(function (q) { var x0 = q[0] * (HL + 16), z0 = q[1] * (HW + 18), t = new T.Mesh(new T.CylinderGeometry(.5, .9, 44, 8), towM); t.position.set(x0, 22, z0); grp.add(t); var h = new T.Mesh(new T.BoxGeometry(6, 3.4, .6), lampM); h.position.set(x0, 45, z0); h.lookAt(0, 0, 0); grp.add(h); });
		return { grp: grp, crowd: body, seats: seats, M4: M4 };
	}
	/* ---------------------------------------------------------------- low-poly footballers */
	var GEO = null;
	function geos() { if (GEO) return GEO; var leg = new T.BoxGeometry(.15, .8, .16); leg.translate(0, -.4, 0); var arm = new T.BoxGeometry(.11, .56, .12); arm.translate(0, -.28, 0);
		GEO = { torso: new T.BoxGeometry(.46, .6, .26), shorts: new T.BoxGeometry(.44, .24, .27), leg: leg, arm: arm, head: new T.SphereGeometry(.13, 10, 8), hair: new T.SphereGeometry(.135, 10, 6, 0, Math.PI * 2, 0, Math.PI / 2), shadow: new T.CircleGeometry(.42, 14), ring: new T.RingGeometry(.62, .78, 28), boot: new T.BoxGeometry(.16, .08, .28) }; return GEO; }
	var SKINS = ['#3b2416', '#4a2d1a', '#5a3820', '#6b4428', '#2e1c12', '#7a5033', '#8d5f3c'];
	var NUMT = {};
	function numTex(bg, n) { var k = bg + n; if (NUMT[k]) return NUMT[k]; var c = d.createElement('canvas'); c.width = 64; c.height = 64; var x = c.getContext('2d'); x.fillStyle = bg; x.fillRect(0, 0, 64, 64); var col = new T.Color(bg); x.fillStyle = col.r * .3 + col.g * .59 + col.b * .11 > .55 ? '#111' : '#fff'; x.font = '900 40px system-ui, sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(String(n), 32, 36); var t = new T.CanvasTexture(c); t.encoding = T.sRGBEncoding; NUMT[k] = t; return t; }
	function makePlayer(kit, gk, v, num) {
		var g = geos(), lin = function (h) { return new T.Color(h).convertSRGBToLinear(); }, shirt = new T.MeshLambertMaterial({ color: lin(gk ? kit.gk : kit.shirt) }), shorts = new T.MeshLambertMaterial({ color: lin(kit.shorts) }), sock = new T.MeshLambertMaterial({ color: lin(kit.socks) }), skin = new T.MeshLambertMaterial({ color: lin(SKINS[Math.floor(v * SKINS.length)]) }), boot = new T.MeshLambertMaterial({ color: lin(v > .5 ? '#111' : '#f5f5f5') }), hairM = new T.MeshLambertMaterial({ color: lin('#120c08') });
		var root = new T.Group(), body = new T.Group(); root.add(body);
		var back = new T.MeshLambertMaterial({ map: numTex(gk ? kit.gk : kit.shirt, num || 0) }), torso = new T.Mesh(g.torso, num ? [shirt, shirt, shirt, shirt, shirt, back] : shirt); torso.position.y = 1.2; body.add(torso);
		var sh = new T.Mesh(g.shorts, shorts); sh.position.y = .86; body.add(sh);
		var head = new T.Mesh(g.head, skin); head.position.y = 1.66; body.add(head); var hair = new T.Mesh(g.hair, hairM); hair.position.y = 1.68; hair.scale.set(1, v > .7 ? 1.3 : .8, 1); body.add(hair);
		function limb(geo, mat, x, y) { var p = new T.Group(); p.position.set(x, y, 0); var m = new T.Mesh(geo, mat); p.add(m); body.add(p); return p; }
		var lL = limb(g.leg, sock, -.11, .8), lR = limb(g.leg, sock, .11, .8), aL = limb(g.arm, gk ? shirt : skin, -.3, 1.46), aR = limb(g.arm, gk ? shirt : skin, .3, 1.46);
		[lL, lR].forEach(function (l) { var b = new T.Mesh(g.boot, boot); b.position.set(0, -.8, .05); l.add(b); });
		var shd = new T.Mesh(g.shadow, new T.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: .32, depthWrite: false })); shd.rotation.x = -Math.PI / 2; shd.position.y = .015; root.add(shd);
		root.userData = { body: body, lL: lL, lR: lR, aL: aL, aR: aR };
		var sc = .96 + v * .1; body.scale.set(sc, sc, sc); return root;
	}
	/* ---------------------------------------------------------------- the match: physics, players, rules, AI */
	function Match(o) {
		var M = { t: 0, clock: 0, half: 1, halfSec: o.halfSec || 180, phase: 'kickoff', phT: 0, ev: o.onEvent || function () {}, diff: o.diff == null ? 1 : o.diff, stats: [{ sh: 0, on: 0, pas: 0, pc: 0, poss: 0, fouls: 0, corners: 0 }, { sh: 0, on: 0, pas: 0, pc: 0, poss: 0, fouls: 0, corners: 0 }], restart: null, pend: null, lastPass: null, excite: 0, goalT: 0, scorers: [] };
		var ball = M.ball = { x: 0, y: BR, z: 0, vx: 0, vy: 0, vz: 0, wx: 0, wy: 0, wz: 0, owner: null, last: null, lastTeam: -1, kickT: 0, outT: 0, shot: null };
		var TM = M.teams = [0, 1].map(function (k) { var club = k ? o.away : o.home, kit = k ? o.awayKit : o.homeKit, sq = squad(club), F = FORMS[club.form] || FORMS['433'];
			var team = { k: k, club: club, kit: kit, dir: k ? -1 : 1, score: 0, human: o.human === 'both' || (o.human === 'home' && !k) || (o.human === 'away' && k), ctrl: null, ctrl2: null, pl: [] };
			var hum0 = o.human === 'both' || (o.human === 'home' && !k) || (o.human === 'away' && k), bump = o.human && !hum0 ? ((o.diff == null ? 1 : o.diff) - 1) * .07 : 0;
			F.forEach(function (f, i) { var st = club.st, v = sq[i].v, a = function (b) { return clamp(b + bump + (v - .5) * .12 + (rnd(i * 7 + k) - .5) * .06, .45, .99); };
				team.pl.push({ team: team, i: i, role: f[2], hu: f[0], hw: f[1], name: sq[i].n, sh: sq[i].sh, num: sq[i].num, x: 0, z: 0, vx: 0, vz: 0, fx: team.dir, fz: 0, tx: 0, tz: 0, stam: 1, stun: 0, kick: 0, slide: 0, dive: 0, diveT: 0, cool: 0, card: 0,
					pace: a(st.pace + (f[2] === 'W' || f[2] === 'FB' ? .05 : f[2] === 'CB' || f[2] === 'GK' ? -.06 : 0)), pass: a(st.pass + (f[2] === 'CM' || f[2] === 'DM' ? .06 : 0)), shoot: a(st.shoot + (f[2] === 'ST' || f[2] === 'W' ? .08 : f[2] === 'CB' ? -.12 : 0)), tack: a(st.tack + (f[2] === 'CB' || f[2] === 'DM' ? .08 : f[2] === 'ST' ? -.1 : 0)), drib: a(st.pace * .5 + st.pass * .5 + (f[2] === 'W' ? .08 : 0)), gk: a(st.gk), v: v, r: 6.2 }); });
			return team; });
		var ALL = TM[0].pl.concat(TM[1].pl); M.roster = ALL.slice();
		function opp(t) { return TM[1 - t.k]; }
		/* ---- formation positions, in the team's attacking direction ---- */
		function U(t, x) { return (x * t.dir + HL) / PL; }              /* metres → depth for that team, 0 own goal line, 1 opponent goal line */
		function X(t, u) { return (u * PL - HL) * t.dir; }
		function kickoffPos(t, kick) { t.pl.forEach(function (p) { var u = Math.min(p.hu, .47), wz = p.hw * HW * .78; if (kick && p.role === 'ST') { u = p === t.pl.filter(function (q) { return q.role === 'ST'; })[0] ? .497 : .47; wz = p === t.pl.filter(function (q) { return q.role === 'ST'; })[0] ? 0 : p.hw * 10; } p.x = X(t, u); p.z = wz; p.vx = p.vz = 0; p.fx = t.dir; p.fz = 0; p.stun = p.slide = p.dive = 0; }); }
		function ballTo(x, z, y) { ball.x = x; ball.z = z; ball.y = y || BR; ball.vx = ball.vy = ball.vz = ball.wx = ball.wy = ball.wz = 0; ball.owner = null; ball.shot = null; }
		/* ---- ball physics: drag ∝ v², Magnus curl from spin, bounce, rolling resistance, posts, net ---- */
		var CD = .0125, CM = .0021;
		function ballStep(h) {
			var b = ball; if (b.owner) return;
			var sp = Math.sqrt(b.vx * b.vx + b.vy * b.vy + b.vz * b.vz), air = b.y > BR + .02 || b.vy > .5;
			if (air) { b.vx -= CD * sp * b.vx * h; b.vy -= (G + CD * sp * b.vy) * h; b.vz -= CD * sp * b.vz * h;
				b.vx += CM * (b.wy * b.vz - b.wz * b.vy) * h; b.vy += CM * (b.wz * b.vx - b.wx * b.vz) * h; b.vz += CM * (b.wx * b.vy - b.wy * b.vx) * h;
				var dk = Math.exp(-.25 * h); b.wx *= dk; b.wy *= dk; b.wz *= dk; }
			else { var hs = Math.sqrt(b.vx * b.vx + b.vz * b.vz); if (hs > 0) { var dec = (1.05 + .016 * hs * hs) * h, k = Math.max(0, hs - dec) / hs; b.vx *= k; b.vz *= k; } b.vy = 0; b.y = BR; var dk2 = Math.exp(-3 * h); b.wx *= dk2; b.wy *= dk2; b.wz *= dk2; }
			b.x += b.vx * h; b.y += b.vy * h; b.z += b.vz * h;
			if (b.y < BR) { b.y = BR; if (b.vy < -1.1) { b.vy = -b.vy * .56; b.vx *= .84; b.vz *= .84; b.wy *= .6; } else b.vy = 0; }
			/* posts and crossbar */
			[-1, 1].forEach(function (s) { var gx = s * HL; if (Math.abs(b.x - gx) > 1) return;
				[-1, 1].forEach(function (t) { var dx = b.x - gx, dz = b.z - t * GW / 2, dd = Math.sqrt(dx * dx + dz * dz); if (dd < BR + .06 && b.y < GH + .06) { var nx = dx / dd, nz = dz / dd, vn = b.vx * nx + b.vz * nz; if (vn < 0) { b.vx -= 1.72 * vn * nx; b.vz -= 1.72 * vn * nz; b.x = gx + nx * (BR + .061); b.z = t * GW / 2 + nz * (BR + .061); M.ev('post', {}); M.excite = 1; } } });
				var dx2 = b.x - gx, dy2 = b.y - GH, d2 = Math.sqrt(dx2 * dx2 + dy2 * dy2); if (d2 < BR + .06 && Math.abs(b.z) < GW / 2) { var nx2 = dx2 / d2, ny2 = dy2 / d2, vn2 = b.vx * nx2 + b.vy * ny2; if (vn2 < 0) { b.vx -= 1.7 * vn2 * nx2; b.vy -= 1.7 * vn2 * ny2; M.ev('post', { bar: 1 }); M.excite = 1; } }
				/* inside the goal: the net catches it */
				if (Math.abs(b.x) > HL && Math.abs(b.z) < GW / 2 && b.y < GH) { if (Math.abs(b.x) > HL + GD - BR) { b.x = s * (HL + GD - BR); b.vx *= -.15; b.vz *= .4; b.vy *= .4; AU.net(); } if (Math.abs(b.z) > GW / 2 - BR) { b.vz *= -.2; b.z = clamp(b.z, -GW / 2 + BR, GW / 2 - BR); } if (b.y > GH - .2 - BR) { b.vy = Math.min(b.vy, 0) * .3; b.y = GH - .2 - BR; } } });
		}
		/* how fast must a ground ball leave the foot to arrive at distance D still moving at about vEnd? */
		function rollSpeed(D, vEnd) { var lo = 2, hi = 45; for (var it = 0; it < 18; it++) { var v0 = (lo + hi) / 2, v = v0, x = 0; while (v > vEnd && x < D) { var dec = (1.05 + .016 * v * v) * .02; v -= dec; x += v * .02; } if (x >= D) hi = v0; else lo = v0; } return hi; }
		function rollTime(D, v0) { var v = v0, x = 0, t = 0; while (x < D && v > .3 && t < 8) { v -= (1.05 + .016 * v * v) * .02; x += v * .02; t += .02; } return t; }
		/* ---- kicks ---- */
		function release(p) { ball.owner = null; ball.last = p; ball.lastTeam = p.team.k; p.cool = .35; p.kick = .3; }
		function passTo(p, tx, tz, opts) { opts = opts || {}; var dx = tx - p.x, dz = tz - p.z, D = len2(dx, dz) || 1, err = (1 - p.pass) * (opts.lob ? .09 : .05) * (1 + (p.stun ? 1 : 0)) + (opts.press || 0) * .04, a = Math.atan2(dz, dx) + (Math.random() - .5) * err * 2;
			release(p); ball.x = p.x + Math.cos(a) * .4; ball.z = p.z + Math.sin(a) * .4; ball.y = BR;
			if (opts.lob) { var ang = opts.high ? .78 : clamp(.32 + D / 160, .34, .62), v0 = Math.sqrt(G * D / Math.sin(2 * ang)) * (1 + D * .0042) * (1 + (Math.random() - .5) * err * 1.5); ball.vx = Math.cos(a) * Math.cos(ang) * v0; ball.vz = Math.sin(a) * Math.cos(ang) * v0; ball.vy = Math.sin(ang) * v0; ball.wx = -Math.sin(a) * 6; ball.wz = Math.cos(a) * 6; ball.wy = (opts.curl || 0) * 40; }
			else { var v0b = Math.min(31, rollSpeed(D, opts.through ? 3.2 : 4.5 + D * .05)) * (1 + (Math.random() - .5) * err); ball.vx = Math.cos(a) * v0b; ball.vz = Math.sin(a) * v0b; ball.vy = 0; ball.wy = 0; }
			AU.kick(opts.lob ? .6 : .35); M.stats[p.team.k].pas++; M.lastPass = { p: p, t: M.t, off: offsideAt(p.team, opts.to), to: opts.to || null, through: !!opts.through }; M.ev('pass', { p: p, to: opts.to, lob: opts.lob, through: opts.through }); }
		function shoot(p, aimZ, power, opts) { opts = opts || {}; var t = opp(p.team), gx = t.dir * -HL, dx = gx - p.x, dz = aimZ - p.z, D = len2(dx, dz), press = pressure(p), ang = Math.abs(Math.atan2(p.fz, p.fx) - Math.atan2(dz, dx)), awk = Math.min(1, ang > Math.PI ? 2 * Math.PI - ang : ang) * .5;
			var err = ((1 - p.shoot) * .11 + press * .05 + awk * .05 + (power > .9 ? (power - .9) * .5 : 0) + D * .0012) * (opts.pen || M.so ? .45 : 1), a = Math.atan2(dz, dx) + (Math.random() - .5) * err * 2, sp = lerp(17, 33, power) * (.92 + p.shoot * .1);
			var lift = opts.chip ? .62 : clamp(.04 + power * .1 + D * .0025 + (Math.random() - .2) * err * 1.4, 0, .36);
			release(p); ball.x = p.x + Math.cos(a) * .4; ball.z = p.z + Math.sin(a) * .4; ball.y = BR + .02;
			if (opts.chip) sp = Math.sqrt(G * D / Math.sin(2 * lift)) * 1.06;
			ball.vx = Math.cos(a) * Math.cos(lift) * sp; ball.vz = Math.sin(a) * Math.cos(lift) * sp; ball.vy = Math.sin(lift) * sp;
			var curl = opts.curl || 0; ball.wy = curl * 60; ball.wx = -Math.sin(a) * (opts.chip ? -8 : 3); ball.wz = Math.cos(a) * (opts.chip ? -8 : 3);
			ball.shot = { p: p, t: M.t }; M.stats[p.team.k].sh++; AU.kick(1); M.excite = Math.max(M.excite, .8); M.ev('shot', { p: p, D: D }); }
		function pressure(p) { var m = 9; opp(p.team).pl.forEach(function (q) { m = Math.min(m, len2(q.x - p.x, q.z - p.z)); }); return clamp(1 - (m - 1) / 4, 0, 1); }
		/* ---- offside: the second-last defender line at the moment of the pass ---- */
		function offLine(t) { var o2 = opp(t), us = o2.pl.map(function (q) { return U(t, q.x); }).sort(function (a, b) { return b - a; }); return Math.max(.5, us[1], U(t, ball.x)); }
		function offsideAt(t, q) { if (!q) return false; return U(t, q.x) > offLine(t) + .002; }
		M.offLine = offLine; M.U = U; M.X = X;
		/* ---- who is in control of the loose ball ---- */
		function tryControl() { if (ball.owner || ball.y > 2.1) return; var best = null, bd = 9; ALL.forEach(function (p) { if (p.cool > 0 || p.stun > .2) return; var dd = len2(ball.x - p.x, ball.z - p.z), reach = p.role === 'GK' && p.diveT > 0 ? (p.saving ? 1.7 : .45) : p.slide > 0 ? 1.25 : .85; if (dd < reach && dd < bd) { bd = dd; best = p; } }); if (!best) return;
			var p = best, sp = len2(ball.vx - p.vx, ball.vz - p.vz) + Math.abs(ball.vy) * .6;
			if (ball.y > 1.25) { if (p.role === 'GK' && inBox(p)) return gkCatch(p, sp); return header(p); }
			if (p.slide > 0 && ball.lastTeam !== p.team.k && ball.owner == null) { ball.vx = (ball.vx * .2 + p.vx * .9); ball.vz = (ball.vz * .2 + p.vz * .9); p.cool = .4; ball.lastTeam = p.team.k; ball.last = p; M.ev('block', { p: p }); return; }
			if (p.role === 'GK' && inBox(p) && ball.shot) return gkCatch(p, sp);
			var hard = sp > 13 ? (sp - 13) / 14 : 0; if (Math.random() < hard * (1.15 - (p.role === 'GK' ? p.gk : p.drib))) { ball.vx = ball.vx * -.25 + (Math.random() - .5) * 4; ball.vz = ball.vz * -.25 + (Math.random() - .5) * 4; ball.vy = 1.2 + Math.random() * 2; p.cool = .3; ball.last = p; ball.lastTeam = p.team.k; M.ev('miscontrol', { p: p }); return; }
			take(p); }
		function take(p) { var prevT = ball.lastTeam, lp = M.lastPass; if (lp) M.prevPass = lp; ball.owner = p; ball.shot = null; ball.y = BR; ball.vy = 0;
			if (lp && M.t - lp.t < 5 && lp.p.team === p.team && lp.p !== p) { if (lp.off && lp.to === p) { M.lastPass = null; return foul(opp(p.team), p.x, p.z, 'offside', p); } M.stats[p.team.k].pc++; lp.p.r += .06; if (lp.through) lp.p.r += .15; }
			if (lp && M.t - lp.t < 5 && lp.p.team !== p.team) { lp.p.r -= .08; p.r += .1; } M.lastPass = null; if (prevT !== p.team.k && prevT >= 0) M.ev('turnover', { p: p }); ball.lastTeam = p.team.k; ball.last = p; }
		function header(p) { var t = p.team, o2 = opp(t), inAtt = U(t, p.x) > .8 && Math.abs(p.z) < 20; p.cool = .4; ball.last = p; ball.lastTeam = t.k;
			if (inAtt) { var aim = (Math.random() - .5) * GW * .9, gx = o2.dir * -HL * -1; gx = -o2.dir * HL; var dx = -t.dir * -1; var hx = t.dir * HL - p.x, hz = aim - p.z, D = len2(hx, hz), sp = 11 + p.shoot * 6; ball.vx = hx / D * sp; ball.vz = hz / D * sp; ball.vy = -1.5 - Math.random() * 2; ball.shot = { p: p, t: M.t }; M.stats[t.k].sh++; M.ev('header', { p: p }); AU.kick(.5); M.excite = .8; }
			else { var tx = t.dir * 30, tz = p.z * .6; var hx2 = tx - p.x, hz2 = tz - p.z, D2 = len2(hx2, hz2); ball.vx = hx2 / D2 * 13; ball.vz = hz2 / D2 * 13; ball.vy = 5; AU.kick(.4); M.ev('clear', { p: p }); } }
		function inBox(p) { var gx = -p.team.dir * HL; return Math.abs(p.x - gx) < 16.5 && Math.abs(p.z) < 20.16; }
		function gkCatch(p, sp) { if (sp < 21 + p.gk * 8 && Math.random() < .55 + p.gk * .45) { ball.owner = p; ball.shot = null; ball.vx = ball.vz = ball.vy = 0; ball.y = 1.1; ball.lastTeam = p.team.k; ball.last = p; p.hold = 1.6; p.heldT = 0; M.stats[1 - p.team.k].on++; p.r += .35; M.ev('save', { p: p, catch: 1 }); AU.ooh(); return; }
			var out = p.team.dir; ball.vx = Math.abs(ball.vx) * .35 * out + out * 3; ball.vz = (Math.random() - .5) * 14; ball.vy = 3 + Math.random() * 3; ball.shot = null; p.cool = .6; ball.last = p; ball.lastTeam = p.team.k; M.stats[1 - p.team.k].on++; p.r += .4; M.ev('save', { p: p }); AU.ooh(); }
		/* ---- tackles and fouls ---- */
		function tackle(p, slide) { var c = ball.owner; if (p.stun > 0 || p.cool > 0) return; if (slide) { p.slide = .55; p.vx = p.fx * 8.5; p.vz = p.fz * 8.5; p.stun = .9; M.ev('slide', { p: p }); }
			if (!c || c.team === p.team) return; var dd = len2(c.x - p.x, c.z - p.z); if (dd > (slide ? 2.2 : 1.7)) { if (!slide) p.stun = .35; return; }
			var behind = (c.fx * (p.x - c.x) + c.fz * (p.z - c.z)) / (dd || 1) < -.35, chance = .42 + (p.tack - c.drib) * .9 + (slide ? .08 : 0) - (behind ? .25 : 0) - len2(c.vx, c.vz) * .015;
			if (behind && Math.random() < (slide ? .55 : .3)) return foul(p.team, c.x, c.z, 'foul', p, c);
			if (Math.random() < chance) { var keep = !slide && Math.random() < .5; if (keep) take(p); else { ball.owner = null; var kn = 4 + Math.random() * 6, ka = Math.random() * 6.283; ball.vx = p.fx * 3 + Math.cos(ka) * kn; ball.vz = p.fz * 3 + Math.sin(ka) * kn; ball.last = p; ball.lastTeam = p.team.k; c.cool = .5; } c.stun = .45; p.r += .2; c.r -= .05; M.ev('tackle', { p: p, c: c }); }
			else { p.stun = slide ? 1.1 : .7; M.ev('tacklemiss', { p: p, c: c }); } }
		function foul(byTeam, x, z, kind, by, on) { /* byTeam committed it; the other team restarts */
			var t = kind === 'offside' ? byTeam : opp(byTeam); if (kind !== 'offside') { M.stats[byTeam.k].fouls++; if (by && by.role !== 'GK' && Math.random() < .22) { by.card++; M.ev('card', { p: by, red: by.card >= 2 }); if (by.card >= 2) sendOff(by); } }
			var pen = kind === 'foul' && Math.abs(x - t.dir * HL) < 16.5 && Math.abs(z) < 20.16;
			setRestart(pen ? 'penalty' : 'freekick', t, pen ? t.dir * (HL - 11) : clamp(x, -HL + 1, HL - 1), pen ? 0 : clamp(z, -HW + 1, HW - 1), kind, by, on); }
		/* ---- restarts ---- */
		function sendOff(p) { var t = p.team; if (ball.owner === p) ball.owner = null; [t.pl, ALL].forEach(function (L) { var i = L.indexOf(p); if (i >= 0) L.splice(i, 1); }); if (t.ctrl === p) t.ctrl = t.pl[t.pl.length - 1]; if (t.ctrl2 === p) t.ctrl2 = null; p.sent = 1; p.x = 0; p.z = HW + 8; if (p.mesh) p.mesh.visible = false; }
		function setRestart(kind, t, x, z, why, by, on) { M.phase = 'restart'; M.restart = { kind: kind, t: t, x: x, z: z, T: 0, why: why, ready: false }; ballTo(x, z, kind === 'throw' ? 2 : BR); ball.lastTeam = t.k; AU.whistle(kind === 'penalty' ? 2 : 1); M.ev('restart', { kind: kind, t: t, why: why, by: by, on: on });
			if (kind === 'corner') M.stats[t.k].corners++;
			var taker = nearest(t.pl.filter(function (q) { return kind === 'goalkick' ? q.role === 'GK' : q.role !== 'GK'; }), x, z); if (kind === 'penalty') taker = t.pl.slice().sort(function (a, b) { return b.shoot - a.shoot; })[0];
			M.restart.taker = taker; var bx = x - t.dir * (kind === 'corner' ? .6 : .5), bz = z - (kind === 'throw' ? Math.sign(z) * .6 : 0); taker.x = bx; taker.z = bz; taker.vx = taker.vz = 0; var fdx = (kind === 'throw' ? t.dir * 6 : t.dir * 10) - (kind === 'throw' ? 0 : 0), fdz = kind === 'throw' ? -Math.sign(z) : 0; var fl = len2(fdx, fdz) || 1; taker.fx = fdx / fl; taker.fz = fdz / fl;
			ALL.forEach(function (q) { if (q === taker) return; var dd = len2(q.x - x, q.z - z); if (q.team !== t && dd < 9.15) { q.x = x + (q.x - x) / (dd || 1) * 9.3; q.z = z + (q.z - z) / (dd || 1) * 9.3; } if (kind === 'penalty' && q !== taker) { var gx = t.dir * HL; if (q.role === 'GK' && q.team !== t) { q.x = gx; q.z = 0; } else { q.x = t.dir * (HL - 19 - Math.random() * 6); q.z = (Math.random() - .5) * 30; } } });
			/* a defensive wall for direct free kicks in range */
			ALL.forEach(function (q) { q.wall = 0; }); var gx0 = t.dir * HL, gd = len2(gx0 - x, z); if (kind === 'freekick' && gd < 32) { var dfd = opp(t), ux = (gx0 - x) / gd, uz = -z / gd, nW = gd < 22 ? 4 : 3, wl = dfd.pl.filter(function (q) { return q.role !== 'GK'; }).sort(function (a2, b2) { return len2(a2.x - x, a2.z - z) - len2(b2.x - x, b2.z - z); }).slice(0, nW);
				wl.forEach(function (q, i) { var off = (i - (nW - 1) / 2) * .62 + .3 * Math.sign(z || 1); q.x = x + ux * 9.15 - uz * off; q.z = z + uz * 9.15 + ux * off; q.vx = q.vz = 0; q.fx = -ux; q.fz = -uz; q.wall = 1; }); M.ev('wall', { n: nW }); }
			if (t.human) selectPlayer(t, taker, true); }
		function nearest(L, x, z) { var b = null, bd = 1e9; L.forEach(function (q) { var dd = len2(q.x - x, q.z - z); if (dd < bd) { bd = dd; b = q; } }); return b; }
		function takeRestart(passOpt) { var R = M.restart; if (!R) return; var p = R.taker, t = R.t; M.phase = 'play'; M.restart = null; ball.owner = p; ball.x = p.x + p.fx * .5; ball.z = p.z + p.fz * .5; ball.y = BR;
			if (passOpt && passOpt.shoot) return shoot(p, passOpt.aimZ, passOpt.power, passOpt);
			if (passOpt && passOpt.to) passTo(p, passOpt.x, passOpt.z, passOpt); else aiOnBall(p, R.kind);
			if (R.kind === 'throw' && !ball.owner) { ball.y = 1.9; ball.vy = Math.max(ball.vy, 2.2); var hs = len2(ball.vx, ball.vz); if (hs > 16) { ball.vx *= 16 / hs; ball.vz *= 16 / hs; } } }
		/* ---- out of play and goals ---- */
		function checkOut() { var b = ball; if (M.phase !== 'play') return;
			if (M.so && (Math.abs(b.x) > HL + BR || Math.abs(b.z) > HW + BR)) { var inM = Math.abs(b.z) < GW / 2 && b.y < GH; if (!inM) soRes(false); else if (Math.abs(b.x) > HL + BR) goal(Math.sign(b.x)); return; }
			if (Math.abs(b.x) > HL + BR) { var s = Math.sign(b.x), inMouth = Math.abs(b.z) < GW / 2 - BR * .3 && b.y < GH - BR * .2; if (inMouth && Math.abs(b.x) > HL + BR) return goal(s);
				var att = TM.filter(function (t) { return t.dir === s; })[0]; /* the team attacking this end */
				if (b.lastTeam === att.k) setRestart('goalkick', opp(att), s * (HL - 5.5), b.z > 0 ? 9 : -9); else setRestart('corner', att, s * (HL - .2), b.z > 0 ? HW - .2 : -HW + .2); return; }
			if (Math.abs(b.z) > HW + BR) { setRestart('throw', TM[1 - Math.max(0, b.lastTeam)], clamp(b.x, -HL + 1, HL - 1), Math.sign(b.z) * HW); } }
		function goal(s) { if (M.so) { soRes(true); return; } var t = TM.filter(function (q) { return q.dir === s; })[0], sc = ball.last && ball.last.team === t ? ball.last : ball.shot && ball.shot.p.team === t ? ball.shot.p : null, og = ball.last && ball.last.team !== t; t.score++; M.stats[t.k].on++; M.phase = 'goal'; M.phT = 0; M.goalT = 0; M.excite = 1; var mn = Math.min(90, Math.floor(M.clock / M.halfSec * 45 + (M.half - 1) * 45) + 1); if (sc && !og) sc.r += 1.1; if (og && ball.last) ball.last.r -= .8; var gk0 = opp(t).pl[0]; gk0.r -= .3; var ast = M.prevPass; if (ast && ast.p.team === t && ast.p !== sc && M.t - ast.t < 7) ast.p.r += .6; M.scorers.push({ k: t.k, n: og ? ball.last.sh + ' (og)' : sc ? sc.sh : t.club.s, m: mn }); AU.roar(); AU.whistle(1); M.ev('goal', { t: t, p: sc, og: og, min: mn }); M.kickTeam = opp(t); }
		/* ---- the AI ---- */
		function lookFor(p, opts) { /* best pass for p: progress, a lane defenders cannot close in time, space around the receiver */
			var t = p.team, o2 = opp(t), best = null, bs = -1e9, line = offLine(t); t.pl.forEach(function (q) { if (q === p || q.stun > .3) return; var dx = q.x - p.x, dz = q.z - p.z, D = len2(dx, dz); if (D < 5 || D > (opts && opts.long ? 55 : 40)) return; if (q.role === 'GK' && U(t, p.x) > .35) return;
				var through = opts && opts.through, lead = through ? 6 + q.pace * 5 : Math.min(2.5, D * .07), tx = q.x + t.dir * lead * (through ? 1 : .5), tz = q.z, ax = tx - p.x, az = tz - p.z, L2 = ax * ax + az * az, DL = Math.sqrt(L2), lane = 9, sp = 9;
				if (through && (U(t, tx) > .97 || Math.abs(tz) > HW - 2)) return;
				o2.pl.forEach(function (r) { var u2 = clamp(((r.x - p.x) * ax + (r.z - p.z) * az) / L2, 0, 1), cx = p.x + ax * u2 - r.x, cz = p.z + az * u2 - r.z, perp = Math.sqrt(cx * cx + cz * cz), m = perp - (.7 + DL * u2 * (through ? .5 : .38)); lane = Math.min(lane, m); sp = Math.min(sp, len2(r.x - tx, r.z - tz)); });
				var prog = (U(t, tx) - U(t, p.x)) * 6, off = U(t, q.x) > line + .002 ? 4 : 0, s = prog + clamp(lane, -3, 3) * .6 + Math.min(sp, 7) * .18 - off - (DL > 32 ? (DL - 32) * .05 : 0) + (U(t, tx) > .72 ? .5 : 0) + (U(t, tx) > .82 && Math.abs(tz) < 16 ? 1 : 0) + (Math.random() - .5) * (.9 - M.diff * .25);
				if (lane < 0) s -= 4; if (s > bs) { bs = s; best = { q: q, x: tx, z: tz, s: s, lane: lane, D: DL }; } }); return best; }
		function shotValue(p) { var t = p.team, gx = t.dir * HL, dx = gx - p.x, D = len2(dx, p.z); if (D > 30) return -1; var angL = Math.atan2(GW / 2 - p.z, Math.abs(dx)) - Math.atan2(-GW / 2 - p.z, Math.abs(dx)), block = 0;
			opp(t).pl.forEach(function (r) { if (r.role === 'GK') return; var ax = gx - p.x, az = -p.z, L2 = ax * ax + az * az, u2 = clamp(((r.x - p.x) * ax + (r.z - p.z) * az) / L2, 0, 1), cx = p.x + ax * u2 - r.x, cz = p.z + az * u2 - r.z; if (Math.sqrt(cx * cx + cz * cz) < 1.2 && u2 > .05) block += .35; });
			return angL * 2.6 * (1 - D / 36) * p.shoot - block + (D < 12 ? .3 : 0) + (D < 20 && Math.abs(p.z) < 12 ? .08 : 0); }
		function aiOnBall(p, setPiece) { var t = p.team, o2 = opp(t), u = U(t, p.x), pr = pressure(p), gk = o2.pl[0];
			if (setPiece === 'penalty') { var side = Math.random() < .5 ? -1 : 1; return shoot(p, side * (GW / 2 - .6 - Math.random() * 1.2), .78 + Math.random() * .15, {}); }
			if (setPiece === 'corner') { var tz = -Math.sign(p.z) * (Math.random() * 6), tx = t.dir * (HL - 9 - Math.random() * 5); return passTo(p, tx, tz, { lob: 1, curl: Math.sign(p.z) * t.dir * .6 }); }
			if (setPiece === 'goalkick' || (p.role === 'GK' && !setPiece)) { var o0 = lookFor(p, { long: 1 }); if (o0 && o0.lane > 2.4 && o0.D < 32) return passTo(p, o0.x, o0.z, { to: o0.q }); var tg = nearest(t.pl.filter(function (q) { return q.role === 'ST' || q.role === 'W' || q.role === 'CM'; }), t.dir * 10, 0); return passTo(p, tg.x + t.dir * 3, tg.z, { lob: 1, to: tg }); }
			var sv = shotValue(p); if (sv > .22 - M.diff * .03 || (sv > .1 && pr > .5)) { var far = gk.z > 0 ? -1 : 1, aim = far * (GW / 2 - .45 - Math.random() * .9); return shoot(p, aim, clamp(.62 + (1 - len2(t.dir * HL - p.x, p.z) / 34) * .2 + Math.random() * .15, 0, .95), { curl: Math.abs(p.z) > 8 && Math.random() < .5 ? -Math.sign(p.z) * t.dir * .5 : 0 }); }
			if (u < .3 && pr > .72 && Math.random() < .7) { var side = Math.abs(p.z) > 8 ? Math.sign(p.z) : (Math.random() < .5 ? -1 : 1); M.ev('clear', { p: p }); return passTo(p, p.x + t.dir * (35 + Math.random() * 20), side * (HW - 4 + Math.random() * 10), { lob: 1 }); }
			var pass = lookFor(p), thr = u > .45 ? lookFor(p, { through: 1 }) : null; if (thr && (!pass || thr.s > pass.s + .3) && thr.lane > 1.6) return passTo(p, thr.x, thr.z, { through: 1, to: thr.q, press: pr });
			if (setPiece) { if (pass) return passTo(p, pass.x, pass.z, { to: pass.q }); var q0 = nearest(t.pl.filter(function (q) { return q !== p && q.role !== 'GK'; }), p.x, p.z); return passTo(p, q0.x, q0.z, { to: q0 }); }
			var space = 12; o2.pl.forEach(function (r) { var ax = r.x - p.x, az = r.z - p.z, ahead = ax * t.dir; if (ahead > -1.5) space = Math.min(space, len2(ax, az * 1.4)); });
			var carry = (space - 3) * .35 + (u < .85 ? .8 : 0) + (u > .5 && space > 4 ? .6 : 0) - pr * 1.4 + (p.role === 'W' || p.role === 'FB' ? .4 : 0) + p.drib * .8;
			if (pass && (pass.s > carry || pr > .75)) return passTo(p, pass.x, pass.z, { to: pass.q, press: pr });
			if (u > .82 && Math.abs(p.z) > 14 && Math.random() < .5) { var tgt = t.dir * (HL - 7 - Math.random() * 6); return passTo(p, tgt, (Math.random() - .5) * 10, { lob: 1, curl: -Math.sign(p.z) * t.dir * .5 }); }
			p.carry = .45 + Math.random() * .4; }
		M.aiOnBall = aiOnBall;
		/* ---- off the ball: the block moves with the ball; runners, pressers, markers ---- */
		var chaseT = [null, null];
		function targets(t) { var o2 = opp(t), own = ball.owner && ball.owner.team === t, bu = U(t, ball.x), line = offLine(t), att = own || (ball.lastTeam === t.k && !ball.owner);
			/* who goes to the ball: the fastest to reach it per team */
			var best = null, bt = 1e9, bp = null, lp = M.lastPass; if (!own) t.pl.forEach(function (q) { if (q.role === 'GK' && !inBoxPt(t, ball.x, ball.z)) return; var ic = intercept(q); var tt = ic.t * (lp && lp.to === q && M.t - lp.t < 4 ? .6 : 1); if (tt < bt) { bt = tt; best = q; bp = ic; } }); chaseT[t.k] = best; if (best) best.ic = bp;
			var shift = att ? .1 : -.04, comp = att ? 1 : .78;
			t.pl.forEach(function (q) { if (q.role === 'GK') return; var u = q.hu * .62 + bu * .48 + shift - .08, wz = q.hw * HW * .84 * comp + ball.z * (att ? .18 : .34);
				if (q.role === 'CB' || q.role === 'FB') u = Math.min(u, att ? .62 : bu - .02); if (q.role === 'ST' || q.role === 'W') { u = Math.max(u, att ? Math.min(line - .006, bu + .12) : .4); if (att && ball.owner && ball.owner !== q && Math.random() < .012) q.run = 2.2; if (q.run > 0) u = Math.min(.95, line + .06); }
				if (!att && (q.role === 'ST')) u = Math.max(u, .45);
				q.tx = X(t, clamp(u, .04, .96)); q.tz = clamp(wz, -HW + 2, HW - 2); q.want = 0; });
			if (!own && best) { best.tx = bp.x; best.tz = bp.z; best.want = 1; var cc = ball.owner; if (cc && cc.team !== t) { /* jockey: get goal-side of the carrier, then step in */ var gx0 = -t.dir * HL, ddx = gx0 - cc.x, ddz = -cc.z, dl = len2(ddx, ddz) || 1, lead = Math.min(1.6, len2(best.x - cc.x, best.z - cc.z) * .3); best.tx = cc.x + cc.vx * .35 + ddx / dl * lead; best.tz = cc.z + cc.vz * .35 + ddz / dl * lead; } }
			if (!own && ball.owner) { /* second presser, and markers goal-side of dangerous attackers */ var c = ball.owner, sec = nearest(t.pl.filter(function (q) { return q !== best && q.role !== 'GK'; }), c.x, c.z); if (sec && len2(sec.x - c.x, sec.z - c.z) < 14) { sec.tx = c.x - t.dir * 3; sec.tz = c.z * .9; sec.want = .6; }
				o2.pl.forEach(function (a) { if (a === c || a.role === 'GK' || U(o2, a.x) < .58) return; var m = nearest(t.pl.filter(function (q) { return (q.role === 'CB' || q.role === 'FB' || q.role === 'DM') && q !== best; }), a.x, a.z); if (m && len2(m.x - a.x, m.z - a.z) < 12) { m.tx = a.x - t.dir * 1.6; m.tz = a.z + (0 - a.z) * .12; } }); }
			var g = t.pl[0], gx = -t.dir * HL, bdx = ball.x - gx, bdz = ball.z, bd = len2(bdx, bdz) || 1, out = clamp(bd * .1, .6, 5.5); g.tx = gx + bdx / bd * out; g.tz = clamp(bdz / bd * out * 1.6, -GW / 2 + .3, GW / 2 - .3);
			if (!own && inBoxPt(t, ball.x, ball.z) && len2(g.x - ball.x, g.z - ball.z) < 11 && !ball.owner) { g.tx = ball.x; g.tz = ball.z; }
			/* set pieces into the box: corners and wide free kicks fill the area */
			var R = M.restart; if (M.phase === 'restart' && R && (R.kind === 'corner' || (R.kind === 'freekick' && Math.abs(R.x - R.t.dir * HL) < 36 && Math.abs(R.z) > 14))) { var att2 = R.t === t, gx2 = R.t.dir * HL, k2 = 0;
				t.pl.forEach(function (q) { if (q.role === 'GK' || q === R.taker || q.wall) return; if (att2) { if (q.role === 'FB' || q.role === 'DM') { q.tx = gx2 - R.t.dir * 30; q.tz = q.hw * 15; return; } q.tx = gx2 - R.t.dir * (6 + (k2 % 3) * 3.5 + Math.random()); q.tz = -9 + (k2 * 4.3) % 18; k2++; } else { q.tx = gx2 - R.t.dir * (4 + (k2 % 4) * 2.6); q.tz = -8 + (k2 * 3.7) % 16; k2++; } }); } }
		/* where the loose ball will be over the next three seconds, and who can get there first */
		var BP = [];
		function ballPath() { BP.length = 0; var x = ball.x, z = ball.z, y = ball.y, vx = ball.vx, vz = ball.vz, vy = ball.vy, h = .05; if (ball.owner) { BP.push([x, z, BR]); return; } for (var i = 0; i < 60; i++) { var sp = Math.sqrt(vx * vx + vz * vz + vy * vy); if (y > BR + .02 || vy > .5) { vx -= CD * sp * vx * h; vz -= CD * sp * vz * h; vy -= (G + CD * sp * vy) * h; } else { var hs = Math.sqrt(vx * vx + vz * vz); if (hs > 0) { var k = Math.max(0, hs - (1.05 + .016 * hs * hs) * h) / hs; vx *= k; vz *= k; } vy = 0; y = BR; } x += vx * h; z += vz * h; y += vy * h; if (y < BR) { y = BR; vy = vy < -1.1 ? -vy * .56 : 0; } if (i % 2 === 1) BP.push([x, z, y]); } }
		function intercept(q) { var sp = 6 + q.pace * 2.6; for (var i = 0; i < BP.length; i++) { var p = BP[i], t0 = (i + 1) * .1; if (p[2] > 2) continue; var dd = Math.max(0, len2(p[0] - q.x, p[1] - q.z) - .7); if (dd / sp + (q.stun || 0) + .15 <= t0) return { t: t0, x: p[0], z: p[1] }; } var e = BP[BP.length - 1]; return { t: 3 + len2(e[0] - q.x, e[1] - q.z) / sp, x: e[0], z: e[1] }; }
		function inBoxPt(t, x, z) { var gx = -t.dir * HL; return Math.abs(x - gx) < 16.5 && Math.abs(z) < 20.16; }
		/* goalkeeper reaction to shots */
		function keeper(t, h) { var g = t.pl[0], b = ball; if (!b.shot || b.owner || g.diveT > 0) return; var gx = -t.dir * HL; if ((b.vx * -t.dir) <= 2) return; var tc = (gx - b.x) / b.vx; if (tc < 0 || tc > 1.6) return; var cz = b.z + b.vz * tc, cy = b.y + b.vy * tc - .5 * G * tc * tc; if (Math.abs(cz) > GW / 2 + .6 || cy > GH + .5) return;
			g.react = (g.react || 0) + h; if (g.react < .2 - g.gk * .12) return; var dz = cz - g.z, dd = Math.abs(dz), reach = 1.1 + g.gk * 1.9; g.diveT = .9; g.react = 0;
			if (dd > .6) { g.dive = Math.sign(dz); g.vz = Math.sign(dz) * Math.min(dd / Math.max(.15, tc), 7.5); } var corner = Math.abs(cz) > GW / 2 - 1 ? .18 : 0, high = cy > 1.7 ? .1 : 0; if (dd < reach + tc * 4.2 && Math.random() < .2 + g.gk * .7 + Math.min(.25, tc * .25) - corner - high - Math.max(0, len2(b.vx, b.vz) - 22) * .025) { g.saving = { z: cz, y: cy, t: tc }; g.vz = clamp((cz - g.z) / Math.max(.14, tc), -9, 9); } else { g.saving = null; g.vz = clamp((cz - g.z) / Math.max(.14, tc), -3.5, 3.5); } }
		/* ---- one fixed step ---- */
		var tgtT = 0;
		function step(h, inp) {
			M.t += h; if ((M.phase === 'play' || M.phase === 'restart') && !M.so) { M.clock += h; }
			if (M.so) { var S0 = M.so; if (M.phase === 'sowait') { S0.wait -= h; if (S0.wait <= 0) { S0.wait = 0; if (S0.done) { M.phase = 'full'; M.phT = 0; AU.whistle(3); M.ev('full', { so: 1 }); return; } nextPen(); } }
				else if (M.phase === 'play') { S0.T += h; if (ball.owner && ball.owner.role === 'GK') soRes(false); else if (S0.T > 3.4 || (S0.T > .8 && len2(ball.vx, ball.vz) < 1.5)) soRes(false); } }
			if (M.phase === 'play' && !M.so && M.clock >= M.halfSec) { M.clock = M.halfSec; if (M.half === 1) { M.phase = 'half'; M.phT = 0; AU.whistle(2); M.ev('half', {}); } else { M.phase = 'full'; M.phT = 0; AU.whistle(3); M.ev('full', {}); } }
			if (M.phase === 'goal') { if (M.hold) return; M.phT += h; M.goalT += h; if (M.phT > 4) kickoff(M.kickTeam); }
			if (M.phase === 'half') { M.phT += h; if (M.phT > 3) { M.half = 2; M.clock = 0; TM.forEach(function (t) { t.dir *= -1; }); kickoff(TM[1]); } return; }
			if (M.phase === 'full') { M.phT += h; return; }
			if (M.phase === 'kickoff') { M.phT += h; if (M.phT > 1.4) { var K = M.kickTeam || TM[0], st = K.pl.filter(function (q) { return q.role === 'ST'; })[0] || K.pl[9]; M.phase = 'play'; ball.owner = st; st.x = -K.dir * .4; st.z = 0; var mate = nearest(K.pl.filter(function (q) { return q !== st && q.role !== 'GK'; }), 0, 0); if (K.human) { selectPlayer(K, st, true); if (M.queued && M.queued.t === K) { var qd = M.queued; M.queued = null; humanAct(K, qd.act, qd.a); } } else passTo(st, mate.x - K.dir * 2, mate.z, { to: mate }); } }
			if (M.phase === 'restart') { var R = M.restart; R.T += h; if (!R.t.human && R.T > (R.kind === 'throw' ? 1.1 : R.kind === 'penalty' ? 2.2 : R.kind === 'corner' ? 5 : 1.6)) takeRestart(); else if (R.t.human && R.T > 8) takeRestart(); }
			tgtT -= h; if (tgtT <= 0) { tgtT = .15; ballPath(); TM.forEach(targets); }
			if (M.phase === 'play' || M.phase === 'restart') TM.forEach(function (t) { keeper(t, h); });
			/* move everyone */
			ALL.forEach(function (p) { p.cool = Math.max(0, p.cool - h); p.stun = Math.max(0, p.stun - h); p.kick = Math.max(0, p.kick - h); p.slide = Math.max(0, p.slide - h); p.diveT = Math.max(0, p.diveT - h); if (p.run) p.run = Math.max(0, p.run - h); if (p.hold) p.hold = Math.max(0, p.hold - h);
				if (M.so && p.role !== 'GK' && !(M.restart && p === M.restart.taker) && p !== ball.last) { p.vx = p.vz = 0; return; }
				var R2 = M.restart, frozen = M.phase === 'restart' && R2 && (p === R2.taker || p.wall) || M.phase === 'kickoff'; if (p.wall && M.phase === 'play') { p.wall -= h; if (p.wall < 0) p.wall = 0; } if (frozen) { p.vx *= .8; p.vz *= .8; return; }
				var ctl = p.team.ctrl === p ? inp[p.team.k === 0 ? 0 : 1] || inp[0] : p.team.ctrl2 === p ? inp[1] : null, dx, dz, want, sprint = false;
				if (ctl && (M.phase === 'play' || M.phase === 'restart')) { dx = ctl.x; dz = ctl.z; want = Math.min(1, len2(dx, dz)); sprint = ctl.sprint; if (want > .05) { var l0 = len2(dx, dz); dx /= l0; dz /= l0; } else { dx = 0; dz = 0; } }
				else { dx = p.tx - p.x; dz = p.tz - p.z; var dd = len2(dx, dz); if (ball.owner === p) { /* carrying: toward goal, away from the nearest opponent */ var t = p.team, gx = t.dir * HL; dx = gx - p.x; dz = (Math.abs(p.z) > 20 ? -p.z * .3 : 0) - p.z * .15; var near = nearest(opp(t).pl, p.x, p.z); if (near && len2(near.x - p.x, near.z - p.z) < 5) { dz += (p.z - near.z) * 1.4; } if (p.role === 'W' && U(t, p.x) < .8) dz = (Math.sign(p.z || 1) * (HW - 5) - p.z) * .4; dd = len2(dx, dz); }
					want = dd > .4 ? Math.min(1, dd / 3) : 0; if (dd > 0) { dx /= dd; dz /= dd; } sprint = p.want > .5 || p.run > 0 || (ball.owner === p && dd > 3 && pressure(p) > .3) || dd > 14; }
				if (p.stun > 0 && p.slide <= 0) want *= .25;
				var top = (p.role === 'GK' ? 5.6 : 5.4) + (sprint && p.stam > .08 ? (2.2 + p.pace * 1.6) : 0) + p.pace * .6, carryK = ball.owner === p ? .9 : 1; top *= carryK * (.75 + p.stam * .25);
				if (sprint && want > .5) p.stam = Math.max(0, p.stam - h * .045); else p.stam = Math.min(1, p.stam + h * .02);
				var tvx = dx * top * want, tvz = dz * top * want, acc = (want > .1 ? 7.5 + p.pace * 2 : 11) * h, ex = tvx - p.vx, ez = tvz - p.vz, el = len2(ex, ez);
				if (p.slide > 0) { p.vx *= Math.exp(-2.2 * h); p.vz *= Math.exp(-2.2 * h); } else if (p.diveT > 0 && p.role === 'GK' && p.dive) { p.vx *= .96; } else if (el > acc) { p.vx += ex / el * acc; p.vz += ez / el * acc; } else { p.vx = tvx; p.vz = tvz; }
				p.x += p.vx * h; p.z += p.vz * h; p.x = clamp(p.x, -HL - 4, HL + 4); p.z = clamp(p.z, -HW - 3, HW + 3);
				var sp = len2(p.vx, p.vz); if (sp > .4 && p.slide <= 0) { var fl = 1 - Math.exp(-10 * h); p.fx += (p.vx / sp - p.fx) * fl; p.fz += (p.vz / sp - p.fz) * fl; var fn = len2(p.fx, p.fz) || 1; p.fx /= fn; p.fz /= fn; } });
			/* bodies don't overlap */
			for (var i = 0; i < ALL.length; i++) for (var j = i + 1; j < ALL.length; j++) { var a = ALL[i], b2 = ALL[j], ddx = b2.x - a.x, ddz = b2.z - a.z, dd2 = ddx * ddx + ddz * ddz; if (dd2 < .36 && dd2 > 1e-6) { var dd3 = Math.sqrt(dd2), push = (.6 - dd3) / 2; a.x -= ddx / dd3 * push; a.z -= ddz / dd3 * push; b2.x += ddx / dd3 * push; b2.z += ddz / dd3 * push; } }
			/* the ball at the feet */
			var c = ball.owner; if (c) { if (c.role === 'GK' && c.hold > 0) { ball.x = c.x + c.fx * .3; ball.z = c.z + c.fz * .3; ball.y = 1.1; if ((!c.team.human && c.hold < .2) || (c.team.human && c.hold <= 0 && (c.heldT = (c.heldT || 0) + h) > 3)) { c.heldT = 0; aiOnBall(c); } }
				else { var spd = len2(c.vx, c.vz), off = .48 + spd * .055, txb = c.x + c.fx * off, tzb = c.z + c.fz * off; ball.vx = c.vx + (txb - ball.x) * 9; ball.vz = c.vz + (tzb - ball.z) * 9; ball.x += ball.vx * h; ball.z += ball.vz * h; ball.y = BR; ball.vy = 0; ball.wx = -c.fz * spd * 2; ball.wz = c.fx * spd * 2;
					if (len2(ball.x - c.x, ball.z - c.z) > 1.6) ball.owner = null;
					else if (spd > 7 && Math.random() < h * 1.1 * (1.25 - c.drib) * (pressure(c) > .3 ? 1.6 : 1)) { /* a heavy touch at full sprint */ ball.owner = null; ball.vx = c.vx * 1.4 + c.fx * 1.5; ball.vz = c.vz * 1.4 + c.fz * 1.5; c.cool = .25; ball.last = c; ball.lastTeam = c.team.k; }
					if (!c.team.human || (c.team.ctrl !== c && c.team.ctrl2 !== c)) { c.carry = (c.carry || 0) - h; c.think = (c.think || 0) - h; if (c.carry <= 0 && c.think <= 0) { c.think = .3 - M.diff * .07 + Math.random() * .15; aiOnBall(c); } }
					/* defenders tackle the carrier */
					opp(c.team).pl.forEach(function (q) { if (q.team.human && (q.team.ctrl === q || q.team.ctrl2 === q)) return; if (q.stun > 0 || q.role === 'GK' && !inBox(q)) return; var dq = len2(q.x - c.x, q.z - c.z); if (dq < 1.6) { q.tk = (q.tk || 0) + h; if (q.tk > .42 - M.diff * .1) { q.tk = 0; tackle(q, dq > 1.1 && Math.random() < .25); } } }); } }
			for (var sbs = 0; sbs < 2; sbs++) ballStep(h / 2);
			if (M.phase === 'play') { tryControl(); checkOut(); }
			if (ball.owner) M.stats[ball.owner.team.k].poss += h;
			/* the human side: auto-switch to the best player when defending */
			TM.forEach(function (t) { if (!t.human) return; if (!t.ctrl) t.ctrl = t.pl[9]; var o0 = ball.owner; if (o0 && o0.team === t && t.ctrl !== o0 && t.ctrl2 !== o0) { if (o.human === 'both' && t.ctrl2) { var d1 = len2(t.ctrl.x - o0.x, t.ctrl.z - o0.z), d2 = len2(t.ctrl2.x - o0.x, t.ctrl2.z - o0.z); if (d1 < d2) t.ctrl = o0; else t.ctrl2 = o0; } else t.ctrl = o0; } if ((!o0 || o0.team !== t) && t.autoT !== undefined) { t.autoT -= h; if (t.autoT <= 0) { t.autoT = 1.2; var cand = chaseT[t.k]; if (cand && cand !== t.ctrl && len2(t.ctrl.x - ball.x, t.ctrl.z - ball.z) > len2(cand.x - ball.x, cand.z - ball.z) + 6) selectPlayer(t, cand); } } });
			M.chT = (M.chT || 0) - h; if (M.chT <= 0 && M.phase === 'play') { M.chT = 7 + Math.random() * 7; if (Math.random() < .6) AU.chant(); } M.excite = Math.max(0, M.excite - h * .25); var danger = Math.max(0, Math.abs(ball.x) / HL - .55) * 2; AU.crowd(Math.min(1, danger * .5 + M.excite * .6));
		}
		function selectPlayer(t, p, silent) { if (!t.human) return; t.ctrl = p; t.autoT = 1.2; if (!silent) M.ev('switch', { p: p }); }
		function kickoff(t) { M.phase = 'kickoff'; M.phT = 0; M.kickTeam = t; TM.forEach(function (q) { kickoffPos(q, q === t); }); ballTo(0, 0); ball.lastTeam = t.k; TM.forEach(function (q) { if (q.human) selectPlayer(q, q.pl.filter(function (r) { return r.role === 'ST'; })[0] || q.pl[9], true); }); AU.whistle(1); }
		/* ---- human actions ---- */
		function humanAct(t, act, a) { var p = t.ctrl; if (!p) return; if (a && a.slot === 1 && t.ctrl2) p = t.ctrl2;
			if (M.phase === 'restart' && M.restart && M.restart.t === t) { var R = M.restart; if (act === 'shoot' && R.kind !== 'throw' && R.kind !== 'corner' && R.kind !== 'goalkick') { return takeRestart({ shoot: 1, aimZ: aimOf(t, a), power: a.power || .8, curl: a.curl }); } var tg = pickTarget(R.taker, a, act === 'through'); if (!tg) return takeRestart(); return takeRestart({ to: tg.q, x: tg.x, z: tg.z, lob: act === 'lob' || R.kind === 'corner' || (R.kind === 'goalkick' && tg.D > 30), through: act === 'through' }); }
			if (M.phase === 'kickoff' && M.kickTeam === t && (act === 'pass' || act === 'through' || act === 'lob')) { M.queued = { t: t, act: act, a: a }; return; }
			if (M.phase !== 'play') return;
			if (ball.owner === p) { if (act === 'pass' || act === 'through' || act === 'lob') { var tg2 = pickTarget(p, a, act === 'through'); if (tg2) passTo(p, tg2.x, tg2.z, { to: tg2.q, lob: act === 'lob', through: act === 'through', press: pressure(p) }); else { var fx0 = a.x || a.z ? a.x : p.fx, fz0 = a.x || a.z ? a.z : p.fz, dist0 = act === 'lob' ? 25 : act === 'through' ? 22 : 14; passTo(p, p.x + fx0 * dist0, p.z + fz0 * dist0, { lob: act === 'lob', through: act === 'through' }); } }
				else if (act === 'shoot') shoot(p, aimOf(t, a), a.power || .75, { curl: a.curl, chip: a.chip }); return; }
			if (act === 'pass' || act === 'switch') { var o0 = ball.owner; if (o0 && o0.team === t) return; var L = t.pl.filter(function (q) { return q !== p && q.role !== 'GK'; }).sort(function (q1, q2) { return len2(q1.x - ball.x, q1.z - ball.z) - len2(q2.x - ball.x, q2.z - ball.z); }); if (L[0]) selectPlayer(t, L[0]); }
			else if (act === 'shoot') { var dd = len2(p.x - ball.x, p.z - ball.z); if (ball.owner && ball.owner.team !== t) tackle(p, dd > 1.5); else if (!ball.owner && dd < 2.2 && ball.y < 1.4) { var gx = t.dir * HL; release(p); var dxs = gx - p.x, dzs = aimOf(t, a) - p.z, Ds = len2(dxs, dzs); ball.vx = dxs / Ds * 22; ball.vz = dzs / Ds * 22; ball.vy = 3; ball.shot = { p: p, t: M.t }; M.stats[t.k].sh++; AU.kick(.9); M.ev('shot', { p: p, D: Ds, volley: 1 }); } else tackle(p, true); }
			else if (act === 'tackle') tackle(p, false); }
		function aimOf(t, a) { var z = (a && a.z) || 0; return clamp(z * GW * .62, -GW / 2 + .35, GW / 2 - .35); }
		function pickTarget(p, a, through) { var t = p.team, ax = a && (a.x || a.z) ? a.x : (p.fx * .6 + t.dir * .4), az = a && (a.x || a.z) ? a.z : p.fz * .6, al = len2(ax, az) || 1; ax /= al; az /= al; var best = null, bs = -1e9;
			t.pl.forEach(function (q) { if (q === p) return; var dx = q.x - p.x, dz = q.z - p.z, D = len2(dx, dz); if (D < 3 || D > 60) return; var cos = (dx * ax + dz * az) / D; if (cos < .5) return; var lead = through ? 6 + q.pace * 5 : Math.min(2.5, D * .07), tx = q.x + (through ? t.dir * lead : q.vx * .35 * (D / 18)), tz = q.z + (through ? 0 : q.vz * .35 * (D / 18)); var s = cos * 3 - D * .03 - (q.role === 'GK' ? 2 : 0); if (s > bs) { bs = s; best = { q: q, x: tx, z: tz, D: D }; } }); return best; }
		/* ---- penalty shoot-out: five each, then sudden death ---- */
		function shootout() { M.so = { k: [[], []], turn: M.kickTeam ? M.kickTeam.k : 0, T: 0, wait: 0, done: false }; M.ev('shootout', {}); nextPen(); }
		function nextPen() { var S0 = M.so, t = TM[S0.turn]; ALL.forEach(function (q) { q.stun = q.slide = q.dive = q.diveT = 0; q.saving = null; }); S0.T = 0; setRestart('penalty', t, t.dir * (HL - 11), 0, 'shootout'); }
		function soRes(ok) { var S0 = M.so; if (S0.wait) return; S0.k[S0.turn].push(ok ? 1 : 0); M.ev('pen', { t: TM[S0.turn], ok: ok }); if (ok) AU.roar(); else AU.ooh(); S0.wait = 1.8; M.phase = 'sowait';
			var a = S0.k[0], b = S0.k[1], sa = a.reduce(function (x, y) { return x + y; }, 0), sb = b.reduce(function (x, y) { return x + y; }, 0), na = a.length, nb = b.length;
			if (na <= 5 && nb <= 5) { if (sa > sb + (5 - nb) || sb > sa + (5 - na)) S0.done = true; } else if (na === nb && sa !== sb) S0.done = true;
			S0.turn = 1 - S0.turn; }
		M.shootout = shootout; M.soRes = soRes; M.nextPen = nextPen; M.setRestart = setRestart;
		M.humanAct = humanAct; M.step = step; M.kickoff = kickoff; M.select = selectPlayer; M.all = ALL; M.takeRestart = takeRestart; M.pressure = pressure;
		TM.forEach(function (t) { kickoffPos(t, !t.k); }); kickoff(TM[0]); M.phT = 0; M.phase = 'kickoff';
		if (o.human === 'both') { TM[0].human = true; TM[1].human = true; }
		return M;
	}
	/* ---------------------------------------------------------------- commentary */
	var LINES = {
		goal: ['GOAAAL! {p} scores for {c}!', 'Bao! {p} buries it! {c} celebrate!', 'It\'s in! {p} with the finish! The stadium is shaking!', '{p}! What a goal! {c} have it!'],
		og: ['Oh no, an own goal! {p} turns it into his own net.'],
		save: ['Great save by {p}!', '{p} gets down well!', 'Denied by {p}!'], catch: ['{p} gathers it safely.', 'Comfortable for {p}.'],
		post: ['OFF THE POST!', 'It hits the woodwork!', 'The post saves them!'], bar: ['Off the crossbar!', 'Rattles the bar!'],
		shot: ['{p} shoots!', '{p} lets fly!', '{p} tries his luck…'], header: ['{p} rises… header!', 'Header from {p}!'],
		through: ['Lovely ball in behind from {p}!', '{p} threads it through!'], tackle: ['Strong challenge from {p}.', '{p} wins it back.', 'Good tackle by {p}.'],
		corner: ['Corner to {c}.'], offside: ['The flag is up. Offside.'], foul: ['Foul. Free kick to {c}.'], penalty: ['PENALTY to {c}!'], card: ['Yellow card for {p}.'], red: ['Second yellow… {p} has to go!'],
		half: ['Half-time.'], full: ['Full-time!'], kickoff: ['And we\'re under way!'] };
	var LINES_SW = {
		goal: ['GOOOLI! {p} anafunga kwa {c}!', 'Bao! Bao safi kutoka kwa {p}!', 'Ni bao! {p}! Uwanja mzima unatetemeka!', '{p}! Bao la kihistoria kwa {c}!'], og: ['Lo! Amejifunga mwenyewe, {p}.'],
		save: ['Ameokoa! {p}!', 'Kipa {p} yuko imara!', '{p} amezuia!'], catch: ['{p} ameudaka mpira.', 'Rahisi kwa {p}.'], post: ['Mlingoti umeokoa!', 'Imegonga mlingoti!'], bar: ['Imegonga mwamba!', 'Mwamba wa juu!'],
		shot: ['{p} anapiga shuti!', '{p} anajaribu bahati yake…'], header: ['{p} anaruka… kichwa!', 'Kichwa kutoka kwa {p}!'], through: ['Pasi murua kutoka kwa {p}!', '{p} anapenyeza pasi!'], tackle: ['Kukaba safi kutoka kwa {p}.', '{p} ameunyang\'anya mpira.'],
		corner: ['Kona kwa {c}.'], offside: ['Bendera juu. Ameotea.'], foul: ['Faulo. Mpira wa adhabu kwa {c}.'], penalty: ['PENALTI kwa {c}!'], card: ['Kadi ya njano kwa {p}.'], red: ['Kadi ya pili… {p} anatolewa nje!'], half: ['Mapumziko.'], full: ['Mchezo umekwisha!'], kickoff: ['Na mechi imeanza!'] };
	var LANG = 'en';
	function line(k, p, c) { var L = (LANG === 'sw' ? LINES_SW : LINES)[k]; if (!L) return ''; return L[Math.floor(Math.random() * L.length)].replace('{p}', p || '').replace('{c}', c || ''); }
	/* ---------------------------------------------------------------- the game shell */
	function ballTex() { var c = d.createElement('canvas'); c.width = 256; c.height = 128; var x = c.getContext('2d'); x.fillStyle = '#f4f4f4'; x.fillRect(0, 0, 256, 128); x.fillStyle = '#151515'; for (var i = 0; i < 10; i++) { var cx = (i % 5) * 52 + (i > 4 ? 26 : 0) + 10, cy = i > 4 ? 92 : 34; x.beginPath(); for (var k = 0; k < 5; k++) { var a = k / 5 * Math.PI * 2 - Math.PI / 2; x.lineTo(cx + Math.cos(a) * 13, cy + Math.sin(a) * 13); } x.fill(); } x.fillStyle = '#c8102e'; x.fillRect(0, 60, 256, 6); var t = new T.CanvasTexture(c); t.encoding = T.sRGBEncoding; return t; }
	function mount(sec, api) {
		api = api || {}; var champs = api.champs || [];
		sec.innerHTML = '<div class="fb" data-fb><canvas class="fb__cv"></canvas>'
			+ '<div class="fb__hud" hidden><div class="fb__score"><span class="fb__tm" data-fb-h></span><b data-fb-sc>0 – 0</b><span class="fb__tm" data-fb-a></span><em data-fb-clk>0\'</em></div><div class="fb__com" data-fb-com></div><div class="fb__me" data-fb-me></div><div class="fb__pow" data-fb-pow hidden><i></i></div><canvas class="fb__map" width="168" height="110" data-fb-map></canvas><div class="fb__bnr" data-fb-bnr hidden></div><button type="button" class="fb__pz" data-fb-pz aria-label="Pause">❚❚</button><div class="fb__rp" data-fb-rp hidden>REPLAY</div><div class="fb__hint" data-fb-hint hidden></div><div class="fb__lu" data-fb-lu hidden></div></div>'
			+ '<div class="fb__touch" data-fb-touch hidden><div class="fb__stick" data-fb-stick><i></i></div><div class="fb__btns"><button type="button" data-fb-b="sprint">Sprint</button><button type="button" data-fb-b="lob">Lob</button><button type="button" data-fb-b="through">Through</button><button type="button" data-fb-b="pass">Pass</button><button type="button" class="is-big" data-fb-b="shoot">Shoot</button></div></div>'
			+ '<div class="fb__rot"><b>↻</b><span>Turn your phone sideways to play</span></div><div class="fb__menu" data-fb-menu></div></div>';
		var root = sec.querySelector('[data-fb]'), cv = root.querySelector('canvas'), q = function (s) { return root.querySelector(s); }, menu = q('[data-fb-menu]'), hud = q('.fb__hud');
		var R = new T.WebGLRenderer({ canvas: cv, antialias: true, powerPreference: 'high-performance' }); R.outputEncoding = T.sRGBEncoding; R.toneMapping = T.ACESFilmicToneMapping; R.toneMappingExposure = 1.0; R.setPixelRatio(Math.min(w.devicePixelRatio || 1, 1.6));
		var S = new T.Scene(), C = new T.PerspectiveCamera(30, 2, .5, 900); S.background = new T.Color(0x0a0d14); S.fog = new T.Fog(0x0a0d14, 160, 420);
		var hemi = new T.HemisphereLight(0xdfe8ff, 0x1c2a1c, .75), key = new T.DirectionalLight(0xffffff, 1.0); key.position.set(-40, 90, 60); S.add(hemi); S.add(key); var fill = new T.DirectionalLight(0xcfe0ff, .45); fill.position.set(50, 70, -60); S.add(fill);
		var intro = 0, introSkip = false, st = null, M = null, cfg = null, ballM = null, pm = [], ring = null, ring2 = null, raf = 0, last = 0, acc = 0, paused = false, cam = { x: 0, z: 0, y: 0 }, rec = [], replay = null, CUP = null;
		function size() { var r = root.getBoundingClientRect(); R.setSize(r.width, r.height, false); C.aspect = r.width / Math.max(1, r.height); C.updateProjectionMatrix(); }
		w.addEventListener('resize', size);
		/* ---- input: keyboard, two game controllers, touch ---- */
		var keys = {}, inp = [{ x: 0, z: 0, sprint: false }, { x: 0, z: 0, sprint: false }], hold = [null, null], tch = { x: 0, z: 0, sprint: false, on: false };
		var K1 = { up: ['KeyW'], down: ['KeyS'], left: ['KeyA'], right: ['KeyD'], sprint: ['ShiftLeft'], pass: ['KeyJ', 'Space'], shoot: ['KeyK'], through: ['KeyL'], lob: ['KeyI'] }, K2 = { up: ['ArrowUp'], down: ['ArrowDown'], left: ['ArrowLeft'], right: ['ArrowRight'], sprint: ['ShiftRight', 'ControlRight'], pass: ['Period', 'Numpad1'], shoot: ['Slash', 'Numpad2'], through: ['Comma', 'Numpad3'], lob: ['Semicolon', 'Numpad5'] };
		function kmap(e) { var two = cfg && cfg.mode === '2p'; for (var s = 0; s < 2; s++) { var Km = s ? K2 : K1; for (var a in Km) if (Km[a].indexOf(e.code) >= 0) return { slot: two ? s : 0, a: a }; } return null; }
		function onKey(e, down) { if (!M || root.hidden || !root.isConnected) return; if (e.code === 'Escape' || e.code === 'KeyP') { if (down) togglePause(); e.preventDefault(); return; } var k = kmap(e); if (!k) return; e.preventDefault(); keys[e.code] = down; if (k.a === 'pass' || k.a === 'shoot' || k.a === 'through' || k.a === 'lob') { if (down && !e.repeat) press(k.slot, k.a); else if (!down) rel(k.slot, k.a); } }
		var kd = function (e) { onKey(e, true); }, ku = function (e) { onKey(e, false); }; d.addEventListener('keydown', kd); d.addEventListener('keyup', ku);
		function press(slot, a) { if (paused || replay) return; AU.init(); if (a === 'shoot') { hold[slot] = { a: a, t: 0 }; return; } act(slot, a, .6); }
		function rel(slot, a) { if (a === 'shoot' && hold[slot]) { var pw = clamp(.25 + hold[slot].t / .9, .25, 1); hold[slot] = null; act(slot, 'shoot', pw); } }
		function teamOf(slot) { if (!M) return null; if (cfg.mode === '2p') return M.teams[slot]; return M.teams[cfg.side]; }
		function act(slot, a, pw) { var t = teamOf(slot); if (!t || !t.human) return; var I = inp[slot]; var ax = I.x, az = I.z; M.humanAct(t, a, { x: ax, z: az, power: pw, curl: Math.abs(az) > .55 ? Math.sign(az) * t.dir * .35 : 0, chip: a === 'shoot' && I.sprint === false && hold.chip }); }
		function readInputs(dt) { var gps = []; try { gps = [].filter.call(navigator.getGamepads ? navigator.getGamepads() : [], function (g) { return g; }); } catch (e) {}
			for (var s = 0; s < 2; s++) { var Km = s ? K2 : K1, two = cfg.mode === '2p', I = inp[s], x = 0, z = 0, spr = false;
				if (!two || s === 0) { var useK = two ? K1 : null; ['up', 'down', 'left', 'right', 'sprint'].forEach(function (a) { var on2 = (useK || K1)[a].some(function (c) { return keys[c]; }) || (!two && K2[a].some(function (c) { return keys[c]; })); if (!on2) return; if (a === 'up') z -= 1; else if (a === 'down') z += 1; else if (a === 'left') x -= 1; else if (a === 'right') x += 1; else spr = true; }); }
				if (two && s === 1) ['up', 'down', 'left', 'right', 'sprint'].forEach(function (a) { if (!K2[a].some(function (c) { return keys[c]; })) return; if (a === 'up') z -= 1; else if (a === 'down') z += 1; else if (a === 'left') x -= 1; else if (a === 'right') x += 1; else spr = true; });
				var gp = two ? gps[s] : gps[0]; if (gp) { var gx = gp.axes[0] || 0, gz = gp.axes[1] || 0; if (Math.abs(gx) > .18 || Math.abs(gz) > .18) { x = gx; z = gz; } var B = function (k) { return !!(gp.buttons[k] && gp.buttons[k].pressed); }; if (B(12)) z = -1; if (B(13)) z = 1; if (B(14)) x = -1; if (B(15)) x = 1; if (B(7) || B(5)) spr = true;
					var pv = gp.__pv || (gp.__pv = {}), map = { 0: 'pass', 1: 'shoot', 3: 'through', 2: 'lob', 4: 'switch' }; I.__pv = I.__pv || {}; for (var bk in map) { var now = B(+bk); if (now && !I.__pv[bk]) press(s, map[bk] === 'switch' ? 'pass' : map[bk]); if (!now && I.__pv[bk]) rel(s, map[bk]); I.__pv[bk] = now; } if (B(9) && !I.__pv.st) togglePause(); I.__pv.st = B(9); }
				var ph0 = api.pad && api.pad.read(two ? s : 0); if (ph0 && (two || s === 0)) { if (Math.abs(ph0.s) + Math.abs(ph0.t) > .15) { x = ph0.s; z = ph0.t; } if (ph0.h) spr = true; var bits = ph0.b | 0, pb0 = I.__pb | 0, BM = { 1: 'pass', 2: 'shoot', 4: 'through', 8: 'lob' }; for (var bb in BM) { var nowB = bits & +bb, wasB = pb0 & +bb; if (nowB && !wasB) press(s, BM[bb]); if (!nowB && wasB) rel(s, BM[bb]); } if ((bits & 16) && !(pb0 & 16)) togglePause(); I.__pb = bits; }
				if (s === 0 && tch.on) { if (Math.abs(tch.x) + Math.abs(tch.z) > .1) { x = tch.x; z = tch.z; } spr = spr || tch.sprint; }
				var l = len2(x, z); if (l > 1) { x /= l; z /= l; } I.x = x; I.z = z; I.sprint = spr; if (hold[s]) hold[s].t += dt; }
			var pw = hold[0] || hold[1]; var pe = q('[data-fb-pow]'); pe.hidden = !pw; if (pw) pe.firstChild.style.width = clamp((.25 + pw.t / .9) * 100, 0, 100) + '%'; }
		/* touch: a stick on the left, buttons on the right */
		(function () { var tz = q('[data-fb-touch]'), stick = q('[data-fb-stick]'), nub = stick.firstChild, id = null, c0 = null;
			if ('ontouchstart' in w || navigator.maxTouchPoints > 0) { tz.hidden = false; root.classList.add('is-touch'); }
			stick.addEventListener('pointerdown', function (e) { id = e.pointerId; var r = stick.getBoundingClientRect(); c0 = { x: r.left + r.width / 2, y: r.top + r.height / 2, r: r.width / 2 }; stick.setPointerCapture(id); tch.on = true; mv(e); });
			function mv(e) { if (e.pointerId !== id) return; var dx = (e.clientX - c0.x) / c0.r, dy = (e.clientY - c0.y) / c0.r, l = len2(dx, dy); if (l > 1) { dx /= l; dy /= l; } tch.x = dx; tch.z = dy; nub.style.transform = 'translate(' + dx * 34 + 'px,' + dy * 34 + 'px)'; }
			stick.addEventListener('pointermove', mv); ['pointerup', 'pointercancel'].forEach(function (ev) { stick.addEventListener(ev, function (e) { if (e.pointerId !== id) return; id = null; tch.x = tch.z = 0; nub.style.transform = ''; }); });
			[].forEach.call(root.querySelectorAll('[data-fb-b]'), function (b) { var a = b.getAttribute('data-fb-b'); b.addEventListener('pointerdown', function (e) { e.preventDefault(); tch.on = true; if (a === 'sprint') tch.sprint = true; else press(0, a); b.classList.add('is-on'); }); ['pointerup', 'pointercancel', 'pointerleave'].forEach(function (ev) { b.addEventListener(ev, function () { if (!b.classList.contains('is-on')) return; b.classList.remove('is-on'); if (a === 'sprint') tch.sprint = false; else rel(0, a); }); }); }); })();
		/* ---- a match: build the stadium in the clubs' colours, the players, the ball ---- */
		function kitFor(club, alt) { var k = alt ? club.alt : club.kit; return { shirt: k[0], shorts: k[1], socks: k[2], gk: club.gk }; }
		function clash(a, b) { var A = new T.Color(a), B = new T.Color(b); return Math.abs(A.r - B.r) + Math.abs(A.g - B.g) + Math.abs(A.b - B.b) < .55; }
		function start(c) { cfg = c; stop(); AU.init(); AU.resume();
			var home = CLUBS.filter(function (x) { return x.id === c.home; })[0], away = CLUBS.filter(function (x) { return x.id === c.away; })[0], hk = kitFor(home), ak = kitFor(away, clash(home.kit[0], away.kit[0]));
			if (st) { S.remove(st.grp); st.grp.traverse(function (o) { if (o.geometry) o.geometry.dispose(); if (o.material && o.material.map) o.material.map.dispose(); }); }
			st = buildStadium(S, { home: home, away: away, boards: (api.boards || []).concat(champs.slice(0, 3).map(function (x) { return 'LAQIM CUP CHAMPION · ' + String(x.n).toUpperCase(); })) });
			pm.forEach(function (m) { S.remove(m); }); pm = [];
			M = Match({ home: home, away: away, homeKit: hk, awayKit: ak, human: c.mode === '2p' ? 'both' : c.mode === 'cpu' ? null : (c.side ? 'away' : 'home'), diff: c.diff, halfSec: c.half * 60, onEvent: onEv });
			var day = c.tod === 'day'; S.background.set(day ? 0x8fbfe6 : 0x0a0d14); S.fog.color.set(day ? 0x9cc7ea : 0x0a0d14); hemi.intensity = day ? 1.0 : .75; key.intensity = day ? 1.35 : 1.0; key.color.set(day ? 0xfff1dc : 0xffffff); R.toneMappingExposure = day ? .95 : 1.0;
			M.all.forEach(function (p) { var m = makePlayer(p.team.kit, p.role === 'GK', p.v, p.num); S.add(m); pm.push(m); p.mesh = m; });
			if (!ballM) { ballM = new T.Mesh(new T.SphereGeometry(BR, 18, 12), new T.MeshStandardMaterial({ map: ballTex(), roughness: .45 })); var bs = new T.Mesh(new T.CircleGeometry(.16, 12), new T.MeshBasicMaterial({ color: 0, transparent: true, opacity: .4, depthWrite: false })); bs.rotation.x = -Math.PI / 2; ballM.userData.sh = bs; S.add(bs); }
			if (!st.trail) { var tg = new T.BufferGeometry(); tg.setAttribute('position', new T.Float32BufferAttribute(new Float32Array(16 * 3), 3)); st.trail = new T.Line(tg, new T.LineBasicMaterial({ color: 0xffffff, transparent: true, opacity: .5 })); st.trail.frustumCulled = false; st.grp.add(st.trail); st.trailP = []; }
			S.add(ballM); var rg = function (col) { var r0 = new T.Mesh(geos().ring, new T.MeshBasicMaterial({ color: col, transparent: true, opacity: .9, depthWrite: false })); r0.rotation.x = -Math.PI / 2; S.add(r0); return r0; };
			if (!ring) { ring = rg(0xffd54a); ring2 = rg(0x4fc3f7); }
			q('[data-fb-h]').textContent = home.s; q('[data-fb-a]').textContent = away.s; q('[data-fb-h]').style.background = hk.shirt; q('[data-fb-a]').style.background = ak.shirt; q('[data-fb-h]').style.color = readable(hk.shirt); q('[data-fb-a]').style.color = readable(ak.shirt);
			menu.hidden = true; hud.hidden = false; rec = []; replay = null; paused = false; cam.x = 0; size(); intro = c.pens ? 0 : 4.5; if (!intro) com(line('kickoff')); M.hold = false; var lu = q('[data-fb-lu]'); if (intro) { lu.innerHTML = '<small>' + esc(c.cupRound || (c.mode === '2p' ? 'Two players' : 'Friendly')) + ' · Laqim Arena, Nairobi · ' + (c.tod === 'day' ? 'Afternoon' : 'Floodlights') + '</small><div>' + M.teams.map(function (t) { return '<section><header>' + crest(t.club) + '<b>' + esc(t.club.n) + '</b><em>' + (t.club.form === '433' ? '4-3-3' : '4-4-2') + '</em></header><ol>' + t.pl.map(function (p) { return '<li><i>' + p.num + '</i>' + esc(p.name) + '<u>' + p.role + '</u></li>'; }).join('') + '</ol></section>'; }).join('<b class="fb__luv">v</b>') + '</div>'; lu.hidden = false; } else lu.hidden = true;
			last = performance.now(); acc = 0; raf = requestAnimationFrame(loop); if (api.onStart) api.onStart(); }
		function readable(hx) { var c0 = new T.Color(hx); return c0.r * .3 + c0.g * .59 + c0.b * .11 > .55 ? '#111' : '#fff'; }
		function stop() { cancelAnimationFrame(raf); raf = 0; }
		/* ---- events → commentary, banners, the crowd, the replay ---- */
		var comT = 0;
		function say(t) { if (!PREF.voice || !w.speechSynthesis || !AU.on) return; try { var u = new SpeechSynthesisUtterance(t.replace(/!+/g, '!')); u.rate = 1.12; u.pitch = 1.05; var vs = speechSynthesis.getVoices(), v0 = LANG === 'sw' ? vs.filter(function (x) { return /^sw/i.test(x.lang); })[0] : (vs.filter(function (x) { return /en-KE/i.test(x.lang); })[0] || vs.filter(function (x) { return /en-GB/i.test(x.lang); })[0]); if (LANG === 'sw' && !v0) return; if (v0) u.voice = v0; speechSynthesis.cancel(); speechSynthesis.speak(u); } catch (e) {} }
		function com(t, loud) { if (!t) return; if (loud) say(t); var e = q('[data-fb-com]'); e.textContent = t; e.classList.remove('is-in'); void e.offsetWidth; e.classList.add('is-in'); comT = 4; }
		function banner(t, sub, ms) { var b = q('[data-fb-bnr]'); b.innerHTML = '<b>' + esc(t) + '</b>' + (sub ? '<span>' + esc(sub) + '</span>' : ''); b.hidden = false; b.classList.remove('is-in'); void b.offsetWidth; b.classList.add('is-in'); clearTimeout(b._t); b._t = setTimeout(function () { b.hidden = true; }, ms || 2000); }
		function onEv(k, e) { var nm = e.p ? e.p.sh : '', cl = e.t ? e.t.club.n : e.p ? e.p.team.club.n : '';
			if (k === 'goal') { com(line(e.og ? 'og' : 'goal', e.og ? (M.ball.last && M.ball.last.sh) : nm, e.t.club.n), true); banner(LANG === 'sw' ? 'BAO!' : 'GOAL', (e.p && !e.og ? e.p.name : e.t.club.n) + ' · ' + e.min + '\'', 2600); M.hold = true; setTimeout(function () { startReplay(); }, 1900); celebrate(e.t.k); vib(200); }
			else if (k === 'save') com(line(e.catch ? 'catch' : 'save', nm), !e.catch); else if (k === 'post') com(line(e.bar ? 'bar' : 'post'), true); else if (k === 'shot') { if (Math.random() < .8) com(line('shot', nm)); } else if (k === 'header') com(line('header', nm));
			else if (k === 'pass' && e.through) com(line('through', nm)); else if (k === 'tackle' && Math.random() < .5) com(line('tackle', nm));
			else if (k === 'restart') { if (e.kind === 'corner') com(line('corner', '', cl)); else if (e.why === 'offside') { com(line('offside')); banner('Offside', e.on ? e.on.name : '', 1400); } else if (e.kind === 'penalty' && e.why !== 'shootout') { com(line('penalty', '', cl)); banner('Penalty!', cl, 1800); } else if (e.kind === 'freekick') com(line('foul', '', cl)); }
			else if (k === 'card') { com(line(e.red ? 'red' : 'card', nm)); banner(e.red ? 'Red card' : 'Yellow card', e.p.name, 1600); }
			else if (k === 'half') { com(line('half')); banner('Half-time', M.teams[0].club.s + ' ' + M.teams[0].score + ' – ' + M.teams[1].score + ' ' + M.teams[1].club.s, 2800); }
			else if (k === 'full') { com(line('full')); setTimeout(fullTime, 1600); }
			else if (k === 'shootout') banner('Penalties', 'Five each, then sudden death', 2400);
			else if (k === 'pen') banner(e.ok ? 'Scored' : 'Missed', soLine(), 1500);
			else if (k === 'switch') vib(15); }
		function soLine() { var so = M.so; return so ? M.teams[0].club.s + ' ' + so.k[0].map(function (x) { return x ? '●' : '○'; }).join('') + '  ·  ' + so.k[1].map(function (x) { return x ? '●' : '○'; }).join('') + ' ' + M.teams[1].club.s : ''; }
		function vib(ms) { try { if (navigator.vibrate) navigator.vibrate(ms); } catch (e) {} }
		var cele = 0, celeSide = 0; function celebrate(k) { cele = 4; celeSide = k; }
		/* ---- replay: the last six seconds from a low angle behind the goal ---- */
		function snap() { var f = new Float32Array(3 + M.roster.length * 4); f[0] = M.ball.x; f[1] = M.ball.y; f[2] = M.ball.z; M.roster.forEach(function (p, i) { f[3 + i * 4] = p.x; f[4 + i * 4] = p.z; f[5 + i * 4] = Math.atan2(p.fx, p.fz); f[6 + i * 4] = len2(p.vx, p.vz); }); rec.push(f); if (rec.length > 400) rec.shift(); }
		function startReplay() { if (!M || rec.length < 30) { M.hold = false; return; } replay = { f: rec.slice(-330), i: 0, side: Math.sign(rec[rec.length - 1][0]) || 1 }; var sc0 = M.scorers[M.scorers.length - 1]; (M.reels = M.reels || []).push({ f: replay.f, side: replay.side, txt: sc0 ? sc0.n + ' ' + sc0.m + '\'' : 'Goal' }); q('[data-fb-rp]').textContent = 'REPLAY'; q('[data-fb-rp]').hidden = false; }
		function endReplay() { var rq = replay && replay.queue; replay = null; q('[data-fb-rp]').hidden = true; if (rq) { if (rq.length) return playReel(rq); menu.hidden = false; hud.hidden = true; return; } if (M) M.hold = false; }
		function playReel(L) { var r0 = L.shift(); menu.hidden = true; hud.hidden = false; replay = { f: r0.f, i: 0, side: r0.side, queue: L }; var tag = q('[data-fb-rp]'); tag.textContent = 'GOAL · ' + r0.txt; tag.hidden = false; }
		/* ---- the frame ---- */
		var mapT = 0, ph = 0;
		var padT = 0; function padLayout(on) { if (!api.pad) return; for (var i = 0; i < 4; i++) api.pad.send(i, { fb: on ? 1 : 0, pz: 0 }); }
		function loop(now) { raf = requestAnimationFrame(loop); var dt = Math.min(.05, (now - last) / 1000); last = now; if (!M) return; padT -= dt; if (padT <= 0) { padT = 2; padLayout(true); }
			if (intro > 0) { intro -= dt; readInputs(dt); if (intro <= 0 || inp[0].x || inp[0].z || hold[0] || hold[1] || introSkip) { introSkip = false; intro = 0; q('[data-fb-lu]').hidden = true; com(line('kickoff')); M.phT = 0; } }
			if (!paused && !replay && intro <= 0) { readInputs(dt); acc += dt; var n = 0; while (acc >= DT && n < 4) { M.step(DT, inp); acc -= DT; n++; snap(); } }
			if (replay) { replay.i += dt * 60 * .55; var fi = Math.floor(replay.i); if (fi >= replay.f.length - 1) endReplay(); else drawFrame(replay.f[fi], dt); }
			else drawLive(dt);
			comT -= dt; if (comT < 0) q('[data-fb-com]').classList.remove('is-in');
			if (cele > 0) { cele -= dt; ph += dt * 14; jumpCrowd(dt); st.jumped = true; } else if (st && st.jumped) { st.jumped = false; var M4b = st.M4; st.seats.forEach(function (s0, i) { M4b.makeRotationY(s0.ry || 0); M4b.setPosition(s0.wx, s0.wy, s0.wz); st.crowd.setMatrixAt(i, M4b); }); st.crowd.instanceMatrix.needsUpdate = true; }
			hudTick(dt); R.render(S, C); }
		var jumpI = 0; function jumpCrowd() { var b = st.crowd, sts = st.seats, M4 = st.M4; for (var k = 0; k < 500; k++) { jumpI = (jumpI + 1) % sts.length; var s = sts[jumpI], y = s.wy + (cele > 0 ? Math.abs(Math.sin(ph + s.ph)) * .35 : 0); M4.makeRotationY(s.ry || 0); M4.setPosition(s.wx, y, s.wz); b.setMatrixAt(jumpI, M4); } b.instanceMatrix.needsUpdate = true; }
		function place(p, x, z, yaw, sp, dt) { var m = p.mesh, u = m.userData; m.position.set(x, 0, z); m.rotation.y = yaw; p.anim = (p.anim || 0) + dt * (2.2 + sp * 1.25); var sw = Math.min(1, sp / 7) * .95, s0 = Math.sin(p.anim);
			u.lL.rotation.x = s0 * sw; u.lR.rotation.x = -s0 * sw; u.aL.rotation.x = -s0 * sw * .8; u.aR.rotation.x = s0 * sw * .8; u.body.position.y = Math.abs(Math.cos(p.anim)) * .05 * sw; u.body.rotation.x = sp > 6 ? .14 : sp * .02;
			if (p.kick > 0) { var k = 1 - p.kick / .3; u.lR.rotation.x = -1.4 + k * 2.4; }
			if (p.slide > 0) { u.body.rotation.x = -1.15; u.body.position.y = -.55; u.lR.rotation.x = -1.4; u.lL.rotation.x = -.9; } else if (p.role === 'GK' && p.diveT > .3 && p.dive) { u.body.rotation.z = -p.dive * Math.min(1.35, (.9 - p.diveT) * 4) * Math.sign(Math.cos(yaw) || 1); u.body.position.y = .25; u.aL.rotation.z = u.aR.rotation.z = 0; u.aL.rotation.x = u.aR.rotation.x = -2.8; } else { u.body.rotation.z = 0; }
			if (p.wall > 0 && M.phase === 'play') { u.body.position.y = Math.max(0, Math.sin((1 - p.wall) * 6)) * .45; u.aL.rotation.x = u.aR.rotation.x = -.3; }
			if (M.restart && M.restart.taker === p && M.restart.kind === 'throw') { u.aL.rotation.x = u.aR.rotation.x = -2.9; }
			if (p.role === 'GK' && M.ball.owner === p && p.hold > 0) { u.aL.rotation.x = u.aR.rotation.x = -1.3; }
			if (p.cool > .2 && M.ball.last === p && M.ball.y > 1.2) { u.body.position.y = .3; u.body.rotation.x = .3; }
			if (M.phase === 'goal' && cele > 0 && p.team.k === celeSide) { u.aL.rotation.x = u.aR.rotation.x = -2.9; u.body.position.y = Math.abs(Math.sin(ph * .5 + p.i)) * .3; } }
		function drawLive(dt) { var b = M.ball;
			M.all.forEach(function (p) { place(p, p.x, p.z, Math.atan2(p.fx, p.fz), len2(p.vx, p.vz), dt); });
			var tr = st.trail, tp = st.trailP, fast = len2(b.vx, b.vz) > 17 && !b.owner; if (fast) { tp.push(b.x, b.y, b.z); if (tp.length > 48) tp.splice(0, 3); } else if (tp.length) tp.splice(0, 6); tr.visible = tp.length > 6; if (tr.visible) { var pa = tr.geometry.attributes.position.array; for (var ti = 0; ti < 16; ti++) { var si2 = Math.min(tp.length / 3 - 1, ti); pa[ti * 3] = tp[si2 * 3]; pa[ti * 3 + 1] = tp[si2 * 3 + 1]; pa[ti * 3 + 2] = tp[si2 * 3 + 2]; } tr.geometry.attributes.position.needsUpdate = true; tr.geometry.setDrawRange(0, Math.min(16, tp.length / 3)); }
			ballM.position.set(b.x, b.y, b.z); var bs = len2(b.vx, b.vz); if (bs > .05) { ballM.rotation.z -= b.vx * dt / BR * .5; ballM.rotation.x += b.vz * dt / BR * .5; } ballM.userData.sh.position.set(b.x, .02, b.z); ballM.userData.sh.scale.setScalar(clamp(1 - b.y * .08, .4, 1));
			var t0 = cfg.mode === '2p' ? M.teams[0] : M.teams[cfg.side], c1 = t0 && t0.human ? t0.ctrl : null, c2 = cfg.mode === '2p' ? M.teams[1].ctrl : null;
			ring.visible = !!c1; if (c1) ring.position.set(c1.x, .03, c1.z); ring2.visible = !!c2; if (c2) ring2.position.set(c2.x, .03, c2.z);
			/* broadcast camera: high on the halfway side, panning with play, leaning in near goal */
			var tx = clamp(b.x * .95, -HL + 13, HL - 13), tz = clamp(b.z * .35, -10, 12), zoom = 1 - Math.min(.22, Math.max(0, Math.abs(b.x) - 30) / 90); if (M.restart && M.restart.kind === 'penalty') { tx = M.restart.t.dir * (HL - 9); zoom = .62; } else if (M.restart && M.restart.kind === 'corner') { tx = Math.sign(M.restart.x) * (HL - 17); tz = M.restart.z * .3; zoom = 1.15; }
			var k = 1 - Math.exp(-3 * dt); cam.x += (tx - cam.x) * k; cam.z += (tz - cam.z) * k; cam.y += (zoom - (cam.y || zoom)) * k;
			if (intro > 0) { var an = (4.5 - intro) * .35 - 1.2; C.position.set(Math.sin(an) * 70, 22 + intro * 3, Math.cos(an) * 70); C.lookAt(0, 0, 0); return; } var zm = cam.y || zoom; C.position.set(cam.x * .92, 27 * zm + 3, 50 * zm + cam.z * .4 + 4); C.lookAt(cam.x, 0, cam.z - 1.5); ring.material.opacity = .7 + Math.sin(performance.now() / 140) * .2; }
		function drawFrame(f, dt) { var side = replay.side; ballM.position.set(f[0], f[1], f[2]); ballM.userData.sh.position.set(f[0], .02, f[2]); M.roster.forEach(function (p, i) { if (p.sent) return; place(p, f[3 + i * 4], f[4 + i * 4], f[5 + i * 4], f[6 + i * 4], dt); }); ring.visible = ring2.visible = false;
			C.position.set(side * (HL + 9), 4.2, f[2] * .3 + 7); C.lookAt(f[0] * .6 + side * HL * .4, 1.2, f[2] * .7); }
		/* ---- HUD ---- */
		function hudTick(dt) { hint(); root.classList.toggle('is-play', menu.hidden); var t0 = M.teams[0], t1 = M.teams[1], mins = Math.min(45, Math.floor(M.clock / M.halfSec * 45)) + (M.half - 1) * 45; q('[data-fb-sc]').textContent = t0.score + ' – ' + t1.score; q('[data-fb-clk]').textContent = M.so ? 'PENS' : M.phase === 'half' ? 'HT' : M.phase === 'full' ? 'FT' : mins + '\'';
			var me = cfg.mode === 'cpu' ? null : (cfg.mode === '2p' ? t0 : M.teams[cfg.side]).ctrl; q('[data-fb-me]').innerHTML = me ? '<b>' + me.num + '</b> ' + esc(me.name) + '<i><s style="width:' + Math.round(me.stam * 100) + '%"></s></i>' : '';
			mapT -= dt; if (mapT <= 0) { mapT = .1; var cx = q('[data-fb-map]').getContext('2d'), W2 = 168, H2 = 110; cx.clearRect(0, 0, W2, H2); cx.fillStyle = 'rgba(20,60,28,.75)'; cx.fillRect(0, 0, W2, H2); cx.strokeStyle = 'rgba(255,255,255,.5)'; cx.lineWidth = 1; cx.strokeRect(4, 4, W2 - 8, H2 - 8); cx.beginPath(); cx.moveTo(W2 / 2, 4); cx.lineTo(W2 / 2, H2 - 4); cx.stroke();
				var mx = function (x) { return 4 + (x + HL) / PL * (W2 - 8); }, mz = function (z) { return 4 + (z + HW) / PW * (H2 - 8); };
				M.all.forEach(function (p) { cx.fillStyle = p.team.kit.shirt; cx.beginPath(); cx.arc(mx(p.x), mz(p.z), p === me ? 4 : 2.6, 0, 7); cx.fill(); if (p === me) { cx.strokeStyle = '#ffd54a'; cx.lineWidth = 1.5; cx.stroke(); } }); cx.fillStyle = '#fff'; cx.beginPath(); cx.arc(mx(M.ball.x), mz(M.ball.z), 2.4, 0, 7); cx.fill(); } }
		var hintK = '';
		function hint() { var e = q('[data-fb-hint]'), k = ''; if (M && cfg.mode !== 'cpu') { var R = M.restart, t = R && R.t; if (M.phase === 'restart' && t && t.human) k = R.kind; else if (M.phase === 'play' && M.ball.owner && M.ball.owner.team.human && M.clock < 4 && M.half === 1 && M.ball.owner.role === 'ST' && Math.abs(M.ball.x) < 1) k = 'kickoff'; }
			if (k === hintK) return; hintK = k; var T0 = { kickoff: 'Kick-off: <b>Pass</b> to start', throw: 'Throw-in: aim and <b>Pass</b>', corner: 'Corner: <b>Lob</b> to cross · <b>Pass</b> short', goalkick: 'Goal kick: <b>Lob</b> long · <b>Pass</b> short', freekick: 'Free kick: <b>Pass</b> · <b>Lob</b> · hold <b>Shoot</b>', penalty: 'Penalty: aim, then hold and release <b>Shoot</b>' }[k]; e.hidden = !T0; if (T0) e.innerHTML = T0; }
		function togglePause() { if (!M || M.phase === 'full') return; paused = !paused; if (paused) { AU.stop(); showMenu('pause'); } else { AU.resume(); menu.hidden = true; last = performance.now(); } }
		q('[data-fb-pz]').addEventListener('click', togglePause);
		q('[data-fb-lu]').addEventListener('click', function () { introSkip = true; }); root.addEventListener('keydown', function () { if (intro > 0) introSkip = true; });
		d.addEventListener('visibilitychange', function () { if (d.hidden && M && !paused && !menu.hidden === false && M.phase !== 'full' && raf) togglePause(); });
		/* ---- menus ---- */
		var PREF = (function () { try { return JSON.parse(localStorage.getItem('psr-fb') || 'null') || {}; } catch (e) { return {}; } })(); PREF.club = PREF.club || 'ncl'; PREF.opp = PREF.opp || 'mdh'; PREF.diff = PREF.diff == null ? 1 : PREF.diff; PREF.half = PREF.half || 3; PREF.tod = PREF.tod || 'night'; PREF.lang = PREF.lang || 'en'; LANG = PREF.lang; PREF.voice = PREF.voice == null ? 1 : PREF.voice;
		function savePref() { try { localStorage.setItem('psr-fb', JSON.stringify(PREF)); } catch (e) {} }
		function club(id) { return CLUBS.filter(function (x) { return x.id === id; })[0] || CLUBS[0]; }
		function ovr(c) { var s = c.st; return Math.round((s.pace + s.pass + s.shoot + s.tack + s.gk) / 5 * 100); }
		function crest(c, big) { return '<i class="fb__crest' + (big ? ' fb__crest--big' : '') + '" style="--a:' + c.kit[0] + ';--b:' + c.kit[1] + ';--c:' + c.kit[2] + '"><b>' + c.s + '</b></i>'; }
		function clubPick(key, label) { var c = club(PREF[key]); return '<div class="fb__pick"><small>' + label + '</small><div class="fb__pk"><button type="button" data-fb-cyc="' + key + '" data-d="-1" aria-label="Previous club">‹</button><div class="fb__pc">' + crest(c, true) + '<b>' + esc(c.n) + '</b><span>Overall ' + ovr(c) + ' · ' + (c.form === '433' ? '4-3-3' : '4-4-2') + ' · ' + { press: 'high press', wing: 'wing play', pass: 'passing', direct: 'direct', counter: 'counter-attack', block: 'low block' }[c.style] + '</span><em>' + ['pace', 'pass', 'shoot', 'tack', 'gk'].map(function (k) { var v0 = Math.round(c.st[k] * 100); return '<s><u>' + { pace: 'Pace', pass: 'Passing', shoot: 'Shooting', tack: 'Defending', gk: 'Keeper' }[k] + '</u><i><b style="width:' + Math.max(4, (v0 - 60) / 35 * 100) + '%"></b></i><em>' + v0 + '</em></s>'; }).join('') + '</em></div><button type="button" data-fb-cyc="' + key + '" data-d="1" aria-label="Next club">›</button></div></div>'; }
		function opts() { return '<div class="fb__opts"><div><small>Kick-off</small>' + [['night', 'Floodlights'], ['day', 'Afternoon']].map(function (o) { return '<button type="button" data-fb-tod="' + o[0] + '" class="' + (PREF.tod === o[0] ? 'is-on' : '') + '">' + o[1] + '</button>'; }).join('') + '</div><div><small>Commentary</small>' + [['en', 'English'], ['sw', 'Kiswahili']].map(function (o) { return '<button type="button" data-fb-lang="' + o[0] + '" class="' + (PREF.lang === o[0] ? 'is-on' : '') + '">' + o[1] + '</button>'; }).join('') + '</div><div><small>Difficulty</small>' + ['Amateur', 'Professional', 'Legend'].map(function (n, i) { return '<button type="button" data-fb-diff="' + i + '" class="' + (PREF.diff === i ? 'is-on' : '') + '">' + n + '</button>'; }).join('') + '</div><div><small>Half length</small>' + [2, 3, 5].map(function (n) { return '<button type="button" data-fb-half="' + n + '" class="' + (PREF.half === n ? 'is-on' : '') + '">' + n + ' min</button>'; }).join('') + '</div></div>'; }
		function hall() { return '<div class="fb__hall"><h3>Hall of Champions</h3>' + (champs.length ? '<ol>' + champs.slice(0, 8).map(function (c) { return '<li><b>' + esc(c.n) + '</b><span>' + esc(c.club || '') + (c.d ? ' · ' + esc(c.d) : '') + '</span></li>'; }).join('') + '</ol>' : '<p>Nobody has lifted the Laqim Cup yet. Win it and your name goes up here and on the billboards in Laqim Racing.</p>') + '</div>'; }
		function showMenu(v, data) { menu.hidden = false; var h = '';
			if (v === 'home') { hud.hidden = true; h = '<div class="fb__title"><small>Laqim</small><h2>Football</h2><p>Eleven-a-side with real ball physics, formations that move together, offside, set pieces and goalkeepers who read the shot.</p></div><div class="fb__modes">'
				+ [['quick', 'Quick match', 'Pick two clubs and kick off.'], ['cup', 'Laqim Cup', 'Three knockout rounds. Win it and you are featured in Laqim Racing.'], ['2p', 'Two players', 'Same screen: keyboard and controller, or two controllers.'], ['pens', 'Penalties', 'Straight to a shoot-out.']].map(function (m) { return '<button type="button" class="fb__mode" data-fb-mode="' + m[0] + '"><b>' + m[1] + '</b><span>' + m[2] + '</span></button>'; }).join('') + '</div><div class="fb__foot">' + hall() + '<div class="fb__keys"><h3>Controls</h3><p><b>Move</b> WASD or arrows · stick</p><p><b>Pass / switch</b> J or Space · A</p><p><b>Shoot / tackle</b> hold K · B</p><p><b>Through ball</b> L · Y &nbsp; <b>Lob / cross</b> I · X</p><p><b>Sprint</b> Shift · RT &nbsp; <b>Pause</b> Esc · Start</p></div></div>' + (api.onExit ? '<button type="button" class="fb__x" data-fb-exit>← Laqim Play</button>' : '') + (api.pad ? '<button type="button" class="fb__phone" data-fb-phone>📱 Use a phone as the controller</button>' : ''); }
			else if (v === 'setup') { var m = data; h = '<button type="button" class="fb__x" data-fb-back>← Back</button><div class="fb__title fb__title--s"><small>' + { quick: 'Quick match', cup: 'Laqim Cup', '2p': 'Two players', pens: 'Penalties' }[m] + '</small><h2>' + (m === 'cup' ? 'Choose your club' : 'Choose the clubs') + '</h2></div><div class="fb__picks">' + clubPick('club', m === '2p' ? 'Player 1' : 'Your club') + (m !== 'cup' ? '<b class="fb__vs">v</b>' + clubPick('opp', m === '2p' ? 'Player 2' : 'Opponent') : '') + '</div>' + (m === 'pens' ? '' : opts()) + '<button type="button" class="fb__go" data-fb-start="' + m + '">' + (m === 'cup' ? 'Enter the Laqim Cup' : 'Kick off') + '</button>' + (m === '2p' ? '<p class="fb__note">Player 1: WASD, Shift, J K L I or controller 1. Player 2: arrows, right Shift, . / , ; or controller 2.</p>' : ''); }
			else if (v === 'pause') h = '<div class="fb__title fb__title--s"><small>' + esc(M.teams[0].club.s + ' ' + M.teams[0].score + ' – ' + M.teams[1].score + ' ' + M.teams[1].club.s) + '</small><h2>Paused</h2></div><div class="fb__col"><button type="button" class="fb__go" data-fb-resume>Resume</button><button type="button" data-fb-restart>Restart the match</button><button type="button" data-fb-sound>Sound: ' + (AU.on ? 'on' : 'off') + '</button><button type="button" data-fb-voice>Commentary voice: ' + (PREF.voice ? 'on' : 'off') + '</button><button type="button" data-fb-quit>Quit to the football menu</button></div>';
			else if (v === 'cup') { var C0 = CUP, rn = ['Quarter-final', 'Semi-final', 'Final'][C0.round]; h = '<div class="fb__title fb__title--s"><small>Laqim Cup</small><h2>' + rn + '</h2></div>' + bracket() + '<button type="button" class="fb__go" data-fb-cupgo>Play the ' + rn.toLowerCase() + '</button><button type="button" class="fb__x" data-fb-quit>← Leave the cup</button>'; }
			else if (v === 'champ') h = '<div class="fb__title"><small>Laqim Cup winners</small><h2>Champions!</h2><p>' + esc(club(CUP.club).n) + ' have won the Laqim Cup. Put your name in the Hall of Champions: it appears here and on the trackside billboards in Laqim Racing.</p></div><form class="fb__champ" data-fb-champ><input name="n" maxlength="18" required placeholder="Your name (letters and spaces)" autocomplete="nickname"><button class="fb__go" type="submit">Add me to the Hall</button></form><p class="fb__note" data-fb-cmsg></p><button type="button" data-fb-quit>Skip</button>';
			menu.innerHTML = '<div class="fb__mi">' + h + '</div>'; bind(v); setTimeout(function () { var f = menu.querySelector('.fb__go, .fb__mode, button'); if (f) try { f.focus({ preventScroll: true }); } catch (e) {} }, 50); }
		function bracket() { var B = CUP.br, h = '<div class="fb__br">'; [0, 1, 2].forEach(function (r) { var L = CUP.rounds[r] || []; h += '<div class="fb__brc"><small>' + ['Quarter-finals', 'Semi-finals', 'Final'][r] + '</small>' + L.map(function (m) { var a = club(m[0]), b = club(m[1]); return '<div class="fb__tie' + (m[0] === CUP.club || m[1] === CUP.club ? ' is-me' : '') + '">' + crest(a) + '<span>' + a.s + '</span><b>' + (m[2] == null ? '–' : m[2] + '–' + m[3] + (m[4] ? ' p' : '')) + '</b><span>' + b.s + '</span>' + crest(b) + '</div>'; }).join('') + '</div>'; }); return h + '</div>'; }
		function bind(v) { var on = function (s, f) { [].forEach.call(menu.querySelectorAll(s), function (b) { b.addEventListener('click', function (e) { f(b, e); }); }); };
			on('[data-fb-mode]', function (b) { showMenu('setup', b.getAttribute('data-fb-mode')); });
			on('[data-fb-back]', function () { showMenu('home'); }); on('[data-fb-phone]', function () { if (api.pad) { api.pad.open(); padLayout(true); } }); on('[data-fb-exit]', function () { stop(); if (api.onExit) api.onExit(); });
			on('[data-fb-cyc]', function (b) { var k = b.getAttribute('data-fb-cyc'), i = CLUBS.indexOf(club(PREF[k])), n = (i + +b.getAttribute('data-d') + CLUBS.length) % CLUBS.length; if (CLUBS[n].id === PREF[k === 'club' ? 'opp' : 'club']) n = (n + +b.getAttribute('data-d') + CLUBS.length) % CLUBS.length; PREF[k] = CLUBS[n].id; savePref(); var m = menu.querySelector('[data-fb-start]').getAttribute('data-fb-start'); showMenu('setup', m); var f = menu.querySelector('[data-fb-cyc="' + k + '"][data-d="' + b.getAttribute('data-d') + '"]'); if (f) f.focus(); });
			on('[data-fb-diff]', function (b) { PREF.diff = +b.getAttribute('data-fb-diff'); savePref(); [].forEach.call(menu.querySelectorAll('[data-fb-diff]'), function (x) { x.classList.toggle('is-on', x === b); }); });
			on('[data-fb-lang]', function (b) { PREF.lang = LANG = b.getAttribute('data-fb-lang'); savePref(); [].forEach.call(menu.querySelectorAll('[data-fb-lang]'), function (x) { x.classList.toggle('is-on', x === b); }); });
			on('[data-fb-tod]', function (b) { PREF.tod = b.getAttribute('data-fb-tod'); savePref(); [].forEach.call(menu.querySelectorAll('[data-fb-tod]'), function (x) { x.classList.toggle('is-on', x === b); }); });
			on('[data-fb-half]', function (b) { PREF.half = +b.getAttribute('data-fb-half'); savePref(); [].forEach.call(menu.querySelectorAll('[data-fb-half]'), function (x) { x.classList.toggle('is-on', x === b); }); });
			on('[data-fb-start]', function (b) { var m = b.getAttribute('data-fb-start'); if (m === 'cup') return newCup(); start({ mode: m === 'pens' ? 'quick' : m, home: PREF.club, away: PREF.opp, side: 0, diff: PREF.diff, half: PREF.half, pens: m === 'pens', tod: PREF.tod }); if (m === 'pens') { M.phase = 'full'; M.shootout(); } });
			on('[data-fb-resume]', function () { togglePause(); }); on('[data-fb-restart]', function () { paused = false; start(cfg); if (cfg.pens) M.shootout(); }); on('[data-fb-sound]', function (b) { b.textContent = 'Sound: ' + (AU.toggle() ? 'on' : 'off'); }); on('[data-fb-voice]', function (b) { PREF.voice = PREF.voice ? 0 : 1; savePref(); b.textContent = 'Commentary voice: ' + (PREF.voice ? 'on' : 'off'); });
			on('[data-fb-quit]', function () { paused = false; stop(); M = null; CUP = null; showMenu('home'); }); on('[data-fb-again]', function () { start(cfg); if (cfg.pens) M.shootout(); }); on('[data-fb-menu]', function () { stop(); M = null; showMenu('home'); });
			on('[data-fb-reel]', function () { if (M && M.reels && M.reels.length) playReel(M.reels.slice()); });
			on('[data-fb-cupgo]', function () { var tie = CUP.rounds[CUP.round].filter(function (m) { return m[0] === CUP.club || m[1] === CUP.club; })[0], home = tie[0] === CUP.club; start({ mode: 'quick', home: tie[0], away: tie[1], side: home ? 0 : 1, diff: CUP.diff, half: CUP.half, tod: CUP.round === 2 ? 'night' : 'day', cupRound: 'Laqim Cup · ' + ['Quarter-final', 'Semi-final', 'Final'][CUP.round] }); });
			on('[data-fb-cupnext]', function () { showMenu(CUP && CUP.won ? 'champ' : CUP && CUP.out ? 'home' : 'cup'); if (CUP && CUP.out) CUP = null; });
			var f0 = menu.querySelector('[data-fb-champ]'); if (f0) f0.addEventListener('submit', function (e) { e.preventDefault(); var n = String(f0.n.value || '').replace(/[^A-Za-zÀ-ɏ' .-]/g, '').replace(/\s+/g, ' ').trim().slice(0, 18), msg = menu.querySelector('[data-fb-cmsg]'); if (n.length < 2) { msg.textContent = 'Use at least two letters.'; return; } msg.textContent = 'Saving…';
				var body = { n: n, club: club(CUP.club).n, score: CUP.final || '' }; (api.submit ? api.submit(body) : Promise.reject()).then(function (r) { champs = (r && r.champs) || [{ n: n, club: body.club }].concat(champs); msg.textContent = 'You are in the Hall of Champions. Look for your name on the billboards in Laqim Racing.'; CUP = null; setTimeout(function () { showMenu('home'); }, 2600); }).catch(function () { champs = [{ n: n, club: body.club }].concat(champs); msg.textContent = 'Saved on this device. (We could not reach the server.)'; CUP = null; setTimeout(function () { showMenu('home'); }, 2600); }); }); }
		/* ---- the Laqim Cup ---- */
		function newCup() { var ids = CLUBS.map(function (c) { return c.id; }).filter(function (x) { return x !== PREF.club; }); ids = shuffle(ids, Date.now() % 997); ids.splice(Math.floor(Math.random() * 4) * 2, 0, PREF.club); ids = ids.slice(0, 8); CUP = { club: PREF.club, diff: PREF.diff, half: PREF.half, round: 0, rounds: [[[ids[0], ids[1]], [ids[2], ids[3]], [ids[4], ids[5]], [ids[6], ids[7]]]] }; showMenu('cup'); }
		function simTie(m) { var a = club(m[0]), b = club(m[1]), ra = ovr(a), rb = ovr(b), ga = 0, gb = 0; for (var i = 0; i < 9; i++) { if (Math.random() < .14 * (ra / (ra + rb)) * 2) ga++; if (Math.random() < .14 * (rb / (ra + rb)) * 2) gb++; } m[2] = ga; m[3] = gb; if (ga === gb) { m[4] = 1; if (Math.random() < ra / (ra + rb)) m[2]++; else m[3]++; } }
		function cupResult(gh, ga, pens) { var L = CUP.rounds[CUP.round], tie = L.filter(function (m) { return m[0] === CUP.club || m[1] === CUP.club; })[0]; tie[2] = gh; tie[3] = ga; if (pens) tie[4] = 1; L.forEach(function (m) { if (m !== tie) simTie(m); });
			var won = (tie[0] === CUP.club ? gh > ga : ga > gh); if (!won) { CUP.out = true; return false; } if (CUP.round === 2) { CUP.won = true; CUP.final = gh + '–' + ga; return true; }
			var W = L.map(function (m) { return m[2] > m[3] ? m[0] : m[1]; }), nx = []; for (var i = 0; i < W.length; i += 2) nx.push([W[i], W[i + 1]]); CUP.round++; CUP.rounds[CUP.round] = nx; return true; }
		/* ---- full time ---- */
		function fullTime() { if (!M || M.phase !== 'full') return; var t0 = M.teams[0], t1 = M.teams[1], so = M.so, draw = t0.score === t1.score;
			if (CUP && draw && !so) { banner('Penalties', 'Level after ninety minutes', 2200); setTimeout(function () { if (M) M.shootout(); }, 1800); return; }
			var sa = so ? so.k[0].reduce(function (x, y) { return x + y; }, 0) : 0, sb = so ? so.k[1].reduce(function (x, y) { return x + y; }, 0) : 0, gh = t0.score + (so ? (sa > sb ? 1 : 0) : 0), ga = t1.score + (so ? (sb > sa ? 1 : 0) : 0);
			var P = M.stats, tot = P[0].poss + P[1].poss || 1, rows = [['Possession', Math.round(P[0].poss / tot * 100) + '%', Math.round(P[1].poss / tot * 100) + '%'], ['Shots', P[0].sh, P[1].sh], ['On target', P[0].on, P[1].on], ['Passes', P[0].pas, P[1].pas], ['Pass accuracy', P[0].pas ? Math.round(P[0].pc / P[0].pas * 100) + '%' : '–', P[1].pas ? Math.round(P[1].pc / P[1].pas * 100) + '%' : '–'], ['Corners', P[0].corners, P[1].corners], ['Fouls', P[0].fouls, P[1].fouls]];
			var cupLine = ''; if (CUP && cfg.cupRound) { var won = cupResult(gh, ga, !!so); cupLine = CUP.won ? '<p class="fb__win">You have won the Laqim Cup!</p>' : CUP.out ? '<p class="fb__lose">Knocked out of the Laqim Cup.</p>' : '<p class="fb__win">Through to the ' + ['', 'semi-final', 'final'][CUP.round] + '!</p>'; }
			var h = '<div class="fb__title fb__title--s"><small>Full-time' + (cfg.cupRound ? ' · ' + esc(cfg.cupRound) : '') + '</small><h2>' + crest(t0.club) + ' ' + t0.score + ' – ' + t1.score + ' ' + crest(t1.club) + '</h2>' + (so ? '<p>' + esc(soLine()) + ' · ' + esc((sa > sb ? t0 : t1).club.n) + ' win on penalties</p>' : '') + '</div>' + cupLine
				+ '<div class="fb__scr">' + [0, 1].map(function (k) { return '<div>' + M.scorers.filter(function (s0) { return s0.k === k; }).map(function (s0) { return esc(s0.n) + ' ' + s0.m + '\''; }).join('<br>') + '</div>'; }).join('') + '</div>' + (function () { var L = M.all.slice().sort(function (x, y) { return y.r - x.r; }), mo = L[0], rt = function (p0) { return clamp(p0.r, 3.5, 10).toFixed(1); }; return '<div class="fb__motm"><small>Player of the match</small><b>' + esc(mo.name) + '</b><span>' + esc(mo.team.club.n) + ' · ' + rt(mo) + '</span></div><div class="fb__rt">' + [0, 1].map(function (k) { return '<ol>' + M.teams[k].pl.slice().sort(function (x, y) { return y.r - x.r; }).slice(0, 5).map(function (p0) { return '<li><i>' + p0.num + '</i>' + esc(p0.sh) + '<b class="' + (p0.r >= 7.5 ? 'is-hi' : p0.r < 6 ? 'is-lo' : '') + '">' + rt(p0) + '</b></li>'; }).join('') + '</ol>'; }).join('') + '</div>'; })() + '<table class="fb__st"><thead><tr><th>' + esc(t0.club.s) + '</th><th></th><th>' + esc(t1.club.s) + '</th></tr></thead><tbody>' + rows.map(function (r) { return '<tr><td>' + r[1] + '</td><th>' + r[0] + '</th><td>' + r[2] + '</td></tr>'; }).join('') + '</tbody></table>'
				+ (M.reels && M.reels.length ? '<button type="button" data-fb-reel>▶ Watch the goals (' + M.reels.length + ')</button>' : '') + (CUP && cfg.cupRound ? '<button type="button" class="fb__go" data-fb-cupnext>' + (CUP.won ? 'Lift the cup' : CUP.out ? 'Back to the menu' : 'On to the next round') + '</button>' : '<button type="button" class="fb__go" data-fb-again>Rematch</button><button type="button" data-fb-menu>Football menu</button>');
			menu.hidden = false; menu.innerHTML = '<div class="fb__mi">' + h + '</div>'; bind('full'); hud.hidden = true; if (api.onResult) api.onResult({ home: t0.club.n, away: t1.club.n, gh: t0.score, ga: t1.score }); setTimeout(function () { var f = menu.querySelector('.fb__go'); if (f) f.focus(); }, 60); }
		/* menu navigation with a controller */
		var mp = {}; (function poll() { requestAnimationFrame(poll); if (menu.hidden || !root.isConnected || root.offsetParent === null) return; var g = null, ph1 = api.pad && api.pad.read(0);
			if (ph1) { var pbits = ph1.b | 0; g = { axes: [ph1.s, ph1.t], buttons: [{ pressed: !!(pbits & 1) }, { pressed: !!(pbits & 2) }] }; padT -= .016; if (padT <= 0) { padT = 2; padLayout(true); } } if (!g) try { var gs = navigator.getGamepads ? navigator.getGamepads() : []; for (var i = 0; i < gs.length; i++) if (gs[i]) { g = gs[i]; break; } } catch (e) {} if (!g) return; var B = function (k) { return !!(g.buttons[k] && g.buttons[k].pressed); }, ax = g.axes[0] || 0, ay = g.axes[1] || 0, dir = B(12) || ay < -.6 ? -1 : B(13) || ay > .6 ? 1 : B(14) || ax < -.6 ? -1 : B(15) || ax > .6 ? 1 : 0;
			var L = [].slice.call(menu.querySelectorAll('button, input')), i0 = L.indexOf(d.activeElement), now = performance.now(); if (dir && (dir !== mp.d || now - (mp.t || 0) > 260)) { mp.t = now; var nx = L[(Math.max(0, i0) + dir + L.length) % L.length]; if (nx) nx.focus(); } mp.d = dir; var A = B(0); if (A && !mp.A && d.activeElement && menu.contains(d.activeElement)) d.activeElement.click(); mp.A = A; var Bb = B(1); if (Bb && !mp.B) { var bk = menu.querySelector('[data-fb-back],[data-fb-resume],[data-fb-exit]'); if (bk) bk.click(); } mp.B = Bb; })();
		showMenu('home'); size();
		return { el: root, open: function () { size(); if (!M) showMenu('home'); }, close: function () { if (M && !paused && M.phase !== 'full') togglePause(); AU.stop(); padLayout(false); }, destroy: function () { stop(); d.removeEventListener('keydown', kd); d.removeEventListener('keyup', ku); }, get match() { return M; }, start: start, CLUBS: CLUBS };
	}
	w.PSRFootball = { mount: function (sec, api) { T = w.THREE; return mount(sec, api); }, Match: function (o) { T = w.THREE; return Match(o); }, CLUBS: CLUBS };
})();
