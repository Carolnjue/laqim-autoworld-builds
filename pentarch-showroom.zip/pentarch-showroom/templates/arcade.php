<?php
/**
 * Laqim Play: a full-screen game hub. No site header, footer or page sections: three experiences, launched full screen.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$psr_logo = get_option( 'psr_logo', home_url( '/wp-content/uploads/2024/09/laqimlogo-300x100.png' ) );
?><!doctype html>
<html <?php language_attributes(); ?> class="psr-arcade">
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#07070a">
<?php wp_head(); ?>
</head>
<body <?php body_class( 'psr-arcade-body' ); ?>>
<div class="ax" data-psr-arcade>
	<div class="ax__bg" aria-hidden="true"><i></i><i></i><i></i></div>
	<header class="ax__top">
		<a class="ax__logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="Laqim Autoworld home"><img src="<?php echo esc_url( $psr_logo ); ?>" alt="Laqim Autoworld"></a>
		<div class="ax__topr">
			<button type="button" class="ax__chip" data-ax-passbtn>🛂 <span class="ax__cl">Passport</span> <b data-ax-passn></b></button>
			<button type="button" class="ax__chip" data-ax-fs>⤢ <span class="ax__cl">Full screen</span></button>
			<a class="ax__chip" href="<?php echo esc_url( home_url( '/' ) ); ?>">Website</a>
		</div>
	</header>
	<main class="ax__hub" data-ax-hub>
		<div class="ax__hello"><b>Choose your experience</b><span>Use a mouse, keyboard, touch, a game controller or your phone.</span></div>
		<div class="ax__tick" data-ax-tick hidden></div>
		<button type="button" class="ax__lab" data-ax-lab><span class="ax__lab-k">New physics engine</span><b>Proving Ground</b><span>Real tyre, suspension and drivetrain physics. Drive any car on tarmac, murram, mud, sand, a river and rocks, then hit the ramps.</span><em>Drive ▶</em></button>
		<div class="ax__tiles">
			<button type="button" class="ax__tile ax__tile--showroom" data-ax-go="showroom"><span class="ax__img" data-ax-img="showroom"></span><span class="ax__shade"></span><span class="ax__in"><small>Explore</small><b>3D Showroom</b><em>Walk the hall, open the doors, spin every car in 3D.</em><span class="ax__play">▶ Enter</span></span></button>
			<button type="button" class="ax__tile ax__tile--racing" data-ax-go="racing"><span class="ax__img" data-ax-img="racing"></span><span class="ax__shade"></span><span class="ax__in"><small>Race</small><b>Laqim Racing</b><em>Five game modes, six tracks, any car in the collection.</em><span class="ax__play">▶ Play</span></span></button>
			<button type="button" class="ax__tile ax__tile--rally" data-ax-go="rally"><span class="ax__img" data-ax-img="rally"></span><span class="ax__shade"></span><span class="ax__in"><small>Story</small><b>Laqim Rally</b><em>A story career across Kenya, ten rally modes and multiplayer.</em><span class="ax__play">▶ Play</span></span></button>
			<button type="button" class="ax__tile ax__tile--football" data-ax-go="football"><span class="ax__img ax__img--pitch"></span><span class="ax__shade"></span><span class="ax__in"><small>New</small><b>Laqim Football</b><em>Eleven-a-side. A league with press conferences, Be a Pro, free kicks and the Laqim Cup. Win and your name goes on the racing billboards.</em><span class="ax__play">▶ Play</span></span></button>
		</div>
	</main>
	<section class="ax__pass" data-ax-pass role="dialog" aria-label="Your Laqim passport" hidden></section>
	<section class="ax__game ax__game--racing" data-ax-game="racing" hidden><?php echo do_shortcode( '[psr_hotlap]' ); ?></section>
	<section class="ax__game ax__game--rally" data-ax-game="rally" hidden><?php echo do_shortcode( '[psr_rally]' ); ?></section>
	<section class="ax__game ax__game--football" data-ax-game="football" hidden></section>
	<section class="ax__game ax__game--lab" data-ax-game="lab" hidden></section>
	<section class="ax__game ax__game--showroom" data-ax-game="showroom" hidden><template data-ax-tpl><?php echo do_shortcode( '[psr_showroom]' ); ?></template></section>
</div>
<?php wp_footer(); ?>
</body>
</html>
