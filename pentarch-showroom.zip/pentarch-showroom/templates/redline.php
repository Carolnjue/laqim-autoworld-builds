<?php
/**
 * REDLINE pages. Same site header and footer as every page; the content is ours.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$rv   = PSR_Redline::$view;
$cars = PSR_Redline::cars();
$trk  = PSR_Redline::tracks();
$R    = 'PSR_Redline';

/* small helpers for this template */
$crumb = function ( $items ) {
	$ld  = array( '@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => array() );
	$out = '<nav class="r8-crumb" aria-label="Breadcrumb"><a href="' . esc_url( home_url( '/' ) ) . '">Laqim</a>';
	$i   = 1;
	$ld['itemListElement'][] = array( '@type' => 'ListItem', 'position' => $i++, 'name' => 'Laqim', 'item' => home_url( '/' ) );
	foreach ( $items as $it ) {
		$out .= '<i>/</i>' . ( $it[1] ? '<a href="' . esc_url( $it[1] ) . '">' . esc_html( $it[0] ) . '</a>' : '<span>' . esc_html( $it[0] ) . '</span>' );
		$ld['itemListElement'][] = array_filter( array( '@type' => 'ListItem', 'position' => $i++, 'name' => $it[0], 'item' => $it[1] ? $it[1] : null ) );
	}
	return $out . '</nav><script type="application/ld+json">' . wp_json_encode( $ld ) . '</script>';
};
$bar = function ( $label, $val, $max, $txt, $win = false ) {
	return '<li class="' . ( $win ? 'is-win' : '' ) . '"><span>' . esc_html( $label ) . '</span><i><s style="width:' . (int) max( 4, min( 100, $max ? $val / $max * 100 : 0 ) ) . '%"></s></i><b>' . esc_html( $txt ) . '</b></li>';
};
$tach = '<svg class="r8-tach" viewBox="0 0 200 120" aria-hidden="true"><path d="M20 110 A80 80 0 0 1 180 110" class="r8-tach__arc"/><path d="M148 52 A80 80 0 0 1 180 110" class="r8-tach__red"/><g class="r8-tach__ticks">' . implode( '', array_map( function ( $k ) { $a = M_PI * ( 1 - $k / 8 ); $x1 = 100 + cos( $a ) * 70; $y1 = 110 - sin( $a ) * 70; $x2 = 100 + cos( $a ) * 80; $y2 = 110 - sin( $a ) * 80; return '<line x1="' . round( $x1, 1 ) . '" y1="' . round( $y1, 1 ) . '" x2="' . round( $x2, 1 ) . '" y2="' . round( $y2, 1 ) . '"/>'; }, range( 0, 8 ) ) ) . '</g><line x1="100" y1="110" x2="100" y2="38" class="r8-tach__needle"/><circle cx="100" cy="110" r="7" class="r8-tach__hub"/></svg>';
$tools = array(
	array( 'import-duty-calculator', 'Import duty', 'What KRA will charge on a car from Japan, the UAE or the UK, and the full landed cost.', '<path d="M3 7h18v10H3zM7 7V5h10v2M8 12h8" />' ),
	array( 'car-loan-calculator', 'Car loan', 'Monthly repayments, total interest and the true price of financing.', '<path d="M4 6h16v12H4zM4 10h16M8 15h3" />' ),
	array( 'fuel-cost-calculator', 'Fuel cost', 'What any car costs to run per month and per year at today\'s pump price.', '<path d="M5 20V5h9v15M5 10h9M14 8l4 3v7a1.5 1.5 0 0 1-3 0v-4h-1" />' ),
);
$tool_cards = function ( $skip = '' ) use ( $tools, $R ) {
	$h = '<div class="r8-tools">';
	foreach ( $tools as $t ) {
		if ( $t[0] === $skip ) {
			continue;
		}
		$h .= '<a class="r8-tool" href="' . esc_url( $R::url( $t[0] ) ) . '"><svg viewBox="0 0 24 24" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round">' . $t[3] . '</g></svg><b>' . esc_html( $t[1] ) . '</b><span>' . esc_html( $t[2] ) . '</span><i>Open →</i></a>';
	}
	return $h . '</div>';
};
$car_opts = function ( $sel = 0 ) use ( $cars, $R ) {
	$h = '';
	uasort( $cars, function ( $a, $b ) { return strcmp( $a['name'], $b['name'] ); } );
	foreach ( $cars as $id => $c ) {
		$h .= '<option value="' . (int) $id . '" data-slug="' . esc_attr( $c['v']->slug ) . '" data-l100="' . esc_attr( $R::l100( $c ) ) . '" data-fuel="' . esc_attr( strtolower( (string) $c['v']->fuel ) ) . '" data-cc="' . esc_attr( (int) round( $c['l'] * 1000 ) ) . '"' . selected( $sel, $id, false ) . '>' . esc_html( $c['name'] ) . '</option>';
	}
	return $h;
};
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<main id="main" class="psr-main r8" data-psr-redline>
<?php
switch ( $rv['k'] ) {

	/* ================================================================ HUB */
	case 'hub':
		$fast = array();
		foreach ( $cars as $id => $c ) {
			if ( ! empty( $c['lab']['circuit']['lap'] ) ) {
				$fast[ $id ] = $c['lab']['circuit']['lap'];
			}
		}
		asort( $fast );
		$top = array_slice( array_keys( $fast ), 0, 5, true );
		$dirt = array();
		foreach ( $cars as $id => $c ) {
			if ( ! empty( $c['lab']['trail']['lap'] ) ) {
				$dirt[ $id ] = $c['lab']['trail']['lap'];
			}
		}
		asort( $dirt );
		$dtop = array_slice( array_keys( $dirt ), 0, 5, true );
		?>
		<section class="r8-hero r8-hero--hub">
			<div class="r8-hero__grid"></div>
			<div class="r8-wrap r8-hero__in">
				<div class="r8-hero__copy">
					<p class="r8-kick"><span class="r8-dot"></span>Laqim Autoworld presents</p>
					<h1 class="r8-word">REDLINE</h1>
					<p class="r8-lead">Tested, costed, compared. Lap times from our physics lab, what a car really costs in Kenya, and straight answers on which one is quicker.</p>
					<div class="r8-acts"><a class="r8-btn r8-btn--red" href="<?php echo esc_url( $R::url( 'lab' ) ); ?>">Lab Tests</a><a class="r8-btn" href="<?php echo esc_url( $R::url( 'import-duty-calculator' ) ); ?>">Import duty calculator</a></div>
				</div>
				<div class="r8-hero__tach"><?php echo $tach; // phpcs:ignore ?><p><b data-r8-count="<?php echo count( $cars ); ?>"><?php echo count( $cars ); ?></b> cars tested on <b>3</b> tracks</p></div>
			</div>
		</section>
		<div class="r8-wrap">
			<section class="r8-sec"><div class="r8-h"><small>Own it</small><h2>The money side</h2></div><?php echo $tool_cards(); // phpcs:ignore ?></section>
			<section class="r8-sec r8-boards">
				<div class="r8-board"><div class="r8-h"><small>Laqim Circuit · tarmac</small><h2>Fastest laps</h2></div><ol>
					<?php foreach ( $top as $id ) : $c = $cars[ $id ]; ?>
						<li><a href="<?php echo esc_url( $R::url( 'lab/' . $c['v']->slug ) ); ?>"><?php if ( $c['th'] ) : ?><img src="<?php echo esc_url( $c['th'] ); ?>" alt="" loading="lazy"><?php endif; ?><b><?php echo esc_html( $c['name'] ); ?></b><span><?php echo esc_html( $R::lap( $c['lab']['circuit']['lap'] ) ); ?></span></a></li>
					<?php endforeach; ?>
				</ol></div>
				<div class="r8-board r8-board--dirt"><div class="r8-h"><small>Rift Valley Trail · dirt</small><h2>Kings of the mud</h2></div><ol>
					<?php foreach ( $dtop as $id ) : $c = $cars[ $id ]; ?>
						<li><a href="<?php echo esc_url( $R::url( 'lab/' . $c['v']->slug ) ); ?>"><?php if ( $c['th'] ) : ?><img src="<?php echo esc_url( $c['th'] ); ?>" alt="" loading="lazy"><?php endif; ?><b><?php echo esc_html( $c['name'] ); ?></b><span><?php echo esc_html( $R::lap( $c['lab']['trail']['lap'] ) ); ?></span></a></li>
					<?php endforeach; ?>
				</ol></div>
			</section>
			<section class="r8-sec r8-vspick" data-r8-vs>
				<div class="r8-h"><small>Head-to-head</small><h2>Settle the argument</h2><p>Pick any two cars. Same physics, same tracks, no excuses.</p></div>
				<div class="r8-vspick__row"><select data-r8-a aria-label="First car"><?php echo $car_opts( (int) ( $top ? reset( $top ) : 0 ) ); // phpcs:ignore ?></select><span class="r8-vsb">VS</span><select data-r8-b aria-label="Second car"><?php echo $car_opts( (int) ( $dtop ? reset( $dtop ) : 0 ) ); // phpcs:ignore ?></select><button type="button" class="r8-btn r8-btn--red" data-r8-go>Compare</button></div>
			</section>
			<?php echo $R::ad( 'wide' ); // phpcs:ignore ?>
			<?php
			$posts = get_posts( array( 'numberposts' => 3, 'post_status' => 'publish' ) );
			if ( $posts ) :
				?>
				<section class="r8-sec"><div class="r8-h"><small>Dispatch</small><h2>Latest from the paddock</h2></div><div class="r8-posts">
				<?php foreach ( $posts as $p ) : ?>
					<a class="r8-post" href="<?php echo esc_url( get_permalink( $p ) ); ?>"><?php echo get_the_post_thumbnail( $p, 'medium_large' ); // phpcs:ignore ?><small><?php echo esc_html( get_the_date( '', $p ) ); ?></small><b><?php echo esc_html( get_the_title( $p ) ); ?></b></a>
				<?php endforeach; ?>
				</div></section>
			<?php endif; ?>
			<section class="r8-sec r8-play"><div><small>Don't just read it</small><h2>Drive every car you see here.</h2><p>Every lap time on REDLINE comes from the same physics as Laqim Racing. Take any car out and try to beat the lab.</p></div><div class="r8-acts"><a class="r8-btn r8-btn--red" href="<?php echo esc_url( home_url( '/play/#racing' ) ); ?>">Play Laqim Racing</a><a class="r8-btn" href="<?php echo esc_url( home_url( '/play/#rally' ) ); ?>">Rally story</a><a class="r8-btn" href="<?php echo esc_url( home_url( '/play/#football' ) ); ?>">Laqim Football</a></div></section>
			<?php $psr_ch = PSR_Redline::champs(); if ( $psr_ch ) : ?>
			<section class="r8-sec r8-champ"><small>Laqim Cup · Hall of Champions</small><ol><?php foreach ( array_slice( $psr_ch, 0, 5 ) as $psr_c ) : ?><li><b><?php echo esc_html( $psr_c['n'] ); ?></b><span><?php echo esc_html( trim( ( $psr_c['club'] ?? '' ) . ' · ' . ( $psr_c['d'] ?? '' ), ' ·' ) ); ?></span></li><?php endforeach; ?></ol><p>Champions race as named rivals in Laqim Racing.</p></section>
			<?php endif; ?>
		</div>
		<?php
		break;

	/* ======================================================= IMPORT DUTY */
	case 'import-duty-calculator':
		echo '<section class="r8-hero r8-hero--tool"><div class="r8-wrap">' . $crumb( array( array( 'REDLINE', $R::url() ), array( 'Import duty calculator', '' ) ) ) . '<h1>Kenya car import duty calculator</h1><p class="r8-lead">KRA taxes and the full landed cost of bringing a car into Kenya, worked out step by step. Updated for 2026.</p></div></section>'; // phpcs:ignore
		?>
		<div class="r8-wrap r8-toolwrap">
			<div class="r8-calc" data-r8-calc="duty">
				<div class="r8-calc__in">
					<label class="r8-f"><span>Value basis</span><select data-k="basis"><option value="cif">CIF value (price + shipping + insurance)</option><option value="crsp">KRA CRSP value</option></select></label>
					<label class="r8-f"><span>Value in KES</span><input type="number" inputmode="numeric" data-k="val" value="2500000" min="0" step="10000"></label>
					<label class="r8-f"><span>Year of first registration</span><select data-k="year"><?php for ( $y = (int) gmdate( 'Y' ); $y >= (int) gmdate( 'Y' ) - 10; $y-- ) { echo '<option' . ( (int) gmdate( 'Y' ) - 4 === $y ? ' selected' : '' ) . '>' . (int) $y . '</option>'; } ?></select></label>
					<label class="r8-f"><span>Engine size (cc)</span><input type="number" inputmode="numeric" data-k="cc" value="1800" min="0" step="100"></label>
					<label class="r8-f"><span>Fuel</span><select data-k="fuel"><option value="petrol">Petrol</option><option value="diesel">Diesel</option><option value="hybrid">Hybrid</option><option value="ev">Fully electric</option></select></label>
					<label class="r8-f r8-f--x" data-hy><span>Hybrid excise rate</span><select data-k="hyb"><option value="0.25">25% (as petrol/diesel)</option><option value="0.10">10%</option></select></label>
					<label class="r8-f"><span>Shipped from</span><select data-k="from"><option value="jp">Japan</option><option value="ae">UAE</option><option value="uk">United Kingdom</option><option value="th">Thailand</option></select></label>
				</div>
				<div class="r8-calc__out" data-out><p class="r8-big"><small>KRA taxes</small><b data-o="tax">—</b></p><ul data-o="rows"></ul><p class="r8-big r8-big--2"><small>Estimated landed cost in Nairobi</small><b data-o="land">—</b></p><p class="r8-warn" data-o="warn" hidden></p></div>
			</div>
			<?php echo $R::ad( 'in' ); // phpcs:ignore ?>
			<article class="r8-prose">
				<h2>How Kenya taxes an imported car</h2>
				<p>KRA starts from a <b>customs value</b>: the higher of what you paid to land the car (CIF) and its value on KRA's Current Retail Selling Price (CRSP) list, reduced for age. Every other tax is built on it.</p>
				<ol>
					<li><b>Import duty:</b> 35% of the customs value for passenger cars (25% for fully electric).</li>
					<li><b>Excise duty:</b> on customs value plus import duty. 20% up to 1,500cc; 25% for petrol 1,501–3,000cc and diesel 1,501–2,500cc; 35% above that; 10% for fully electric. Sources differ on hybrids, so the calculator lets you choose.</li>
					<li><b>VAT:</b> 16% of customs value plus import duty plus excise.</li>
					<li><b>Import Declaration Fee:</b> 2.5% of customs value. <b>Railway Development Levy:</b> 2% of customs value.</li>
				</ol>
				<p>Cars must be under eight years old from first registration. Older cars are turned away at Mombasa. On top of KRA's taxes come port handling, transport to Nairobi, clearing, inspection and NTSA registration; the calculator adds typical figures for each.</p>
				<p class="r8-note">An estimate to plan with, not a KRA assessment. Your clearing agent's figure on the day is final.</p>
				<h2>Questions people ask</h2>
				<details><summary>Why is the customs value not just what I paid?</summary><p>KRA uses the higher of your CIF value and the age-reduced CRSP value, so a very cheap auction price does not mean very low duty.</p></details>
				<details><summary>How old can an imported car be?</summary><p>Under eight years from the year of first registration. In 2026 that means 2019 or newer for most of the year.</p></details>
				<details><summary>Do hybrids pay less?</summary><p>Fully electric cars pay less import duty and excise. For hybrids, published guides disagree on the excise rate, so check with your clearing agent.</p></details>
			</article>
			<script type="application/ld+json"><?php echo wp_json_encode( array( '@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => array( array( '@type' => 'Question', 'name' => 'How is import duty on a car calculated in Kenya?', 'acceptedAnswer' => array( '@type' => 'Answer', 'text' => 'Import duty is 35% of the customs value; excise duty of 20%, 25% or 35% applies on customs value plus import duty depending on engine size; VAT of 16% applies on the total; plus a 2.5% Import Declaration Fee and 2% Railway Development Levy on the customs value.' ) ), array( '@type' => 'Question', 'name' => 'How old can an imported car be in Kenya?', 'acceptedAnswer' => array( '@type' => 'Answer', 'text' => 'Under eight years from the year of first registration.' ) ) ) ) ); ?></script>
			<?php echo $R::lead( 'import', 'Get clearing and shipping quotes', 'Tell us the car and where it is. We will pass your request to vetted importers and clearing agents.' ); // phpcs:ignore ?>
			<section class="r8-sec"><div class="r8-h"><small>More tools</small><h2>Keep counting</h2></div><?php echo $tool_cards( 'import-duty-calculator' ); // phpcs:ignore ?></section>
		</div>
		<?php
		break;

	/* =========================================================== LOAN */
	case 'car-loan-calculator':
		echo '<section class="r8-hero r8-hero--tool r8-hero--loan"><div class="r8-wrap">' . $crumb( array( array( 'REDLINE', $R::url() ), array( 'Car loan calculator', '' ) ) ) . '<h1>Car loan calculator</h1><p class="r8-lead">Monthly repayments, total interest and what the car really costs once financed.</p></div></section>'; // phpcs:ignore
		?>
		<div class="r8-wrap r8-toolwrap">
			<div class="r8-calc" data-r8-calc="loan">
				<div class="r8-calc__in">
					<label class="r8-f"><span>Car price (KES)</span><input type="number" inputmode="numeric" data-k="price" value="3500000" step="50000" min="0"></label>
					<label class="r8-f"><span>Deposit (%)</span><input type="range" data-k="dep" min="0" max="80" value="20" step="5"><em data-v="dep">20%</em></label>
					<label class="r8-f"><span>Interest rate (% a year)</span><input type="number" data-k="rate" value="15" step="0.25" min="0"></label>
					<label class="r8-f"><span>Term (months)</span><input type="range" data-k="term" min="12" max="72" value="48" step="6"><em data-v="term">48 months</em></label>
					<label class="r8-f"><span>Interest method</span><select data-k="method"><option value="reducing">Reducing balance</option><option value="flat">Flat rate</option></select></label>
				</div>
				<div class="r8-calc__out"><p class="r8-big"><small>Monthly repayment</small><b data-o="pm">—</b></p><ul data-o="rows"></ul><div class="r8-split" data-o="split"><i></i><i></i></div></div>
			</div>
			<?php echo $R::ad( 'in' ); // phpcs:ignore ?>
			<article class="r8-prose">
				<h2>Reducing balance or flat rate?</h2>
				<p>On a <b>reducing balance</b> loan you pay interest only on what you still owe, so each month more of the payment clears the loan. A <b>flat rate</b> charges interest on the full amount for the whole term: the same headline rate costs far more. Always ask which one a lender quotes.</p>
				<p>Banks and asset-finance firms also add insurance, tracking and processing fees. Put them in the price to see the true monthly figure.</p>
				<p class="r8-note">Rates here are examples you set yourself, not offers.</p>
			</article>
			<?php echo $R::lead( 'finance', 'Compare finance offers', 'Get asset-finance quotes from partner lenders for the car you want.' ); // phpcs:ignore ?>
			<section class="r8-sec"><div class="r8-h"><small>More tools</small><h2>Keep counting</h2></div><?php echo $tool_cards( 'car-loan-calculator' ); // phpcs:ignore ?></section>
		</div>
		<?php
		break;

	/* =========================================================== FUEL */
	case 'fuel-cost-calculator':
		echo '<section class="r8-hero r8-hero--tool r8-hero--fuel"><div class="r8-wrap">' . $crumb( array( array( 'REDLINE', $R::url() ), array( 'Fuel cost calculator', '' ) ) ) . '<h1>Fuel cost calculator</h1><p class="r8-lead">What a car costs to run at today\'s pump price. Pick one from the collection or enter your own figures.</p></div></section>'; // phpcs:ignore
		?>
		<div class="r8-wrap r8-toolwrap">
			<div class="r8-calc" data-r8-calc="fuel" data-petrol="<?php echo esc_attr( $R::PUMP_PETROL ); ?>" data-diesel="<?php echo esc_attr( $R::PUMP_DIESEL ); ?>">
				<div class="r8-calc__in">
					<label class="r8-f r8-f--wide"><span>Car</span><select data-k="car"><option value="">My own car</option><?php echo $car_opts(); // phpcs:ignore ?></select></label>
					<label class="r8-f"><span>Litres per 100 km</span><input type="number" data-k="l100" value="9" step="0.1" min="1"></label>
					<label class="r8-f"><span>Fuel</span><select data-k="fuel"><option value="petrol">Super petrol</option><option value="diesel">Diesel</option></select></label>
					<label class="r8-f"><span>Pump price (KES/litre)</span><input type="number" data-k="price" value="<?php echo esc_attr( $R::PUMP_PETROL ); ?>" step="0.01"></label>
					<label class="r8-f"><span>Kilometres a month</span><input type="range" data-k="km" min="200" max="6000" value="1500" step="100"><em data-v="km">1,500 km</em></label>
				</div>
				<div class="r8-calc__out"><p class="r8-big"><small>Per month</small><b data-o="pm">—</b></p><ul data-o="rows"></ul></div>
			</div>
			<p class="r8-note">Pump prices: <?php echo esc_html( $R::PUMP_DATE ); ?> (EPRA). Consumption for cars in the collection is a Laqim estimate from weight, engine size and power; real figures depend on traffic and driving.</p>
			<?php echo $R::ad( 'in' ); // phpcs:ignore ?>
			<section class="r8-sec"><div class="r8-h"><small>More tools</small><h2>Keep counting</h2></div><?php echo $tool_cards( 'fuel-cost-calculator' ); // phpcs:ignore ?></section>
		</div>
		<?php
		break;

	/* ======================================================= LAB INDEX */
	case 'lab':
		echo '<section class="r8-hero r8-hero--lab"><div class="r8-wrap">' . $crumb( array( array( 'REDLINE', $R::url() ), array( 'Lab Tests', '' ) ) ) . '<p class="r8-kick"><span class="r8-dot"></span>Same physics · same tracks · no excuses</p><h1>Lab Tests</h1><p class="r8-lead">Every car in the collection, driven flat out by the same robot driver through the same physics: tyre grip, weight transfer, power, gearing and drag. Sort by any column.</p></div></section>'; // phpcs:ignore
		?>
		<div class="r8-wrap">
			<div class="r8-tablebar"><input type="search" placeholder="Find a car" data-r8-find aria-label="Find a car"><span><?php echo count( $cars ); ?> cars</span></div>
			<div class="r8-tablewrap"><table class="r8-table" data-r8-table>
				<thead><tr><th data-s="t">Car</th><th data-s="n" data-d="1">Laqim Circuit</th><th data-s="n" data-d="1">Rift Valley</th><th data-s="n" data-d="1">Nairobi Night</th><th data-s="n" data-d="1">0–100</th><th data-s="n">hp/tonne</th><th data-s="n">Top speed</th></tr></thead>
				<tbody>
				<?php foreach ( $cars as $id => $c ) : $lb = $c['lab']; ?>
					<tr><td data-v="<?php echo esc_attr( $c['name'] ); ?>"><a href="<?php echo esc_url( $R::url( 'lab/' . $c['v']->slug ) ); ?>"><?php if ( $c['th'] ) : ?><img src="<?php echo esc_url( $c['th'] ); ?>" alt="" loading="lazy"><?php endif; ?><span><?php echo esc_html( $c['name'] ); ?></span></a></td>
					<?php foreach ( array( 'circuit', 'trail', 'night' ) as $k ) : $x = $lb[ $k ]['lap'] ?? 0; ?><td data-v="<?php echo esc_attr( $x ? $x : 9999 ); ?>"><?php echo esc_html( $R::lap( $x ) ); ?><?php $rk = $R::rank( $id, $k ); if ( $rk && $rk <= 3 ) { echo ' <em class="r8-p' . (int) $rk . '">P' . (int) $rk . '</em>'; } ?></td><?php endforeach; ?>
					<td data-v="<?php echo esc_attr( $c['acc'] ? $c['acc'] : 99 ); ?>"><?php echo $c['acc'] ? esc_html( number_format( $c['acc'], 1 ) . ' s' ) : '—'; ?></td>
					<?php $ptw = $c['kg'] ? round( $c['hp'] / ( $c['kg'] / 1000 ) ) : 0; ?><td data-v="<?php echo (int) $ptw; ?>"><?php echo $ptw ? (int) $ptw : '—'; ?></td>
					<td data-v="<?php echo esc_attr( $c['vmax'] ); ?>"><?php echo $c['vmax'] ? esc_html( $c['vmax'] . ' km/h' ) : '—'; ?></td></tr>
				<?php endforeach; ?>
				</tbody>
			</table></div>
			<p class="r8-note">Lap times come from the Laqim Racing physics with each car in standard form, driven by the same robot driver. 0–100 and top speed are the makers' figures. A simulation, not a stopwatch: the same rules for every car make the comparison fair.</p>
			<?php echo $R::ad( 'wide' ); // phpcs:ignore ?>
		</div>
		<?php
		break;

	/* ======================================================== LAB CAR */
	case 'car':
		$v  = $rv['v'];
		$id = (int) $v->id;
		$c  = $cars[ $id ];
		$lb = $c['lab'];
		$n  = count( $cars );
		$l100 = $R::l100( $c );
		$isd  = false !== strpos( strtolower( (string) $v->fuel ), 'diesel' );
		$pump = $isd ? $R::PUMP_DIESEL : $R::PUMP_PETROL;
		$mo   = $l100 ? 1500 / 100 * $l100 * $pump : 0;
		$pw   = $c['kg'] ? round( $c['hp'] / ( $c['kg'] / 1000 ) ) : 0;
		/* verdict lines built only from the numbers */
		$lines = array();
		$rc = $R::rank( $id, 'circuit' );
		$rt = $R::rank( $id, 'trail' );
		$rn = $R::rank( $id, 'night' );
		if ( $rc ) {
			$lines[] = $rc <= 10 ? 'One of the ten fastest cars in the collection round the Laqim Circuit (' . $rc . ' of ' . $n . ').' : ( $rc > $n * .75 ? 'Not built for lap times: ' . $rc . ' of ' . $n . ' on the Laqim Circuit.' : 'Mid-pack on tarmac: ' . $rc . ' of ' . $n . ' round the Laqim Circuit.' );
		}
		if ( $rt && $rc ) {
			$lines[] = $rt + 15 < $rc ? 'Comes alive on dirt: ' . $rt . ' of ' . $n . ' on the Rift Valley Trail, well above its tarmac ranking.' : ( $rt > $rc + 15 ? 'Prefers smooth roads: it drops to ' . $rt . ' of ' . $n . ' on the Rift Valley Trail.' : 'Consistent on any surface: ' . $rt . ' of ' . $n . ' on the Rift Valley Trail.' );
		}
		if ( $pw ) {
			$lines[] = $pw . ' hp per tonne' . ( $pw > 400 ? ', hypercar territory.' : ( $pw > 250 ? ', serious performance-car pace.' : ( $pw < 120 ? ', so it is about comfort, not speed.' : '.' ) ) );
		}
		if ( $l100 ) {
			$lines[] = 'About ' . number_format( $l100, 1 ) . ' litres per 100 km by our estimate: roughly KES ' . number_format( $mo, 0 ) . ' a month in fuel for 1,500 km in Nairobi.';
		}
		$riv = $R::rivals( $id, 3 );
		echo '<section class="r8-hero r8-hero--car"' . ( $c['img'] ? ' style="--r8img:url(' . esc_url( $c['img'] ) . ')"' : '' ) . '><div class="r8-wrap">' . $crumb( array( array( 'REDLINE', $R::url() ), array( 'Lab Tests', $R::url( 'lab' ) ), array( $c['name'], '' ) ) ) . '<p class="r8-kick"><span class="r8-dot"></span>Lab Test</p><h1>' . esc_html( $c['name'] ) . '</h1><p class="r8-lead">' . esc_html( trim( ( $v->year ? $v->year . ' · ' : '' ) . $v->engine . ( $c['hp'] ? ' · ' . $c['hp'] . ' hp' : '' ) ) ) . '</p><div class="r8-acts"><a class="r8-btn r8-btn--red" href="' . esc_url( home_url( '/play/?car=' . $id . '#racing' ) ) . '">Race it in Laqim Racing</a><a class="r8-btn" href="' . esc_url( PSR_Front::url( $v ) ) . '">Photos and full specs</a></div></div></section>'; // phpcs:ignore
		?>
		<div class="r8-wrap">
			<section class="r8-laps">
				<?php foreach ( $trk as $k => $t ) : $x = $lb[ $k ]['lap'] ?? 0; $rk = $R::rank( $id, $k ); ?>
					<div class="r8-lapc r8-lapc--<?php echo esc_attr( $k ); ?>"><small><?php echo esc_html( $t[1] ); ?></small><b><?php echo esc_html( $t[0] ); ?></b><strong><?php echo esc_html( $R::lap( $x ) ); ?></strong><span><?php echo $rk ? 'P' . (int) $rk . ' of ' . (int) $n : 'No time'; ?></span><i><s style="width:<?php echo $rk ? (int) round( ( 1 - ( $rk - 1 ) / max( 1, $n - 1 ) ) * 100 ) : 0; ?>%"></s></i></div>
				<?php endforeach; ?>
			</section>
			<section class="r8-sec r8-verdict"><div class="r8-h"><small>The numbers say</small><h2>Lab verdict</h2></div><ul><?php foreach ( $lines as $ln ) { echo '<li>' . esc_html( $ln ) . '</li>'; } ?></ul></section>
			<section class="r8-sec r8-specgrid">
				<div><small>0–100 km/h (maker)</small><b><?php echo $c['acc'] ? esc_html( number_format( $c['acc'], 1 ) . ' s' ) : '—'; ?></b></div>
				<div><small>Fastest point, Laqim Circuit (lab)</small><b><?php echo ! empty( $lb['circuit']['top'] ) ? esc_html( $lb['circuit']['top'] . ' km/h' ) : '—'; ?></b></div>
				<div><small>Fastest point, Rift Valley Trail (lab)</small><b><?php echo ! empty( $lb['trail']['top'] ) ? esc_html( $lb['trail']['top'] . ' km/h' ) : '—'; ?></b></div>
				<div><small>Power</small><b><?php echo $c['hp'] ? esc_html( $c['hp'] . ' hp' ) : '—'; ?></b></div>
				<div><small>Top speed (maker)</small><b><?php echo $c['vmax'] ? esc_html( $c['vmax'] . ' km/h' ) : '—'; ?></b></div>
				<div><small>Power to weight</small><b><?php echo $pw ? esc_html( $pw . ' hp/t' ) : '—'; ?></b></div>
				<div><small>Fuel (estimate)</small><b><?php echo $l100 ? esc_html( number_format( $l100, 1 ) . ' L/100 km' ) : 'Electric'; ?></b></div>
				<div><small>Fuel a month, 1,500 km</small><b><?php echo $mo ? esc_html( 'KES ' . number_format( $mo, 0 ) ) : '—'; ?></b></div>
			</section>
			<?php echo $R::ad( 'in' ); // phpcs:ignore ?>
			<?php if ( $riv ) : ?>
			<section class="r8-sec"><div class="r8-h"><small>Closest rivals in the lab</small><h2>Head-to-heads</h2></div><div class="r8-rivals">
				<?php foreach ( $riv as $r ) : $o = $cars[ $r ]; ?>
					<a class="r8-rival" href="<?php echo esc_url( $R::vs_url( $v, $o['v'] ) ); ?>"><?php if ( $o['th'] ) : ?><img src="<?php echo esc_url( $o['th'] ); ?>" alt="" loading="lazy"><?php endif; ?><span><?php echo esc_html( $c['name'] ); ?> <em>vs</em> <?php echo esc_html( $o['name'] ); ?></span></a>
				<?php endforeach; ?>
			</div></section>
			<?php endif; ?>
			<?php echo $R::lead( 'buy', 'Thinking of owning one?', 'Get import, finance and insurance quotes for this model from our partners.', $id ); // phpcs:ignore ?>
			<script type="application/ld+json"><?php echo wp_json_encode( array_filter( array( '@context' => 'https://schema.org', '@type' => 'Car', 'name' => $c['name'], 'brand' => array( '@type' => 'Brand', 'name' => $v->make ), 'model' => $v->model, 'vehicleModelDate' => $v->year ? (string) $v->year : null, 'image' => $c['img'] ? $c['img'] : null, 'url' => $R::url( 'lab/' . $v->slug ), 'vehicleEngine' => $v->engine ? array( '@type' => 'EngineSpecification', 'name' => $v->engine ) : null, 'accelerationTime' => $c['acc'] ? array( '@type' => 'QuantitativeValue', 'value' => $c['acc'], 'unitCode' => 'SEC', 'description' => '0-100 km/h' ) : null, 'speed' => $c['vmax'] ? array( '@type' => 'QuantitativeValue', 'maxValue' => $c['vmax'], 'unitCode' => 'KMH' ) : null ) ) ); ?></script>
		</div>
		<?php
		break;

	/* ============================================================= VS */
	case 'vs':
		$a  = $cars[ (int) $rv['a']->id ];
		$b  = $cars[ (int) $rv['b']->id ];
		$wa = 0;
		$wb = 0;
		$rows = array();
		foreach ( $trk as $k => $t ) {
			$xa = $a['lab'][ $k ]['lap'] ?? 0;
			$xb = $b['lab'][ $k ]['lap'] ?? 0;
			if ( $xa && $xb ) {
				if ( $xa < $xb ) {
					$wa++;
				} elseif ( $xb < $xa ) {
					$wb++;
				}
			}
			$rows[] = array( $t[0], $xa, $xb, 'lap' );
		}
		$rows[] = array( '0–100 km/h (maker)', $a['acc'], $b['acc'], 's' );
		$rows[] = array( 'Fastest point, Laqim Circuit (lab)', $a['lab']['circuit']['top'] ?? 0, $b['lab']['circuit']['top'] ?? 0, 'kmh' );
		$rows[] = array( 'Power', $a['hp'], $b['hp'], 'hp' );
		$rows[] = array( 'Weight', $a['kg'], $b['kg'], 'kg' );
		$rows[] = array( 'Top speed (maker)', $a['vmax'], $b['vmax'], 'kmh' );
		$fa = $R::l100( $a );
		$fb = $R::l100( $b );
		$rows[] = array( 'Fuel (estimate, L/100 km)', $fa, $fb, 'fuel' );
		$win = $wa === $wb ? '' : ( $wa > $wb ? $a['name'] : $b['name'] );
		$canon = $R::vs_url( $rv['a'], $rv['b'] );
		echo '<section class="r8-hero r8-hero--vs"><div class="r8-vsimg"' . ( $a['img'] ? ' style="--r8a:url(' . esc_url( $a['img'] ) . ')"' : '' ) . '></div><div class="r8-vsimg r8-vsimg--b"' . ( $b['img'] ? ' style="--r8b:url(' . esc_url( $b['img'] ) . ')"' : '' ) . '></div><div class="r8-wrap r8-vshero">' . $crumb( array( array( 'REDLINE', $R::url() ), array( 'Head-to-head', '' ) ) ) . '<h1><span>' . esc_html( $a['name'] ) . '</span><em>vs</em><span>' . esc_html( $b['name'] ) . '</span></h1><p class="r8-lead">' . ( $win ? esc_html( $win ) . ' wins ' . max( $wa, $wb ) . ' of 3 tracks in the lab.' : 'Dead level across the three tracks.' ) . '</p></div></section>'; // phpcs:ignore
		?>
		<div class="r8-wrap">
			<section class="r8-vst"><?php foreach ( $rows as $r ) :
				list( $lbl, $x, $y, $u ) = $r;
				$lower = in_array( $u, array( 'lap', 's', 'kg', 'fuel' ), true );
				$wx = $x && $y && ( $lower ? $x < $y : $x > $y );
				$wy = $x && $y && ( $lower ? $y < $x : $y > $x );
				$fmt = function ( $z ) use ( $u, $R ) {
					if ( ! $z ) {
						return '—';
					}
					switch ( $u ) {
						case 'lap':
							return $R::lap( $z );
						case 's':
							return number_format( $z, 1 ) . ' s';
						case 'hp':
							return $z . ' hp';
						case 'kg':
							return number_format( $z ) . ' kg';
						case 'kmh':
							return $z . ' km/h';
						default:
							return number_format( $z, 1 );
					}
				};
				?>
				<div class="r8-vsr"><b class="<?php echo $wx ? 'is-win' : ''; ?>"><?php echo esc_html( $fmt( $x ) ); ?></b><span><?php echo esc_html( $lbl ); ?></span><b class="<?php echo $wy ? 'is-win' : ''; ?>"><?php echo esc_html( $fmt( $y ) ); ?></b></div>
			<?php endforeach; ?></section>
			<div class="r8-acts r8-acts--c"><a class="r8-btn r8-btn--red" href="<?php echo esc_url( home_url( '/play/?car=' . (int) $rv['a']->id . '#racing' ) ); ?>">Race them yourself</a><a class="r8-btn" href="<?php echo esc_url( $R::url( 'lab/' . $a['v']->slug ) ); ?>"><?php echo esc_html( $a['name'] ); ?> lab test</a><a class="r8-btn" href="<?php echo esc_url( $R::url( 'lab/' . $b['v']->slug ) ); ?>"><?php echo esc_html( $b['name'] ); ?> lab test</a></div>
			<?php echo $R::ad( 'wide' ); // phpcs:ignore ?>
			<section class="r8-sec r8-vspick" data-r8-vs><div class="r8-h"><small>Another one</small><h2>Pick a new fight</h2></div><div class="r8-vspick__row"><select data-r8-a aria-label="First car"><?php echo $car_opts( (int) $rv['a']->id ); // phpcs:ignore ?></select><span class="r8-vsb">VS</span><select data-r8-b aria-label="Second car"><?php echo $car_opts( (int) $rv['b']->id ); // phpcs:ignore ?></select><button type="button" class="r8-btn r8-btn--red" data-r8-go>Compare</button></div></section>
		</div>
		<?php
		break;

	/* ====================================================== ADVERTISE */
	case 'advertise':
		echo '<section class="r8-hero r8-hero--ad"><div class="r8-wrap">' . $crumb( array( array( 'REDLINE', $R::url() ), array( 'Advertise', '' ) ) ) . '<p class="r8-kick"><span class="r8-dot"></span>Partners</p><h1>Put your brand on the grid.</h1><p class="r8-lead">REDLINE readers are working out what to import, finance, insure and fit next. Players spend minutes at a time in Laqim Racing, Laqim Rally and Laqim Football, staring at track-side and pitch-side boards. All of them can carry your name.</p></div></section>'; // phpcs:ignore
		?>
		<div class="r8-wrap">
			<section class="r8-packs">
				<div class="r8-pack"><small>01</small><b>Track-side billboards</b><p>Your logo and line on the boards around the Laqim Circuit, the Rift Valley Trail and the Nairobi Night Run, seen in every race.</p></div>
				<div class="r8-pack"><small>02</small><b>Sponsored car of the week</b><p>Your car, or one you sell, featured in Laqim Racing with its own weekly leaderboard and your prize for the fastest lap.</p></div>
				<div class="r8-pack"><small>03</small><b>Tool partner</b><p>Your quote button on the import duty, loan or fuel calculator, in front of people actively planning a purchase.</p></div>
				<div class="r8-pack"><small>04</small><b>Lab Test presenter</b><p>"Presented by" placement across the Lab Tests and head-to-heads for a marque or a category.</p></div>
				<div class="r8-pack"><small>05</small><b>Stadium boards in Laqim Football</b><p>Pitch-side LED boards all the way round the stadium, in every match, every replay and every Laqim Cup final.</p></div>
				<div class="r8-pack"><small>06</small><b>Rally stage and story partner</b><p>Your brand on the rally stage gantries, or as the title sponsor of a chapter in the Laqim Rally story, with your name in the cutscenes.</p></div>
				<div class="r8-pack"><small>07</small><b>Laqim Cup title sponsor</b><p>"The Laqim Cup presented by you": on the bracket, the trophy screen and the Hall of Champions that winners share.</p></div>
				<div class="r8-pack"><small>08</small><b>Daily stage sponsor</b><p>Rally's Stage of the Day changes at midnight and players come back for it. Own the daily stage and its share codes.</p></div>
			</section>
			<section class="r8-quote" id="talk"><div class="r8-quote__t"><small>Talk to us</small><h2>Book a slot</h2><p>Tell us about your brand and what you would like to reach. We reply by email.</p></div>
				<?php echo str_replace( 'name="kind" value="general"', 'name="kind" value="advertise"', PSR_Front::form( 0, 'general', 'Send' ) ); // phpcs:ignore ?>
			</section>
		</div>
		<?php
		break;
}
echo '<div class="r8-wrap">' . $R::dispatch_box() . '</div>'; // phpcs:ignore
?>
</main>
<?php wp_footer(); ?>
</body>
</html>
