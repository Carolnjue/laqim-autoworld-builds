<?php
/**
 * Vehicle page.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$v      = PSR_Front::$vehicle;
$media  = PSR_DB::media( $v->id );
$cover  = PSR_DB::cover( $v );
$title  = PSR_DB::title( $v );
$km     = PSR_Front::km( $v );
$price  = PSR_Front::price( $v );
$wa     = PSR_Front::whatsapp( 'Hello Laqim, a question about the ' . $title . ( $v->year ? ' (' . $v->year . ')' : '' ) . ': ' . PSR_Front::url( $v ) );
$phone  = psr_settings( 'phone' );
$xx     = PSR_Front::extra( $v->id );
$est    = $xx['est'] ?? array();
$specs  = array_filter(
	array(
		'Model year'   => $v->year ? $v->year : '',
		'Generation'   => $xx['gen'] ?? '',
		'Engine'       => $v->engine,
		'Power'        => $v->power,
		'Torque'       => ! empty( $xx['torque'] ) ? number_format( $xx['torque'] ) . ' Nm' : '',
		'0–100 km/h'   => ! empty( $xx['accel'] ) ? ( in_array( 'accel', $est, true ) ? '≈ ' : '' ) . number_format( $xx['accel'], 1 ) . ' s' . ( in_array( 'accel', $est, true ) ? ' (estimate)' : '' ) : '',
		'Top speed'    => ! empty( $xx['vmax'] ) ? $xx['vmax'] . ' km/h' : '',
		'Transmission' => $xx['gearbox'] ?? $v->transmission,
		'Drive'        => $v->drivetrain,
		'Fuel'         => $v->fuel,
		'Consumption'  => $v->consumption,
		'Kerb weight'  => ! empty( $xx['weight'] ) ? number_format( $xx['weight'] ) . ' kg' : '',
		'Length'       => ! empty( $xx['length'] ) ? number_format( $xx['length'] ) . ' mm' : '',
		'Wheelbase'    => ! empty( $xx['wheelbase'] ) ? number_format( $xx['wheelbase'] ) . ' mm' : '',
		'Seats'        => $v->seats,
		'Body'         => $v->body,
		'Built in'     => $xx['built'] ?? '',
	)
);
$facts  = array_slice(
	array_filter(
		array(
			'Power'  => $v->power,
			'0–100'  => ! empty( $xx['accel'] ) ? ( in_array( 'accel', $est, true ) ? '≈' : '' ) . number_format( $xx['accel'], 1 ) . ' s' : '',
			'Top speed' => ! empty( $xx['vmax'] ) ? $xx['vmax'] . ' km/h' : '',
		)
	),
	0,
	3,
	true
);
$hl     = array_filter( explode( "\n", (string) $v->highlights ) );
$feat   = array_filter( explode( "\n", (string) $v->features ) );
$cred   = array_filter( explode( "\n", (string) $v->credits ) );
$intro  = array(
	'gallery'    => 'Part of the Laqim showcase: remarkable cars gathered for people who love them. Photographs are credited where they come from public sources.',
	'commission' => 'Part of the Laqim showcase: remarkable cars gathered for people who love them. Photographs are credited where they come from public sources.',
	'reserved'   => 'A new addition to the showcase. More photographs and details are on the way.',
	'placed'     => 'From the Laqim archive.',
);
$more   = array();
$pool   = PSR_DB::query( array( 'exclude' => $v->id, 'limit' => 60 ) );
if ( $pool ) {
	$me_st = PSR_Front::stats( $v );
	$me_hp = (float) ( $me_st['hp'] ?? 0 );
	$scored = array();
	foreach ( $pool as $o ) {
		if ( $o->model === $v->model ) {
			continue; // Skip twins of the same model.
		}
		$o_st = PSR_Front::stats( $o );
		$o_hp = (float) ( $o_st['hp'] ?? 0 );
		$sc   = 0;
		$sc  += ( strtolower( (string) $o->body ) === strtolower( (string) $v->body ) ) ? 2 : 0;
		$sc  += ( $me_hp && $o_hp ) ? max( 0, 3 - abs( $me_hp - $o_hp ) / 90 ) : 0;
		$sc  += ( $o->make === $v->make ) ? 1.5 : 0;
		$sc  += mt_rand( 0, 100 ) / 400;
		$scored[] = array( $sc, $o );
	}
	usort( $scored, function ( $a, $b ) { return $b[0] <=> $a[0]; } );
	$seen = array();
	foreach ( $scored as $p ) {
		if ( isset( $seen[ $p[1]->model ] ) ) {
			continue;
		}
		$seen[ $p[1]->model ] = 1;
		$more[] = $p[1];
		if ( count( $more ) >= 3 ) {
			break;
		}
	}
}
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<main id="main" class="psr-main psr-v" data-psr-vehicle>

	<section class="v-hero">
		<div class="v-hero__img"><?php echo wp_get_attachment_image( $cover, 'full', false, array( 'loading' => 'eager', 'fetchpriority' => 'high', 'sizes' => '100vw', 'alt' => esc_attr( $title ) ) ); ?></div>
		<div class="v-hero__in">
			<nav class="v-crumbs" aria-label="Breadcrumb"><a href="<?php echo esc_url( PSR_Front::collection_url() ); ?>">The Collection</a><span>/</span><a href="<?php echo esc_url( PSR_Front::collection_url( 'make=' . rawurlencode( $v->make ) ) ); ?>"><?php echo esc_html( $v->make ); ?></a></nav>
			<p class="v-hero__status"><span class="psr-chip psr-chip--<?php echo esc_attr( $v->status ); ?>"><?php echo esc_html( PSR_Front::status_label( $v->status ) ); ?></span></p>
			<h1 class="v-hero__title"><small><?php echo esc_html( $v->make ); ?></small><span><?php echo esc_html( $v->model ); ?></span></h1>
			<?php if ( $v->variant ) : ?><p class="v-hero__variant"><?php echo esc_html( $v->variant ); ?></p><?php endif; ?>
			<?php if ( $facts ) : ?>
				<dl class="v-hero__facts">
					<?php foreach ( $facts as $k => $val ) : ?><div><dt><?php echo esc_html( $k ); ?></dt><dd><?php echo esc_html( $val ); ?></dd></div><?php endforeach; ?>
				</dl>
			<?php endif; ?>
		</div>
		<a class="v-hero__down" href="#overview" aria-label="Scroll to details"><i></i></a>
	</section>

	<div class="v-bar" data-psr-bar>
		<div class="v-bar__in">
			<p class="v-bar__t"><b><?php echo esc_html( $v->make ); ?></b> <?php echo esc_html( $v->model ); ?><?php if ( $v->year ) : ?> <span><?php echo (int) $v->year; ?></span><?php endif; ?></p>
			<p class="v-bar__p"><?php echo esc_html( PSR_Front::status_label( $v->status ) ); ?></p>
			<div class="v-bar__a">
				<?php if ( $wa ) : ?><a class="psr-btn psr-btn--ghost" href="<?php echo esc_url( $wa ); ?>" target="_blank" rel="noopener"><?php echo PSR_Front::icon( 'wa' ); // phpcs:ignore ?><span>WhatsApp</span></a><?php endif; ?>
				<a class="psr-btn psr-btn--solid" href="#ask"><span><?php esc_html_e( 'Ask about it', 'pentarch-showroom' ); ?></span><?php echo PSR_Front::icon( 'arrow' ); // phpcs:ignore ?></a>
			</div>
		</div>
	</div>

	<?php if ( $media ) : ?>
	<section class="v-gallery" aria-label="Photographs">
		<div class="v-mosaic v-mosaic--<?php echo (int) min( 5, count( $media ) ); ?>">
			<?php foreach ( array_slice( $media, 0, 5 ) as $i => $m ) : ?>
				<button type="button" class="v-tile psr-reveal" data-lb="<?php echo (int) $i; ?>" aria-label="<?php echo esc_attr( sprintf( 'Open photo %d of %d', $i + 1, count( $media ) ) ); ?>">
					<?php echo wp_get_attachment_image( $m->attachment_id, 0 === $i ? 'full' : 'large', false, array( 'loading' => 0 === $i ? 'eager' : 'lazy', 'sizes' => 0 === $i ? '(max-width:800px) 100vw, 60vw' : '(max-width:800px) 50vw, 25vw', 'alt' => sprintf( '%s, photo %d of %d', $title, $i + 1, count( $media ) ) ) ); ?>
					<?php if ( 4 === $i && count( $media ) > 5 ) : ?><span class="v-more">+<?php echo (int) count( $media ) - 5; ?></span><?php endif; ?>
				</button>
			<?php endforeach; ?>
		</div>
		<div class="v-gallery__foot">
			<button type="button" class="psr-btn psr-btn--line" data-lb="0"><?php echo PSR_Front::icon( 'expand' ); // phpcs:ignore ?><span><?php echo esc_html( sprintf( 'View all %d photographs', count( $media ) ) ); ?></span></button>
			<?php if ( $cred ) : ?><p class="v-credits">Photographs: <?php echo esc_html( implode( '; ', $cred ) ); ?>, via Wikimedia Commons. Illustrative of the model.</p><?php endif; ?>
		</div>
		<script type="application/json" data-lb-items><?php
		$items = array();
		foreach ( $media as $m ) {
			$src     = wp_get_attachment_image_src( $m->attachment_id, '2048x2048' );
			$items[] = array( 'src' => $src ? $src[0] : '', 't' => wp_get_attachment_image_url( $m->attachment_id, 'medium' ), 'w' => $src ? $src[1] : 0, 'h' => $src ? $src[2] : 0, 'c' => $m->credit );
		}
		echo wp_json_encode( $items );
		?></script>
	</section>
	<?php endif; ?>

	<section class="v-overview" id="overview">
		<div class="v-wrap v-overview__grid">
			<div class="v-story psr-reveal">
				<p class="lx-eyebrow"><?php esc_html_e( 'Curator’s note', 'pentarch-showroom' ); ?></p>
				<?php if ( $v->tagline ) : ?><h2 class="v-lede"><?php echo esc_html( $v->tagline ); ?></h2><?php endif; ?>
				<div class="v-prose"><?php echo $v->summary ? wp_kses_post( wpautop( $v->summary ) ) : '<p>' . esc_html( $intro[ $v->status ] ?? '' ) . '</p>'; ?></div>
				<?php if ( $hl ) : ?>
					<ul class="v-highlights">
						<?php foreach ( $hl as $h ) : ?><li><?php echo esc_html( $h ); ?></li><?php endforeach; ?>
					</ul>
				<?php endif; ?>
			</div>
			<aside class="v-spec psr-reveal">
				<p class="lx-eyebrow"><?php esc_html_e( 'Specification', 'pentarch-showroom' ); ?></p>
				<dl>
					<?php foreach ( $specs as $k => $val ) : ?><div><dt><?php echo esc_html( $k ); ?></dt><dd><?php echo esc_html( $val ); ?></dd></div><?php endforeach; ?>
				</dl>
				<?php if ( $feat ) : ?>
					<p class="lx-eyebrow v-spec__eq"><?php esc_html_e( 'Equipment', 'pentarch-showroom' ); ?></p>
					<ul class="v-chips"><?php foreach ( $feat as $f ) : ?><li><?php echo esc_html( $f ); ?></li><?php endforeach; ?></ul>
				<?php endif; ?>
			</aside>
		</div>
	</section>

	<?php echo PSR_Front::profile_block( $v ); // phpcs:ignore -- escaped inside ?>

	<?php echo PSR_Front::viewer_block( $v ); // phpcs:ignore -- escaped inside ?>

	<section class="v-viewing" id="ask">
		<div class="v-wrap v-viewing__grid">
			<div class="v-viewing__txt psr-reveal">
				<p class="lx-eyebrow"><?php esc_html_e( 'Talk cars with us', 'pentarch-showroom' ); ?></p>
				<h2 class="v-h2">Questions about <em>this car?</em></h2>
				<p><?php echo esc_html( $intro[ $v->status ] ?? $intro['gallery'] ); ?></p>
				<ul class="v-promise">
					<li><?php esc_html_e( 'Ask about the model, its history or its specification.', 'pentarch-showroom' ); ?></li>
					<li><?php esc_html_e( 'Suggest a car you would like to see in the showcase.', 'pentarch-showroom' ); ?></li>
					<li><?php esc_html_e( 'Own something remarkable? Send it in to be featured.', 'pentarch-showroom' ); ?></li>
				</ul>
				<p class="v-direct">
					<a href="<?php echo esc_url( home_url( '/feature-your-car/' ) ); ?>"><?php echo PSR_Front::icon( 'arrow' ); // phpcs:ignore ?><span>Feature your car</span></a>
					<?php if ( $wa ) : ?><a href="<?php echo esc_url( $wa ); ?>" target="_blank" rel="noopener"><?php echo PSR_Front::icon( 'wa' ); // phpcs:ignore ?><span>WhatsApp a curator</span></a><?php endif; ?>
				</p>
			</div>
			<div class="v-viewing__form psr-reveal">
				<?php echo PSR_Front::form( (int) $v->id, 'enquiry' ); // phpcs:ignore ?>
			</div>
		</div>
	</section>

	<?php if ( $more ) : ?>
	<section class="v-more-sec">
		<div class="v-wrap">
			<div class="v-more-head"><h2 class="v-h2">Its natural <em>rivals</em></h2><a class="psr-btn psr-btn--line" href="<?php echo esc_url( PSR_Front::collection_url() ); ?>"><span>All vehicles</span><?php echo PSR_Front::icon( 'arrow' ); // phpcs:ignore ?></a></div>
			<div class="psr-grid"><?php foreach ( $more as $o ) { echo PSR_Front::card( $o, 'psr-reveal' ); } // phpcs:ignore ?></div>
		</div>
	</section>
	<?php endif; ?>

</main>
<?php wp_footer(); ?>
</body>
</html>
