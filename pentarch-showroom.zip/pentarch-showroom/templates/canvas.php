<?php
/**
 * Canvas: a clean page with only the Live Edit head, header and footer around the content.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<main id="main" class="psr-main">
<?php
if ( is_404() ) {
	echo '<section class="psr-404"><p class="lx-eyebrow">404</p><h1 class="lx-h1">This page has moved on.</h1><p>The link may be old, or the car may have left the showcase. Search for it, or pick up from one of these.</p><p class="psr-404__acts"><a class="lx-btn lx-btn--gold" href="#search" data-lx-search>Search the site</a><a class="lx-btn lx-btn--solid" href="' . esc_url( PSR_Front::collection_url() ) . '">See the collection</a><a class="lx-btn lx-btn--solid" href="' . esc_url( home_url( '/showroom/' ) ) . '">3D Showroom</a><a class="lx-btn lx-btn--solid" href="' . esc_url( home_url( '/play/' ) ) . '">Play</a></p></section>';
} elseif ( have_posts() ) {
	while ( have_posts() ) {
		the_post();
		$c = get_the_content();
		if ( false === strpos( $c, '[ple' ) && ! is_front_page() ) {
			echo '<article class="psr-prose"><h1 class="lx-h1">' . esc_html( get_the_title() ) . '</h1>';
			the_content();
			echo '</article>';
		} else {
			the_content();
		}
	}
}
?>
</main>
<?php wp_footer(); ?>
</body>
</html>
