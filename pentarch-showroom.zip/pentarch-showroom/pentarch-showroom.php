<?php
/**
 * Plugin Name:       Pentarch Showroom
 * Description:       A curated vehicle collection for luxury showcase websites. Cars, galleries and messages live in their own database tables, with a collection page, car pages, a 3D hero, a Guess the Car game, a Spec Duel and shortcodes that work inside Pentarch Live Edit pages.
 * Version:           1.7.336
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Pentarch Communications
 * Author URI:        https://pentarchcommunications.com
 * License:           GPL-2.0-or-later
 * Text Domain:       pentarch-showroom
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'PSR_VERSION', '1.7.336' );
define( 'PSR_DB_VERSION', '1' );
define( 'PSR_FILE', __FILE__ );
define( 'PSR_DIR', plugin_dir_path( __FILE__ ) );
define( 'PSR_URL', plugin_dir_url( __FILE__ ) );

require_once PSR_DIR . 'includes/class-db.php';
require_once PSR_DIR . 'includes/class-front.php';
require_once PSR_DIR . 'includes/class-admin.php';
require_once PSR_DIR . 'includes/class-importer.php';
require_once PSR_DIR . 'includes/class-kit.php';
require_once PSR_DIR . 'includes/class-redline.php';

register_activation_hook( __FILE__, array( 'PSR_DB', 'install' ) );
register_activation_hook( __FILE__, array( 'PSR_Front', 'flush_on_activate' ) );
register_deactivation_hook( __FILE__, 'flush_rewrite_rules' );

add_action( 'plugins_loaded', array( 'PSR_DB', 'maybe_upgrade' ) );
PSR_Front::init();
PSR_Redline::init();

/* Allow 3D car models (.glb) in the Media Library. */
add_filter( 'upload_mimes', function ( $m ) {
	$m['glb'] = 'model/gltf-binary';
	return $m;
} );
add_filter( 'wp_check_filetype_and_ext', function ( $data, $file, $filename ) {
	if ( preg_match( '/\.glb$/i', (string) $filename ) ) {
		$data['ext']             = 'glb';
		$data['type']            = 'model/gltf-binary';
		$data['proper_filename'] = $filename;
	}
	return $data;
}, 10, 3 );
PSR_Admin::init();

/**
 * Plugin settings with defaults.
 *
 * @param string|null $key Optional single key.
 * @return mixed
 */
function psr_settings( $key = null ) {
	$defaults = array(
		'brand'        => get_bloginfo( 'name' ),
		'show_prices'  => 0,
		'currency'     => 'KES',
		'phone'        => '',
		'whatsapp'     => '',
		'email'        => get_option( 'admin_email' ),
		'address'      => '',
		'hours'        => '',
		'base'         => 'collection',
		'canvas'       => 1,
		'strip_theme'  => 1,
		'hero_slices'  => 7,
		'hero_seconds' => 6,
		'adsense_client' => '',
		'adsense_slot'   => '',
		'billboards'     => '',
	);
	$s = wp_parse_args( (array) get_option( 'psr_settings', array() ), $defaults );
	return null === $key ? $s : ( isset( $s[ $key ] ) ? $s[ $key ] : null );
}
